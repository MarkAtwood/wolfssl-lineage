ed25519.o: ../../../wolfsslPort/wolfcrypt/src/ed25519.c \
 ../../../wolfsslPort/wolfssl/wolfcrypt/settings.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/visibility.h \
 ../../../wolfsslPort/IDE/ECLIPSE/DEOS/user_settings.h \
 /desk/include/stddef.h /desk/include/deos.h /desk/include/systyp.h \
 /desk/include/stdint.h /desk/include/deprecated-types.h \
 /desk/include/deosapi.h /desk/include/deoskern.h /desk/include/thrdapi.h \
 /desk/include/threaduk.h /desk/include/deosuk.h /desk/include/executuk.h \
 /desk/include/sysapiuk.h /desk/include/procuk.h /desk/include/debug.h \
 /desk/include/excptuk.h /desk/include/procapi.h /desk/include/scheduk.h \
 /desk/include/schedapi.h /desk/include/mutexapi.h \
 /desk/include/mutexuk.h /desk/include/eventapi.h /desk/include/timeout.h \
 /desk/include/eventuk.h /desk/include/semaapi.h /desk/include/semauk.h \
 /desk/include/excptapi.h /desk/include/status.h /desk/include/debugapi.h \
 /desk/include/memapi.h /desk/include/memapiuk.h \
 /desk/x86/include/pageattr.h /desk/include/parapi.h \
 /desk/include/paruk.h /desk/include/sysapi.h /desk/include/ipcapi.h \
 /desk/include/ipcuk.h /desk/include/resapi.h /desk/include/res_uk.h \
 /desk/x86/include/resapiar.h /desk/include/statapi.h \
 /desk/include/intapi.h /desk/include/intuk.h /desk/include/abomapi.h \
 /desk/include/abomuk.h /desk/include/platapi.h /desk/include/hash.h \
 /desk/include/libapi.h /desk/include/libuk.h /desk/include/socketapi.h \
 /desk/include/saldefs.h /desk/include/transport.h \
 /desk/include/transportdefs.h /desk/include/socket-common.h \
 /desk/include/pack.h /desk/include/unpack.h /desk/include/lwip-socket.h \
 /desk/include/mem.h /desk/include/ansidefs.h /desk/include/string.h \
 /desk/include/stdlib.h /desk/include/stdio.h /desk/include/stdarg.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/ed25519.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/types.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/wc_port.h /desk/include/ctype.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/fe_operations.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/ge_operations.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/random.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/sha256.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/sha512.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/error-crypt.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/hash.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/md5.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/sha.h \
 ../../../wolfsslPort/wolfssl/wolfcrypt/md4.h \
 ../../../wolfsslPort/wolfcrypt/src/misc.c \
 ../../../wolfsslPort/wolfssl/wolfcrypt/misc.h

../../../wolfsslPort/wolfssl/wolfcrypt/settings.h:

../../../wolfsslPort/wolfssl/wolfcrypt/visibility.h:

../../../wolfsslPort/IDE/ECLIPSE/DEOS/user_settings.h:

/desk/include/stddef.h:

/desk/include/deos.h:

/desk/include/systyp.h:

/desk/include/stdint.h:

/desk/include/deprecated-types.h:

/desk/include/deosapi.h:

/desk/include/deoskern.h:

/desk/include/thrdapi.h:

/desk/include/threaduk.h:

/desk/include/deosuk.h:

/desk/include/executuk.h:

/desk/include/sysapiuk.h:

/desk/include/procuk.h:

/desk/include/debug.h:

/desk/include/excptuk.h:

/desk/include/procapi.h:

/desk/include/scheduk.h:

/desk/include/schedapi.h:

/desk/include/mutexapi.h:

/desk/include/mutexuk.h:

/desk/include/eventapi.h:

/desk/include/timeout.h:

/desk/include/eventuk.h:

/desk/include/semaapi.h:

/desk/include/semauk.h:

/desk/include/excptapi.h:

/desk/include/status.h:

/desk/include/debugapi.h:

/desk/include/memapi.h:

/desk/include/memapiuk.h:

/desk/x86/include/pageattr.h:

/desk/include/parapi.h:

/desk/include/paruk.h:

/desk/include/sysapi.h:

/desk/include/ipcapi.h:

/desk/include/ipcuk.h:

/desk/include/resapi.h:

/desk/include/res_uk.h:

/desk/x86/include/resapiar.h:

/desk/include/statapi.h:

/desk/include/intapi.h:

/desk/include/intuk.h:

/desk/include/abomapi.h:

/desk/include/abomuk.h:

/desk/include/platapi.h:

/desk/include/hash.h:

/desk/include/libapi.h:

/desk/include/libuk.h:

/desk/include/socketapi.h:

/desk/include/saldefs.h:

/desk/include/transport.h:

/desk/include/transportdefs.h:

/desk/include/socket-common.h:

/desk/include/pack.h:

/desk/include/unpack.h:

/desk/include/lwip-socket.h:

/desk/include/mem.h:

/desk/include/ansidefs.h:

/desk/include/string.h:

/desk/include/stdlib.h:

/desk/include/stdio.h:

/desk/include/stdarg.h:

../../../wolfsslPort/wolfssl/wolfcrypt/ed25519.h:

../../../wolfsslPort/wolfssl/wolfcrypt/types.h:

../../../wolfsslPort/wolfssl/wolfcrypt/wc_port.h:

/desk/include/ctype.h:

../../../wolfsslPort/wolfssl/wolfcrypt/fe_operations.h:

../../../wolfsslPort/wolfssl/wolfcrypt/ge_operations.h:

../../../wolfsslPort/wolfssl/wolfcrypt/random.h:

../../../wolfsslPort/wolfssl/wolfcrypt/sha256.h:

../../../wolfsslPort/wolfssl/wolfcrypt/sha512.h:

../../../wolfsslPort/wolfssl/wolfcrypt/error-crypt.h:

../../../wolfsslPort/wolfssl/wolfcrypt/hash.h:

../../../wolfsslPort/wolfssl/wolfcrypt/md5.h:

../../../wolfsslPort/wolfssl/wolfcrypt/sha.h:

../../../wolfsslPort/wolfssl/wolfcrypt/md4.h:

../../../wolfsslPort/wolfcrypt/src/misc.c:

../../../wolfsslPort/wolfssl/wolfcrypt/misc.h:
