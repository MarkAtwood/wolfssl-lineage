# =============================================================================
#
#                         THIS FILE IS AUTO GENERATED.
#          ANY CHANGES TO THIS FILE MAY BE OVERWRITTEN WITHOUT NOTICE.
# =============================================================================

# The project public make(1) targets.
.PHONY: all code boot install
all : code
install : all


# The pathname of the current makefile.  MAKEFILE_LIST must be sampled before including
# any other makefile, and the assignment must be immediate (i.e., :=).
project-config-makefile := $(word $(words $(MAKEFILE_LIST)),$(MAKEFILE_LIST))

WORKSPACE_DIR=$(PROJECT_DIR)/..
include $(WORKSPACE_DIR)/workspace-config.mk
include $(OA_SCRIPTS_DIR)/deos-executable-rules.mk
include $(OA_SCRIPTS_DIR)/deos-it-rules.mk


# compile
VPATH += $(PROJECT_DIR)
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt/port/atmel
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt/port
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt/port/devcrypto
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt/port/pic32
VPATH += $(PROJECT_DIR)/wolfsslPort/src
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/openssl
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt/port/caam
VPATH += $(PROJECT_DIR)/config
VPATH += $(PROJECT_DIR)/code
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfcrypt
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt/port/st
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt/port/ti
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfcrypt/src
VPATH += $(PROJECT_DIR)/wolfsslPort/IDE/ECLIPSE
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfcrypt/benchmark
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfcrypt/test
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt/port/nxp
VPATH += $(PROJECT_DIR)/wolfsslPort
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt/port/xilinx
VPATH += $(PROJECT_DIR)/wolfsslPort/IDE
VPATH += $(PROJECT_DIR)/wolfsslPort/IDE/ECLIPSE/DEOS
VPATH += $(PROJECT_DIR)/wolfsslPort/wolfssl/wolfcrypt/port/af_alg

# ist support
# no ist.xml files found in the project
# user customizable source code variables:
# directories for file extension: .CPP
PROJECT.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_atmel.CPP-files ?=
wolfsslPort_wolfssl.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt_port.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_pic32.CPP-files ?=
wolfsslPort_src.CPP-files ?=
wolfsslPort_wolfssl_openssl.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_caam.CPP-files ?=
config.CPP-files ?=
code.CPP-files ?=
wolfsslPort_wolfcrypt.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_st.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_ti.CPP-files ?=
wolfsslPort_wolfcrypt_src.CPP-files ?=
wolfsslPort_IDE_ECLIPSE.CPP-files ?=
wolfsslPort_wolfcrypt_benchmark.CPP-files ?=
wolfsslPort_wolfcrypt_test.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_nxp.CPP-files ?=
wolfsslPort.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.CPP-files ?=
wolfsslPort_IDE.CPP-files ?=
wolfsslPort_IDE_ECLIPSE_DEOS.CPP-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.CPP-files ?=

# directories for file extension: .cxx
PROJECT.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_atmel.cxx-files ?=
wolfsslPort_wolfssl.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt_port.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_pic32.cxx-files ?=
wolfsslPort_src.cxx-files ?=
wolfsslPort_wolfssl_openssl.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_caam.cxx-files ?=
config.cxx-files ?=
code.cxx-files ?=
wolfsslPort_wolfcrypt.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_st.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_ti.cxx-files ?=
wolfsslPort_wolfcrypt_src.cxx-files ?=
wolfsslPort_IDE_ECLIPSE.cxx-files ?=
wolfsslPort_wolfcrypt_benchmark.cxx-files ?=
wolfsslPort_wolfcrypt_test.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_nxp.cxx-files ?=
wolfsslPort.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cxx-files ?=
wolfsslPort_IDE.cxx-files ?=
wolfsslPort_IDE_ECLIPSE_DEOS.cxx-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cxx-files ?=

# directories for file extension: .cpp
PROJECT.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files ?=
wolfsslPort_wolfssl.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files ?=
wolfsslPort_src.cpp-files ?=
wolfsslPort_wolfssl_openssl.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files ?=
config.cpp-files ?=
code.cpp-files ?=
wolfsslPort_wolfcrypt.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files ?=
wolfsslPort_wolfcrypt_src.cpp-files ?=
wolfsslPort_IDE_ECLIPSE.cpp-files ?=
wolfsslPort_wolfcrypt_benchmark.cpp-files ?=
wolfsslPort_wolfcrypt_test.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files ?=
wolfsslPort.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files ?=
wolfsslPort_IDE.cpp-files ?=
wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files ?=

# directories for file extension: .c++
PROJECT.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_atmel.c++-files ?=
wolfsslPort_wolfssl.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt_port.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_pic32.c++-files ?=
wolfsslPort_src.c++-files ?=
wolfsslPort_wolfssl_openssl.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_caam.c++-files ?=
config.c++-files ?=
code.c++-files ?=
wolfsslPort_wolfcrypt.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_st.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_ti.c++-files ?=
wolfsslPort_wolfcrypt_src.c++-files ?=
wolfsslPort_IDE_ECLIPSE.c++-files ?=
wolfsslPort_wolfcrypt_benchmark.c++-files ?=
wolfsslPort_wolfcrypt_test.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_nxp.c++-files ?=
wolfsslPort.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c++-files ?=
wolfsslPort_IDE.c++-files ?=
wolfsslPort_IDE_ECLIPSE_DEOS.c++-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c++-files ?=

# directories for file extension: .c
PROJECT.c-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files ?=
wolfsslPort_wolfssl.c-files ?=
wolfsslPort_wolfssl_wolfcrypt_port.c-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files ?=
wolfsslPort_src.c-files ?=
wolfsslPort_wolfssl_openssl.c-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files ?=
config.c-files ?=
code.c-files ?=
wolfsslPort_wolfcrypt.c-files ?=
wolfsslPort_wolfssl_wolfcrypt.c-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_st.c-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files ?=
wolfsslPort_wolfcrypt_src.c-files ?=
wolfsslPort_IDE_ECLIPSE.c-files ?=
wolfsslPort_wolfcrypt_benchmark.c-files ?=
wolfsslPort_wolfcrypt_test.c-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files ?=
wolfsslPort.c-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files ?=
wolfsslPort_IDE.c-files ?=
wolfsslPort_IDE_ECLIPSE_DEOS.c-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files ?=

# directories for file extension: .C
PROJECT.C-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_atmel.C-files ?=
wolfsslPort_wolfssl.C-files ?=
wolfsslPort_wolfssl_wolfcrypt_port.C-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.C-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_pic32.C-files ?=
wolfsslPort_src.C-files ?=
wolfsslPort_wolfssl_openssl.C-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_caam.C-files ?=
config.C-files ?=
code.C-files ?=
wolfsslPort_wolfcrypt.C-files ?=
wolfsslPort_wolfssl_wolfcrypt.C-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_st.C-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_ti.C-files ?=
wolfsslPort_wolfcrypt_src.C-files ?=
wolfsslPort_IDE_ECLIPSE.C-files ?=
wolfsslPort_wolfcrypt_benchmark.C-files ?=
wolfsslPort_wolfcrypt_test.C-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_nxp.C-files ?=
wolfsslPort.C-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.C-files ?=
wolfsslPort_IDE.C-files ?=
wolfsslPort_IDE_ECLIPSE_DEOS.C-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.C-files ?=

# directories for file extension: .cp
PROJECT.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_atmel.cp-files ?=
wolfsslPort_wolfssl.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_pic32.cp-files ?=
wolfsslPort_src.cp-files ?=
wolfsslPort_wolfssl_openssl.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_caam.cp-files ?=
config.cp-files ?=
code.cp-files ?=
wolfsslPort_wolfcrypt.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_st.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_ti.cp-files ?=
wolfsslPort_wolfcrypt_src.cp-files ?=
wolfsslPort_IDE_ECLIPSE.cp-files ?=
wolfsslPort_wolfcrypt_benchmark.cp-files ?=
wolfsslPort_wolfcrypt_test.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_nxp.cp-files ?=
wolfsslPort.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cp-files ?=
wolfsslPort_IDE.cp-files ?=
wolfsslPort_IDE_ECLIPSE_DEOS.cp-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cp-files ?=

# directories for file extension: .cc
PROJECT.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_atmel.cc-files ?=
wolfsslPort_wolfssl.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt_port.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_pic32.cc-files ?=
wolfsslPort_src.cc-files ?=
wolfsslPort_wolfssl_openssl.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_caam.cc-files ?=
config.cc-files ?=
code.cc-files ?=
wolfsslPort_wolfcrypt.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_st.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_ti.cc-files ?=
wolfsslPort_wolfcrypt_src.cc-files ?=
wolfsslPort_IDE_ECLIPSE.cc-files ?=
wolfsslPort_wolfcrypt_benchmark.cc-files ?=
wolfsslPort_wolfcrypt_test.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_nxp.cc-files ?=
wolfsslPort.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cc-files ?=
wolfsslPort_IDE.cc-files ?=
wolfsslPort_IDE_ECLIPSE_DEOS.cc-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cc-files ?=

# directories for file extension: .pd.xml
PROJECT.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files ?=
wolfsslPort_wolfssl.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files ?=
wolfsslPort_src.pd.xml-files ?=
wolfsslPort_wolfssl_openssl.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files ?=
config.pd.xml-files ?=
code.pd.xml-files ?=
wolfsslPort_wolfcrypt.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files ?=
wolfsslPort_wolfcrypt_src.pd.xml-files ?=
wolfsslPort_IDE_ECLIPSE.pd.xml-files ?=
wolfsslPort_wolfcrypt_benchmark.pd.xml-files ?=
wolfsslPort_wolfcrypt_test.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files ?=
wolfsslPort.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files ?=
wolfsslPort_IDE.pd.xml-files ?=
wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files ?=
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files ?=


# Waiting for AL to tell me what to do here... += F/udp-vs-tcp/wolfsslPort/src
# Waiting for AL to tell me what to do here... += F/udp-vs-tcp/code
# Waiting for AL to tell me what to do here... += F/udp-vs-tcp/wolfsslPort/IDE/ECLIPSE/DEOS
# Waiting for AL to tell me what to do here... += F/udp-vs-tcp/config
# Waiting for AL to tell me what to do here... += F/udp-vs-tcp/wolfsslPort/wolfcrypt/benchmark
# Waiting for AL to tell me what to do here... += F/udp-vs-tcp/wolfsslPort/wolfcrypt/test
# Waiting for AL to tell me what to do here... += F/udp-vs-tcp/wolfsslPort/wolfcrypt/src
code.cpp-files = udp-vs-tcp.cpp
config.pd.xml-files = udp-vs-tcp.pd.xml
wolfsslPort_IDE_ECLIPSE_DEOS.c-files = deos_malloc.c
wolfsslPort_IDE_ECLIPSE_DEOS.c-files += tls_wolfssl.c
wolfsslPort_src.c-files = crl.c
wolfsslPort_src.c-files += tls.c
wolfsslPort_src.c-files += sniffer.c
wolfsslPort_src.c-files += wolfio.c
wolfsslPort_src.c-files += ocsp.c
wolfsslPort_src.c-files += keys.c
wolfsslPort_src.c-files += internal.c
wolfsslPort_src.c-files += bio.c
wolfsslPort_src.c-files += ssl.c
wolfsslPort_src.c-files += tls13.c
wolfsslPort_wolfcrypt_benchmark.c-files = benchmark.c
wolfsslPort_wolfcrypt_src.c-files = ripemd.c
wolfsslPort_wolfcrypt_src.c-files += signature.c
wolfsslPort_wolfcrypt_src.c-files += logging.c
wolfsslPort_wolfcrypt_src.c-files += sp_armthumb.c
wolfsslPort_wolfcrypt_src.c-files += blake2b.c
wolfsslPort_wolfcrypt_src.c-files += sp_c64.c
wolfsslPort_wolfcrypt_src.c-files += camellia.c
wolfsslPort_wolfcrypt_src.c-files += dh.c
wolfsslPort_wolfcrypt_src.c-files += cryptodev.c
wolfsslPort_wolfcrypt_src.c-files += md4.c
wolfsslPort_wolfcrypt_src.c-files += asm.c
wolfsslPort_wolfcrypt_src.c-files += random.c
wolfsslPort_wolfcrypt_src.c-files += sp_arm32.c
wolfsslPort_wolfcrypt_src.c-files += chacha20_poly1305.c
wolfsslPort_wolfcrypt_src.c-files += fe_low_mem.c
wolfsslPort_wolfcrypt_src.c-files += integer.c
wolfsslPort_wolfcrypt_src.c-files += wc_encrypt.c
wolfsslPort_wolfcrypt_src.c-files += error.c
wolfsslPort_wolfcrypt_src.c-files += sp_c32.c
wolfsslPort_wolfcrypt_src.c-files += wc_port.c
wolfsslPort_wolfcrypt_src.c-files += ecc.c
wolfsslPort_wolfcrypt_src.c-files += ed25519.c
wolfsslPort_wolfcrypt_src.c-files += sha3.c
wolfsslPort_wolfcrypt_src.c-files += asn.c
wolfsslPort_wolfcrypt_src.c-files += dsa.c
wolfsslPort_wolfcrypt_src.c-files += srp.c
wolfsslPort_wolfcrypt_src.c-files += md2.c
wolfsslPort_wolfcrypt_src.c-files += sha512.c
wolfsslPort_wolfcrypt_src.c-files += cmac.c
wolfsslPort_wolfcrypt_src.c-files += pwdbased.c
wolfsslPort_wolfcrypt_src.c-files += sha.c
wolfsslPort_wolfcrypt_src.c-files += misc.c
wolfsslPort_wolfcrypt_src.c-files += wolfmath.c
wolfsslPort_wolfcrypt_src.c-files += coding.c
wolfsslPort_wolfcrypt_src.c-files += fe_operations.c
wolfsslPort_wolfcrypt_src.c-files += des3.c
wolfsslPort_wolfcrypt_src.c-files += wolfevent.c
wolfsslPort_wolfcrypt_src.c-files += ecc_fp.c
wolfsslPort_wolfcrypt_src.c-files += idea.c
wolfsslPort_wolfcrypt_src.c-files += chacha.c
wolfsslPort_wolfcrypt_src.c-files += curve25519.c
wolfsslPort_wolfcrypt_src.c-files += poly1305.c
wolfsslPort_wolfcrypt_src.c-files += hmac.c
wolfsslPort_wolfcrypt_src.c-files += memory.c
wolfsslPort_wolfcrypt_src.c-files += hash.c
wolfsslPort_wolfcrypt_src.c-files += cpuid.c
wolfsslPort_wolfcrypt_src.c-files += ge_low_mem.c
wolfsslPort_wolfcrypt_src.c-files += wc_pkcs11.c
wolfsslPort_wolfcrypt_src.c-files += sp_x86_64.c
wolfsslPort_wolfcrypt_src.c-files += md5.c
wolfsslPort_wolfcrypt_src.c-files += rsa.c
wolfsslPort_wolfcrypt_src.c-files += arc4.c
wolfsslPort_wolfcrypt_src.c-files += ge_operations.c
wolfsslPort_wolfcrypt_src.c-files += sp_arm64.c
wolfsslPort_wolfcrypt_src.c-files += compress.c
wolfsslPort_wolfcrypt_src.c-files += pkcs7.c
wolfsslPort_wolfcrypt_src.c-files += evp.c
wolfsslPort_wolfcrypt_src.c-files += tfm.c
wolfsslPort_wolfcrypt_src.c-files += aes.c
wolfsslPort_wolfcrypt_src.c-files += pkcs12.c
wolfsslPort_wolfcrypt_src.c-files += sp_int.c
wolfsslPort_wolfcrypt_src.c-files += rabbit.c
wolfsslPort_wolfcrypt_src.c-files += sha256.c
wolfsslPort_wolfcrypt_src.c-files += hc128.c
wolfsslPort_wolfcrypt_test.c-files = test.c

# This is here to support selective building of files
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl.cpp-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl.cpp-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl.cpp-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl.cpp-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl.cpp-files += $(wolfsslPort_wolfssl__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl.cpp-files += $(wolfsslPort_wolfssl__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl.cpp-files += $(wolfsslPort_wolfssl__$(VARIANT).cpp-files)

wolfsslPort_wolfssl__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl.c-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl.c-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl.c-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl.c-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl.c-files += $(wolfsslPort_wolfssl__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl.c-files += $(wolfsslPort_wolfssl__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl__$(VARIANT).c-files?=; wolfsslPort_wolfssl.c-files += $(wolfsslPort_wolfssl__$(VARIANT).c-files)

wolfsslPort_wolfssl__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl.pd.xml-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl.pd.xml-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl.pd.xml-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl.pd.xml-files += $(wolfsslPort_wolfssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl.pd.xml-files += $(wolfsslPort_wolfssl__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl.pd.xml-files += $(wolfsslPort_wolfssl__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl.pd.xml-files += $(wolfsslPort_wolfssl__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32__$(VARIANT).pd.xml-files)

wolfsslPort_src__$(TARGET_ARCH).cpp-files?=; wolfsslPort_src.cpp-files += $(wolfsslPort_src__$(TARGET_ARCH).cpp-files)
wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_src.cpp-files += $(wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_src__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_src.cpp-files += $(wolfsslPort_src__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_src.cpp-files += $(wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_src__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_src.cpp-files += $(wolfsslPort_src__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_src__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_src.cpp-files += $(wolfsslPort_src__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_src__$(VARIANT).cpp-files?=; wolfsslPort_src.cpp-files += $(wolfsslPort_src__$(VARIANT).cpp-files)

wolfsslPort_src__$(TARGET_ARCH).c-files?=; wolfsslPort_src.c-files += $(wolfsslPort_src__$(TARGET_ARCH).c-files)
wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_src.c-files += $(wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_src__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_src.c-files += $(wolfsslPort_src__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_src.c-files += $(wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_src__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_src.c-files += $(wolfsslPort_src__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_src__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_src.c-files += $(wolfsslPort_src__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_src__$(VARIANT).c-files?=; wolfsslPort_src.c-files += $(wolfsslPort_src__$(VARIANT).c-files)

wolfsslPort_src__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_src.pd.xml-files += $(wolfsslPort_src__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_src.pd.xml-files += $(wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_src__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_src.pd.xml-files += $(wolfsslPort_src__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_src.pd.xml-files += $(wolfsslPort_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_src__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_src.pd.xml-files += $(wolfsslPort_src__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_src__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_src.pd.xml-files += $(wolfsslPort_src__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_src__$(VARIANT).pd.xml-files?=; wolfsslPort_src.pd.xml-files += $(wolfsslPort_src__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_openssl__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_openssl.cpp-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_openssl.cpp-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_openssl.cpp-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_openssl.cpp-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_openssl.cpp-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_openssl.cpp-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_openssl__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_openssl.cpp-files += $(wolfsslPort_wolfssl_openssl__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_openssl__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_openssl.c-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_openssl.c-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_openssl.c-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_openssl.c-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_openssl.c-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_openssl.c-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_openssl__$(VARIANT).c-files?=; wolfsslPort_wolfssl_openssl.c-files += $(wolfsslPort_wolfssl_openssl__$(VARIANT).c-files)

wolfsslPort_wolfssl_openssl__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_openssl.pd.xml-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_openssl.pd.xml-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_openssl.pd.xml-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_openssl.pd.xml-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_openssl.pd.xml-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_openssl.pd.xml-files += $(wolfsslPort_wolfssl_openssl__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_openssl__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_openssl.pd.xml-files += $(wolfsslPort_wolfssl_openssl__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_caam__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam__$(VARIANT).pd.xml-files)

config__$(TARGET_ARCH).cpp-files?=; config.cpp-files += $(config__$(TARGET_ARCH).cpp-files)
config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; config.cpp-files += $(config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
config__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; config.cpp-files += $(config__$(TARGET_ARCH)_$(VARIANT).cpp-files)
config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; config.cpp-files += $(config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
config__$(TARGET_SUB_ARCH).cpp-files?=; config.cpp-files += $(config__$(TARGET_SUB_ARCH).cpp-files)
config__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; config.cpp-files += $(config__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
config__$(VARIANT).cpp-files?=; config.cpp-files += $(config__$(VARIANT).cpp-files)

config__$(TARGET_ARCH).c-files?=; config.c-files += $(config__$(TARGET_ARCH).c-files)
config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; config.c-files += $(config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
config__$(TARGET_ARCH)_$(VARIANT).c-files?=; config.c-files += $(config__$(TARGET_ARCH)_$(VARIANT).c-files)
config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; config.c-files += $(config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
config__$(TARGET_SUB_ARCH).c-files?=; config.c-files += $(config__$(TARGET_SUB_ARCH).c-files)
config__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; config.c-files += $(config__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
config__$(VARIANT).c-files?=; config.c-files += $(config__$(VARIANT).c-files)

config__$(TARGET_ARCH).pd.xml-files?=; config.pd.xml-files += $(config__$(TARGET_ARCH).pd.xml-files)
config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; config.pd.xml-files += $(config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
config__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; config.pd.xml-files += $(config__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; config.pd.xml-files += $(config__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
config__$(TARGET_SUB_ARCH).pd.xml-files?=; config.pd.xml-files += $(config__$(TARGET_SUB_ARCH).pd.xml-files)
config__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; config.pd.xml-files += $(config__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
config__$(VARIANT).pd.xml-files?=; config.pd.xml-files += $(config__$(VARIANT).pd.xml-files)

code__$(TARGET_ARCH).cpp-files?=; code.cpp-files += $(code__$(TARGET_ARCH).cpp-files)
code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; code.cpp-files += $(code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
code__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; code.cpp-files += $(code__$(TARGET_ARCH)_$(VARIANT).cpp-files)
code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; code.cpp-files += $(code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
code__$(TARGET_SUB_ARCH).cpp-files?=; code.cpp-files += $(code__$(TARGET_SUB_ARCH).cpp-files)
code__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; code.cpp-files += $(code__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
code__$(VARIANT).cpp-files?=; code.cpp-files += $(code__$(VARIANT).cpp-files)

code__$(TARGET_ARCH).c-files?=; code.c-files += $(code__$(TARGET_ARCH).c-files)
code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; code.c-files += $(code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
code__$(TARGET_ARCH)_$(VARIANT).c-files?=; code.c-files += $(code__$(TARGET_ARCH)_$(VARIANT).c-files)
code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; code.c-files += $(code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
code__$(TARGET_SUB_ARCH).c-files?=; code.c-files += $(code__$(TARGET_SUB_ARCH).c-files)
code__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; code.c-files += $(code__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
code__$(VARIANT).c-files?=; code.c-files += $(code__$(VARIANT).c-files)

code__$(TARGET_ARCH).pd.xml-files?=; code.pd.xml-files += $(code__$(TARGET_ARCH).pd.xml-files)
code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; code.pd.xml-files += $(code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
code__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; code.pd.xml-files += $(code__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; code.pd.xml-files += $(code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
code__$(TARGET_SUB_ARCH).pd.xml-files?=; code.pd.xml-files += $(code__$(TARGET_SUB_ARCH).pd.xml-files)
code__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; code.pd.xml-files += $(code__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
code__$(VARIANT).pd.xml-files?=; code.pd.xml-files += $(code__$(VARIANT).pd.xml-files)

wolfsslPort_wolfcrypt__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfcrypt.cpp-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfcrypt.cpp-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt.cpp-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt.cpp-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfcrypt.cpp-files += $(wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt.cpp-files += $(wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt__$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt.cpp-files += $(wolfsslPort_wolfcrypt__$(VARIANT).cpp-files)

wolfsslPort_wolfcrypt__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfcrypt.c-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH).c-files)
wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfcrypt.c-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt.c-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt.c-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfcrypt.c-files += $(wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt.c-files += $(wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt__$(VARIANT).c-files?=; wolfsslPort_wolfcrypt.c-files += $(wolfsslPort_wolfcrypt__$(VARIANT).c-files)

wolfsslPort_wolfcrypt__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfcrypt__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_st__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_ti__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti__$(VARIANT).pd.xml-files)

wolfsslPort_wolfcrypt_src__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfcrypt_src.cpp-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfcrypt_src.cpp-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_src.cpp-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_src.cpp-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfcrypt_src.cpp-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_src.cpp-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt_src__$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_src.cpp-files += $(wolfsslPort_wolfcrypt_src__$(VARIANT).cpp-files)

wolfsslPort_wolfcrypt_src__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfcrypt_src.c-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH).c-files)
wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfcrypt_src.c-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_src.c-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_src.c-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfcrypt_src.c-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_src.c-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt_src__$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_src.c-files += $(wolfsslPort_wolfcrypt_src__$(VARIANT).c-files)

wolfsslPort_wolfcrypt_src__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt_src.pd.xml-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt_src.pd.xml-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_src.pd.xml-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_src.pd.xml-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt_src.pd.xml-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_src.pd.xml-files += $(wolfsslPort_wolfcrypt_src__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt_src__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_src.pd.xml-files += $(wolfsslPort_wolfcrypt_src__$(VARIANT).pd.xml-files)

wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH).cpp-files?=; wolfsslPort_IDE_ECLIPSE.cpp-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH).cpp-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_IDE_ECLIPSE.cpp-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_IDE_ECLIPSE.cpp-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_IDE_ECLIPSE.cpp-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_IDE_ECLIPSE.cpp-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_IDE_ECLIPSE.cpp-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_IDE_ECLIPSE__$(VARIANT).cpp-files?=; wolfsslPort_IDE_ECLIPSE.cpp-files += $(wolfsslPort_IDE_ECLIPSE__$(VARIANT).cpp-files)

wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH).c-files?=; wolfsslPort_IDE_ECLIPSE.c-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH).c-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_IDE_ECLIPSE.c-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_IDE_ECLIPSE.c-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_IDE_ECLIPSE.c-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_IDE_ECLIPSE.c-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_IDE_ECLIPSE.c-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_IDE_ECLIPSE__$(VARIANT).c-files?=; wolfsslPort_IDE_ECLIPSE.c-files += $(wolfsslPort_IDE_ECLIPSE__$(VARIANT).c-files)

wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_IDE_ECLIPSE__$(VARIANT).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE__$(VARIANT).pd.xml-files)

wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfcrypt_benchmark.cpp-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfcrypt_benchmark.cpp-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_benchmark.cpp-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_benchmark.cpp-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfcrypt_benchmark.cpp-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_benchmark.cpp-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt_benchmark__$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_benchmark.cpp-files += $(wolfsslPort_wolfcrypt_benchmark__$(VARIANT).cpp-files)

wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfcrypt_benchmark.c-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH).c-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfcrypt_benchmark.c-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_benchmark.c-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_benchmark.c-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfcrypt_benchmark.c-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_benchmark.c-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt_benchmark__$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_benchmark.c-files += $(wolfsslPort_wolfcrypt_benchmark__$(VARIANT).c-files)

wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt_benchmark.pd.xml-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt_benchmark.pd.xml-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_benchmark.pd.xml-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_benchmark.pd.xml-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt_benchmark.pd.xml-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_benchmark.pd.xml-files += $(wolfsslPort_wolfcrypt_benchmark__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt_benchmark__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_benchmark.pd.xml-files += $(wolfsslPort_wolfcrypt_benchmark__$(VARIANT).pd.xml-files)

wolfsslPort_wolfcrypt_test__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfcrypt_test.cpp-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfcrypt_test.cpp-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_test.cpp-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_test.cpp-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfcrypt_test.cpp-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_test.cpp-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfcrypt_test__$(VARIANT).cpp-files?=; wolfsslPort_wolfcrypt_test.cpp-files += $(wolfsslPort_wolfcrypt_test__$(VARIANT).cpp-files)

wolfsslPort_wolfcrypt_test__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfcrypt_test.c-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH).c-files)
wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfcrypt_test.c-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_test.c-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_test.c-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfcrypt_test.c-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_test.c-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfcrypt_test__$(VARIANT).c-files?=; wolfsslPort_wolfcrypt_test.c-files += $(wolfsslPort_wolfcrypt_test__$(VARIANT).c-files)

wolfsslPort_wolfcrypt_test__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt_test.pd.xml-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt_test.pd.xml-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_test.pd.xml-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_test.pd.xml-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfcrypt_test.pd.xml-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_test.pd.xml-files += $(wolfsslPort_wolfcrypt_test__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfcrypt_test__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfcrypt_test.pd.xml-files += $(wolfsslPort_wolfcrypt_test__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp__$(VARIANT).pd.xml-files)

wolfsslPort__$(TARGET_ARCH).cpp-files?=; wolfsslPort.cpp-files += $(wolfsslPort__$(TARGET_ARCH).cpp-files)
wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort.cpp-files += $(wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort.cpp-files += $(wolfsslPort__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort.cpp-files += $(wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort.cpp-files += $(wolfsslPort__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort.cpp-files += $(wolfsslPort__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort__$(VARIANT).cpp-files?=; wolfsslPort.cpp-files += $(wolfsslPort__$(VARIANT).cpp-files)

wolfsslPort__$(TARGET_ARCH).c-files?=; wolfsslPort.c-files += $(wolfsslPort__$(TARGET_ARCH).c-files)
wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort.c-files += $(wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort.c-files += $(wolfsslPort__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort.c-files += $(wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort.c-files += $(wolfsslPort__$(TARGET_SUB_ARCH).c-files)
wolfsslPort__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort.c-files += $(wolfsslPort__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort__$(VARIANT).c-files?=; wolfsslPort.c-files += $(wolfsslPort__$(VARIANT).c-files)

wolfsslPort__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort.pd.xml-files += $(wolfsslPort__$(TARGET_ARCH).pd.xml-files)
wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort.pd.xml-files += $(wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort.pd.xml-files += $(wolfsslPort__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort.pd.xml-files += $(wolfsslPort__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort.pd.xml-files += $(wolfsslPort__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort.pd.xml-files += $(wolfsslPort__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort__$(VARIANT).pd.xml-files?=; wolfsslPort.pd.xml-files += $(wolfsslPort__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx__$(VARIANT).pd.xml-files)

wolfsslPort_IDE__$(TARGET_ARCH).cpp-files?=; wolfsslPort_IDE.cpp-files += $(wolfsslPort_IDE__$(TARGET_ARCH).cpp-files)
wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_IDE.cpp-files += $(wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_IDE__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_IDE.cpp-files += $(wolfsslPort_IDE__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_IDE.cpp-files += $(wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_IDE__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_IDE.cpp-files += $(wolfsslPort_IDE__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_IDE__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_IDE.cpp-files += $(wolfsslPort_IDE__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_IDE__$(VARIANT).cpp-files?=; wolfsslPort_IDE.cpp-files += $(wolfsslPort_IDE__$(VARIANT).cpp-files)

wolfsslPort_IDE__$(TARGET_ARCH).c-files?=; wolfsslPort_IDE.c-files += $(wolfsslPort_IDE__$(TARGET_ARCH).c-files)
wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_IDE.c-files += $(wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_IDE__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_IDE.c-files += $(wolfsslPort_IDE__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_IDE.c-files += $(wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_IDE__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_IDE.c-files += $(wolfsslPort_IDE__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_IDE__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_IDE.c-files += $(wolfsslPort_IDE__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_IDE__$(VARIANT).c-files?=; wolfsslPort_IDE.c-files += $(wolfsslPort_IDE__$(VARIANT).c-files)

wolfsslPort_IDE__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_IDE.pd.xml-files += $(wolfsslPort_IDE__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_IDE.pd.xml-files += $(wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_IDE__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_IDE.pd.xml-files += $(wolfsslPort_IDE__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_IDE.pd.xml-files += $(wolfsslPort_IDE__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_IDE__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_IDE.pd.xml-files += $(wolfsslPort_IDE__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_IDE__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_IDE.pd.xml-files += $(wolfsslPort_IDE__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_IDE__$(VARIANT).pd.xml-files?=; wolfsslPort_IDE.pd.xml-files += $(wolfsslPort_IDE__$(VARIANT).pd.xml-files)

wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH).cpp-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH).cpp-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(VARIANT).cpp-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(VARIANT).cpp-files)

wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH).c-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH).c-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(VARIANT).c-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(VARIANT).c-files)

wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_IDE_ECLIPSE_DEOS__$(VARIANT).pd.xml-files?=; wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS__$(VARIANT).pd.xml-files)

wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(VARIANT).cpp-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(VARIANT).cpp-files)

wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH)_$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH)_$(VARIANT).c-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(VARIANT).c-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(VARIANT).c-files)

wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(TARGET_SUB_ARCH)_$(VARIANT).pd.xml-files)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(VARIANT).pd.xml-files?=; wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg__$(VARIANT).pd.xml-files)


# Project directory/child hierarchy variables
ECLIPSE.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files)
IDE.cpp-files += $(wolfsslPort_IDE_ECLIPSE.cpp-files)
IDE.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_src.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_openssl.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files)
PROJECT.cpp-files += $(config.cpp-files)
PROJECT.cpp-files += $(code.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfcrypt.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfcrypt_src.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_IDE_ECLIPSE.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfcrypt_benchmark.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfcrypt_test.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files)
PROJECT.cpp-files += $(wolfsslPort.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_IDE.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files)
PROJECT.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files)
port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files)
port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files)
port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files)
port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files)
port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files)
port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files)
port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files)
port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files)
port.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files)
wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files)
wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port.cpp-files)
wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files)
wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files)
wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files)
wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files)
wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files)
wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files)
wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files)
wolfcrypt.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_openssl.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files)
wolfssl.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_src.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_openssl.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfcrypt.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfcrypt_src.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_IDE_ECLIPSE.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfcrypt_benchmark.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfcrypt_test.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_IDE.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files)
wolfsslPort.cpp-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files)

ECLIPSE.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.c-files)
IDE.c-files += $(wolfsslPort_IDE_ECLIPSE.c-files)
IDE.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files)
PROJECT.c-files += $(wolfsslPort_src.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_openssl.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files)
PROJECT.c-files += $(config.c-files)
PROJECT.c-files += $(code.c-files)
PROJECT.c-files += $(wolfsslPort_wolfcrypt.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files)
PROJECT.c-files += $(wolfsslPort_wolfcrypt_src.c-files)
PROJECT.c-files += $(wolfsslPort_IDE_ECLIPSE.c-files)
PROJECT.c-files += $(wolfsslPort_wolfcrypt_benchmark.c-files)
PROJECT.c-files += $(wolfsslPort_wolfcrypt_test.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files)
PROJECT.c-files += $(wolfsslPort.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files)
PROJECT.c-files += $(wolfsslPort_IDE.c-files)
PROJECT.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.c-files)
PROJECT.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files)
port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files)
port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files)
port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files)
port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files)
port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files)
port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files)
port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files)
port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.c-files)
port.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files)
wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files)
wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port.c-files)
wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files)
wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files)
wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files)
wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files)
wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files)
wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files)
wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.c-files)
wolfcrypt.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_openssl.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files)
wolfssl.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files)
wolfsslPort.c-files += $(wolfsslPort_src.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_openssl.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfcrypt.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfcrypt_src.c-files)
wolfsslPort.c-files += $(wolfsslPort_IDE_ECLIPSE.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfcrypt_benchmark.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfcrypt_test.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files)
wolfsslPort.c-files += $(wolfsslPort_IDE.c-files)
wolfsslPort.c-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.c-files)
wolfsslPort.c-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files)

ECLIPSE.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files)
IDE.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE.pd.xml-files)
IDE.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_src.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_openssl.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files)
PROJECT.pd.xml-files += $(config.pd.xml-files)
PROJECT.pd.xml-files += $(code.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfcrypt.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfcrypt_src.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfcrypt_benchmark.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfcrypt_test.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_IDE.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files)
PROJECT.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files)
port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files)
port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files)
port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files)
port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files)
port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files)
port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files)
port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files)
port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files)
port.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files)
wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files)
wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files)
wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files)
wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files)
wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files)
wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files)
wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files)
wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files)
wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files)
wolfcrypt.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_openssl.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files)
wolfssl.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_src.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_openssl.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_caam.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfcrypt.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_st.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_ti.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfcrypt_src.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfcrypt_benchmark.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfcrypt_test.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_IDE.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_IDE_ECLIPSE_DEOS.pd.xml-files)
wolfsslPort.pd.xml-files += $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.pd.xml-files)

# Object file variables
# All the .o files that come from cpp files
wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.cpp-files:.cpp=.o)
wolfsslPort_wolfssl.cpp-files.o = $(wolfsslPort_wolfssl.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_wolfcrypt_port.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.cpp-files:.cpp=.o)
wolfsslPort_src.cpp-files.o = $(wolfsslPort_src.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_openssl.cpp-files.o = $(wolfsslPort_wolfssl_openssl.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_caam.cpp-files:.cpp=.o)
config.cpp-files.o = $(config.cpp-files:.cpp=.o)
code.cpp-files.o = $(code.cpp-files:.cpp=.o)
wolfsslPort_wolfcrypt.cpp-files.o = $(wolfsslPort_wolfcrypt.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_wolfcrypt.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_st.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_ti.cpp-files:.cpp=.o)
wolfsslPort_wolfcrypt_src.cpp-files.o = $(wolfsslPort_wolfcrypt_src.cpp-files:.cpp=.o)
wolfsslPort_IDE_ECLIPSE.cpp-files.o = $(wolfsslPort_IDE_ECLIPSE.cpp-files:.cpp=.o)
wolfsslPort_wolfcrypt_benchmark.cpp-files.o = $(wolfsslPort_wolfcrypt_benchmark.cpp-files:.cpp=.o)
wolfsslPort_wolfcrypt_test.cpp-files.o = $(wolfsslPort_wolfcrypt_test.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.cpp-files:.cpp=.o)
wolfsslPort.cpp-files.o = $(wolfsslPort.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.cpp-files:.cpp=.o)
wolfsslPort_IDE.cpp-files.o = $(wolfsslPort_IDE.cpp-files:.cpp=.o)
wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files.o = $(wolfsslPort_IDE_ECLIPSE_DEOS.cpp-files:.cpp=.o)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.cpp-files:.cpp=.o)
PROJECT.cpp-files.o = $(PROJECT.cpp-files:.cpp=.o)
CLEAN_FILES += $(PROJECT.cpp-files.o)
DEPEND_FILES += $(PROJECT.cpp-files.o:.o=.d)
MAKE_PARENT_WHEN_NECESSARY += $(PROJECT.cpp-files.o)

# All the .o files that come from c files
wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_atmel.c-files:.c=.o)
wolfsslPort_wolfssl.c-files.o = $(wolfsslPort_wolfssl.c-files:.c=.o)
wolfsslPort_wolfssl_wolfcrypt_port.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port.c-files:.c=.o)
wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_devcrypto.c-files:.c=.o)
wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_pic32.c-files:.c=.o)
wolfsslPort_src.c-files.o = $(wolfsslPort_src.c-files:.c=.o)
wolfsslPort_wolfssl_openssl.c-files.o = $(wolfsslPort_wolfssl_openssl.c-files:.c=.o)
wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_caam.c-files:.c=.o)
config.c-files.o = $(config.c-files:.c=.o)
code.c-files.o = $(code.c-files:.c=.o)
wolfsslPort_wolfcrypt.c-files.o = $(wolfsslPort_wolfcrypt.c-files:.c=.o)
wolfsslPort_wolfssl_wolfcrypt.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt.c-files:.c=.o)
wolfsslPort_wolfssl_wolfcrypt_port_st.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_st.c-files:.c=.o)
wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_ti.c-files:.c=.o)
wolfsslPort_wolfcrypt_src.c-files.o = $(wolfsslPort_wolfcrypt_src.c-files:.c=.o)
wolfsslPort_IDE_ECLIPSE.c-files.o = $(wolfsslPort_IDE_ECLIPSE.c-files:.c=.o)
wolfsslPort_wolfcrypt_benchmark.c-files.o = $(wolfsslPort_wolfcrypt_benchmark.c-files:.c=.o)
wolfsslPort_wolfcrypt_test.c-files.o = $(wolfsslPort_wolfcrypt_test.c-files:.c=.o)
wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_nxp.c-files:.c=.o)
wolfsslPort.c-files.o = $(wolfsslPort.c-files:.c=.o)
wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_xilinx.c-files:.c=.o)
wolfsslPort_IDE.c-files.o = $(wolfsslPort_IDE.c-files:.c=.o)
wolfsslPort_IDE_ECLIPSE_DEOS.c-files.o = $(wolfsslPort_IDE_ECLIPSE_DEOS.c-files:.c=.o)
wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files.o = $(wolfsslPort_wolfssl_wolfcrypt_port_af_alg.c-files:.c=.o)
PROJECT.c-files.o = $(PROJECT.c-files:.c=.o)
CLEAN_FILES += $(PROJECT.c-files.o)
DEPEND_FILES += $(PROJECT.c-files.o:.o=.d)
MAKE_PARENT_WHEN_NECESSARY += $(PROJECT.c-files.o)


#pd_xml validation
xml.pd.cck-files = $(addprefix validated-xml/, $(PROJECT.pd.xml-files:.pd.xml=.pd.xml.cck))
CLEAN_FILES += $(xml.pd.cck-files)
MAKE_PARENT_WHEN_NECESSARY +=  $(xml.pd.cck-files)
CLEAN_FILES += validated-xml
code: $(xml.pd.cck-files)


# link
BINARY=$(OUTPUT_DIR)/$(PROJECT_NAME).exe
CLEAN_FILES += $(BINARY) $(BINARY).dbg $(OUTPUT_DIR)/$(PROJECT_NAME).map
$(BINARY): $(PROJECT.cpp-files.o) $(PROJECT.c-files.o)
code : $(BINARY)

#elfchk
$(BINARY:$(suffix $(BINARY))=.elfchk) : $(BINARY)
CLEAN_FILES += $(BINARY:$(suffix $(BINARY))=.elfchk)
