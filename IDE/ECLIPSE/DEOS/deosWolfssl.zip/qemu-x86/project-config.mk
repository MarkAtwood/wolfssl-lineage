# =============================================================================
#
#                         THIS FILE IS AUTO GENERATED.
#          ANY CHANGES TO THIS FILE MAY BE OVERWRITTEN WITHOUT NOTICE.
# =============================================================================

# The project public make(1) targets.
.PHONY: all code boot install
all : code
install : all


# The pathname of the current makefile.  MAKEFILE_LIST must be sampled before including
# any other makefile, and the assignment must be immediate (i.e., :=).
project-config-makefile := $(word $(words $(MAKEFILE_LIST)),$(MAKEFILE_LIST))

WORKSPACE_DIR=$(PROJECT_DIR)/..
include $(WORKSPACE_DIR)/workspace-config.mk
include $(OA_SCRIPTS_DIR)/deos-platform-rules.mk

# 653Config support
# No 653 files detected in this project

# ioiConfig support
# No ioi files detected in this project

# registy platreg lines
FILES.platreg ?=
FILES.platreg += $(DESK_DIR)/platform/qemu-x86/etc/cffs.fp.xml
FILES.platreg += $(DESK_DIR)/x86/etc/deos-kernel.fp.xml
FILES.platreg += $(DESK_DIR)/etc/gdb-server.pd.xml
FILES.platreg += $(DESK_DIR)/etc/inetd-gdb-only.pd.xml
FILES.platreg += $(DESK_DIR)/x86/etc/libansi.fp.xml
FILES.platreg += $(DESK_DIR)/x86/etc/libdart.fp.xml
FILES.platreg += $(DESK_DIR)/x86/etc/libmtl.fp.xml
FILES.platreg += $(DESK_DIR)/x86/etc/libsal.fp.xml
FILES.platreg += $(DESK_DIR)/platform/qemu-x86/etc/lwip-network.pd.xml
FILES.platreg += $(DESK_DIR)/etc/memory-object-based-video-channel.fp.xml
FILES.platreg += $(DESK_DIR)/platform/qemu-x86/etc/platreg.pi.xml
FILES.platreg += $(DESK_DIR)/etc/standard-apps.fp.xml
FILES.platreg += $(PROJECT_DIR.udp-vs-tcp)/config/udp-vs-tcp.pd.xml
FILES.platreg += $(DESK_DIR)/x86/etc/virtio-net.fp.xml
DEPENDENCIES.platreg ?=
DEPENDENCIES.platreg += $(project-config-makefile)
$(eval $(call makereg,platreg,$(FILES.platreg),$(DEPENDENCIES.platreg)))
# registy platregd lines
FILES.platregd ?=
FILES.platregd += $(DESK_DIR)/platform/qemu-x86/etc/cffs.fp.xml
FILES.platregd += $(DESK_DIR)/etc/deos-kernel-download-mode.fp.xml
FILES.platregd += $(DESK_DIR)/x86/etc/deos-kernel.fp.xml
FILES.platregd += $(DESK_DIR)/x86/etc/libansi.fp.xml
FILES.platregd += $(DESK_DIR)/platform/qemu-x86/etc/lwip-network.pd.xml
FILES.platregd += $(DESK_DIR)/etc/memory-object-based-video-channel.fp.xml
FILES.platregd += $(DESK_DIR)/platform/qemu-x86/etc/platreg.pi.xml
FILES.platregd += $(DESK_DIR)/etc/standard-apps-download-mode.fp.xml
FILES.platregd += $(DESK_DIR)/etc/standard-apps.fp.xml
FILES.platregd += $(DESK_DIR)/x86/etc/virtio-net.fp.xml
DEPENDENCIES.platregd ?=
DEPENDENCIES.platregd += $(project-config-makefile)
$(eval $(call makereg,platregd,$(FILES.platregd),$(DEPENDENCIES.platregd)))


# hypstart
# The -kernelFile switches for loadlist.txt.  The common make
# infrastructure defines The variables HYPSTART_KFS_FILES, and
# HYPSTART_WORKSTATION_FILES based on HYPSTART_kernelFile_SWITCHES.
HYPSTART_kernelFile_SWITCHES += -kernelFile=ansi.dll,$(DESK_DIR)/x86/appbin/libansi.so
HYPSTART_kernelFile_SWITCHES += -kernelFile=ftpserv.exe,$(DESK_DIR)/x86/appbin/ftpserv.exe
HYPSTART_kernelFile_SWITCHES += -kernelFile=gdbserver.exe,$(DESK_DIR)/x86/appbin/gdbserver.exe
HYPSTART_kernelFile_SWITCHES += -kernelFile=inetd.config,$(DESK_DIR)/etc/inetd-gdb-only.config
HYPSTART_kernelFile_SWITCHES += -kernelFile=inetd.exe,$(DESK_DIR)/x86/appbin/inetd.exe
HYPSTART_kernelFile_SWITCHES += -kernelFile=kernel.exe,$(DESK_DIR)/x86/appbin/dbg/kernel.exe
HYPSTART_kernelFile_SWITCHES += -kernelFile=libansi.so,$(DESK_DIR)/x86/appbin/libansi.so
HYPSTART_kernelFile_SWITCHES += -kernelFile=libdart.so,$(DESK_DIR)/x86/appbin/libdart.so
HYPSTART_kernelFile_SWITCHES += -kernelFile=libdebuggerkernelsupport.so,$(DESK_DIR)/x86/appbin/libdebuggerkernelsupport.so
HYPSTART_kernelFile_SWITCHES += -kernelFile=libdeosname.so,$(DESK_DIR)/x86/appbin/libdeosname.so
HYPSTART_kernelFile_SWITCHES += -kernelFile=libm.so,$(DESK_DIR)/x86/appbin/libm.so
HYPSTART_kernelFile_SWITCHES += -kernelFile=libmtl.so,$(DESK_DIR)/x86/appbin/libmtl.so
HYPSTART_kernelFile_SWITCHES += -kernelFile=libprintx.so,$(PROJECT_DIR.printx)/output/i686-pc-elf/diagnostic/libprintx.so
HYPSTART_kernelFile_SWITCHES += -kernelFile=libsal.so,$(DESK_DIR)/x86/appbin/libsal.so
HYPSTART_kernelFile_SWITCHES += -kernelFile=libvirtio-net.so,$(DESK_DIR)/x86/appbin/libvirtio-net.so
HYPSTART_kernelFile_SWITCHES += -kernelFile=lwip.config,$(PROJECT_DIR.qemu-x86)/config/lwip.config
HYPSTART_kernelFile_SWITCHES += -kernelFile=lwip.exe,$(DESK_DIR)/x86/appbin/dbg/lwip.exe
HYPSTART_kernelFile_SWITCHES += -kernelFile=mailbox-transport.config,$(PROJECT_DIR.udp-vs-tcp)/config/mailbox-transport.config
HYPSTART_kernelFile_SWITCHES += -kernelFile=names.dat,$(PROJECT_DIR.qemu-x86)/output/names.dat
$(PROJECT_DIR.qemu-x86)/output/names.dat : names.dat
HYPSTART_kernelFile_SWITCHES += -kernelFile=pal.dll,$(DESK_DIR)/platform/qemu-x86/appbin/dbg/pal.dll
HYPSTART_kernelFile_SWITCHES += -kernelFile=platreg-names.dat,$(PROJECT_DIR.qemu-x86)/output/platreg-itfiles/platreg-names.dat
HYPSTART_kernelFile_SWITCHES += -kernelFile=platreg.bin,$(PROJECT_DIR.qemu-x86)/output/platreg-itfiles/platreg.bin
HYPSTART_kernelFile_SWITCHES += -kernelFile=platregd-names.dat,$(PROJECT_DIR.qemu-x86)/output/platregd-itfiles/platregd-names.dat
HYPSTART_kernelFile_SWITCHES += -kernelFile=platregd.bin,$(PROJECT_DIR.qemu-x86)/output/platregd-itfiles/platregd.bin
HYPSTART_kernelFile_SWITCHES += -kernelFile=sm.exe,$(DESK_DIR)/x86/appbin/sm.exe
HYPSTART_kernelFile_SWITCHES += -kernelFile=standard-apps.config,$(DESK_DIR)/etc/standard-apps.config
HYPSTART_kernelFile_SWITCHES += -kernelFile=sysvstrm.config,$(DESK_DIR)/etc/sysvstrm.config
HYPSTART_kernelFile_SWITCHES += -kernelFile=sysvstrm.exe,$(DESK_DIR)/x86/appbin/sysvstrm.exe
HYPSTART_kernelFile_SWITCHES += -kernelFile=udp-vs-tcp.exe,$(PROJECT_DIR.udp-vs-tcp)/output/i686-pc-elf/diagnostic/udp-vs-tcp.exe
$(eval $(call make-file-from-list-rule,loadlist.txt,$$(HYPSTART_kernelFile_SWITCHES),$(project-config-makefile) $(PROJECT_DIR)/bootimage.hyp))
$(call make-relative-path-rules)
all: loadlist.txt $(HYPSTART_WORKSTATION_FILES)

# Platform project Validate in place:
platreg-xml-to-update ?=
$(eval $(call COPY_CHANGED_FILES,$(platreg-xml-to-update),platreg-itfiles,all))
platregd-xml-to-update ?=
$(eval $(call COPY_CHANGED_FILES,$(platregd-xml-to-update),platregd-itfiles,all))

# generate exeNames.present file
all : exeNames.present
all : loadlist-absolute-paths.txt

# exported files
$(eval $(call INSTALL_FILES, $(INSTALL_PREFIX)/etc, $(PROJECT_DIR)/config/lwip.config))
$(eval $(call INSTALL_FILES, $(INSTALL_PREFIX)/etc, $(OUTPUT_DIR)/names.dat))
$(eval $(call INSTALL_FILES, $(INSTALL_PREFIX)/etc, $(OUTPUT_DIR)/platreg-itfiles/platreg-names.dat))
$(eval $(call INSTALL_FILES, $(INSTALL_PREFIX)/etc, $(OUTPUT_DIR)/platreg-itfiles/platreg.bin))
$(eval $(call INSTALL_FILES, $(INSTALL_PREFIX)/etc, $(OUTPUT_DIR)/platregd-itfiles/platregd-names.dat))
$(eval $(call INSTALL_FILES, $(INSTALL_PREFIX)/etc, $(OUTPUT_DIR)/platregd-itfiles/platregd.bin))
$(eval $(call INSTALL_FILES, $(INSTALL_PREFIX)/etc, $(OUTPUT_DIR)/qemu-x86.cd.xml))
CLEAN_FILES += $(INSTALL_PREFIX)


# boot image
boot : deosBoot.qemu
deosBoot.qemu : $(HYPSTART_WORKSTATION_FILES) loadlist.txt $(PROJECT_DIR)/bootimage.hyp
	makeboot @../bootimage.hyp -bootDest=dir:$(dir $@) > $@.cck
CLEAN_FILES += deosBoot.qemu deosBoot.qemu.cck deosBoot.qemu.launch

# all : boot
# hypdump
# boot : deosBoot.qemu.htm
deosBoot.qemu.htm: deosBoot.qemu
	hypdump -hypFile=deosBoot.qemu -target=x86 -hdFile=deosBoot.qemu.htm > hd.cck
CLEAN_FILES += deosBoot.qemu.htm hd.cck


