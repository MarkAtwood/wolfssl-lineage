# =============================================================================
#
#                         THIS FILE IS AUTO GENERATED.
#          ANY CHANGES TO THIS FILE MAY BE OVERWRITTEN WITHOUT NOTICE.
# =============================================================================

# The project public make(1) targets.
.PHONY: all code boot install
all : code
install : all


# The pathname of the current makefile.  MAKEFILE_LIST must be sampled before including
# any other makefile, and the assignment must be immediate (i.e., :=).
project-config-makefile := $(word $(words $(MAKEFILE_LIST)),$(MAKEFILE_LIST))

WORKSPACE_DIR=$(PROJECT_DIR)/..
include $(WORKSPACE_DIR)/workspace-config.mk
include $(OA_SCRIPTS_DIR)/deos-executable-rules.mk


# compile
VPATH += $(PROJECT_DIR)
VPATH += $(PROJECT_DIR)/code

# ist support
# no ist.xml files found in the project
# user customizable source code variables:
# directories for file extension: .CPP
PROJECT.CPP-files ?=
code.CPP-files ?=

# directories for file extension: .cxx
PROJECT.cxx-files ?=
code.cxx-files ?=

# directories for file extension: .cpp
PROJECT.cpp-files ?=
code.cpp-files ?=

# directories for file extension: .c++
PROJECT.c++-files ?=
code.c++-files ?=

# directories for file extension: .C
PROJECT.C-files ?=
code.C-files ?=

# directories for file extension: .cp
PROJECT.cp-files ?=
code.cp-files ?=

# directories for file extension: .cc
PROJECT.cc-files ?=
code.cc-files ?=


# Waiting for AL to tell me what to do here... += F/printx/code
code.cpp-files = printx.cpp

# This is here to support selective building of files
code__$(TARGET_ARCH).cpp-files?=; code.cpp-files += $(code__$(TARGET_ARCH).cpp-files)
code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files?=; code.cpp-files += $(code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH).cpp-files)
code__$(TARGET_ARCH)_$(VARIANT).cpp-files?=; code.cpp-files += $(code__$(TARGET_ARCH)_$(VARIANT).cpp-files)
code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; code.cpp-files += $(code__$(TARGET_ARCH)_$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
code__$(TARGET_SUB_ARCH).cpp-files?=; code.cpp-files += $(code__$(TARGET_SUB_ARCH).cpp-files)
code__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files?=; code.cpp-files += $(code__$(TARGET_SUB_ARCH)_$(VARIANT).cpp-files)
code__$(VARIANT).cpp-files?=; code.cpp-files += $(code__$(VARIANT).cpp-files)


# Project directory/child hierarchy variables
PROJECT.cpp-files += $(code.cpp-files)

# Object file variables
# All the .o files that come from cpp files
code.cpp-files.o = $(code.cpp-files:.cpp=.o)
PROJECT.cpp-files.o = $(PROJECT.cpp-files:.cpp=.o)
CLEAN_FILES += $(PROJECT.cpp-files.o)
DEPEND_FILES += $(PROJECT.cpp-files.o:.o=.d)
MAKE_PARENT_WHEN_NECESSARY += $(PROJECT.cpp-files.o)



# link with intermediate archive
BINARY=$(OUTPUT_DIR)/lib$(PROJECT_NAME).so
CLEAN_FILES += $(BINARY) $(BINARY).dbg $(OUTPUT_DIR)/$(PROJECT_NAME).map
LINK_ARCHIVE =  lib$(PROJECT_NAME).a
CLEAN_FILES += $(LINK_ARCHIVE)
$(LINK_ARCHIVE): $(PROJECT.cpp-files.o)
$(BINARY) : $(LINK_ARCHIVE)
code : $(BINARY)

#elfchk
$(BINARY:$(suffix $(BINARY))=.elfchk) : $(BINARY)
CLEAN_FILES += $(BINARY:$(suffix $(BINARY))=.elfchk)
