# file: tkuti.tcl
# miscellaneous Tk utilities.
#
# $Header: /baseline/SNACC/tcl-lib/tkuti.tcl,v 1.1.1.1 2000/08/21 20:35:46 leonberp Exp $
# $Log: tkuti.tcl,v $
# Revision 1.1.1.1  2000/08/21 20:35:46  leonberp
# First CVS Version of SNACC.
#
# Revision 1.1  1997/01/01 23:12:03  rj
# first check-in
#

proc getpos {w xn yn} \
{
  upvar $xn x $yn y
  set geom [wm geometry $w]
  scan $geom {%dx%d+%d+%d} w h x y
}
