// file: .../c++-lib/src/asn-type.C  - Abstract class that all ASN.1 types are derived from
//               Design motivated by ANY type.
//
//               Runtime cost in speed and space for virtual fcns will
//               hopefully not be too bad
//
//               If your ASN.1 code does not use ANY or ANY DEFIND BY
//               types then you could  make the BEnc, BDec and Clone
//               non-virtual in the AsnType to improve performance.
//               (undef SUPPORT_ANY_TYPE)
//
//               NOTE: The virtual encode/decode/print etc fcns
//               could be purely virtual (= 0) creating an abstract class
//               but the ANY handling code needs to instantiate the AsnType
//               base class (via Cloning).   Also it allows for default
//               error reporting for ANY types that have not been
//               instantiated properly.
//
// Copyright (C) 1992 Michael Sample and the University of British Columbia
//
// This library is free software; you can redistribute it and/or
// modify it provided that this copyright/license information is retained
// in original form.
//
// If you modify this file, you must clearly indicate your changes.
//
// This source code is distributed in the hope that it will be
// useful, but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// MS 92
//
// $Header: /baseline/SNACC/c++-lib/src/asn-type.cpp,v 1.16 2003/01/06 16:20:07 leonberp Exp $
// $Log: asn-type.cpp,v $
// Revision 1.16  2003/01/06 16:20:07  leonberp
// Changed BDec() and BDecContent() to use const AsnBufs
//
// Revision 1.15  2002/12/17 20:27:40  leonberp
// made BEnc() and BEncContent() const
//
// Revision 1.14  2002/10/23 21:02:48  leonberp
// fixed AsnBuf references and fixed clock skew problem
//
// Revision 1.13  2002/10/23 10:51:10  mcphersc
// Changed BUF_TYPE to AsnBuf
//
// Revision 1.12  2002/09/25 13:56:15  vracarl
// fixed a typo
//
// Revision 1.11  2002/09/25 13:36:42  vracarl
// made asn_buf fixes
//
// Revision 1.10  2002/05/29 19:26:06  leonberp
// removed PDU_MEMBERS_MACRO and added BDecPDU and BEncPDU to AsnType
//
// Revision 1.9  2002/05/10 16:39:36  leonberp
// latest changes for release 2.2
// includes integrating asn-useful into C & C++ runtime library, the compiler changes that go along with that, SnaccException changes for C++ runtime and compiler
//
// Revision 1.8  2001/08/29 22:04:19  leonberp
// enchanced Clone() to allocate a new pointe AND COPY the object
//
// Revision 1.7  2001/07/16 15:53:18  rwc
// MS Win32 mods to recent changes by Pierce (for Unix/Linux and Namespace updates).
//
// Revision 1.6  2001/07/12 19:33:40  leonberp
// Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
//
// Revision 1.5  2001/06/28 21:38:29  rwc
// Updated to remove referneces to vdacerr, which originally replaced the cerr standard error output.
// Updated all references in macros and source that printed to vdacerr.  All code now performs an
// ASN_THROW(...) exception.
//
// Revision 1.4  2001/06/28 15:29:46  rwc
// ADDED "SNACCASN" namespace definition to all SNACC data structures.
// This should not affect most applications since we do not have any name
// conflicts.
// ALSO, combined all ASN primitive data type includes into asn-incl.h.
//
// Revision 1.3  2001/06/18 17:47:44  rwc
// Updated to reflect newly added C++ Exception error handling, instead of "C" longjmp and setjmp calls.
// Changes made to both the compiler and the SNACC C++ run-time library.
//
// Revision 1.2  2000/10/16 18:10:38  rwc
// removed most warnings from C++-lib, some C-lib.
//
// Revision 1.1.1.1  2000/08/21 20:36:09  leonberp
// First CVS Version of SNACC.
//
// Revision 1.4  1997/01/01 20:13:55  rj
// "virtual" removed from functions. (fix due to changed C++ language.)
//
// Revision 1.3  1995/07/24  20:35:21  rj
// _getref() gets an additional optional argument to faciliate the different member access semantics of TclGetVal() and TclSetVal().
//
// additional function TclUnsetVal() to delete OPTIONAL members and SEQUENCE OF and SET OF list elements.
// returns an error for all other types.
//
// #if TCL ... #endif wrapped into #if META ... #endif
//
// call constructor with additional pdu and create arguments.
//
// changed `_' to `-' in file names.
//
// Revision 1.2  1994/10/08  04:18:31  rj
// code for meta structures added (provides information about the generated code itself).
//
// code for Tcl interface added (makes use of the above mentioned meta code).
//
// virtual inline functions (the destructor, the Clone() function, BEnc(), BDec() and Print()) moved from inc/*.h to src/*.C because g++ turns every one of them into a static non-inline function in every file where the .h file gets included.
//
// made Print() const (and some other, mainly comparison functions).
//
// several `unsigned long int' turned into `size_t'.
//
// Revision 1.1  1994/09/13  14:18:45  rj
// inline functions moved from asn_type.h to asn_type.C.
// functions that are called upon error only don't need to be that fast.
//
// Revision 1.2  1994/08/28  10:00:57  rj
// comment leader fixed.
//
// Revision 1.1  1994/08/28  09:20:44  rj
// first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.

#include "asn-incl.h"

_BEGIN_SNACC_NAMESPACE

AsnType::~AsnType()
{
}

void AsnType::Print (std::ostream &os) const
{
   os << "ERROR - Attempt to print an improperly formed ANY type (programming error)." 
      << std::endl;
}

bool AsnType::BEncPdu (AsnBuf &b, AsnLen &bytesEncoded) const
{
   try 
   {
   	bytesEncoded = BEnc (b);
  	return true;
   }
   catch (...)
   {
      return false;
   }
}

bool AsnType::BDecPdu (const AsnBuf &b, AsnLen &bytesDecoded)
{
	try
   {
      bytesDecoded = 0;
      {		  
         BDec (b, bytesDecoded);
	     return true;
      }
   }
   catch (...)
   {
      return false;
   }
}

#if META

const AsnTypeDesc AsnType::_desc (NULL, NULL, false, AsnTypeDesc::VOID, NULL);

const AsnTypeDesc *AsnType::_getdesc() const
{
  return &_desc;
}

AsnType	*AsnType::_getref (const char *membername, bool create)
{
  return NULL;
}

const char *AsnType::_typename() const
{
  return _desc.typenames[_getdesc()->type];
}

#if TCL

int AsnType::TclGetDesc (Tcl_DString *valstr) const
{
  return TCL_OK;
}

int AsnType::TclGetVal (Tcl_Interp *interp) const
{
  Tcl_AppendResult (interp, "can't get value from ", _typename(), NULL);
  return TCL_ERROR;
}

int AsnType::TclSetVal (Tcl_Interp *interp, const char *)
{
  Tcl_AppendResult (interp, "can't set value in ", _typename(), NULL);
  return TCL_ERROR;
}

int AsnType::TclUnsetVal (Tcl_Interp *interp, const char *)
{
  Tcl_AppendResult (interp, "can't unset member(s) in ", _typename(), NULL);
  return TCL_ERROR;
}

#endif /* TCL */
#endif /* META */

_END_SNACC_NAMESPACE
