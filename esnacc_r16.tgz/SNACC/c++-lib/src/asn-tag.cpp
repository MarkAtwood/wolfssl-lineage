// file: .../c++-lib/src/asn-tag.C -  ASN.1 tag manipulation routines
//
// MS 92/06/18
// Copyright (C) 1992 Michael Sample and the University of British Columbia
//
// This library is free software; you can redistribute it and/or
// modify it provided that this copyright/license information is retained
// in original form.
//
// If you modify this file, you must clearly indicate your changes.
//
// This source code is distributed in the hope that it will be
// useful, but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// $Header: /baseline/SNACC/c++-lib/src/asn-tag.cpp,v 1.10 2003/10/16 11:44:05 nicholar Exp $

#include "asn-incl.h"

_BEGIN_SNACC_NAMESPACE

/*
 * Decode a BER Tag from the given buffer.  Error is
 * flagged if the tag is too long or if a read error occurs.
 */
AsnTag
BDecTag (const AsnBuf &b, AsnLen &bytesDecoded)
{
	FUNC("BDecTag()");

	// Read first byte and shift it into the AsnTag
	unsigned char tagByte = b.GetUByte();
	AsnTag tagId = tagByte << ((TB - 1) * 8);
	bytesDecoded++;

	// Check if long tag format (last 5 bits all set) */
	if ((tagByte & 0x1f) == 0x1f)
	{
		int i = 1;
		do
		{
			// Read next tag byte
			tagByte = b.GetUByte();
			tagId |= tagByte << ((TB - i - 1) * 8);
			bytesDecoded++;
			i++;
		}
		while ((tagByte & 0x80) && (i < TB));

		// Check that tag isn't too long
		if (tagByte & 0x80)
			throw EXCEPT("tag value overflow", INVALID_TAG);
	}

	return tagId;
} /* BDecTag */


_END_SNACC_NAMESPACE
