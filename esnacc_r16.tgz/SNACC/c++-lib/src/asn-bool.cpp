// file: .../c++-lib/src/asn-bool.C - methods for AsnBool (ASN.1 BOOLEAN) class
//
// MS 92/06/16
// Copyright (C) 1992 Michael Sample and the University of British Columbia
//
// This library is free software; you can redistribute it and/or
// modify it provided that this copyright/license information is retained
// in original form.
//
// If you modify this file, you must clearly indicate your changes.
//
// This source code is distributed in the hope that it will be
// useful, but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// $Header: /baseline/SNACC/c++-lib/src/asn-bool.cpp,v 1.12 2003/01/06 16:20:07 leonberp Exp $
// $Log: asn-bool.cpp,v $
// Revision 1.12  2003/01/06 16:20:07  leonberp
// Changed BDec() and BDecContent() to use const AsnBufs
//
// Revision 1.11  2002/12/17 20:27:40  leonberp
// made BEnc() and BEncContent() const
//
// Revision 1.10  2002/10/23 21:02:48  leonberp
// fixed AsnBuf references and fixed clock skew problem
//
// Revision 1.9  2002/10/23 10:51:10  mcphersc
// Changed BUF_TYPE to AsnBuf
//
// Revision 1.8  2002/09/25 13:42:07  vracarl
// made asn_buf fixes
//
// Revision 1.7  2002/05/10 16:39:34  leonberp
// latest changes for release 2.2
// includes integrating asn-useful into C & C++ runtime library, the compiler changes that go along with that, SnaccException changes for C++ runtime and compiler
//
// Revision 1.6  2001/08/29 22:04:18  leonberp
// enchanced Clone() to allocate a new pointe AND COPY the object
//
// Revision 1.5  2001/07/12 19:33:36  leonberp
// Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
//
// Revision 1.4  2001/06/28 15:29:48  rwc
// ADDED "SNACCASN" namespace definition to all SNACC data structures.
// This should not affect most applications since we do not have any name
// conflicts.
// ALSO, combined all ASN primitive data type includes into asn-incl.h.
//
// Revision 1.3  2001/06/18 17:47:43  rwc
// Updated to reflect newly added C++ Exception error handling, instead of "C" longjmp and setjmp calls.
// Changes made to both the compiler and the SNACC C++ run-time library.
//
// Revision 1.2  2000/10/16 18:10:37  rwc
// removed most warnings from C++-lib, some C-lib.
//
// Revision 1.1.1.1  2000/08/21 20:36:08  leonberp
// First CVS Version of SNACC.
//
// Revision 1.7  1997/02/28 13:39:44  wan
// Modifications collected for new version 1.3: Bug fixes, tk4.2.
//
// Revision 1.6  1997/02/16 20:26:03  rj
// check-in of a few cosmetic changes
//
// Revision 1.5  1995/07/24  20:10:43  rj
// call constructor with additional pdu and create arguments.
//
// #if TCL ... #endif wrapped into #if META ... #endif
//
// changed `_' to `-' in file names.
//
// Revision 1.4  1994/10/08  04:18:22  rj
// code for meta structures added (provides information about the generated code itself).
//
// code for Tcl interface added (makes use of the above mentioned meta code).
//
// virtual inline functions (the destructor, the Clone() function, BEnc(), BDec() and Print()) moved from inc/*.h to src/*.C because g++ turns every one of them into a static non-inline function in every file where the .h file gets included.
//
// made Print() const (and some other, mainly comparison functions).
//
// several `unsigned long int' turned into `size_t'.
//
// Revision 1.3  1994/08/31  23:30:48  rj
// use the bool built-in where applicable, and a replacement type otherwise.
//
// Revision 1.2  1994/08/28  10:01:11  rj
// comment leader fixed.
//
// Revision 1.1  1994/08/28  09:20:58  rj
// first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.


#include "asn-incl.h"

_BEGIN_SNACC_NAMESPACE


AsnLen AsnBool::BEnc (AsnBuf &b) const
{
    AsnLen l;
    l = BEncContent (b);
    BEncDefLenTo127 (b, l);
    l++;
    l += BEncTag1 (b, UNIV, PRIM, BOOLEAN_TAG_CODE);
    return l;
}

void AsnBool::BDec (const AsnBuf &b, AsnLen &bytesDecoded)
{
   FUNC("AsnBool::BDec()");

   AsnLen elmtLen;
   AsnTag tagId;

   tagId = BDecTag (b, bytesDecoded); 
   if (tagId != MAKE_TAG_ID (UNIV, PRIM, BOOLEAN_TAG_CODE))
   {
      throw InvalidTagException(typeName(), tagId, STACK_ENTRY);
   }
   elmtLen = BDecLen (b, bytesDecoded);

   BDecContent (b, MAKE_TAG_ID (UNIV, PRIM, BOOLEAN_TAG_CODE), elmtLen, bytesDecoded);
}

// Decodes the content of a BOOLEAN and sets this object's value
// to the decoded value. Flags an error if the length is wrong
// or a read error occurs.
void AsnBool::BDecContent (const AsnBuf &b, AsnTag /*tagId*/, AsnLen elmtLen, AsnLen &bytesDecoded)
{
   FUNC("AsnBool::BDecContent");

   if (elmtLen != 1)
   {
      throw BoundsException("AsnBool max length exceeded", STACK_ENTRY);
   }

   value = (b.GetByte() != 0);
   bytesDecoded++;

//   if (b.ReadError())
//   {
//      throw SNACC_EXCEPT("decoded past end of data ");
//   }
}

AsnLen AsnBool::BEncContent (AsnBuf &b) const
{
    b.PutByteRvs ((unsigned char)(value ? 0xFF : 0));
    return 1;
}

// print the BOOLEAN's value in ASN.1 value notation to the given ostream
void AsnBool::Print (std::ostream &os) const
{
  os << (value ? "TRUE" : "FALSE");
}

void AsnBool::PrintXML (std::ostream &os, const char *lpszTitle) const 
{
   os << "<BOOLEAN>"; 
   if (lpszTitle) os << lpszTitle; 
   os << "-"; 
   Print(os); os << "</BOOLEAN>\n"; 
}


#if META

const AsnTypeDesc AsnBool::_desc (NULL, NULL, false, AsnTypeDesc::BOOLEAN, NULL);

const AsnTypeDesc *AsnBool::_getdesc() const
{
  return &_desc;
}

#if TCL

int AsnBool::TclGetVal (Tcl_Interp *interp) const
{
  Tcl_SetResult (interp, value ? "TRUE" : "FALSE", TCL_STATIC);
  return TCL_OK;
}

int AsnBool::TclSetVal (Tcl_Interp *interp, const char *valstr)
{
  int valval;

  if (Tcl_GetBoolean (interp, (char*) valstr, &valval) != TCL_OK)
    return TCL_ERROR;

  value = valval;

  return TCL_OK;
}

#endif /* TCL */
#endif /* META */

_END_SNACC_NAMESPACE
