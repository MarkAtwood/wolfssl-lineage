#ifndef WIN32
#include <string.h>
#endif
#include "asn-incl.h"

_BEGIN_SNACC_NAMESPACE

// Copy Constructor
//
// copy m_str and pFileSeg
AsnOcts::AsnOcts(const AsnOcts &o)
{
   m_str = o.m_str;
   if (o.m_pFileSeg != NULL)
      m_pFileSeg = new AsnFileSeg(*o.m_pFileSeg);
   else
      m_pFileSeg = NULL;
}

AsnOcts::~AsnOcts()
{
   if (m_pFileSeg != NULL)
      delete m_pFileSeg;
}

// Returns the length of the AsnOcts.
size_t AsnOcts::Len() const
{ 
   size_t result = 0;

   result = m_str.length();

   if (m_pFileSeg != NULL)
      result = m_pFileSeg->size();
   
   return result;
}

// Returns the data
const std::string & AsnOcts::data() const 
{ 
	char ch;

   // IF the octet string is not in an AsnFileSeg just return the string
   //
   if (m_pFileSeg == NULL)
   {
		return m_str;
   }
   // ELSE if the octet string is in an AsnFileSeg read it into the 
   // string then return it. Destroy the AsnFileSeg in the process.
   //
	else
   {
      m_pFileSeg->pubseekoff(0, std::ios_base::beg, std::ios_base::in);  
		while ((ch = (char)m_pFileSeg->snextc()) != EOF)
		{
			m_str += ch;
			ch = (char)m_pFileSeg->snextc();  
		}
      delete m_pFileSeg;
      m_pFileSeg = NULL;
		return m_str;
	}
}

// Returns the data
const char * AsnOcts::c_str() const 
{ 
  return data().c_str();
}

const unsigned char* AsnOcts::c_ustr() const
{
   return (unsigned char *) data().data();
}

 // Initialize the AsnOcts with a char * and length.
 // copies the string str.
 void AsnOcts::Set (const char *str, size_t len)
 {
	m_str.assign(str, len);
 }

// Prints the AsnOcts to the given ostream in Value Notation.
void AsnOcts::PrintXML (std::ostream &os, const char *lpszTitle,
                        const char *lpszType) const
{
   if (lpszType)
     os << "<" << lpszType << ">";
   else
     os << "<OCTET_STRING>";
   if (lpszTitle)
      os << lpszTitle;
   os << "-";
   Print(os);
   //PrintXMLSupport(&os, ((AsnOcts *)this)->Access(), octetLen);
   if (lpszType)
     os << "</" << lpszType << ">\n";
   else
     os << "</OCTET_STRING>\n";
}

// Prints the AsnOcts to the given ostream in Value Notation.
void AsnOcts::Print (std::ostream &os) const
{
    int i;
    os << "'";
    for (i = 0; i < (int)Len(); i++)
        os << TO_HEX (c_ustr()[i] >> 4) << (TO_HEX (c_ustr()[i]));

    os << "'H  -- \"";

    /* put printable parts in ASN.1 comment */
    for (i = 0; i < (int)Len(); i++)
    {
        if (isspace ((unsigned char)c_ustr()[i]) || ! isprint(c_ustr()[i]))
            os << ".";  /* newlines->space (so don't screw up ASN.1 comment) */
        else
            os << c_ustr()[i];
    }
    os << "\" --";
} /* AsnOcts::Print */


AsnLen AsnOcts::BEncContent (AsnBuf &b) const
{
   if (m_pFileSeg != NULL)
      b.PutFileSeg(m_pFileSeg);
   else
      b.PutSegRvs(m_str.data(), m_str.length());

    return Len();
}

// Decodes a BER OCTET STRING value and puts it in this object.
// Constructed OCTET STRINGs are always concatenated into primitive ones.
void AsnOcts::BDecContent (const AsnBuf &b, AsnTag tagId, AsnLen elmtLen, AsnLen &bytesDecoded)
{
    FUNC("AsnOcts::BDecContent()");

    if (elmtLen != 0)
    {
       /*
        * tagId is encoded tag shifted into long int.
        * if CONS bit is set then constructed octet string
        */
       if (tagId & 0x20000000)
       {
           BDecConsOcts (b, elmtLen, bytesDecoded);
       }
       else /* primitive octet string */
       {
         if (elmtLen == INDEFINITE_LEN)
            throw BoundsException("indefinite length on primitive", STACK_ENTRY);

			/** PIERCE: commented out until further testing is done 
         else if (elmtLen > MAX_OCTS)  // use a filebuf instead of memory
	      {
             m_pFileSeg = b.GetFileSeg(elmtLen);
	      }
	      else                          // use memory
	      {
            b.GetSeg(m_str, elmtLen);
	      }
			**/

			b.GetSeg(m_str,elmtLen);

         bytesDecoded += elmtLen;
       }
    }
    
} /* AsnOcts::BDecContent */

AsnLen AsnOcts::BEnc (AsnBuf &b) const
{
    AsnLen l;
    l =  BEncContent (b);
    l += BEncDefLen (b, l);
    l += BEncTag1 (b, UNIV, PRIM, OCTETSTRING_TAG_CODE);
    return l;
}

void AsnOcts::BDec (const AsnBuf &b, AsnLen &bytesDecoded)
{
    FUNC("AsnOcts::BDec()");

    AsnLen elmtLen;
    AsnTag tag;

    tag = BDecTag (b, bytesDecoded);
    if ((tag != MAKE_TAG_ID (UNIV, PRIM, OCTETSTRING_TAG_CODE)) &&
	(tag != MAKE_TAG_ID (UNIV, CONS, OCTETSTRING_TAG_CODE)))
    {
        throw InvalidTagException(typeName(), tag, STACK_ENTRY);
    }
    elmtLen = BDecLen (b, bytesDecoded);
    BDecContent (b, tag, elmtLen, bytesDecoded);
}


/*
 * decodes a seq of universally tagged octets until either EOC is
 * encountered or the given len decoded.  Return them in a
 * single concatenated octet string
 */
void AsnOcts::BDecConsOcts (const AsnBuf &b, AsnLen elmtLen, AsnLen &bytesDecoded)
{
   ConsStringDeck strDeck;

   strDeck.Fill(b, elmtLen, bytesDecoded);
   strDeck.Collapse( m_str );

}  /* BDecConsOcts */

void ConsStringDeck::Fill(const AsnBuf &b, AsnLen elmtLen, AsnLen &bytesDecoded)
{
    FUNC("ConsStringDeck::Fill()");

    unsigned char *strPtr;
    AsnLen totalElmtsLen1 = 0;
    unsigned long tagId1;
    AsnLen elmtLen1 = elmtLen;

    for (; (totalElmtsLen1 < elmtLen) || (elmtLen == INDEFINITE_LEN);)
    {
        tagId1 = BDecTag (b, totalElmtsLen1);

        if (tagId1 == EOC_TAG_ID)
        {  
           // We may have found a EOC TAG
           // if next byte is a 0 then is an EOC tag
           if (b.GetByte() == 0)
           {
              ++totalElmtsLen1;

              // this is only valid if the length is indefinite
              if (elmtLen != INDEFINITE_LEN)
                 throw EXCEPT("EOC tag found without indefinite length encoding", DECODE_ERROR);
              break;
           }
           else
           {
              throw EXCEPT("Partial EOC tag found", DECODE_ERROR);
           }
        }
        else if (tagId1 == MAKE_TAG_ID (UNIV, PRIM, m_baseTag))
        {
            /*
             * primitive part of string, put references to piece (s) in
             * str stack
             */
             elmtLen1 = BDecLen (b, totalElmtsLen1);

		     if(elmtLen1 == INDEFINITE_LEN) 
                throw InvalidTagException("Primitive String can not have INDEFINITE_LEN", tagId1, STACK_ENTRY);   
           
             strPtr = (unsigned char *)b.GetSeg(elmtLen1);
             push_back( StringPair(strPtr, elmtLen1) );
             totalElmtsLen1 += elmtLen1;
        }
        else if (tagId1 == MAKE_TAG_ID (UNIV, CONS, m_baseTag))
        {
            /*
             * primitive part of string, put references to piece (s) in
             * str stack
             */
             elmtLen1 = BDecLen(b, totalElmtsLen1);
				 
			 if ((elmtLen1 != INDEFINITE_LEN) && (elmtLen1 + totalElmtsLen1) > elmtLen)
			   throw BoundsException("Invalid constructed object", STACK_ENTRY);

				 Fill(b, elmtLen1, totalElmtsLen1);
        }
        else if (m_baseTag == 0 && TAG_IS_CONS(tagId1))
        {
           /* Handle set and sequence 
            */
           elmtLen1 = BDecLen(b, totalElmtsLen1);

		   if ((elmtLen1 != INDEFINITE_LEN) && (elmtLen1 + totalElmtsLen1) > elmtLen)
		      throw BoundsException("Invalid constructed object", STACK_ENTRY);

           Fill(b, elmtLen1, totalElmtsLen1);
        }
         else if (m_baseTag == 0)
        {
           elmtLen1 = BDecLen (b, totalElmtsLen1);
            
		   if (elmtLen1 == INDEFINITE_LEN) 
            throw InvalidTagException("Primitive String can not have INDEFINITE_LEN", tagId1, STACK_ENTRY);   
           
		   if(elmtLen1 > b.length())
            throw InvalidTagException("Primitive String, length", tagId1, STACK_ENTRY);              

           strPtr = (unsigned char *)b.GetSeg(elmtLen1);
           push_back( StringPair(strPtr, elmtLen1) );
           totalElmtsLen1 += elmtLen1;
        }
        else
            throw InvalidTagException("Constructed String", tagId1, STACK_ENTRY);              
    } /* end of for */

    bytesDecoded += totalElmtsLen1;
}

void ConsStringDeck::Collapse(std::string &str)
{
    iterator i;
    i = begin();
    for (; i != end(); i++)
    {
       str.append((char *)i->first, i->second);
    }

}

ConsStringDeck::~ConsStringDeck() 
{
   iterator i;
   i = begin();
   for (; i != end(); i++)
   {
      delete i->first;
      i->first = NULL;
   }
}

bool AsnOcts::operator == (const AsnOcts &o) const
{
   if ( (o.Len() == Len()) && (memcmp(o.c_ustr(), c_ustr(), Len()) == 0) )
         return true;
   return false;
}

bool AsnOcts::operator != (const AsnOcts &o) const
{
   return !operator ==(o);
}


_END_SNACC_NAMESPACE
