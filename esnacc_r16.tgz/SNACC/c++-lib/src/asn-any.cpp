// file: .../c++-lib/src/asn-any.C
//
// MS 92
// Copyright (C) 1992 Michael Sample and the University of British Columbia
//
// This library is free software; you can redistribute it and/or
// modify it provided that this copyright/license information is retained
// in original form.
//
// If you modify this file, you must clearly indicate your changes.
//
// This source code is distributed in the hope that it will be
// useful, but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//
#include "asn-incl.h"

_BEGIN_SNACC_NAMESPACE

Table *AsnAny::oidHashTbl = NULL;
Table *AsnAny::intHashTbl = NULL;
long SM_DetermineLengthBuf(AsnBuf &SNACCinputBuf, AsnLen elmtLen0, 
                           int bFirstTimeFlag=false);
long SM_DetermineLengthBuf(AsnBuf &SNACCinputBuf);

class AnyTableDestructor
{
public:
   ~AnyTableDestructor() { AsnAny::AsnAnyDestroyHashTbls(); }
};

static AnyTableDestructor __anyTableDestructor;


// Define this ANY value's type to the one that the given id hashes
// to in the ANY table.
void
AsnAny::SetTypeByInt (const AsnInt& id) const
{
    Hash hash;
    void *anyInfo;

    /* use int as hash string */
    hash = MakeHash ((const char*)id.c_str(), id.length());
    if (CheckForAndReturnValue (intHashTbl, hash, &anyInfo))
        ai = (AnyInfo*) anyInfo;
    else
        ai = NULL; /* indicates failure */

} /* SetAnyTypeByInt */

// Define this ANY value's type to the one that the given id hashes
// to in the ANY table.
void AsnAny::SetTypeByOid (const AsnOid &id) const
{
    Hash hash;
    void *anyInfo;

    /* use encoded oid as hash string */
    hash = MakeHash (id.Str(), id.Len());
    if (CheckForAndReturnValue (oidHashTbl, hash, &anyInfo))
        ai = (AnyInfo*) anyInfo;
    else
        ai = NULL; /* indicates failure */
    //RWC;4/16/01; lastly, clear ->value in case loaded previously.

} /* SetAnyTypeByOid */



// Given an integer, intId, to hash on, the type and it's anyId
// are installed in the integer id hash tbl
void
AsnAny::InstallAnyByInt (AsnIntType intId, int anyId, AsnType *type)
{
    AnyInfo *a;
    Hash h;

    a = new AnyInfo;
    //  Oid will be NULL and 0 len by default constructor
    a->anyId = anyId;
    a->intId = intId;
    a->typeToClone = type;

    if (AsnAny::intHashTbl == NULL)
        AsnAny::intHashTbl = InitHash();

	 AsnInt intval = intId;
    h = MakeHash ((const char*)intval.c_str(), intval.length());
    if ( ! Insert (AsnAny::intHashTbl, a, h) )
    {
       delete a->typeToClone;
       delete a;
    }

}  /* InstallAnyByInt */


//
//
void AsnAny::AsnAnyDestroyHashTbls() // Added for static call to destroy special; at end.
{
   if (oidHashTbl)
   {
       AsnAnyDestroyHashTbl(oidHashTbl);
   }
   if (intHashTbl)
   {
       AsnAnyDestroyHashTbl(intHashTbl);
   }
}

//
//
void AsnAny::AsnAnyDestroyHashTbl(Table *&pHashTbl) // Added for static call to destroy special; at end.
{
    HashSlot *pHash;
    AnyInfo *pA;
    int i;
    for (i=0; i < TABLESIZE; i++)
         if ((*pHashTbl)[i])
         {
            pHash = (HashSlot *)(*pHashTbl)[i];
            pA = (AnyInfo *)pHash->value;
            if (pHash->table)
              AsnAnyDestroyHashTbl(pHash->table);
            else if (pA->typeToClone)
            {
              delete pA->typeToClone;
              delete pA;
            }
            delete pHash;
         }
      delete[] pHashTbl;
      pHashTbl = NULL;
}
//

// given an OBJECT IDENTIFIER, oid, to hash on, the type and it's anyId
// are installed in the OBJECT IDENTIFIER id hash tbl
void
AsnAny::InstallAnyByOid (AsnOid &oid, int anyId, AsnType *type)
{
    AnyInfo *a;
    Hash h;

    a =  new AnyInfo;
    a->anyId = anyId;
    a->oid = oid;  // copy given oid
    a->typeToClone = type;

    h = MakeHash (oid.Str(), oid.Len());

    if (AsnAny::oidHashTbl == NULL)
        AsnAny::oidHashTbl = InitHash();

    if (! Insert (AsnAny::oidHashTbl, a, h))
    {
       delete a->typeToClone;
       delete a;
    }

}  /* InstallAnyByOid */


// FUNCTION: BEnc()
// PUPROSE: Encode ANY DEFINED BY if "value" is present otherwise encode ANY if 
//          anyBuf is present.  If neither is present an exception is thrown.
//
AsnLen
AsnAny::BEnc (AsnBuf &b) const
{
   FUNC("AsnAny::BEnc()");

   if (value != NULL)
      return value->BEnc(b);
   else if (anyBuf != NULL)
   {
		anyBuf->ResetMode();
		b.insert(*anyBuf);
		return anyBuf->length();

#ifdef OLD
      std::string data;
      
		// PIERCE: make this more efficient
      //
      anyBuf->ResetMode();
      anyBuf->GetSeg(data);
      anyBuf->ResetMode();
      b.PutSegRvs(data.data(), data.length());
      return anyBuf->length();
#endif
   }
   else
      throw EXCEPT("Unknown any with no value", ENCODE_ERROR);
}



// BDec()
//
// Decoded ANY DEFINED BY or UNKNOWN ANY from 'b'.  If an ANY DEFINED
// BY is found it's will be decoded into value.  If an UNKNOWN ANY is
// found it's binary values will be copied into 'anyBuf'.
//
void AsnAny::BDec (const AsnBuf &b, AsnLen &bytesDecoded)
{
   FUNC("AsnAny::BDec");

   // ai will be NULL if this is an ANY (not an ANY DEFINED BY)
   if (ai == NULL)
   {             
      anyBuf = new AsnBuf;
      b.GrabAny(*anyBuf, bytesDecoded);
   }
   else
   {
      // the type is already known clone it and use it's BDec to decode the 
      // ASN.1
      //
      value = ai->typeToClone->Clone();
      if (value == NULL)
      {
         throw SnaccException(STACK_ENTRY, "typeToClone->Clone() failed", INVALID_ANY);
      }
      else
         value->BDec (b, bytesDecoded);
   }
}


void AsnAny::Print (std::ostream &os) const
{
   if (value != NULL)
      value->Print(os);
   else if (anyBuf != NULL)
   {
      os << "UNKNOWN ANY hex dump: ";
      anyBuf->hexDump(os);
   }
}

void AsnAny::PrintXML (std::ostream &os, const char *lpszTitle) const 
{
   if (lpszTitle) 
       os << "<" << lpszTitle << " type=\"ANY\">"; 
   else
       os << "<ANY>"; 
   Print(os);
   if (lpszTitle) 
       os << "</" << lpszTitle << ">\n"; 
   else
       os << "</ANY>\n"; 
}

AsnAny::~AsnAny()
{
   delete this->value;
   this->value = NULL;
   delete this->anyBuf;
   this->anyBuf = NULL;
}

AsnAny &AsnAny::operator = (const AsnAny &o) 
{ 
   FUNC("AsnAny::operator=");
   ai = o.ai;  // pointer into Any Table

   delete value;
   value = NULL;
   delete anyBuf;
   anyBuf = NULL;

   // NOW, take care of special CSM_Buffer copy, if present.
   if (o.value != NULL)
   {
      value = o.value->Clone();
      if (value == NULL)
         throw SnaccException(STACK_ENTRY,"AsnType::Clone() failed",INVALID_ANY);
   }
   else if (o.anyBuf != NULL)
   {
      anyBuf = new AsnBuf(*o.anyBuf);
   }
   return *this; 
}



extern "C" {
void SNACCDLL_API SNACC_CleanupMemory()
{
#ifndef NO_THREADS
   threadDestroy();  // ONLY necessary if a thread lock is created (and it is 
                     //  important to clear all memory leaks before exiting.
#endif
   AsnAny::AsnAnyDestroyHashTbls();   // FINAL call, to clear static tables, 
                                      //  before exiting.
}
}     // END extern "C"

_END_SNACC_NAMESPACE
