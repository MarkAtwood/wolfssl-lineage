// file: .../c++-lib/src/asn-oid.C   - OBJECT IDENTIFIER
//
//  Mike Sample
//  92/07/02
// Copyright (C) 1992 Michael Sample and the University of British Columbia
//
// This library is free software; you can redistribute it and/or
// modify it provided that this copyright/license information is retained
// in original form.
//
// If you modify this file, you must clearly indicate your changes.
//
// This source code is distributed in the hope that it will be
// useful, but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// $Header: /baseline/SNACC/c++-lib/src/asn-oid.cpp,v 1.53 2003/10/08 16:34:38 leonberp Exp $

#ifndef WIN32
#include <string.h>
#endif
#include "asn-incl.h"
#if TCL
#include <strstream.h>
#endif

#ifdef SCO_SV
int SCOisdigit (int c)
{
     if (c >= '0' && c <= '9')
         return (1);
     return (0);
}

#define isdigit SCOisdigit

#endif

_BEGIN_SNACC_NAMESPACE


// Initializes an AsnOid with a string and it's length.
// The string should hold the encoded OID.
// The string is copied
void AsnOid::Set (const char *encOid, size_t len)
{
	if (encOid != oid)
	{
		delete[] oid;
		delete[] m_lpszOidString;
		m_lpszOidString = NULL;

		octetLen = len;
		oid = new char[octetLen];
		memcpy (oid, encOid, octetLen);
	}
}


// Inits an AsnOid from another OID.
// The oid string is copied.
void AsnOid::Set (const AsnOid &o)
{
	if (&o != this)
	{
		Set(o.oid, o.octetLen);
		if (o.m_lpszOidString != NULL)
		{
			m_lpszOidString = new char[strlen(o.m_lpszOidString)+1];
			strcpy(m_lpszOidString, o.m_lpszOidString);
        }
    }
}


// Given an array of unsigned long integers, an AsnOid is built.
void AsnOid::Set (unsigned long arcNumArr[], long arrLength)
{
    FUNC("AsnOid::Set()");

    char *tmpBuf=NULL;
    size_t totalLen;
    size_t elmtLen;
    long int tmpArcNum;
    long int headArcNum;
    int i;

    if ((arcNumArr == NULL) || (arrLength < 1))
    {
       throw ParameterException("Invalid arguments in AsnOid::Set()", STACK_ENTRY);
    }

    char *buf = new char[arrLength*5];  // Sized according to length
    tmpBuf = buf;

    // munge together first oid arc numbers
    headArcNum = tmpArcNum = (arcNumArr[0] * 40) + arcNumArr[1];

    // figure encoded length for this arc number
    for (elmtLen = 1; (tmpArcNum >>= 7) != 0; elmtLen++)
	 ;

    // write bytes except the last/least significant of the head arc number
    // more bit is on
    totalLen = elmtLen;
    for (i = 1; i < (int)elmtLen; i++)
    {
        *(tmpBuf++) = (char)(0x80 | (headArcNum >> ((elmtLen-i)*7)));
    }

    // write least significant (more bit is off)
    *(tmpBuf++) = (char)(0x7f & headArcNum);

    // repeat for the rest of the arc numbers
    for (i = 2; (i < arrLength) && (arcNumArr[i] != (unsigned long)-1); i++)
    {
        tmpArcNum = arcNumArr[i];
        for (elmtLen = 1; (tmpArcNum >>= 7) != 0; elmtLen++)
	    ;
        totalLen += elmtLen;
        tmpArcNum = arcNumArr[i];
        for (int j = 1; j < (int)elmtLen; j++)
        {
            *(tmpBuf++) = (char)(0x80 | (tmpArcNum >> ((elmtLen-j)*7)));
        }
        *(tmpBuf++) = (char)(0x7f & tmpArcNum);
    }

	Set(buf, totalLen);
	delete[] buf;

}  /* AsnOid::Set */


// returns the number of arc numbers in the OID value
unsigned long int AsnOid::NumArcs() const
{
    int i;
    int numArcs;

    for (numArcs=0, i=0; i < (int)octetLen; )
    {
        // skip octets in this arc num with the 'more' bit set
        for (; (i < (int)octetLen) && (oid[i] & 0x80); i++)
	    ;

        // skip last octet in this arc num (no more bit)
        i++;

        numArcs++;
    }

    // add one to return value because the first two arcs are
    // crunched together into a single one.
    return numArcs +1;

}  /* AsnOid::NumArcs */


bool AsnOid::OidEquiv (const AsnOid &o) const
{
    return ((o.octetLen == octetLen) && (memcmp (o.oid, oid, octetLen) == 0));
}


// Decodes the content of a BER OBJECT IDENTIFIER value and puts
// the results in this AsnOid object.
void AsnOid::BDecContent (const AsnBuf &b, AsnTag /* tagId */, AsnLen elmtLen, AsnLen &bytesDecoded)
{
    FUNC("AsnOid::BDecContent()");
    
    if (elmtLen == INDEFINITE_LEN)
       throw BoundsException("indefinite length on primitive", STACK_ENTRY);

    if (elmtLen < 1)
        throw OidException("invalid length of OID", STACK_ENTRY);

	delete[] oid;
	oid = NULL;
	delete[] m_lpszOidString;
	m_lpszOidString = NULL;

    /* treat like primitive octet string */
    octetLen = elmtLen;
    oid =  new char[elmtLen];
	if (oid == NULL)
       throw MemoryException(elmtLen, "oid", STACK_ENTRY);
    b.GetSeg (oid, elmtLen);

    bytesDecoded += elmtLen;
} /* AsnOid::BDecContent */

AsnLen AsnOid::BEnc (AsnBuf &b) const
{
    AsnLen l;
    l =  BEncContent (b);
    l += BEncDefLen (b, l);
    l += BEncTag1 (b, UNIV, PRIM, OID_TAG_CODE);
    return l;
}

void AsnOid::BDec (const AsnBuf &b, AsnLen &bytesDecoded)
{
    FUNC("AsnOid::BDec()");

    AsnLen elmtLen;
    AsnTag tagId;
    
    tagId = BDecTag(b, bytesDecoded);

    if (tagId != MAKE_TAG_ID (UNIV, PRIM, OID_TAG_CODE))
    {
        throw InvalidTagException(typeName(), tagId, STACK_ENTRY);
    }
    elmtLen = BDecLen (b, bytesDecoded);

    BDecContent (b, MAKE_TAG_ID (UNIV, PRIM, OID_TAG_CODE), elmtLen, bytesDecoded);
}

AsnLen AsnOid::BEncContent (AsnBuf &b) const
{
    b.PutSegRvs (oid, octetLen);
    return octetLen;
}

// Prints an AsnOid in ASN.1 Value Notation.
// Decodes the oid to get the individual arc numbers
void AsnOid::Print (std::ostream &os) const
{
  unsigned short int firstArcNum;
  unsigned long int arcNum;
  int i;

  // print oid in
  os << "{";

  if (oid)
  {
    // un-munge first two arc numbers
    for (arcNum = 0, i=0; (i < (int)octetLen) && (oid[i] & 0x80); i++)
      arcNum = (arcNum << 7) + (oid[i] & 0x7f);

    arcNum = (arcNum << 7) + (oid[i] & 0x7f);
    i++;
    firstArcNum = (unsigned short int)(arcNum/40);
    if (firstArcNum > 2)
      firstArcNum = 2;

    os << firstArcNum  << " " << arcNum - (firstArcNum * 40);

    for (; i < (int)octetLen; )
    {
      for (arcNum = 0; (i < (int)octetLen) && (oid[i] & 0x80); i++)
	arcNum = (arcNum << 7) + (oid[i] & 0x7f);

      arcNum = (arcNum << 7) + (oid[i] & 0x7f);
      i++;
      os << " " << arcNum;
    }
  }
  else
    os << "-- void --";

  os << "}";

} // AsnOid::Print

void AsnOid::PrintXML (std::ostream &os, const char *lpszTitle) const
{
   if (lpszTitle) 
       os << "<" << lpszTitle << " type=\"OID\">"; 
   else
       os << "<OID>\n"; 
   Print(os); 
   if (lpszTitle) 
       os << "</" << lpszTitle << ">"; 
   else
       os << "</OID>\n"; 
}


#if META

const AsnOidTypeDesc AsnOid::_desc (NULL, NULL, false, AsnTypeDesc::OBJECT_IDENTIFIER, NULL);

const AsnTypeDesc *AsnOid::_getdesc() const
{
  return &_desc;
}

#if TCL

int AsnOid::TclGetVal (Tcl_Interp *interp) const
{
  if (oid)
  {
    strstream buf;
    buf << *this;
    buf.str()[strlen(buf.str())-1] = '\0';			// chop the trailing '}'
    Tcl_SetResult (interp, buf.str()+1, TCL_VOLATILE);	// copy without leading '{'
  }
  return TCL_OK;
}

int AsnOid::TclSetVal (Tcl_Interp *interp, const char *valstr)
{
  if (!*valstr)
  {
    delete[] oid;
    oid = NULL;
    octetLen = 0;
    return TCL_OK;
  }

  Args arc;
  if (Tcl_SplitList (interp, (char*)valstr, &arc.c, &arc.v) != TCL_OK)
    return TCL_ERROR;
  if (arc.c < 2)
  {
    Tcl_AppendResult (interp, "oid arc must contain at least two numbers", NULL);
    Tcl_SetErrorCode (interp, "SNACC", "ILLARC", "<2", NULL);
    return TCL_ERROR;
  }
  if (arc.c > 11)
  {
    Tcl_AppendResult (interp, "snacc limits oid arcs to no more than 11 numbers", NULL);
    Tcl_SetErrorCode (interp, "SNACC", "ILLARC", ">11", NULL);
    return TCL_ERROR;
  }

  int na[11], i;
  for (i=0; i<arc.c; i++)
    if (Tcl_GetInt (interp, arc.v[i], na+i) != TCL_OK)
      return TCL_ERROR;
  while (i < 11)
    na[i++] = -1;

  ReSet (na[0], na[1], na[2], na[3], na[4], na[5], na[6], na[7], na[8], na[9], na[10]);

  return TCL_OK;
}

#endif /* TCL */
#endif /* META */

//
//
void AsnOid::PutChar(const char *szOidCopy) // set from a number-dot null term string
{
    FUNC("AsnOid::PutChar");

    long arc=0;
    bool invalidOid = false;
    long i=0;
    bool firstDigit=true;
    char *pTmpStr = NULL;
    unsigned long *aul = NULL;
    
    // SANITY CHECK - IS THE PARAMETER NULL?
    if (szOidCopy == NULL)
    {
       throw ParameterException("szOidCopy == NULL", STACK_ENTRY);
    }
    
    // MAKE A TEMPORARY COPY THE INPUT STRING
    if ((pTmpStr = strdup(szOidCopy)) == NULL)
    {
       throw SNACC_MEMORY_EXCEPT(strlen(szOidCopy), "pTmpStr");
    }
    
    // PARSE STRING FOR PROPER FORMAT:
    //   DOES NOT BEGIN OR END WITH A DOT
    //   DOES NOT CONTAIN ANY SUCCESSIVE DOTS
    //   DOES NOT CONTAIN ANY NON-DOTS OR NON NUMERIC CHARACTERS
    if (pTmpStr[i] == '.' || strlen(pTmpStr) < 1)
    {
        invalidOid=true;
    }
    else
    {
        // LOOP THROUGH OID STRING
        for(i=0;i<(long)strlen(pTmpStr);i++)
        {
            // IF IT IS A DIGIT, IS IT THE FIRST
            if (isdigit(pTmpStr[i]))
            {
                if (firstDigit==true)
                {
                    firstDigit=false;
                    arc++;
                }
            }
            else  // OTHERWISE IS IT A DOT FOLLOWED BY A DIGIT
            {
                if ((pTmpStr[i] == '.') && (isdigit(pTmpStr[i+1])))
                {
                    firstDigit=true;
                }
                else  // OTHERWISE IT IS BAD
                {
                    invalidOid=true;
                    arc=0;
                    break;
                }
            }
        }
    }

	free(pTmpStr);
	pTmpStr = NULL;
    
    // DID WE GET NOTHING OR AN INVALID CHARACTER
    if ((invalidOid==true) || (arc == 0))
    {
       throw OidException("Invalid character in OID string.", STACK_ENTRY);
    }
    
    // OK NOW WE HAVE A COUNT OF THE NUMBER OF NUMERIC ELEMENTS IN THIS OID
    //   WE ALLOCATE THE APPROPRIATE NUMBER OF ELEMENTS IN OUR ARRAY

    aul = new unsigned long[arc+2];
    const char *pszTok=NULL;
    
    const char* pszTok2 = szOidCopy;
    for(i=0; pszTok2 != NULL; i++)
    {
        if (i+1 > arc)
        {
           throw OidException("Number of arcs exceeded allocated array size", STACK_ENTRY);
        }
        // ASSIGN THIS ELEMENT TO THE ARRAY
        aul[i] = atol(pszTok2);
        pszTok = pszTok2;
        pszTok2=strchr(pszTok, '.');
        if (pszTok2 != NULL)
            pszTok2++;    // POINT past '.'
    }    // FOR strchr(pszTok, '.')
    aul[i] = (unsigned long)-1;     // set end of array.
    
    // CALL THE SET FUNCTION TO ASSIGN THE SNACC VALUE FOR THIS OID
    Set(aul, arc);

	// PIERCE
    m_lpszOidString = new char[strlen(szOidCopy)+1];
    strcpy(m_lpszOidString, szOidCopy);  //RETAIN copy internally.
    
	delete[] aul;

}	// END AsnOid::PutChar(...)

//
//
unsigned long AsnOid::GetLongOid(unsigned long *&pOidLong) //array terminates with -1.
{
    unsigned short int firstArcNum;
    unsigned long int arcNum;
    unsigned int i = 0;
    unsigned int j = 0;
    AsnOid *asnOid=this;
    unsigned long lLengthArcs = (unsigned long)-1;  // -1 in case of error 
    unsigned int numlongs;
    
    const char *oid = asnOid->Str();
    size_t octetLen = asnOid->Len();

    if (pOidLong == NULL)
    {
        numlongs = NumArcs() + 1;

        // allocate space
        pOidLong = (unsigned long *) calloc(numlongs, sizeof(unsigned long));
        if (pOidLong == NULL)
           return lLengthArcs;
     }
     lLengthArcs = NumArcs();    
    
    // un-munge first two arc numbers
    for (arcNum = 0, i=0; (i < octetLen) && (oid[i] & 0x80); i++)
        arcNum = (arcNum << 7) + (oid[i] & 0x7f);
    
    arcNum = (arcNum << 7) + (oid[i] & 0x7f);
    i++;
    firstArcNum = (unsigned short int)(arcNum/40);
    if (firstArcNum > 2)
        firstArcNum = 2;

    pOidLong[j++] = firstArcNum;
    pOidLong[j++] = arcNum - (firstArcNum * 40);

    for (; i < octetLen; )
    {
        for (arcNum = 0; (i < octetLen) && (oid[i] & 0x80); i++)
            arcNum = (arcNum << 7) + (oid[i] & 0x7f);
        
        arcNum = (arcNum << 7) + (oid[i] & 0x7f);

        // assign arcnum to a long type
        pOidLong[j++] = arcNum;
        i++;
    }      

    // make last assignment
    pOidLong[lLengthArcs] = (unsigned long)-1;  // -1 for end 

    return lLengthArcs;
}

char * AsnOid::GetChar(void) const
{
   char *ptr=NULL;
   if (m_lpszOidString == NULL)
      createDottedOidStr();
   if (m_lpszOidString)
      ptr = strdup(m_lpszOidString);
     
   return ptr;
}

// FUNCTION: createDottedOidStr()
//
// PURPOSE: Populate null terrminated dotted notation string.  This function
//          will always re-create m_lpszOidString.
//
void AsnOid::createDottedOidStr() const
{
    unsigned short int firstArcNum;
    unsigned long int arcNum;
    unsigned int i;
    char szBuffer[128];

    FUNC("AsnOid::createDottedOidStr()");

    if (oid == NULL)
        throw OidException("NULL pointer in AsnOid", STACK_ENTRY);

	if (m_lpszOidString != NULL)
	{
		delete[] m_lpszOidString;
		m_lpszOidString = NULL;
	}
    
    // un-munge first two arc numbers
     for (arcNum = 0, i=0; (i < octetLen) && (oid[i] & 0x80); i++)
         arcNum = (arcNum << 7) + (oid[i] & 0x7f);
 
     arcNum = (arcNum << 7) + (oid[i] & 0x7f);
     i++;
     firstArcNum = (unsigned short int)(arcNum/40);
     if (firstArcNum > 2)
         firstArcNum = 2;
 
     sprintf(szBuffer, "%ld.%ld", (long)firstArcNum, 
         (long)(arcNum - (firstArcNum * 40)));
 
     for (; i < octetLen; )
     {
         for (arcNum = 0; (i < octetLen) && (oid[i] & 0x80); i++)
             arcNum = (arcNum << 7) + (oid[i] & 0x7f);
     
         arcNum = (arcNum << 7) + (oid[i] & 0x7f);
         i++;
         if (strlen(szBuffer) + 8 < 128)
             sprintf(&szBuffer[strlen(szBuffer)], ".%ld", arcNum);
         else
             break;     // OBVIOUSLY this is a bad OID value; avoid core dump.
     }

     m_lpszOidString = new char[strlen(szBuffer)+1];
     strcpy(m_lpszOidString, szBuffer);  //RETAIN copy internally.
}


//
//
bool AsnOid::operator == (const char *o) const
{
   if (m_lpszOidString == NULL)
      createDottedOidStr();

   if (m_lpszOidString && strcmp(m_lpszOidString, o) == 0) 
       return true; 
   else 
       return false;
}

//
//
bool AsnOid::operator < (const AsnOid &o) const
{
	if (octetLen < o.octetLen)
		return true;
	else if (octetLen > o.octetLen)
		return false;
	else
       return (memcmp (oid, o.oid, octetLen) < 0);
}

AsnOid::operator const char *() const
{
   if (m_lpszOidString == NULL)
      createDottedOidStr();

   return m_lpszOidString;
}

AsnOid::~AsnOid()
{ 
   if (oid != NULL)
      delete[] oid; 
	if (m_lpszOidString != NULL)
	  	delete[] m_lpszOidString; 
	oid = NULL;
	m_lpszOidString = NULL;
}

_END_SNACC_NAMESPACE

#ifdef SCO_SVV
/* Replacement for SCO 5.0.4 isdigit(), bug in c++ version
   isdigit returns true if c is decimal digit */
int SCOisdigit (char c)
{
     if (c >= '0' && c <= '9')
         return (1);
     return (0);
}
#endif // SCO isdigit()
