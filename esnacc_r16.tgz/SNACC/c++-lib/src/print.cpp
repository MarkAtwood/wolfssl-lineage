// file: .../c++-lib/src/print.C
//
// MS 92
// Copyright (C) 1992 Michael Sample and the University of British Columbia
//
// This library is free software; you can redistribute it and/or
// modify it provided that this copyright/license information is retained
// in original form.
//
// If you modify this file, you must clearly indicate your changes.
//
// This source code is distributed in the hope that it will be
// useful, but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// $Header: /baseline/SNACC/c++-lib/src/print.cpp,v 1.6 2002/05/10 16:39:36 leonberp Exp $
// $Log: print.cpp,v $
// Revision 1.6  2002/05/10 16:39:36  leonberp
// latest changes for release 2.2
// includes integrating asn-useful into C & C++ runtime library, the compiler changes that go along with that, SnaccException changes for C++ runtime and compiler
//
// Revision 1.5  2001/08/29 22:04:20  leonberp
// enchanced Clone() to allocate a new pointe AND COPY the object
//
// Revision 1.4  2001/08/22 19:51:56  rwc
// Updated to add thread lock/unlock routines.
//
// Revision 1.3  2001/07/12 19:33:44  leonberp
// Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
//
// Revision 1.2  2001/06/28 15:29:46  rwc
// ADDED "SNACCASN" namespace definition to all SNACC data structures.
// This should not affect most applications since we do not have any name
// conflicts.
// ALSO, combined all ASN primitive data type includes into asn-incl.h.
//
// Revision 1.1.1.1  2000/08/21 20:36:09  leonberp
// First CVS Version of SNACC.
//
// Revision 1.5  1997/02/16 20:26:09  rj
// check-in of a few cosmetic changes
//
// Revision 1.4  1995/07/24  20:34:55  rj
// changed `_' to `-' in file names.
//
// Revision 1.3  1994/10/08  04:18:33  rj
// code for meta structures added (provides information about the generated code itself).
//
// code for Tcl interface added (makes use of the above mentioned meta code).
//
// virtual inline functions (the destructor, the Clone() function, BEnc(), BDec() and Print()) moved from inc/*.h to src/*.C because g++ turns every one of them into a static non-inline function in every file where the .h file gets included.
//
// made Print() const (and some other, mainly comparison functions).
//
// several `unsigned long int' turned into `size_t'.
//
// Revision 1.2  1994/08/28  10:01:22  rj
// comment leader fixed.
//
// Revision 1.1  1994/08/28  09:21:12  rj
// first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.

#include "asn-incl.h"

_BEGIN_SNACC_NAMESPACE

// the generated operator << routines for aggregate types use these globals
unsigned short int SNACCDLL_API indentG = 0;
unsigned short int SNACCDLL_API stdIndentG = 4;

void
Indent (std::ostream &os, unsigned short int i)
{
  while (i-->0)
    os <<  ' ';
}

std::ostream &operator << (std::ostream &os, const AsnType &v)
{
  threadLock();   //RWC; necessary to thread protect global indent counts.
  v.Print (os);
  threadUnlock();
  return os;
}

_END_SNACC_NAMESPACE
