// file: .../c++-lib/src/asn-bits.C - AsnBits (ASN.1 BIT STRING) Type
//
//  Mike Sample
//  92/07/02
// Copyright (C) 1992 Michael Sample and the University of British Columbia
//
// This library is free software; you can redistribute it and/or
// modify it provided that this copyright/license information is retained
// in original form.
//
// If you modify this file, you must clearly indicate your changes.
//
// This source code is distributed in the hope that it will be
// useful, but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
// $Header: /baseline/SNACC/c++-lib/src/asn-bits.cpp,v 1.40 2003/09/16 16:05:47 beauchas Exp $
// $Log: asn-bits.cpp,v $
// Revision 1.40  2003/09/16 16:05:47  beauchas
// Checking elmtLen to see if it is the proper size before trying to decode the content.
//
// Revision 1.39  2003/09/11 17:01:51  beauchas
// In BDecContent:  Added code to check unused bitlen and throwing an exception if > 7.  Also added elmtLen checks for either being too large or <=0.
//
// Revision 1.38  2003/08/29 12:41:47  colestor
// Updated to better protect against bad user data when dealing with missing data.
// (Testing NISCC SMIME messages).
// add "if (bits)" to for loop, line 393 to avoid crash.
//
// Revision 1.37  2003/01/06 16:20:07  leonberp
// Changed BDec() and BDecContent() to use const AsnBufs
//
// Revision 1.36  2002/12/17 20:27:40  leonberp
// made BEnc() and BEncContent() const
//
// Revision 1.35  2002/12/13 22:06:22  leonberp
// fixed warning
//
// Revision 1.34  2002/12/12 22:00:58  leonberp
// fixed default bitstring support added AsnBits::soloBitCheck()
//
// Revision 1.33  2002/12/12 19:02:21  leonberp
// removed StrStk (no longer used) removed references to it in asn-bits.cpp
//
// Revision 1.32  2002/12/11 20:00:09  leonberp
// added numBits > 0 check for Set()
//
// Revision 1.31  2002/11/25 20:21:19  leonberp
// added AsnBuf copy constructor
//
// Revision 1.30  2002/10/23 21:02:48  leonberp
// fixed AsnBuf references and fixed clock skew problem
//
// Revision 1.29  2002/10/23 10:51:10  mcphersc
// Changed BUF_TYPE to AsnBuf
//
// Revision 1.28  2002/10/01 20:38:26  leonberp
// Added ConsStringDeck to AsnBits to handle Constructed BIT STRING
//
// Revision 1.27  2002/09/26 20:18:52  vracarl
// made asn_buf fixes
//
// Revision 1.26  2002/06/17 16:38:38  leonberp
// added new default constructor
//
// Revision 1.25  2002/06/12 20:38:41  leonberp
// added operator= for binary string form
//
// Revision 1.24  2002/06/05 13:55:06  vracarl
// put a check in for bits being NULL
//
// Revision 1.23  2002/05/29 19:26:06  leonberp
// removed PDU_MEMBERS_MACRO and added BDecPDU and BEncPDU to AsnType
//
// Revision 1.22  2002/05/23 22:33:40  nicholar
// Fixed memory leak and removed warning
//
// Revision 1.21  2002/05/10 16:39:34  leonberp
// latest changes for release 2.2
// includes integrating asn-useful into C & C++ runtime library, the compiler changes that go along with that, SnaccException changes for C++ runtime and compiler
//
// Revision 1.20  2002/04/16 19:30:05  vracarl
// made AsnBits::isEmpty const
//
// Revision 1.19  2002/04/16 19:11:49  vracarl
// added  more checks to  AsnBits::isEmpty
//
// Revision 1.18  2002/04/16 17:16:17  vracarl
// added isEmpty to AsnBits
//
// Revision 1.17  2002/03/01 14:03:31  vracarl
// added an INDEFINATE_LEN check on the primitive
//
// Revision 1.16  2002/02/20 15:13:05  grafb
// Oooops, Bits should be bits (lowercase b), corrected
//
// Revision 1.15  2002/02/19 18:04:38  grafb
// Corrected all delete bits to delete[] bits.
//
// Revision 1.14  2001/10/29 12:05:34  nicholar
// Replaced Asn1Alloc with new
//
// Revision 1.13  2001/10/11 22:26:25  rwc
// Newly tested memory leak fixes.
//
// Revision 1.12  2001/10/09 13:52:30  rwc
// Memory leak testing updates.
//
// Revision 1.11  2001/08/29 22:04:17  leonberp
// enchanced Clone() to allocate a new pointe AND COPY the object
//
// Revision 1.10  2001/08/29 17:01:48  leonberp
// no message
//
// Revision 1.9  2001/08/23 20:47:05  rwc
// Bounds checker updates, in an attempt to avoid Linux core dump
// in c++-examples/vdatest.
//
// Revision 1.8  2001/07/19 16:02:51  sfl
// Yet more string.h updates.
//
// Revision 1.7  2001/07/12 19:33:36  leonberp
// Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
//
// Revision 1.6  2001/06/28 15:29:48  rwc
// ADDED "SNACCASN" namespace definition to all SNACC data structures.
// This should not affect most applications since we do not have any name
// conflicts.
// ALSO, combined all ASN primitive data type includes into asn-incl.h.
//
// Revision 1.5  2001/06/18 17:47:43  rwc
// Updated to reflect newly added C++ Exception error handling, instead of "C" longjmp and setjmp calls.
// Changes made to both the compiler and the SNACC C++ run-time library.
//
// Revision 1.4  2001/01/22 20:18:46  rwc
// Updates to test newly added ASN.1 XML output.
//
// Revision 1.3  2000/10/16 18:10:36  rwc
// removed most warnings from C++-lib, some C-lib.
//
// Revision 1.2  2000/08/23 20:10:44  leonberp
// fixed AsnBits::BitsEquiv()
//
// Revision 1.1.1.1  2000/08/21 20:36:08  leonberp
// First CVS Version of SNACC.
//
// Revision 1.9  1997/08/27 15:55:15  wan
// GetBit now returns 0 or 1, not 0 or <#bit>, even if bool type is emulated.
//
// Revision 1.8  1997/02/28 13:39:44  wan
// Modifications collected for new version 1.3: Bug fixes, tk4.2.
//
// Revision 1.7  1997/01/01 20:19:01  rj
// dereferencing pointer to member function is neither necessary nor allowed
//
// Revision 1.6  1995/08/17  15:37:49  rj
// set Tcl's errorCode variable
//
// Revision 1.5  1995/07/24  20:09:07  rj
// use memzero that is defined in .../snacc.h to use either memset or bzero.
// use memcmpeq that is defined in .../snacc.h to use either memcmp or bcmp.
//
// call constructor with additional pdu and create arguments.
//
// #if TCL ... #endif wrapped into #if META ... #endif
//
// changed `_' to `-' in file names.
//
// Revision 1.4  1994/10/08  04:18:21  rj
// code for meta structures added (provides information about the generated code itself).
//
// code for Tcl interface added (makes use of the above mentioned meta code).
//
// virtual inline functions (the destructor, the Clone() function, BEnc(), BDec() and Print()) moved from inc/*.h to src/*.C because g++ turns every one of them into a static non-inline function in every file where the .h file gets included.
//
// made Print() const (and some other, mainly comparison functions).
//
// several `unsigned long int' turned into `size_t'.
//
// Revision 1.3  1994/08/31  23:37:57  rj
// TRUE turned into true
//
// Revision 1.2  1994/08/28  10:01:11  rj
// comment leader fixed.
//
// Revision 1.1  1994/08/28  09:20:57  rj
// first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.

#ifndef WIN32
#include <string.h>
#endif
#include "asn-incl.h"

_BEGIN_SNACC_NAMESPACE

char SNACCDLL_API numToHexCharTblG[16] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};


AsnBits::AsnBits(const char *stringForm)
{
   bits=NULL;
   nblFlag = false; 
   bitLen = 0;
   if (stringForm)
      operator=(stringForm);
}

AsnBits::~AsnBits()
{
  delete[] bits;
}


// Initializes the bits string with a bit string numBits in length.
// All bits are zeroed.
void AsnBits::Set (size_t numBits)
{
  if (numBits > 0)
  {
     bitLen = numBits;
     size_t octetLen = (bitLen+7)/8;

     if (bits)
         delete[] bits;
     bits = new char[octetLen];
     memset (bits, 0, octetLen); // init to zeros
  }
}

// initializes a BIT STRING with the given string and bit length
// Copies the bits from bitsOcts.
void AsnBits::Set (const char *bitOcts, size_t numBits)
{
    if (bitOcts != bits)
    {
        if (bits)
            delete[] bits;
        bitLen = numBits;
        size_t octetLen = (bitLen+7)/8;
        bits = new char[octetLen];
        memcpy (bits, bitOcts, octetLen);
    }
}

// initializes a BIT STRING by copying another BIT STRING's bits
void AsnBits::Set (const AsnBits &b)
{
	if (&b != this)
	{
		delete[] bits;
		bits = NULL;

		bitLen = b.bitLen;
		nblFlag = b.nblFlag;

		size_t octetLen = (bitLen+7)/8;
		if (octetLen)
		{
			bits = new char[octetLen];
			memcpy (bits, b.bits, octetLen);
		}
	}
}

// PIERCE 8-28-2001 removed ReSet members
//
#if 0
// Initializes the bits string with a bit string numBits in length.
// All bits are zeroed.
void AsnBits::ReSet (size_t numBits)
{
  delete[] bits;
  Set (numBits);
}

// frees old bits value and then re-initializes the
// BIT STRING with the given string and bit length
// Copies the bitOcts into bits.
void AsnBits::ReSet (const char *bitOcts, size_t numBits)
{
  if (bitOcts != bits)
  {
    delete[] bits;
    Set (bitOcts, numBits);
  }
}

// frees old bits value and then re-initializes the
// BIT STRING by copying another BIT STRING's bits
void AsnBits::ReSet (const AsnBits &b)
{
  if (&b != this)  // avoid b = b; probs
  {
    delete[] bits;
    Set (b);
  }
}
#endif

// Returns true if the given BIT STRING is the same as this one
bool AsnBits::BitsEquiv (const AsnBits &ab) const
{
  size_t octetsLessOne = (bitLen-1)/8;
  size_t unusedBits;
  
  unusedBits = bitLen % 8;
  if (unusedBits != 0)
     unusedBits = 8 - unusedBits;

  if (!bitLen && !ab.bitLen)
    return true;

  // trailing bits may not be significant
  return bitLen == ab.bitLen
    && !memcmp (bits, ab.bits, octetsLessOne)
    && (bits[octetsLessOne] & (0xFF << unusedBits)) == (ab.bits[octetsLessOne] & (0xFF << unusedBits));
}  /* AsnBits::BitsEquiv */


// set given bit to 1. Most signif. bit is bit 0, least signif bit is bitLen-1
void AsnBits::SetBit (size_t bit)
{
  if (bit < bitLen)
  {
    size_t octet = bit/8;
    size_t octetsBit = 7 - (bit % 8);	// bit zero is first/most sig bit in octet
    bits[octet] |= 1 << octetsBit;
  }
} /* AsnBits::SetBit */

// Clr bit. Most signif. bit is bit 0, least signif bit is bitLen-1
void AsnBits::ClrBit (size_t bit)
{
  if (bit < bitLen)
  {
    size_t octet = bit/8;
    size_t octetsBit = 7 - (bit % 8);	// bit zero is first/most sig bit in octet
    bits[octet] &= ~(1 << octetsBit);
  }
} /* AsnBits::ClrBit */

// returns given bit. Most signif. bit is bit 0, least signif bit is bitLen-1.
// Returns false if the given bit index is out of range.
bool AsnBits::GetBit (size_t bit) const
{
  if (bit < bitLen)
  {
    size_t octet = bit/8;
    size_t octetsBit = 7 - (bit % 8);	// bit zero is first/most sig bit in octet
    return !!(bits[octet] & (1 << octetsBit));
  }
  return false;
}  /* AsnBits::GetBit */


// Returns true if the bit string is empty
bool AsnBits::IsEmpty () const
{
  size_t i = 0;

  if (bits == NULL)
      return true;
  if (bitLen <= 0)
      return true;
  for (i = 0; i < bitLen; i++)
  {
     if (GetBit(i) == 1)
         return false;
  }
  return true;
}  /* AsnBits::IsEmpty */


// Encodes the content (included unused bits octet) of the BIT STRING
// to the given buffer.
AsnLen AsnBits::BEncContent (AsnBuf &b) const
{
    size_t unusedBits;
    size_t byteLen;

    unsigned int i;
    //bool bStop;
    
    // IF bitstring is a NamedBitList 
    if (nblFlag)
    {

       // Calculate last octet.  
       // 
       size_t finalOctet;
       if (bitLen <= 8)
          finalOctet = 0;
       else if (bitLen % 8 == 0)
          finalOctet = ((bitLen / 8) - 1);
       else 
          finalOctet = bitLen / 8;

       // The final octet is the last octet which has at least 
       // one bit set.  Loop backwards starting with the
       // last octet (calculated above) until you find an
       // that has at least one bit set (it's value is not 0).
       //
       if (bits != NULL)
          for (; finalOctet > 0 && bits[finalOctet] == 0; finalOctet--);

       // Calculate unsigned bits in final octet
       //
       if (bits == NULL || (finalOctet == 0 && bits[0] == 0))
       {
          byteLen = 0;
          unusedBits = 0;
       }
       else
       {
          // Calculate how many trailing bits are unset in the
          // last octet.
          unusedBits=0;
          for (i = 0; i < 8 && ! (bits[finalOctet] & (0x01 << i)); i++)
              unusedBits++;
          byteLen = finalOctet + 1;
       }
    } 
    else 
    {
       // If this is not a NamedBitList Calculate the unusedBits
       // as ( (BitLen() / 8) + 1) * 8 ) - BitLen();
       //
       // In other words it's the number of bits not used by
       // the BIT STRING specification, not the number of unset 
       // bits in the the final subsequent octet.
       unusedBits = bitLen % 8;
       if (unusedBits != 0)
          unusedBits = 8 - unusedBits;
       
       byteLen = (bitLen+7)/8;
    }
    b.PutSegRvs (bits, byteLen);

//    unusedBits = (bitLen % 8);
//    if (unusedBits != 0)
//        unusedBits = 8 - unusedBits;
    b.PutByteRvs ((unsigned char)unusedBits);

    return byteLen + 1;

} /* AsnBits::BEncContent */


// Decodes a BER BIT STRING from the given buffer and stores
// the value in this object.
void AsnBits::BDecContent (const AsnBuf &b, AsnTag tagId, AsnLen elmtLen, AsnLen &bytesDecoded)
{
   FUNC("AsnBits::BDecContent");

	if (elmtLen == INDEFINITE_LEN || elmtLen > b.length())
	{
	   throw MemoryException(elmtLen, "elmtLen requests for too much data", STACK_ENTRY);
	}

   /*
    * tagId is encoded tag shifted into long int.
    * if CONS bit is set then constructed bit string
    */
   if (tagId & 0x20000000)
     BDecConsBits (b, elmtLen, bytesDecoded);

   else /* primitive octet string */
   {
     if (elmtLen == INDEFINITE_LEN)
        throw BoundsException("indefinite length on primitive", STACK_ENTRY);

	 if (elmtLen > b.length() || elmtLen <= 0)
        throw BoundsException("length problem on decoding content", STACK_ENTRY);

     bytesDecoded += elmtLen;
     elmtLen--;

	 unsigned int iUnusedBitLen= (unsigned int)b.GetByte();
	 if (iUnusedBitLen > 7)
        throw BoundsException("Length problem - Unused bits > 7", STACK_ENTRY);

     bitLen = (elmtLen * 8) - iUnusedBitLen;
     bits =  new char[elmtLen];
     b.GetSeg (bits, elmtLen);
   }

} /* AsnBits::BDecContent */

AsnLen AsnBits::BEnc (AsnBuf &b) const
{
    AsnLen l;
    l =  BEncContent (b);
    l += BEncDefLen (b, l);
    l += BEncTag1 (b, UNIV, PRIM, BITSTRING_TAG_CODE);
    return l;
}

void AsnBits::BDec (const AsnBuf &b, AsnLen &bytesDecoded)
{
   FUNC("AsnBits::BDec");

   AsnLen elmtLen;
   AsnTag tag;

   tag = BDecTag (b, bytesDecoded);
   if ((tag != MAKE_TAG_ID (UNIV, PRIM, BITSTRING_TAG_CODE))
   && (tag != MAKE_TAG_ID (UNIV, CONS, BITSTRING_TAG_CODE)))
   {
      throw InvalidTagException(typeName(), tag, STACK_ENTRY);
   }
   elmtLen = BDecLen (b, bytesDecoded);
   BDecContent (b, tag, elmtLen, bytesDecoded);
}

/*
 * decodes a seq of universally tagged bits until either EOC is
 * encountered or the given len decoded.  Return them in a
 * single concatenated bit string
 */
void AsnBits::BDecConsBits (const AsnBuf &b, AsnLen elmtLen, AsnLen &bytesDecoded)
{
   FUNC("AsnBits::BDecConsBits ()");

   ConsStringDeck deck(BITSTRING_TAG_CODE);
   ConsStringDeck::iterator i;

   deck.Fill(b, elmtLen, bytesDecoded);
   
   // Check all but the last card to make sure it's set to zero
   // 
   // This enforces the constructed BIT STRING rule which states
   // the unused bits must 0 except for the last component.
   //
   i = deck.begin();
   for (; i < (deck.end() - 1); i++)
   {
      if (i->first[0] != 0)
         throw EXCEPT("Constructed BIT STRING contains a component with a unused bits value other than 0", DECODE_ERROR);
   }
}  /* BDecConsBits */

// prints the BIT STRING to the given ostream.
void AsnBits::Print (std::ostream &os) const
{
    size_t octetLen = (bitLen+7)/8;

    os << "'";
    for (unsigned int i = 0; i < octetLen; i++)
        os << TO_HEX (bits[i] >> 4) << (TO_HEX (bits[i]));
    os << "'H  -- BIT STRING bitlen = " << bitLen << " --";
}

void AsnBits::PrintXML(std::ostream &os, const char *lpszTitle) const
{
   os << "<BIT_STRING>";
   if (lpszTitle)
      os << lpszTitle;
   os << "-";
   Print(os);
   os << "</BIT_STRING>\n";
}

// operator=(const char *)
//
// create AsnBits object from the BINARY string form
//
// example:
//     '1001'B
//
AsnBits & AsnBits::operator=(const char *stringForm)
{
   FUNC("AsnBits::operator=()");

   char *pend = NULL;
   char *pbegin = NULL;
   
   pend = strstr(stringForm, "'B");

   pbegin = strstr(stringForm,"'");
   pbegin++;

   if (pend == NULL || pbegin == NULL)
   {
      throw ParameterException("Invalid string form for BIT STRING", 
         STACK_ENTRY);
   }

   // Set length
   Set(pend - pbegin);

   for (int i=0; (pbegin + i) != pend; i++)
   {
      // if ASCII 0
      if (pbegin[i] == '0')
         ClrBit(i);
      // else if ASCII 1
      else if (pbegin[i] == '1')
         SetBit(i);
      else
         // PIERCE THROW
       throw ParameterException("Invalid string form for BIT STRING", 
         STACK_ENTRY);
   }

   nblFlag = true;
   return *this;
}

// soloBitCheck()
//
// determines if the only bit set is 'b'.  This is used to determine whether a
// BIT STRING contains only the default bit set.  If it does then it is not encoded.
//
bool AsnBits::soloBitCheck(size_t b)
{
   bool result = false;

   if (GetBit(b))
   {
      // Clear bit b and check if bit string is empty
      ClrBit(b);
      if (IsEmpty())
      {
         result = true;
      }
      SetBit(b);
   }
   return result;
}

#if META

const AsnBitsTypeDesc AsnBits::_desc (NULL, NULL, false, AsnTypeDesc::BIT_STRING, NULL, NULL);

const AsnTypeDesc *AsnBits::_getdesc() const
{
  return &_desc;
}

#if TCL

int AsnBits::TclGetVal (Tcl_Interp *interp) const
{
  Tcl_ResetResult(interp);
  for (int i=0; i<bitLen; i++)
    Tcl_AppendResult(interp,GetBit (i) ? "1" : "0",NULL);
  return TCL_OK;
}

int AsnBits::TclSetVal (Tcl_Interp *interp, const char *valstr)
{
  int		i;
  const char	*p;

  for (i=0, p=valstr; *p; i++, p++)
    switch (*p)
    {
      case '0':
      case '1':
	break;
      default:
	const char c[2] = { *p, '\0' };
	Tcl_AppendResult (interp, "illegal character '", c, "' for bit in type ", _getdesc()->getmodule()->name, ".", _getdesc()->getname(), NULL);
	Tcl_SetErrorCode (interp, "SNACC", "ILLBIT", NULL);
	return TCL_ERROR;
    }

  ReSet (i);

  for (i=0, p=valstr; i<bitLen; i++, p++)
    *p == '0' ? ClrBit(i) : SetBit(i);

  return TCL_OK;
}

#endif /* TCL */
#endif /* META */

_END_SNACC_NAMESPACE
