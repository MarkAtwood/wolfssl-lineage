//
// asn-stringType.cpp
//

#include "asn-incl.h"


#if defined(HPUX) || defined(HPUX32)

/* for some strange reason GCC 3.2.1 on HPUX has trouble specializing the 
 * basic_string<> template for wchar_t.  Do the following is necessary on HPUX
 * until GCC is fixed or we figure out another work around.
 */

namespace std 
{
const basic_string<wchar_t>::size_type 
    basic_string<wchar_t>::_Rep::_S_max_size = (((npos - sizeof(_Rep))/sizeof(wchar_t)) - 1) / 4;

const wchar_t basic_string<wchar_t>::_Rep::_S_terminal = wchar_t();
}

#endif // HPUX

#ifdef _MSC_VER
#pragma warning(disable: 4127)	// Disable conditional expression is constant
#endif

using namespace SNACC;


#define MAX_UTF8_OCTS_PER_CHAR		6

typedef struct
{
	unsigned char mask;
	unsigned char value;
   unsigned short bits;
	unsigned long maxCharValue;
} MaskValue;

const MaskValue gUTF8Masks[6] = {
	{ 0x80, 0x00, 1, 0x0000007F },		// one-byte encoding
	{ 0xE0, 0xC0, 3, 0x000007FF },		// two-byte encoding
	{ 0xF0, 0xE0, 4, 0x0000FFFF },		// three-byte encoding
	{ 0xF8, 0xF0, 5, 0x0001FFFF },		// four-byte encoding
	{ 0xFC, 0xF8, 6, 0x03FFFFFF },		// five-byte encoding
	{ 0xFE, 0xFC, 7, 0x07FFFFFF }		// six-byte encoding
};



AsnString& AsnString::operator=(const char* str)
{
	if (str == NULL)
		erase();
	else
		assign(str);
	return *this;
}

AsnLen AsnString::BEnc(AsnBuf &b) const
{
    AsnLen l = BEncContent(b);
    l += BEncDefLen(b, l);
    l += BEncTag1(b, UNIV, PRIM, tagCode());
    return l;
}

void AsnString::BDec(const AsnBuf &b, AsnLen &bytesDecoded)
{
	FUNC("AsnStringType::BDec()");
	
	AsnTag tag = BDecTag(b, bytesDecoded);
	if ((tag != MAKE_TAG_ID (UNIV, PRIM, tagCode())) &&
		(tag != MAKE_TAG_ID (UNIV, CONS, tagCode())))
	{
		throw InvalidTagException(typeName(),tag, STACK_ENTRY);
	}
	
	AsnLen elmtLen1 = BDecLen(b, bytesDecoded);
	BDecContent(b, tag, elmtLen1, bytesDecoded);
}

AsnLen AsnString::BEncContent(AsnBuf &b) const
{
	FUNC("AsnString::BEncContent()");

#ifndef DISABLE_STRING_CHECK
	if (!check())
		throw EXCEPT("Invalid character present", RESTRICTED_TYPE_ERROR);
#endif

   b.PutSegRvs(c_str(), length());
	return length();
}

void AsnString::BDecContent(const AsnBuf &b, AsnTag tagId, AsnLen elmtLen, AsnLen &bytesDecoded)
{
	FUNC("AsnString::BDecContent()");

	// Erase the existing characters
	erase();

	// If tag is constructed...
	if (TAG_IS_CONS(tagId))
	{
		BDecConsString(b, elmtLen, bytesDecoded);
	}
	else	// primitive string
	{
        if (elmtLen != INDEFINITE_LEN)//RWC; TMP disable -1,indefinite length value
                            //RWC;  FOUND through NISCC tests for EnvelopedData
        {
			  b.GetSeg(*this, elmtLen);
			  bytesDecoded += elmtLen;
        }
		  else
		  {
			  throw BoundsException("Indefinite length not allowed on primitive", STACK_ENTRY);
		  }
	}

/*RWC;DISABLE; USER CAN CALL SEPARATELY;#ifndef DISABLE_STRING_CHECK
	if (!check())
		throw EXCEPT("Invalid character present", RESTRICTED_TYPE_ERROR);
#endif;RWC;*/
}

void AsnString::Print(std::ostream &os) const
{
   os << typeName() << ":\n" << c_str() << "\n";
}

void AsnString::PrintXML(std::ostream &os, const char *lpszTitle) const
{
	const char* title = lpszTitle;
	if (title == NULL)
		title = typeName();

   os << "<" << title << ">" << c_str() << "</" << title << ">";
}

void AsnString::BDecConsString(const AsnBuf &b, AsnLen elmtLen,
							   AsnLen &bytesDecoded)
{
	FUNC("AsnString::BDecConsString()");

	AsnLen totalElmtsLen = 0;
	while ((totalElmtsLen < elmtLen) || (elmtLen == INDEFINITE_LEN))
	{
		AsnTag innerTag = BDecTag(b, totalElmtsLen);
		
		if ((innerTag == EOC_TAG_ID) && (elmtLen == INDEFINITE_LEN))
		{
			BDEC_2ND_EOC_OCTET(b, totalElmtsLen);
			break;
		}
		
		AsnLen innerLen = BDecLen(b, totalElmtsLen);
		if (innerTag == MAKE_TAG_ID (UNIV, PRIM, OCTETSTRING_TAG_CODE))
		{
			char *seg =  new char[elmtLen];
			if (seg == NULL)
			   throw MemoryException(elmtLen, "seg", STACK_ENTRY);
			b.GetSeg(seg, elmtLen);
			bytesDecoded += elmtLen;
			
			totalElmtsLen += elmtLen;

			append(seg, elmtLen);
			innerLen -= elmtLen;
			delete[] seg;
		}
		else if (innerTag == MAKE_TAG_ID (UNIV, CONS, OCTETSTRING_TAG_CODE))
		{
			BDecConsString(b, innerLen, totalElmtsLen);
		}
		else  // wrong tag
			throw InvalidTagException(typeName(), innerTag, STACK_ENTRY);
	}

    bytesDecoded += totalElmtsLen;
} // end of AsnString::BDecConsString()


AsnLen WideAsnString::BEnc(AsnBuf &b) const
{
    AsnLen l = BEncContent(b);
    l += BEncDefLen(b, l);
    l += BEncTag1(b, UNIV, PRIM, tagCode());
    return l;
}

void WideAsnString::BDec(const AsnBuf &b, AsnLen &bytesDecoded)
{
    FUNC("WideAsnString::BDec()");
	
	AsnTag tag = BDecTag(b, bytesDecoded);
	if ((tag != MAKE_TAG_ID (UNIV, PRIM, tagCode())) &&
		(tag != MAKE_TAG_ID (UNIV, CONS, tagCode())))
	{
		throw InvalidTagException(typeName(), tag, STACK_ENTRY);
	}
	
    AsnLen elmtLen1 = BDecLen(b, bytesDecoded);
	BDecContent(b, tag, elmtLen1, bytesDecoded);
}

void WideAsnString::Print(std::ostream &os) const
{
	std::string utf8Form;
	getAsUTF8(utf8Form);
	os << "typeName():\n" << utf8Form.c_str() << "\n";
}

void WideAsnString::PrintXML(std::ostream &os, const char *lpszTitle) const
{
	const char *title = lpszTitle;
	if (title == NULL)
		title = typeName();
	
	std::string utf8Form;
	getAsUTF8(utf8Form);
	os << "<" << title << ">" << utf8Form.c_str() << "</" << title << ">";
}

// Set the wide-character string from the UTF-8 string
void WideAsnString::set(const char* str)
{
	FUNC("WideAsnString::set()");

	const size_t wcharSize = sizeof(wchar_t);

	// Erase the existing characters
	erase();

	// If the string is NULL, just return
	if (str == NULL)
		return;

	// Reserve space for a worst case wchar_t string
	unsigned int strLength = strlen(str);
	reserve(strLength);
	
	// Convert the UTF-8 string to a wchar_t string
	unsigned int i = 0;
	while (i < strLength)
	{
		// Determine the number of UTF-8 octets that follow the first
		unsigned int j;
		for (j = 0; (j < MAX_UTF8_OCTS_PER_CHAR) &&
			((gUTF8Masks[j].mask & str[i]) != gUTF8Masks[j].value); ++j)
			;
		
		// Throw an exception if the first octet was invalid or if the
		// number of subsequent octets exceeds the UTF-8 string length
		if ((j == MAX_UTF8_OCTS_PER_CHAR) || ((i + j) >= strLength))
			throw EXCEPT("Invalid UTF-8 string", RESTRICTED_TYPE_ERROR);
		
		// Throw an exception if the size of the wchar_t doesn't support the
		// size of this UTF-8 character
		//
      if ( abs((j * 6) - gUTF8Masks[j].bits) > (wcharSize*8))
		{
			throw EXCEPT("UTF-8 character too large for wchar_t",
				RESTRICTED_TYPE_ERROR);
		}
		
		// Copy the bits from the first octet into a temp wide character
		wchar_t tmp = (char)(~gUTF8Masks[j].mask & str[i++]);
		
		// Add in the bits from each subsequent octet
		for (; j > 0; j--)
		{
			// Throw an exception if the subsequent octet isn't properly
			// formatted
			if ((str[i] & 0xC0) != 0x80)
				throw EXCEPT("Invalid UTF-8 string", RESTRICTED_TYPE_ERROR);
		
			tmp <<= 6;
			tmp |= str[i++] & 0x3F;
		}
		append(1, tmp);
	}
}

// Convert wide character string to UTF-8 character string
//
void WideAsnString::getAsUTF8(std::string& utf8String) const
{
	FUNC("WideAsnString::getAsUTF8()");
	
	// Size the resulting string for a worst case UTF-8 string
	utf8String.resize(length() * MAX_UTF8_OCTS_PER_CHAR);
	
	// Convert each wide character into a UTF-8 char sequence
	std::string::size_type x = 0;
	for (const_iterator i = begin(); i != end(); ++i)
	{
		// Return an error if the wide character is invalid
		if (*i < 0)
			throw EXCEPT("Invalid wide character", RESTRICTED_TYPE_ERROR);
		
		// Determine the number of characters required to encode this
		// wide character
		unsigned int j;
		for (j = 0; (j < MAX_UTF8_OCTS_PER_CHAR) &&
			(*i > gUTF8Masks[j].maxCharValue); ++j)
			;
		
		// Return an error if the wide character is invalid
		if (j == MAX_UTF8_OCTS_PER_CHAR)
			throw EXCEPT("Invalid wide character", RESTRICTED_TYPE_ERROR);
		
		/* Skip over the first UTF-8 octet and encode the remaining octets
		(if any) from right-to-left.  Fill in the least significant six bits
		of each octet with the low-order bits from the wide character value */
		wchar_t temp_wchar = *i;
		for (unsigned int y = j; y > 0; --y)
		{
			utf8String[x + y] = (char)(0x80 | (temp_wchar & 0x3F));
			temp_wchar >>= 6;
		}
		
		// Encode the first UTF-8 octet
		utf8String[x] = gUTF8Masks[j].value;
		utf8String[x++] |= ~gUTF8Masks[j].mask & temp_wchar;
		
		// Update the UTF-8 string index (skipping over the subsequent octets
		// already encoded)
		x += j;
	}

	// Resize the string to the correct length
	utf8String.resize(x);

} // end of WideAsnString::getAsUTF8()


char* WideAsnString::getAsUTF8() const
{
	std::string utf8Form;
	getAsUTF8(utf8Form);

	return strdup(utf8Form.c_str());
} // end of WideAsnString::getAsUTF8()

AsnLen WideAsnString::CombineConsString(const AsnBuf &b, AsnLen elmtLen,
										std::string& encStr)
{
	FUNC("WideAsnString::CombineConsString()");

	AsnLen totalElmtsLen = 0;
	while ((totalElmtsLen < elmtLen) || (elmtLen == INDEFINITE_LEN))
	{
		AsnTag innerTag = BDecTag(b, totalElmtsLen);
		
		if ((innerTag == EOC_TAG_ID) && (elmtLen == INDEFINITE_LEN))
		{
			BDEC_2ND_EOC_OCTET(b, totalElmtsLen);
			break;
		}
		
		AsnLen innerLen = BDecLen(b, totalElmtsLen);
		if (innerTag == MAKE_TAG_ID (UNIV, PRIM, OCTETSTRING_TAG_CODE))
		{
			char *seg =  new char[elmtLen];
			if (seg == NULL)
			   throw MemoryException(elmtLen, "seg", STACK_ENTRY);
			b.GetSeg(seg, elmtLen);
			totalElmtsLen += elmtLen;

			encStr.append(seg, elmtLen);
			innerLen -= elmtLen;
			delete[] seg;
		}
		else if (innerTag == MAKE_TAG_ID (UNIV, CONS, OCTETSTRING_TAG_CODE))
		{
			totalElmtsLen += CombineConsString(b, innerLen, encStr);
		}
		else  // wrong tag
			throw InvalidTagException(typeName(), innerTag, STACK_ENTRY);
	}

    return totalElmtsLen;
} // end of WideAsnString::CombineConsString()

bool NumericString::check() const
{
	for (const_iterator i = begin(); i != end(); ++i)
	{
		// Check for 0-9
		if ((*i < '0') || (*i > '9'))
		{
			// Check for space
			if (*i != ' ')
				return false;
		}
	}
	return true;
}

bool PrintableString::check() const
{
	for (const_iterator i = begin(); i != end(); ++i)
	{
		// Check for A-Z
		if ((*i < 'A') || (*i > 'Z'))
		{
			// Check for a-z
			if ((*i < 'a') || (*i > 'z'))
			{
				// Check for 0-9
				if ((*i < '0') || (*i > '9'))
				{
					switch (*i)
					{
					case ' ':		// space
					case '\'':		// apostrophe
					case '(':		// left parenthesis
					case ')':		// right parenthesis
					case '+':		// plus sign
					case ',':		// comma
					case '-':		// hyphen-minus
					case '.':		// full stop (period)
					case '/':		// solidus
					case ':':		// colon
					case '=':		// equal sign
					case '?':		// question mark
						break;

					default:
						return false;
					}
				}
			}
		}
	}
	return true;
}

bool IA5String::check() const
{
	for (const_iterator i = begin(); i != end(); ++i)
	{
		// Check that character is less than 128
		if ( (*i < 0) )
			return false;
	}

	return true;
}

bool VisibleString::check() const
{
	for (const_iterator i = begin(); i != end(); ++i)
	{
		// Check that character is between ' ' and '~' inclusive
		if ((*i < ' ') || (*i > '~'))
			return false;
	}

	return true;
}


// Encode BMPString octets into byte stream
//
AsnLen BMPString::BEncContent(AsnBuf &b) const
{
	FUNC("BMPString::BEncContent");
	
	const size_t wcharSize = sizeof(wchar_t);

	AsnLen len = 0;
	const_reverse_iterator wstrI;
	for (wstrI = rbegin(); wstrI != rend(); ++wstrI)
	{
		wchar_t wc = *wstrI;
		for (unsigned int i = 0; i < 2; ++i)
		{
			b.PutByteRvs((unsigned char)wc);
			wc >>= 8;
			++len;
		}
		
		// Check that the upper bytes, if any, are zero
		if ((wcharSize > 2) && (wc != 0))
			throw EXCEPT("Invalid BMPString", RESTRICTED_TYPE_ERROR);
	}
	return len;
}

void BMPString::BDecContent(const AsnBuf &b, AsnTag tagId, AsnLen elmtLen,
							AsnLen &bytesDecoded)
{
	FUNC("BMPString::BDecContent");
	
	// Erase the existing characters
	erase();

	if (elmtLen == INDEFINITE_LEN || elmtLen > b.length())
	{
	   throw MemoryException(elmtLen, "elmtLen requests for too much data", STACK_ENTRY);
	}

	// If tag is constructed, decode and combine the segments
	std::string encStr;
	if (TAG_IS_CONS(tagId))
	{
		bytesDecoded += CombineConsString(b, elmtLen, encStr);
	}
	else	// tag is primitive, just combine the one segment
	{
		char *seg =  new char[elmtLen];
		if (seg == NULL)
		   throw MemoryException(elmtLen, "seg", STACK_ENTRY);
		b.GetSeg(seg, elmtLen);
		bytesDecoded += elmtLen;

		encStr.append(seg, elmtLen);
		delete[] seg;
	}

	// encoding length must be a multiple of two since BMPString uses
	// 2 bytes to represent a character.
	//
	if (encStr.length() % 2 != 0)
	{
		throw EXCEPT("Invalid BMPString length not multiple of 2",
			RESTRICTED_TYPE_ERROR);
	}
	
	// decode BMPString into wide string
	//
	resize(encStr.length() / 2);
	std::string::const_iterator iEnc = encStr.begin();
	for (size_type i = 0; i < size(); ++i)
	{
		wchar_t wtmpCh = *iEnc++;
		wtmpCh <<= 8;
		wtmpCh |= *iEnc++;
		at(i) = wtmpCh;
	}
}


// Encode UniversalString octets into byte stream
//
AsnLen UniversalString::BEncContent(AsnBuf &b) const
{
	FUNC("UniversalString::BEncContent");
	
	const size_t wcharSize = sizeof(wchar_t);

	AsnLen len = 0;
	const_reverse_iterator wstrI;
	for (wstrI = rbegin(); wstrI != rend(); ++wstrI)
	{
		wchar_t wc = *wstrI;
		for (unsigned int i = 0; i < 4; ++i)
		{
			if (i < wcharSize)
				b.PutByteRvs((unsigned char)wc);
			else
				b.PutByteRvs(0);
			wc >>= 8;
			++len;
		}

		// Check that the upper bytes, if any, are zero
		if ((wcharSize > 4) && (wc != 0))
			throw EXCEPT("Invalid UniversalString", RESTRICTED_TYPE_ERROR);
	}
	return len;
}

void UniversalString::BDecContent(const AsnBuf &b, AsnTag tagId, AsnLen elmtLen,
								  AsnLen &bytesDecoded)
{
	FUNC("UniversalString::BDecContent");
	
	// Erase the existing characters
	erase();

	if (elmtLen == INDEFINITE_LEN || elmtLen > b.length())
	{
	   throw MemoryException(elmtLen, "elmtLen requests for too much data", STACK_ENTRY);
	}


	// If tag is constructed, decode and combine the segments
	std::string encStr;
	if (TAG_IS_CONS(tagId))
	{
		bytesDecoded += CombineConsString(b, elmtLen, encStr);
	}
	else	// tag is primitive, just combine the one segment
	{
		char *seg =  new char[elmtLen];
		if (seg == NULL)
		   throw MemoryException(elmtLen, "seg", STACK_ENTRY);
		b.GetSeg(seg, elmtLen);
		bytesDecoded += elmtLen;

		encStr.append(seg, elmtLen);
		delete[] seg;
	}

	// encoding length must be a multiple of four since UniversalString
	// uses 4 bytes to represent a character.
	//
	if (encStr.length() % 4 != 0)
	{
		throw EXCEPT("Invalid UniversalString length not multiple of 4",
			RESTRICTED_TYPE_ERROR);
	}
	
	const size_t wcharSize = sizeof(wchar_t);

	// decode UniversalString into wide string
	//
	resize(encStr.length() / 4);
	std::string::iterator iEnc = encStr.begin();
	for (size_type i = 0; i < size(); ++i)
	{
		wchar_t wtmpCh = 0;
		for (unsigned int iByte = 4; iByte > 0; --iByte)
		{
			// Check that the wchar_t won't overflow
			if ((wcharSize - iByte) < 0)
			{
				if (*iEnc++ != 0)
				{
					throw EXCEPT("UniversalString not supported by platform wchar_t size",
						RESTRICTED_TYPE_ERROR);
				}
				// else just skip the zero byte
			}
			else
			{
				wtmpCh <<= 8;
				wtmpCh |= *iEnc++;
			}
		}
		at(i) = wtmpCh;
	}
}


AsnLen UTF8String::BEncContent(AsnBuf &b) const
{
	std::string utf8;
	getAsUTF8(utf8);

	AsnLen len = utf8.length();
	b.PutSegRvs(utf8.data(), len);
	return len;
}

void UTF8String::BDecContent(const AsnBuf &b, AsnTag tagId, AsnLen elmtLen,
							 AsnLen &bytesDecoded)
{
	FUNC("UTF8String::BDecContent()");
	
	// Erase the existing characters
	erase();

	try 
	{
    	if (elmtLen == INDEFINITE_LEN || elmtLen > b.length())
		{
	       throw MemoryException(elmtLen, "elmtLen requests for too much data", STACK_ENTRY);
		}


		// If tag is constructed, decode and combine the segments
		std::string encStr;
		if (TAG_IS_CONS(tagId))
		{
			bytesDecoded += CombineConsString(b, elmtLen, encStr);
		}
		else	// tag is primitive, just combine the one segment
		{
			char *seg =  new char[elmtLen];
			if (seg == NULL)
			   throw MemoryException(elmtLen, "seg", STACK_ENTRY);
			b.GetSeg(seg, elmtLen);
			bytesDecoded += elmtLen;
			
			encStr.append(seg, elmtLen);
			delete[] seg;
		}
		
		// Decode this UTF-8 string and assign it to this object
		set(encStr.c_str());
	}
	catch (SnaccException& snaccE) {
		snaccE.push(STACK_ENTRY);
		throw;
	}
}
