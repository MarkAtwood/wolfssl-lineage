#ifndef _ASN_BUF_H
#define _ASN_BUF_H 1


#ifdef WIN32
#pragma warning(disable: 4100 4702 4710 4514 4786 4251 4018 4146 4284)
#pragma warning(push,3)

#include <ostream>
#include <streambuf>
#include <deque>
#include <list>
#include <fstream>
#include <sstream>
#pragma warning(pop)

#else // WIN32

#include <ostream>
#include <streambuf>
#include <deque>
#include <list>
#include <fstream>
#include <utility>
#include <sstream>

#endif // WIN32



#ifndef SNACCDLL_API
#ifdef WIN32
#ifdef SNACCDLL_EXPORTS
#define SNACCDLL_API __declspec(dllexport)
#else
#ifdef SNACCDLL_NONE
#define SNACCDLL_API 
#else
#define SNACCDLL_API __declspec(dllimport)
#endif
#endif
#else
#define SNACCDLL_API 
#endif
#endif

#define _SEG_SIZE 4096



namespace SNACC
{

// Forward declarations
class Card;
class AsnFileSeg;

typedef unsigned long      AsnLen;

typedef std::deque<Card *> Deck;


struct SNACCDLL_API AsnBufLoc
{
   Deck::iterator m_card;
   long           m_offset;
};


class SNACCDLL_API AsnBuf
{
public:
   AsnBuf();
   AsnBuf(const char *seg, size_t segLen);
   AsnBuf(const std::stringstream &ss);
   AsnBuf(std::streambuf *sb);
   AsnBuf(const AsnBuf &o);
   AsnBuf(const char *pFilename);
   ~AsnBuf()  { clear(); }

   void          PutByteRvs (char byte);
   void          PutSegRvs  (const char *seg, size_t segLen);
   void          PutStream(std::streambuf *sb);

   unsigned char GetUByte() const { return (unsigned char) GetByte();}
   char          GetByte() const;
   //unsigned long GetSeg(char *seg, long segLen) const;
   void GetSeg(char *seg, long segLen) const;
	char *        GetSeg(long segLen) const;
   void          GetSeg(std::string &str, long segLen=0) const;
   AsnFileSeg *  GetFileSeg(long segLen) const;
   void          PutFileSeg(AsnFileSeg *fs);
   void          GrabAny(AsnBuf &anyBuf, SNACC::AsnLen &bytesDecoded) const;
   const Deck &  deck() const {return m_deck;}
   const Card &  card() const {return **m_card;}
   unsigned long length() const;
	void			  insert(const AsnBuf &that);
   long          splice(AsnBuf &b);
   void          skip(size_t skipBytes);
   char          PeekByte() const;
   AsnBuf &      operator=(const AsnBuf &o);
   bool          operator==(const AsnBuf &b) const;
   bool          operator<(const AsnBuf &rhs) const;

   void          hexDump(std::ostream &os) const;

#ifdef _DEBUG
   void status(std::ostream &os);
#endif

   AsnBufLoc GetReadLoc() const;
   void      SetReadLoc(const AsnBufLoc &bl) const;

//#ifdef WIN32
//   void ResetMode(std::ios_base::open_mode mode = std::ios_base::in) const;
//#else
   void ResetMode(std::ios_base::openmode mode = std::ios_base::in) const;
//#endif

private:
   void clear();

protected:
   mutable SNACC::Deck::iterator m_card;
   mutable SNACC::Deck m_deck;
};


// Class for handling memory based encodings.  It
// writes into the stream in reverse.
//
class SNACCDLL_API AsnRvsBuf : public std::streambuf
{

public:
   AsnRvsBuf(char *preFilled, size_t segSize);
   AsnRvsBuf(const char *seg, size_t segSize);
   AsnRvsBuf(const AsnBuf& otherBuf);
   explicit AsnRvsBuf(long segSize = _SEG_SIZE);
   virtual ~AsnRvsBuf();

   const char *str()  { return m_pStart; }
   int         pcount() { return ( (m_buf + m_segSize) - m_pStart ); }

   long max_size() const {return m_segSize;}

   friend class AsnBuf;

protected:
   virtual int_type        underflow();
   virtual int_type        overflow(int c = EOF);   
   virtual std::streamsize xsputn(const char *s, std::streamsize n);
	virtual std::streambuf::pos_type        seekoff(std::streambuf::off_type off, std::ios_base::seekdir way,
                                   std::ios_base::openmode which = std::ios_base::in | std::ios_base::out);
	virtual std::streambuf::pos_type        seekpos(std::streambuf::pos_type sp,
                                   std::ios_base::openmode which = std::ios_base::in | std::ios_base::out);
private:
   char *m_buf;
   char *m_pStart;
   char *m_pReadLoc;
   long  m_segSize;
   bool m_bDeleteable;
};


// Used to store the location of a large object
// (OCTET STRING or ANY) within an AsnBuf card that
// contains a file (i.e. filebuf).
//
class SNACCDLL_API AsnFileSeg : public std::streambuf
{
public:
   explicit AsnFileSeg(const char *pFilename);
   explicit AsnFileSeg(AsnFileSeg *afs, unsigned long segLen);
   AsnFileSeg(const AsnFileSeg &o);
   ~AsnFileSeg();
   unsigned long size() { return m_segSize; }

protected:
   virtual int_type        underflow();
   virtual int_type        uflow();

   virtual int_type        overflow(int c = EOF) { return EOF; }
   virtual std::streamsize xsgetn(char *s, std::streamsize n);
   virtual std::streamsize xsputn(const char *s, std::streamsize n) { return overflow(); }
   virtual pos_type        seekoff(off_type off, std::ios_base::seekdir way,
                                   std::ios_base::openmode which = std::ios_base::in | std::ios_base::out);
   virtual pos_type        seekpos(pos_type sp,
                                   std::ios_base::openmode which = std::ios_base::in | std::ios_base::out);
private:
   long            m_offset;
   long            m_segSize;
   char           *m_filename;
   std::filebuf   *m_fb;
};

// Expanding buffer which contains a deque of streambufs.
// This allows for non-contiguous memory to be used for
// encoding. Each element (or card) in the deque (deck)
// can be a file or memory based.
//

// Deck contains a streambuf * and a bool flag that indicates
// whether or not the streambuf can be deleted. 
//
enum AsnBufType { FILE_TYPE=0, RVS_BUF_TYPE, IN_MEM_TYPE, EXT_MEM_TYPE} ;

class Card : public std::pair<std::streambuf *, AsnBufType>
{
public:
#if 0
   Card()
   {  first = NULL; second = EXT_MEM_TYPE;}
#endif

   Card(std::streambuf *sb)
   { first = sb; second = EXT_MEM_TYPE; }

   Card(const std::stringstream &ss)
   { first = ss.rdbuf(); second = EXT_MEM_TYPE;}

   Card(AsnRvsBuf *pRvsBuf)
   { first = pRvsBuf; second = RVS_BUF_TYPE;}

   Card(AsnFileSeg *pFs)
   { first = pFs; second = FILE_TYPE;}

   Card(const Card &o)
   {
      first = o.first;
      second = o.second;
   }
   
   virtual ~Card()
   {
      if (second != EXT_MEM_TYPE)
         delete first;
   }
  
   long size();    // number of bytes stored in card
   long length();  // number of bytes not read from card

#ifdef _DEBUG
   const char * bufTypeStr(); // return a string discribing the bufType
#endif

   void resetType(AsnBufType type) {second = type;}
   std::streambuf * rdbuf()  {return first;}
   const std::streambuf * rdbuf() const  {return first;}
   enum AsnBufType bufType() const {return second;}
};

} // end namespace SNACC

SNACCDLL_API void sortSet(std::list<SNACC::AsnBuf> &bufList);

SNACCDLL_API std::ostream & operator<<(std::ostream &os, const SNACC::AsnBuf &b);

#endif // _ASN_BUF_H
