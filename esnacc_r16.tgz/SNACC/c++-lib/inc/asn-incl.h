// file: .../c++-lib/inc/asn-incl.h - C++ class SNACCDLL_API
//
//
//  NEW HISTORY started once all SNACC class definitions move to a single file.
//

#ifndef SNACC_ASN_INCL_H
#define SNACC_ASN_INCL_H


#include "asn-config.h"
#include "asn-buf.h"

#ifdef WIN32
#pragma warning(push,3)
#include <string>
#pragma warning(pop)
#else // WIN32
#include <iostream>
#include <string>
#include "asn-chartraits.h" 

#if defined(SunOS) || defined(SCO_SV) || defined(HPUX) || defined(HPUX32)
namespace std
{
typedef basic_string<wchar_t> wstring;
}
#endif // SunOS
#endif

#if TCL
#include <tcl.h>
#undef VOID
#endif

#if META
#include "meta.h"
#endif

void SNACCDLL_API BDEC_2ND_EOC_OCTET(const SNACC::AsnBuf &b, SNACC::AsnLen &bytesDecoded);

_BEGIN_SNACC_NAMESPACE

//########################################################################
//########################################################################


#define INDEFINITE_LEN   ~0UL // max unsigned value used for indef rep
#define MAX_OCTS 1048576  // 1 meg

#ifdef USE_INDEF_LEN

#define BEncEocIfNec(b)\
    BEncEoc (b)

#define BEncConsLen(b, len)\
    2 + BEncIndefLen (b) /* include len for EOC */

#else // default -- use definite length -- usually faster (for snacc encoders) and smaller encodings

#define BEncEocIfNec(b) 0; /* do nothing */

#define BEncConsLen(b, len)\
    BEncDefLen (b, len)

#endif

#define BEncIndefLen( b)\
    1;\
    b.PutByteRvs (0x80)

/*
 * use if you know the encoded length will be 0 >= len <= 127
 * Eg for booleans, nulls, any resonable integers and reals
 *
 * NOTE: this particular Encode Routine does NOT return the length
 * encoded (1).  The length counter must be explicity incremented
 */
#define BEncDefLenTo127( b, len)\
    b.PutByteRvs ((unsigned char) len)



AsnLen SNACCDLL_API BDecLen (const AsnBuf &b, AsnLen &bytesDecoded);

AsnLen SNACCDLL_API BEncDefLen (AsnBuf &b, AsnLen len);

AsnLen SNACCDLL_API BEncEoc (AsnBuf &b);

void  SNACCDLL_API BDecEoc (const AsnBuf &b, AsnLen &bytesDecoded);

//########################################################################
//########################################################################

class SNACCDLL_API AsnType
{
public:
  virtual         ~AsnType();

  virtual AsnType      *Clone() const=0;

  virtual void        BDec (const AsnBuf &b, AsnLen &bytesDecoded)=0;
  virtual AsnLen      BEnc (AsnBuf &b) const =0 ;

  bool BEncPdu (AsnBuf &b, AsnLen &bytesEncoded) const;
  bool BDecPdu (const AsnBuf &b, AsnLen &bytesDecoded);

  virtual void        Print (std::ostream &) const=0;

  virtual const char * typeName(void) const { return "AsnType"; }

#if META
  static const AsnTypeDesc   _desc;

  virtual const AsnTypeDesc   *_getdesc() const;
  virtual AsnType      *_getref (const char *membername, bool create=false);

private:
  const char         *_typename() const;

#if TCL
public:
  virtual int         TclGetDesc (Tcl_DString *) const;
  virtual int         TclGetVal (Tcl_Interp *) const;
  virtual int         TclSetVal (Tcl_Interp *, const char *val);
  virtual int         TclUnsetVal (Tcl_Interp *, const char *membernames);
#endif // TCL
#endif // META
};

//########################################################################
//########################################################################

#if SIZEOF_INT == 4
  #define UL   unsigned int
#elif SIZEOF_LONG == 4
  #define UL   unsigned long
#elif SIZEOF_SHORT == 4
  #define UL   unsigned short
#else
  #define UL unsigned int
#endif
typedef UL   AsnTag;

// Tag Id's byte len
#define TB   sizeof (SNACC::AsnTag)

// The MAKE_TAG_ID macro generates the TAG_ID rep for the
// the given class/form/code (rep'd in long integer form)
// if the class/form/code are constants the compiler (should)
// calculate the tag completely --> zero runtime overhead.
// This is good for efficiently comparing tags in switch statements
// (decoding) etc.  because run-time bit fiddling (eliminated) minimized
#ifndef _IBM_ENC_
#define MAKE_TAG_ID( cl, fm, cd)\
   ((((UL)(cl)) << ((TB -1) * 8)) | (((UL)(fm)) << ((TB -1) * 8)) | (MAKE_TAG_ID_CODE (((UL)(cd)))))
#else
#define MAKE_TAG_ID( cl, fm, cd)\
   ((MAKE_TAG_ID_CODE (cd)) | (cl << ((TB -1) * 8)) | (fm << ((TB -1) * 8)))
#endif /* _IBM_ENC_ */

#define MAKE_TAG_ID_CODE( cd)\
( (cd < 31) ?  (MAKE_TAG_ID_CODE1 (cd)):\
      ((cd < 128)?  (MAKE_TAG_ID_CODE2 (cd)):\
    ((cd < 16384)?  (MAKE_TAG_ID_CODE3 (cd)):\
      (MAKE_TAG_ID_CODE4 (cd)))))

#define MAKE_TAG_ID_CODE1( cd) ((long int)cd << ((TB -1) * 8))
#define MAKE_TAG_ID_CODE2( cd) ((31l << ((TB -1) * 8)) | (cd << ((TB-2) * 8)))
#define MAKE_TAG_ID_CODE3( cd) ((31l << ((TB -1) * 8))\
            | ((cd & 0x3f80) << 9)\
            | ( 0x0080 << ((TB-2) * 8))\
            | ((cd & 0x007F) << ((TB-3)* 8)))

#define MAKE_TAG_ID_CODE4( cd) ((31l << ((TB -1) * 8))\
            | ((cd & 0x1fc000) << 2)\
            | ( 0x0080 << ((TB-2) * 8))\
            | ((cd & 0x3f80) << 1)\
            | ( 0x0080 << ((TB-3) * 8))\
            | ((cd & 0x007F) << ((TB-4)*8)))


typedef enum BER_CLASS
{
    ANY_CLASS = -2,
    NULL_CLASS = -1,
    UNIV = 0,
    APPL = (1 << 6),
    CNTX = (2 << 6),
    PRIV = (3 << 6)
} BER_CLASS;

typedef enum BER_FORM
{
    ANY_FORM = -2,
    NULL_FORM = -1,
    PRIM = 0,
    CONS = (1 << 5)
} BER_FORM;


typedef enum BER_UNIV_CODE
{
    NO_TAG_CODE = 0,
    BOOLEAN_TAG_CODE = 1,
    INTEGER_TAG_CODE,
    BITSTRING_TAG_CODE,
    OCTETSTRING_TAG_CODE,
    NULLTYPE_TAG_CODE,
    OID_TAG_CODE,
    OD_TAG_CODE,
    EXTERNAL_TAG_CODE,
    REAL_TAG_CODE,
    ENUM_TAG_CODE,
    UTF8STRING_TAG_CODE=12,
    SEQ_TAG_CODE =  16,
    SET_TAG_CODE,
    NUMERICSTRING_TAG_CODE,
    PRINTABLESTRING_TAG_CODE,
    TELETEXSTRING_TAG_CODE,
    VIDEOTEXSTRING_TAG_CODE,
    IA5STRING_TAG_CODE,
    UTCTIME_TAG_CODE,
    GENERALIZEDTIME_TAG_CODE,
    GRAPHICSTRING_TAG_CODE,
    VISIBLESTRING_TAG_CODE,
    GENERALSTRING_TAG_CODE,
    UNIVERSALSTRING_TAG_CODE = 28,
    BMPSTRING_TAG_CODE = 30
} BER_UNIV_CODE;

#define TT61STRING_TAG_CODE TELETEXSTRING_TAG_CODE
#define ISO646STRING_TAG_CODE VISIBLESTRING_TAG_CODE

/*
 * the TAG_ID_[CLASS/FORM/CODE] macros are not
 * super fast - try not to use during encoding/decoding
 */
#define TAG_ID_CLASS( tid) ( (tid & (0xC0 << ((TB-1) *8))) >> ((TB -1) * 8))
#define TAG_ID_FORM( tid)  ( (tid & (0x20 << ((TB-1) *8))) >> ((TB -1) * 8))

/*
 * TAG_IS_CONS evaluates to true if the given AsnTag type
 * tag has the constructed bit set.
 */
#define TAG_IS_CONS(tag) ((tag) & (CONS << ((TB-1) *8)))


#define EOC_TAG_ID 0



/*
 * tag encoders.  given constant exprs for class SNACCDLL_API form & code in the
 * source, these can be optimized by the compiler (eg
 * do the shifts and bitwise ors etc)
 */

#define BEncTag1( b, class, form, code)\
    1;\
    b.PutByteRvs ((unsigned char)((class) | (form) | (code)))

#define BEncTag2( b, class, form, code)\
    2;\
    b.PutByteRvs (code);\
    b.PutByteRvs ((char)((class) | (form) | 31))

#define BEncTag3( b, class, form, code)\
    3;\
    b.PutByteRvs ((code) & 0x7F);\
    b.PutByteRvs ((char)(0x80 | (char)((code) >> 7)));\
    b.PutByteRvs ((class) | (form) | 31)

#define BEncTag4( b, class, form, code)\
    4;\
    b.PutByteRvs ((code) & 0x7F);\
    b.PutByteRvs ((char)(0x80 | (char)((code) >> 7)));\
    b.PutByteRvs ((char)(0x80 | (char)((code) >> 14)));\
    b.PutByteRvs ((class) | (form) | 31)

#define BEncTag5( b, class, form, code)\
    5;\
    b.PutByteRvs ((code) & 0x7F);\
    b.PutByteRvs ((char)(0x80 | (char)((code) >> 7)));\
    b.PutByteRvs ((char)(0x80 | (char)((code) >> 14)));\
    b.PutByteRvs ((char)(0x80 | (char)((code) >> 21)));\
    b.PutByteRvs ((class) | (form) | 31)


AsnTag SNACCDLL_API BDecTag (const AsnBuf &b, AsnLen &bytesDecoded);

//########################################################################
//########################################################################

class SNACCDLL_API AsnOid: public AsnType
{

public:
	AsnOid()								{ Init(); PutChar("0.0"); }
	AsnOid(const char *encOid, size_t len)	{ Init(); Set(encOid, len); }
	AsnOid(const AsnOid &o)					{ Init(); Set(o); }
	AsnOid(const char *pszOID)				{ Init(); PutChar(pszOID); }
	~AsnOid();

	AsnOid& operator=(const AsnOid &o)		{ Set(o); return *this; }
	operator const char*() const;
	virtual AsnType *Clone() const			{ return new AsnOid(*this); }

	size_t Len() const						{ return octetLen; }
	const char *Str() const					{ return oid; }
   
	// get a copy of the OID's NULL-terminated dotted string notation
	char* GetChar(void) const;
   
	// set from a number-dot null term string
	void PutChar(const char *szOidCopy);
   
	// *** End of dotted string members ***
	unsigned long int NumArcs(void) const;

	bool operator==(const AsnOid &o) const		{ return OidEquiv(o); }
	bool operator==(const char *o) const;
	bool operator!=(const AsnOid &o) const		{ return !OidEquiv (o); }
	bool operator!=(const char *o) const		{ return !operator==(o); }
	bool operator<(const AsnOid &o) const;
  
	unsigned long GetLongOid(unsigned long *&pOidLong); //array terminates with -1.

	// Set methods overwrite oid and octetLen values
	void Set(const char *encOid, size_t len);
	void Set(const AsnOid &o);

  // first two arc numbers are mandatory.  rest are optional since negative arc nums are not allowed in the
  // encodings, use them to indicate the 'end of arc numbers' in the optional parameters
  void            Set (unsigned long arcNumArr[], long arrLength);

  AsnLen         BEncContent (AsnBuf &b) const;
  void           BDecContent (const AsnBuf &b, AsnTag tagId, AsnLen elmtLen, AsnLen &bytesDecoded);
  AsnLen         BEnc (AsnBuf &b) const;
  void           BDec (const AsnBuf &b, AsnLen &bytesDecoded);

  void            Print (std::ostream &os) const;
  void            PrintXML (std::ostream &os, const char *lpszTitle=NULL) const;

#if META
  static const AsnOidTypeDesc   _desc;

  const AsnTypeDesc      *_getdesc() const;

#if TCL
  int            TclGetVal (Tcl_Interp *) const;
  int            TclSetVal (Tcl_Interp *, const char *val);
#endif /* TCL */
#endif /* META */

private:
	bool OidEquiv (const AsnOid &o) const;
	void createDottedOidStr() const;
	void Init()		{ 	octetLen = 0; oid = NULL; m_lpszOidString = NULL; }

protected:
   size_t         octetLen;
   char           *oid;
   mutable char   *m_lpszOidString;
};

typedef std::pair<unsigned char *, unsigned long> StringPair;

class ConsStringDeck : public std::deque< StringPair >
{
public:
   ConsStringDeck(AsnTag baseTag = OCTETSTRING_TAG_CODE) {m_baseTag = baseTag;}
   
   virtual ~ConsStringDeck(); 
   void Fill(const AsnBuf &b, AsnLen elmtLen, AsnLen &bytesDecoded);
   void Collapse(std::string &str);

private:
   AsnTag m_baseTag;
};

//########################################################################
//########################################################################

class SNACCDLL_API AsnOcts: public AsnType
{
public:
   // constructor always copies strings so destructor can always delete
   AsnOcts() {m_pFileSeg = NULL;}
   AsnOcts (const char *str) { m_pFileSeg = NULL; m_str.assign(str); }
   AsnOcts (const char *str, const size_t len) { m_pFileSeg = NULL; m_str.assign(str, len); }
   AsnOcts (const AsnOcts &o);
//   AsnOcts (const std::filebuf &fb);
   virtual ~AsnOcts();

   virtual AsnType     *Clone() const { return new AsnOcts(*this);}

   AsnOcts      &operator = (const AsnOcts &o)  { m_str = o.m_str; return *this; }
   AsnOcts      &operator = (const char *str)   { m_str.assign(str); return *this; }

   void         Set (const char *str, size_t len);

   size_t       Len() const;

   const std::string &   data() const;
   const char *          c_str() const;
   const unsigned char * c_ustr() const;

   bool operator == (const AsnOcts &o) const;
   bool operator != (const AsnOcts &o) const;

   AsnLen         BEncContent (AsnBuf &b) const;
   void           BDecContent (const AsnBuf &b, AsnTag tagId, AsnLen elmtLen, AsnLen &bytesDecoded);
   AsnLen         BEnc (AsnBuf &b) const ;
   void           BDec (const AsnBuf &b, AsnLen &bytesDecoded);

   void           Print (std::ostream &os) const;
   void           PrintXML (std::ostream &os, const char *lpszTitle=NULL,
                     const char *lpszType=NULL) const;


private:
  void           BDecConsOcts (const AsnBuf &b, AsnLen elmtLen, AsnLen &bytesDecoded);
  void           FillStringDeck(AsnBuf &b, AsnLen elmtLen, AsnLen &bytesDecoded);
  
  // IF AsnOcts length is < MAX_OCTS, store in AsnString base
  mutable std::string  m_str;

  // IF AsnOcts length is > MAX_OCTS, store in m_FileBuf;
  mutable AsnFileSeg     *m_pFileSeg;
};

//########################################################################
//########################################################################


class SNACCDLL_API AsnInt : public AsnType
{
protected:
   unsigned char *m_bytes;
   unsigned long  m_len;
   void storeDERInteger(const unsigned char *pDataCopy, long dataLen, bool unsignedFlag);

public:
   AsnInt (AsnIntType val=0);
   AsnInt (const char *str, bool unsignedFlag = true);
   AsnInt (const AsnOcts &o, bool unsignedFlag = true);
   AsnInt (const char *str, const size_t len, bool unsignedFlag = true);
   AsnInt (const AsnInt &that);
   ~AsnInt ();

   virtual AsnType        *Clone() const {return new AsnInt(*this);}

   operator AsnIntType() const;
   bool        operator == (AsnIntType o) const;
   bool        operator != (AsnIntType o) const		{ return !operator==(o);}
   bool        operator == (const AsnInt &o) const;
   bool        operator != (const AsnInt &o) const;
   bool        operator < (const AsnInt &o) const;
   AsnInt &    operator = (const AsnInt &o);

   long length(void) const { return m_len; }
   const unsigned char * c_str(void) const { return m_bytes; }
   void getPadded(unsigned char *&data, size_t &len, const size_t padToSize=0) const;

   
   void        Set(const unsigned char *str, size_t len, bool unsignedFlag=true);
   void        Set(AsnIntType i);

   AsnLen         BEnc (AsnBuf &b) const;
   void           BDec (const AsnBuf &b, AsnLen &bytesDecoded);
   AsnLen         BEncContent (AsnBuf &b) const;
   void           BDecContent (const AsnBuf &b, AsnTag tagId, AsnLen elmtLen, AsnLen &bytesDecoded);


   virtual const char * typeName(void) const { return "INTEGER"; }
  
   void      Print (std::ostream &os) const;
   void      PrintXML (std::ostream &os, const char *lpszTitle=NULL) const; 

#if META
  static const AsnIntTypeDesc   _desc;

  const AsnTypeDesc      *_getdesc() const;

#if TCL
  int            TclGetVal (Tcl_Interp *) const;
  int            TclSetVal (Tcl_Interp *, const char *val);
#endif /* TCL */
#endif /* META */
};


//########################################################################
//########################################################################
//hash.h
#define TABLESIZE 256
#define INDEXMASK 0xFF
#define INDEXSHIFT 8

typedef void *Table[TABLESIZE];

typedef unsigned int Hash;

typedef struct HashSlot
{
  int    leaf;
  Hash   hash;
  void  *value;
  Table *table;
} HashSlot;

Hash MakeHash (const char *str, size_t len);

Table *InitHash();

int Insert (Table *table, void *element, Hash hash);

int CheckFor (Table *table, Hash hash);

int CheckForAndReturnValue (Table *table, Hash hash, void **value);

//########################################################################
//########################################################################

extern SNACCDLL_API char         numToHexCharTblG[];

#define TO_HEX( fourBits)   (numToHexCharTblG[(fourBits) & 0x0F])

class SNACCDLL_API AsnBits: public AsnType
{
public:

  AsnBits(const char *stringForm=NULL);
  AsnBits (size_t numBits) 
          { bits=NULL;nblFlag = false; Set (numBits); }
  AsnBits (const char *bitOcts, size_t numBits)
          {bits=NULL; nblFlag = false; Set (bitOcts, numBits); }
  AsnBits (const AsnBits &b)      { bits=NULL; Set (b); }
  ~AsnBits();

  virtual AsnType         *Clone() const {return new AsnBits(*this);}

  AsnBits         &operator = (const AsnBits &b)      { Set (b); return *this; }

  // overwrite existing bits and bitLen values
  void            Set (size_t numBits);
  void            Set (const char *bitOcts, size_t numBits);
  void            Set (const AsnBits &b);

  AsnBits &       operator = (const char *stringForm);
  bool            operator == (const AsnBits &ab) const   { return BitsEquiv (ab); }
  bool            operator != (const AsnBits &ab) const   { return !BitsEquiv (ab); }

  bool            soloBitCheck(size_t);
  void            SetBit (size_t);
  void            ClrBit (size_t);
  bool            GetBit (size_t) const;
  bool            IsEmpty() const;

  void            UseNamedBitListRules(bool flag) { nblFlag = flag; }

  size_t         BitLen() const            { return bitLen; }
  const char *   data() const { return bits; }
  size_t         length() const { return ((bitLen+7)/8); }

  AsnLen         BEncContent (AsnBuf &b) const;
  void           BDecContent (const AsnBuf &b, AsnTag tagId, AsnLen elmtLen, AsnLen &bytesDecoded);
  AsnLen         BEnc (AsnBuf &b) const;
  void           BDec (const AsnBuf &b, AsnLen &bytesDecoded);

  void            Print (std::ostream &) const;
  void            PrintXML (std::ostream &os, const char *lpszTitle=NULL) const;

#if META
  static const AsnBitsTypeDesc   _desc;

  const AsnTypeDesc      *_getdesc() const;

#if TCL
  int            TclGetVal (Tcl_Interp *) const;
  int            TclSetVal (Tcl_Interp *, const char *val);
#endif /* TCL */
#endif /* META */

private:
  bool            BitsEquiv (const AsnBits &ab) const;
  void            BDecConsBits (const AsnBuf &b, AsnLen elmtLen, AsnLen &bytesDecoded);

protected:
  size_t       bitLen;
  char         *bits;
  bool         nblFlag;

};

//########################################################################

class SNACCDLL_API AsnBool: public AsnType
{
protected:

  bool            value;

public:
   AsnBool (const bool val=false):
     value (val)
   {}

   virtual AsnType         *Clone() const {return new AsnBool(*this);}

   operator bool() const         { return value; }

   AsnBool         &operator = (bool newvalue)      { value = newvalue; return *this; }

   AsnLen         BEnc (AsnBuf &b) const;
   void           BDec (const AsnBuf &b, AsnLen &bytesDecoded);
   AsnLen         BEncContent (AsnBuf &b) const;
   void           BDecContent (const AsnBuf &b, AsnTag tagId, AsnLen elmtLen, AsnLen &bytesDecoded);

   void           Print (std::ostream &) const;
   void           PrintXML (std::ostream &os, const char *lpszTitle=NULL) const; 

#if META
  static const AsnBoolTypeDesc   _desc;

  const AsnTypeDesc      *_getdesc() const;

#if TCL
  int            TclGetVal (Tcl_Interp *) const;
  int            TclSetVal (Tcl_Interp *, const char *val);
#endif // TCL
#endif // META
};

//########################################################################
//########################################################################

class SNACCDLL_API AsnEnum: public AsnInt
{
public:
#if !TCL
            AsnEnum():
              AsnInt()
            {}
#endif
            AsnEnum (int i):
              AsnInt (i)
            {}

              virtual AsnType         *Clone() const{return new AsnEnum(*this);}

  AsnLen         BEnc (AsnBuf &b) const;
  void            BDec (const AsnBuf &b, AsnLen &bytesDecoded);

#if META
  static const AsnEnumTypeDesc   _desc;

  const AsnTypeDesc      *_getdesc() const;

#if TCL
  int            TclGetVal (Tcl_Interp *) const;
  int            TclSetVal (Tcl_Interp *, const char *val);
#endif /* TCL */
#endif /* META */
};



//########################################################################
//########################################################################

class SNACCDLL_API AsnNull: public AsnType
{
public:
  virtual AsnType         *Clone() const {return new AsnNull(*this);}

  AsnLen         BEncContent (AsnBuf &) const      { return 0; }
  void           BDecContent (const AsnBuf &b, AsnTag tagId, AsnLen elmtLen, AsnLen &bytesDecoded);
  AsnLen         BEnc (AsnBuf &b) const;
  void           BDec (const AsnBuf &b, AsnLen &bytesDecoded);

  void           Print (std::ostream &os) const;
  void           PrintXML (std::ostream &os, const char *lpszTitle=NULL) const;

#if META
  static const AsnNullTypeDesc   _desc;

  const AsnTypeDesc      *_getdesc() const;

#if TCL
  int            TclGetVal (Tcl_Interp *) const;
  int            TclSetVal (Tcl_Interp *, const char *val);
#endif /* TCL */
#endif /* META */
};

//########################################################################
//########################################################################

class SNACCDLL_API AsnReal: public AsnType
{
protected:
  double         value;

public:
   AsnReal():value (0.0){}
   AsnReal (double val):value (val){}

   virtual AsnType *Clone() const { return new AsnReal(*this);}

                  operator double() const         { return value; }
   AsnReal       &operator = (double newvalue)    { value = newvalue; return *this; }

   AsnLen         BEncContent (AsnBuf &b) const;
   void           BDecContent (const AsnBuf &b, AsnTag tagId, AsnLen elmtLen, AsnLen &bytesDecoded);
   AsnLen         BEnc (AsnBuf &b) const;
   void           BDec (const AsnBuf &b, AsnLen &bytesDecoded);

   void           Print (std::ostream &os) const;
   void           PrintXML (std::ostream &os, const char *lpszTitle=NULL) const; 

#if META
  static const AsnRealTypeDesc   _desc;

  const AsnTypeDesc      *_getdesc() const;

#if TCL
  int            TclGetVal (Tcl_Interp *) const;
  int            TclSetVal (Tcl_Interp *, const char *val);
#endif /* TCL */
#endif /* META */
};

extern const AsnReal      PLUS_INFINITY;
extern const AsnReal      MINUS_INFINITY;


//########################################################################
//########################################################################

/* this is put into the hash table with the int or oid as the key */
class SNACCDLL_API AnyInfo
{
public:
  int            anyId;   // will be a value from the AnyId enum
  AsnOid         oid;   // will be zero len/null if intId is valid
  AsnIntType     intId;
  AsnType        *typeToClone;
};

class SNACCDLL_API AsnAny: public AsnType
{
public:
   static Table         *oidHashTbl;   // all AsnAny class SNACCDLL_API instances
   static Table         *intHashTbl;   // share these tables
   mutable AnyInfo      *ai;      // points to entry in hash tbl for this type
   AsnType              *value;
   AsnBuf               *anyBuf; // used if ai == null

   AsnAny()            { ai = NULL; value = NULL; anyBuf=NULL;}
   AsnAny(const AsnAny &o) { ai = NULL; value = NULL; anyBuf = NULL; *this = o; }
   virtual ~AsnAny();

   AsnAny &operator = (const AsnAny &o);
   virtual AsnType * Clone() const { return new AsnAny(*this); }

   static void AsnAnyDestroyHashTbls(); 
   
   // Recursive call to destroy table during destruction
   static void AsnAnyDestroyHashTbl(Table *&pHashTbl);

   // class SNACCDLL_API level methods
   static void         InstallAnyByInt (AsnIntType intId, int anyId, AsnType *type);
   static void         InstallAnyByOid (AsnOid &oid,  int anyId, AsnType *type);

   int            GetId()   const            { return ai ? ai->anyId : -1; }
   void           SetTypeByInt (const AsnInt& id) const;
   void           SetTypeByOid (const AsnOid &id) const;

   AsnLen         BEnc (AsnBuf &b) const;
   void           BDec (const AsnBuf &b, AsnLen &bytesDecoded);

   void   Print (std::ostream &) const;
   void   PrintXML (std::ostream &os, const char *lpszTitle=NULL) const; 

#if TCL
   int            TclGetDesc (Tcl_DString *) const;
   int            TclGetVal (Tcl_DString *) const;
   int            TclSetVal (Tcl_Interp *, const char *val);
   int            TclUnSetVal (Tcl_Interp *, const char *member);
#endif /* TCL */

};


// SNACC ASN.1 String Types
//
// DEFINE some extra functionality to the "*String" classes using similar names
// RWC;

class SNACCDLL_API AsnString : public std::string, public AsnType
{
public:
	AsnString(const char* str = NULL)				{ operator=(str); }
	AsnString(const std::string& str)				{ operator=(str); }
	
	AsnString& operator=(const char* str);
	AsnString& operator=(const std::string& str)	{ assign(str); return *this; }
	
//	const std::string & get();
//	void set(const AsnString &o);
	
	int cvt_LDAPtoStr  (char *in_string, char  **char_ptr);
	int cvt_StrtoLDAP  (wchar_t *in_string, char  **char_ptr);
	
	// returns a null terminated 'C' string
   //	const char *c_str() const;
	
	AsnLen BEnc(AsnBuf &b) const;
	void   BDec(const AsnBuf &b, AsnLen& bytesDecoded);
	AsnLen BEncContent(AsnBuf &b) const;
	void   BDecContent(const AsnBuf &b, AsnTag tagId, AsnLen elmtLen,
		AsnLen& bytesDecoded);
	
	
	// each string type must implement these methods
	// 
	// tagCode should be implemented to return the ASN.1 tag corresponding to the 
	// character string type.
	//
	// the check method should be implemented to enforce any rules imposed on the 
	// character string type.
	virtual BER_UNIV_CODE tagCode(void) const = 0;
	virtual bool check() const						{ return true; }
	
	void Print(std::ostream& os) const;
	void PrintXML(std::ostream& os, const char *lpszTitle) const;
	
private:
	void BDecConsString(const AsnBuf &b, AsnLen elmtLen, AsnLen &bytesDecoded);
};


class SNACCDLL_API NumericString : public AsnString
{
public:
	NumericString(const char* str = NULL) : AsnString(str)		{}
	NumericString(const std::string& str) : AsnString(str)		{}
	
	NumericString& operator=(const char* str)
		{ AsnString::operator=(str); return *this;}
	NumericString& operator=(const std::string& str)
		{ AsnString::operator=(str); return *this; }

    AsnType* Clone() const					{ return new NumericString(*this); }
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return NUMERICSTRING_TAG_CODE; }
	bool check() const;				// Enforce string rules
};


class SNACCDLL_API PrintableString : public AsnString
{
public:
	PrintableString(const char* str = NULL) : AsnString(str)	{}
	PrintableString(const std::string& str) : AsnString(str)	{}
	
	PrintableString& operator=(const char* str)
		{ AsnString::operator=(str); return *this;}
	PrintableString& operator=(const std::string& str)
		{ AsnString::operator=(str); return *this; }

    AsnType* Clone() const					{ return new PrintableString(*this); }
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return PRINTABLESTRING_TAG_CODE; }
	bool check() const;				// Enforce string rules
};


class SNACCDLL_API TeletexString : public AsnString
{
public:
	TeletexString(const char* str = NULL) : AsnString(str)		{}
	TeletexString(const std::string& str) : AsnString(str)		{}
	
	TeletexString& operator=(const char* str)
		{ AsnString::operator=(str); return *this;}
	TeletexString& operator=(const std::string& str)
		{ AsnString::operator=(str); return *this; }

    AsnType* Clone() const					{ return new TeletexString(*this); }
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return TELETEXSTRING_TAG_CODE; }
};

// T61String -- Alternate name for TeletexString
typedef TeletexString T61String;


class SNACCDLL_API VideotexString : public AsnString
{
public:
	VideotexString(const char* str = NULL) : AsnString(str)		{}
	VideotexString(const std::string& str) : AsnString(str)		{}
	
	VideotexString& operator=(const char* str)
		{ AsnString::operator=(str); return *this;}
	VideotexString& operator=(const std::string& str)
		{ AsnString::operator=(str); return *this; }

    AsnType* Clone() const					{ return new VideotexString(*this); }
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return VIDEOTEXSTRING_TAG_CODE; }
};

class SNACCDLL_API IA5String : public AsnString
{
public:
	IA5String(const char* str = NULL) : AsnString(str)		{}
	IA5String(const std::string& str) : AsnString(str)		{}
	
	IA5String& operator=(const char* str)
		{ AsnString::operator=(str); return *this;}
	IA5String& operator=(const std::string& str)
		{ AsnString::operator=(str); return *this; }

    AsnType* Clone() const					{ return new IA5String(*this); }
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return IA5STRING_TAG_CODE; }
	bool check() const;				// Enforce string rules
};


class SNACCDLL_API GraphicString : public AsnString
{
public:
	GraphicString(const char* str = NULL) : AsnString(str)		{}
	GraphicString(const std::string& str) : AsnString(str)		{}
	
	GraphicString& operator=(const char* str)
		{ AsnString::operator=(str); return *this;}
	GraphicString& operator=(const std::string& str)
		{ AsnString::operator=(str); return *this; }

    AsnType* Clone() const					{ return new GraphicString(*this); }
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return GRAPHICSTRING_TAG_CODE; }
};


class SNACCDLL_API VisibleString : public AsnString
{
public:
	VisibleString(const char* str = NULL) : AsnString(str)		{}
	VisibleString(const std::string& str) : AsnString(str)		{}
	
	VisibleString& operator=(const char* str)
		{ AsnString::operator=(str); return *this;}
	VisibleString& operator=(const std::string& str)
		{ AsnString::operator=(str); return *this; }

    AsnType* Clone() const					{ return new VisibleString(*this); }
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return VISIBLESTRING_TAG_CODE; }
	bool check() const;				// Enforce string rules
};

// ISO646String -- Alternate name for VisibleString
typedef VisibleString ISO646String;


class SNACCDLL_API GeneralString : public AsnString
{
public:
	GeneralString(const char* str = NULL) : AsnString(str)		{}
	GeneralString(const std::string& str) : AsnString(str)		{}
	
	GeneralString& operator=(const char* str)
		{ AsnString::operator=(str); return *this;}
	GeneralString& operator=(const std::string& str)
		{ AsnString::operator=(str); return *this; }

    AsnType* Clone() const					{ return new GeneralString(*this); }
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return GENERALSTRING_TAG_CODE; }
};


// Multi-byte character based definitions... BMP, Universal, UTF8.
class SNACCDLL_API WideAsnString : public std::wstring, public AsnType
{
public:
	WideAsnString(const char* str = NULL)				{ set(str); }
	WideAsnString(const std::string& str)				{ set(str.c_str()); }
	WideAsnString(const std::wstring& wstr) 			{ assign(wstr); }
	
	// each string type must implement these methods
	// 
	// tagCode should be implemented to return the ASN.1 tag corresponding to the 
	// character string type.
	//
	// the check method should be implemented to enforce any rules imposed on the 
	// character string type.
	virtual BER_UNIV_CODE tagCode() const = 0;
//	virtual bool check() const = 0;
	
	AsnLen BEnc(AsnBuf &b) const;
	void   BDec(const AsnBuf &b, AsnLen &bytesDecoded);
	virtual AsnLen BEncContent(AsnBuf &b) const = 0;
	virtual void   BDecContent(const AsnBuf &b, AsnTag tagId, AsnLen elmtLen,
		AsnLen &bytesDecoded) = 0;
	
	void Print(std::ostream &os) const;
	void PrintXML(std::ostream &os, const char *lpszTitle) const;
	
	void set(const char* str);
//	void set(const std::wstring &wcstr);
//	void set(const WideAsnString &that);
	
//	const std::wstring & get() const;
	void getAsUTF8(std::string &utf8String) const;
	char* getAsUTF8() const;
	
protected:
	AsnLen CombineConsString(const AsnBuf &b, AsnLen elmtLen, std::string& encStr);
};

class SNACCDLL_API BMPString : public WideAsnString
{
public:
	BMPString(const char* str = NULL) : WideAsnString(str) 			{}
	BMPString(const std::string& str) : WideAsnString(str)			{}
	BMPString(const std::wstring& wstr) : WideAsnString(wstr)		{}
	
	BMPString& operator=(const char* str)
		{ set(str); return *this;}
	BMPString& operator=(const std::string& str)
		{ set(str.c_str()); return *this; }
	BMPString& operator=(const std::wstring& wstr)
		{ assign(wstr); return *this; }
	
	const char* typeName()					{ return "BMPString"; }
	AsnType* Clone() const					{ return new BMPString(*this); }
	
	AsnLen BEncContent(AsnBuf &b) const;
	void   BDecContent(const AsnBuf &b, AsnTag tagId, AsnLen elmtLen,
		AsnLen &bytesDecoded);
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return BMPSTRING_TAG_CODE; }
//	bool check() const; 			// Enforce string rules
};


class SNACCDLL_API UniversalString : public WideAsnString
{
public:
	UniversalString(const char* str = NULL) : WideAsnString(str)		{}
	UniversalString(const std::string& str) : WideAsnString(str)		{}
	UniversalString(const std::wstring& wstr) : WideAsnString(wstr) 	{}
	
	UniversalString& operator=(const char* str)
		{ set(str); return *this;}
	UniversalString& operator=(const std::string& str)
		{ set(str.c_str()); return *this; }
	UniversalString& operator=(const std::wstring& wstr)
		{ assign(wstr); return *this; }

	const char* typeName()				{ return "UniversalString"; }
	AsnType* Clone() const				{ return new UniversalString(*this); }

	AsnLen BEncContent(AsnBuf &b) const;
	void   BDecContent(const AsnBuf &b, AsnTag tagId, AsnLen elmtLen,
		AsnLen &bytesDecoded);
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const		{ return UNIVERSALSTRING_TAG_CODE; }
//	bool check() const; 			// Enforce string rules
};


class SNACCDLL_API UTF8String : public WideAsnString
{
public:
	UTF8String(const char* str = NULL) : WideAsnString(str) 		{}
	UTF8String(const std::string& str) : WideAsnString(str) 		{}
	UTF8String(const std::wstring& wstr) : WideAsnString(wstr) 		{}
	
	UTF8String& operator=(const char* str)
		{ set(str); return *this;}
	UTF8String& operator=(const std::string& str)
		{ set(str.c_str()); return *this; }
	UTF8String& operator=(const std::wstring& wstr)
		{ assign(wstr); return *this; }

	const char* typeName()				{ return "UTF8String"; }
	AsnType* Clone() const				{ return new UTF8String(*this); }

	AsnLen BEncContent(AsnBuf &b) const;
	void   BDecContent(const AsnBuf &b, AsnTag tagId, AsnLen elmtLen,
		AsnLen &bytesDecoded);
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const		{ return UTF8STRING_TAG_CODE; }
//	bool check() const; 			// Enforce string rules
};


// Time Classes
//
class SNACCDLL_API UTCTime : public VisibleString
{
public:
	UTCTime(const char* str = NULL) : VisibleString(str)	{}
	UTCTime(const std::string& str) : VisibleString(str)	{}
	virtual ~UTCTime()										{}
	
	UTCTime& operator=(const char* str)
		{ VisibleString::operator=(str); return *this;}
	UTCTime& operator=(const std::string& str)
		{ VisibleString::operator=(str); return *this; }

    AsnType* Clone() const					{ return new UTCTime(*this); }
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return UTCTIME_TAG_CODE; }
};


class SNACCDLL_API GeneralizedTime : public VisibleString
{
public:
	GeneralizedTime(const char* str = NULL) : VisibleString(str)	{}
	GeneralizedTime(const std::string& str) : VisibleString(str)	{}
	virtual ~GeneralizedTime()										{}
	
	GeneralizedTime& operator=(const char* str)
		{ VisibleString::operator=(str); return *this;}
	GeneralizedTime& operator=(const std::string& str)
		{ VisibleString::operator=(str); return *this; }

    AsnType* Clone() const					{ return new GeneralizedTime(*this); }
	
	// ASN.1 tag for the character string
	BER_UNIV_CODE tagCode() const			{ return GENERALIZEDTIME_TAG_CODE; }
};


// AnyDefinedBy is currently the same as AsnAny:
typedef AsnAny         AsnAnyDefinedBy;

void SNACCDLL_API threadLock();
void SNACCDLL_API threadUnlock();
void SNACCDLL_API threadDestroy();
extern "C" {
void SNACCDLL_API SNACC_CleanupMemory();
}


//########################################################################
//########################################################################

_END_SNACC_NAMESPACE

//#include "sm_vdasnacc.h"
#include "print.h"
#include "snaccexcept.h"
#include "asn-list.h"
#include "asn-usefultypes.h"

#endif
