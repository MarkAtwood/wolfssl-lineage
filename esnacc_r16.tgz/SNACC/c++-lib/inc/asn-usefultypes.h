
_BEGIN_SNACC_NAMESPACE

/* [UNIVERSAL 7] IMPLICIT OCTET STRING */
class SNACCDLL_API ObjectDescriptor: public AsnOcts
{
public:
	ObjectDescriptor(): AsnOcts() {}
	ObjectDescriptor (const char *str): AsnOcts (str) {}
	ObjectDescriptor (const char *str, const size_t len): AsnOcts (str, len) {}
	ObjectDescriptor &operator = (const char *str) { AsnOcts::operator=(str); return *this;}
  AsnType		*Clone() const;

  AsnLen		BEnc (AsnBuf &b) const;
  void			BDec (const AsnBuf &b, AsnLen &bytesDecoded/*, s env*/);

};

class SNACCDLL_API EXTERNALChoice: public AsnType
{
public:
  enum ChoiceIdEnum
  {
     NoChoiceCid=-1,
     single_ASN1_typeCid = 0,
     octet_alignedCid = 1,
     arbitraryCid = 2
  };

  enum ChoiceIdEnum	choiceId;
  union
  {
     void * NoChoice;
     AsnOcts		*single_ASN1_type;
     AsnOcts		*octet_aligned;
     AsnBits		*arbitrary;
  };


   EXTERNALChoice() {Init();}
   EXTERNALChoice(const EXTERNALChoice& that);
public:
  virtual const char * typeName(void) const { return "EXTERNALChoice"; }
   void Init(void);
   virtual ~EXTERNALChoice() {Clear();}

   void Clear();

  AsnType		*Clone() const;

  EXTERNALChoice		&operator = (const EXTERNALChoice &that);
  AsnLen		BEncContent (AsnBuf &b) const;
  void			BDecContent (const AsnBuf &b, AsnTag tag, AsnLen elmtLen, AsnLen &bytesDecoded/*, s env*/);
  AsnLen		BEnc (AsnBuf &b) const;
  void			BDec (const AsnBuf &b, AsnLen &bytesDecoded/*, s env*/);

  void			Print (std::ostream &os) const;
  void			PrintXML (std::ostream &os, const char *lpszTitle=NULL) const;
};


class SNACCDLL_API EXTERNAL: public AsnType
{
public:
  AsnOid		*direct_reference;
  AsnInt		*indirect_reference;
  ObjectDescriptor		*data_value_descriptor;
  EXTERNALChoice		*encoding;

   EXTERNAL() {Init();}
   void Init(void);
   virtual ~EXTERNAL() {Clear();}
   void Clear();
   EXTERNAL(const EXTERNAL& that);
public:
  virtual const char * typeName(void) const { return "EXTERNAL"; }
  AsnType		*Clone() const;

  EXTERNAL		&operator = (const EXTERNAL &that);
  AsnLen		BEncContent (AsnBuf &b) const;
  void	   BDecContent (const AsnBuf &b, AsnTag tag, AsnLen elmtLen, AsnLen &bytesDecoded/*, s env*/);

  AsnLen		BEnc (AsnBuf &b) const;
  void		BDec (const AsnBuf &b, AsnLen &bytesDecoded/*, s env*/);

  void		Print (std::ostream &os) const;
  void		PrintXML (std::ostream &os, const char *lpszTitle=NULL) const;
};

_END_SNACC_NAMESPACE
