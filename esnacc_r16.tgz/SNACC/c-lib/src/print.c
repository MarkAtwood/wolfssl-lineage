/*
 * print.c - library routines for printing ASN.1 values.
 *
 * Copyright (C) 1992 Michael Sample and the University of British Columbia
 *
 * This library is free software; you can redistribute it and/or
 * modify it provided that this copyright/license information is retained
 * in original form.
 *
 * If you modify this file, you must clearly indicate your changes.
 *
 * This source code is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * $Header: /baseline/SNACC/c-lib/src/print.c,v 1.6 2003/01/15 17:44:59 mcphersc Exp $
 * $Log: print.c,v $
 * Revision 1.6  2003/01/15 17:44:59  mcphersc
 * took out stdIdentG global variable
 *
 * Revision 1.5  2002/10/21 17:01:29  mcphersc
 * fixed unsigned short int
 *
 * Revision 1.4  2002/09/03 19:41:58  vracarl
 * got rid of c++ comments
 *
 * Revision 1.3  2002/07/25 11:16:25  sfl
 * got rid of warnings
 *
 * Revision 1.1.1.1  2000/08/21 20:35:52  leonberp
 * First CVS Version of SNACC.
 *
 * Revision 1.3  1997/03/13 09:15:19  wan
 * Improved dependency generation for stupid makedepends.
 * Corrected PeekTag to peek into buffer only as far as necessary.
 * Added installable error handler.
 * Fixed small glitch in idl-code generator (Markku Savela <msa@msa.tte.vtt.fi>).
 *
 * Revision 1.2  1995/07/24 21:04:55  rj
 * changed `_' to `-' in file names.
 *
 * Revision 1.1  1994/08/28  09:46:08  rj
 * first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.
 *
 * Revision - 22 January 1998 - DAD
 * commented out the printf in Asn1DefaultErrorHandler() - hinders use of the snacc lib
 * within a dll which shouldn't be printing out to a console...
 *
 */

#include "asn-config.h"
#include "print.h"



void
Indent PARAMS ((f, i),
    FILE *f _AND_
    unsigned short i)
{
    for (; i > 0; i--)
        fputc (' ', f);  /* this may be slow */
}

void Asn1DefaultErrorHandler PARAMS ((str, severity),
    char* str _AND_
    int severity)
{
  /*  fprintf(stderr,"%s",str); DAD - temp removing for now*/
   severity=severity;   /* referenced  */
   str=str;
}

static Asn1ErrorHandler asn1CurrentErrorHandler = Asn1DefaultErrorHandler;

void
Asn1Error PARAMS ((str),
    char* str)
{
    (*asn1CurrentErrorHandler)(str,1);
}

void
Asn1Warning PARAMS ((str),
    char* str)
{
    (*asn1CurrentErrorHandler)(str,0);
}

Asn1ErrorHandler
Asn1InstallErrorHandler PARAMS ((handler),
    Asn1ErrorHandler handler)
{
    Asn1ErrorHandler former = asn1CurrentErrorHandler;
    asn1CurrentErrorHandler = handler;
    return former;
}

