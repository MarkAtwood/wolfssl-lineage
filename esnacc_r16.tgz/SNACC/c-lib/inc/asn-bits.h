/*
 * asn_bits.h
 *
 * MS 92
 * Copyright (C) 1992 Michael Sample and the University of British Columbia
 *
 * This library is free software; you can redistribute it and/or
 * modify it provided that this copyright/license information is retained
 * in original form.
 *
 * If you modify this file, you must clearly indicate your changes.
 *
 * This source code is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * $Header: /baseline/SNACC/c-lib/inc/asn-bits.h,v 1.6 2003/02/20 21:07:59 leonberp Exp $
 * $Log: asn-bits.h,v $
 * Revision 1.6  2003/02/20 21:07:59  leonberp
 * added #ifdef __cplusplus extern "C" to headers
 *
 * Revision 1.5  2002/10/23 10:23:51  mcphersc
 * Changed BUF_TYPE to AsnBuf
 *
 * Revision 1.4  2002/10/21 17:01:21  mcphersc
 * fixed unsigned short int
 *
 * Revision 1.3  2002/10/18 13:10:32  mcphersc
 * took out long int to unsigned long
 *
 * Revision 1.2  2001/07/12 19:34:00  leonberp
 * Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
 *
 * Revision 1.1.1.1  2000/08/21 20:35:54  leonberp
 * First CVS Version of SNACC.
 *
 * Revision 1.4  1997/08/28 07:25:48  povey
 * Changes to support DER encoding/decoding
 *
 * Revision 1.3.1.1  1997/08/20 23:14:43  povey
 *
 * Revision 1.3  1995/07/24 21:01:09  rj
 * changed `_' to `-' in file names.
 *
 * Revision 1.2  1994/12/11  21:48:28  rj
 * argument order of BDecAsnBitsContent() fixed.
 *
 * Revision 1.1  1994/08/28  09:21:23  rj
 * first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.
 *
 */


#ifndef _asn_bits_h_
#define _asn_bits_h_

#ifdef __cplusplus
extern "C" {
#endif



typedef struct AsnBits
{
  int	bitLen;
  char	*bits;
} AsnBits;

extern char numToHexCharTblG[];


/* 
 * BER encode/decode routines
 */
AsnLen BEncAsnBits PROTO ((GenBuf *b, AsnBits *data));

void BDecAsnBits PROTO ((GenBuf *b, AsnBits *result, AsnLen *bytesDecoded, ENV_TYPE env));

AsnLen BEncAsnBitsContent PROTO ((GenBuf *b, AsnBits *bits));

void BDecAsnBitsContent PROTO ((GenBuf *b, AsnTag tagId, AsnLen len, AsnBits *result, AsnLen *bytesDecoded, ENV_TYPE env));

/* 
 * DER encode/decode routines
 *
 * Same as BER except that the bits are zero padded (however BEncxx does this)
 */
#define DEncAsnBits BEncAsnBits

#define DDecAsnBits BDecAsnBits

#define DEncAsnBitsContent BEncAsnBitsContent

#define DDecAsnBitsContent BDecAsnBitsContent

/* Print and Free routines */
void FreeAsnBits PROTO ((AsnBits *v));

void PrintAsnBits PROTO ((FILE *f, AsnBits *b, unsigned short  indent));




/* Utility routines */
#define TO_HEX( fourBits)	(numToHexCharTblG[(fourBits) & 0x0f])


#define ASNBITS_PRESENT( abits)	((abits)->bits != NULL)

int AsnBitsEquiv PROTO ((AsnBits *b1, AsnBits *b2));

void SetAsnBit PROTO ((AsnBits *b1, size_t bit));

void ClrAsnBit PROTO ((AsnBits *b1, size_t bit));

int GetAsnBit PROTO ((AsnBits *b1, size_t bit));

#ifdef __cplusplus
} 
#endif /* extern 'C' */

#endif /* conditional include */

