/*
 * asn_real.h
 *
 * MS 92
 * Copyright (C) 1992 Michael Sample and the University of British Columbia
 *
 * This library is free software; you can redistribute it and/or
 * modify it provided that this copyright/license information is retained
 * in original form.
 *
 * If you modify this file, you must clearly indicate your changes.
 *
 * This source code is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * $Header: /baseline/SNACC/c-lib/inc/asn-real.h,v 1.7 2003/02/20 21:07:59 leonberp Exp $
 * $Log: asn-real.h,v $
 * Revision 1.7  2003/02/20 21:07:59  leonberp
 * added #ifdef __cplusplus extern "C" to headers
 *
 * Revision 1.6  2002/10/23 10:23:51  mcphersc
 * Changed BUF_TYPE to AsnBuf
 *
 * Revision 1.5  2002/10/21 17:05:46  mcphersc
 * fixed long int
 *
 * Revision 1.4  2002/10/21 17:01:21  mcphersc
 * fixed unsigned short int
 *
 * Revision 1.3  2002/10/18 13:10:32  mcphersc
 * took out long int to unsigned long
 *
 * Revision 1.2  2001/07/12 19:34:03  leonberp
 * Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
 *
 * Revision 1.1.1.1  2000/08/21 20:35:54  leonberp
 * First CVS Version of SNACC.
 *
 * Revision 1.2  1995/07/24 21:01:18  rj
 * changed `_' to `-' in file names.
 *
 * Revision 1.1  1994/08/28  09:21:35  rj
 * first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.
 *
 * Revision - 22 January 1998 - DAD
 * added proto for SignedIntOctetLen()
 * 
 */


#ifndef _asn_real_h_
#define _asn_real_h_

#ifdef __cplusplus
extern "C" {
#endif

typedef double AsnReal;

extern AsnReal PLUS_INFINITY;
extern AsnReal MINUS_INFINITY;


void InitAsnInfinity();
unsigned long SignedIntOctetLen PROTO ((long  val));
    
AsnLen BEncAsnReal PROTO ((GenBuf *b, AsnReal *data));

void BDecAsnReal PROTO ((GenBuf *b, AsnReal *result, AsnLen *bytesDecoded, ENV_TYPE env));

AsnLen BEncAsnRealContent PROTO ((GenBuf *b, AsnReal *data));

void BDecAsnRealContent PROTO ((GenBuf *b, AsnTag tag, AsnLen len, AsnReal *result, AsnLen *bytesDecoded, ENV_TYPE env));

/* do nothing */
#define FreeAsnReal( v)

void PrintAsnReal PROTO ((FILE *f, AsnReal *b, unsigned short indent));

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

