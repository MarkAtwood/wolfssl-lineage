/*
 * asn_bool.h
 *
 * MS 92
 * Copyright (C) 1992 Michael Sample and the University of British Columbia
 *
 * This library is free software; you can redistribute it and/or
 * modify it provided that this copyright/license information is retained
 * in original form.
 *
 * If you modify this file, you must clearly indicate your changes.
 *
 * This source code is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * $Header: /baseline/SNACC/c-lib/inc/asn-bool.h,v 1.5 2003/02/20 21:07:59 leonberp Exp $
 * $Log: asn-bool.h,v $
 * Revision 1.5  2003/02/20 21:07:59  leonberp
 * added #ifdef __cplusplus extern "C" to headers
 *
 * Revision 1.4  2002/10/23 10:23:51  mcphersc
 * Changed BUF_TYPE to AsnBuf
 *
 * Revision 1.3  2002/10/21 17:01:21  mcphersc
 * fixed unsigned short int
 *
 * Revision 1.2  2001/07/12 19:34:00  leonberp
 * Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
 *
 * Revision 1.1.1.1  2000/08/21 20:35:54  leonberp
 * First CVS Version of SNACC.
 *
 * Revision 1.2  1995/07/24 21:01:10  rj
 * changed `_' to `-' in file names.
 *
 * Revision 1.1  1994/08/28  09:21:24  rj
 * first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.
 *
 */

#ifndef _asn_bool_h_
#define _asn_bool_h_

#ifdef __cplusplus
extern "C" {
#endif


typedef unsigned char AsnBool;


AsnLen BEncAsnBool PROTO ((GenBuf *b, AsnBool *data));

void BDecAsnBool PROTO ((GenBuf *b, AsnBool *result, AsnLen *bytesDecoded, ENV_TYPE env));

AsnLen BEncAsnBoolContent PROTO ((GenBuf *b, AsnBool *data));

void BDecAsnBoolContent PROTO ((GenBuf *b, AsnTag tag, AsnLen len, AsnBool *result, AsnLen *bytesDecoded, ENV_TYPE env));

/* do nothing  */
#define FreeAsnBool( v)

void PrintAsnBool PROTO ((FILE *f, AsnBool *b, unsigned short  indent));

#ifdef __cplusplus
}
#endif /* extern 'C' */

#endif

