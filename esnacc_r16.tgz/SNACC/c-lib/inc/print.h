/*
 * print.h
 *
 * MS 92
 * Copyright (C) 1992 Michael Sample and the University of British Columbia
 *
 * This library is free software; you can redistribute it and/or
 * modify it provided that this copyright/license information is retained
 * in original form.
 *
 * If you modify this file, you must clearly indicate your changes.
 *
 * This source code is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * $Header: /baseline/SNACC/c-lib/inc/print.h,v 1.5 2003/02/20 21:07:59 leonberp Exp $
 * $Log: print.h,v $
 * Revision 1.5  2003/02/20 21:07:59  leonberp
 * added #ifdef __cplusplus extern "C" to headers
 *
 * Revision 1.4  2002/10/23 13:33:08  mcphersc
 * no message
 *
 * Revision 1.3  2002/10/21 17:01:21  mcphersc
 * fixed unsigned short int
 *
 * Revision 1.2  2001/07/12 19:34:06  leonberp
 * Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
 *
 * Revision 1.1.1.1  2000/08/21 20:35:54  leonberp
 * First CVS Version of SNACC.
 *
 * Revision 1.2  1995/07/24 21:01:23  rj
 * changed `_' to `-' in file names.
 *
 * Revision 1.1  1994/08/28  09:45:38  rj
 * first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.
 *
 * Revision - 22 January 1998 - DAD
 * Added proto for Asn1DefaultErrorHandler()
 */

#ifndef _snaccc_print_h_
#define _snaccc_print_h_

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned short  stdIndentG;

void Indent PROTO ((FILE *f, unsigned short i));

void Asn1DefaultErrorHandler PROTO ((char* str,int severity));


#ifdef __cplusplus
}
#endif

#endif /* conditional include */

