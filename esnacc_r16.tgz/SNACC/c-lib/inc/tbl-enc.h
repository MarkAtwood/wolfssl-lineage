/*
 * tbl-enc.h - type table encoder
 *
 *
 * Mike Sample
 *
 * Copyright (C) 1993 Michael Sample
 *            and the University of British Columbia
 * This library is free software; you can redistribute it and/or
 * modify it provided that this copyright/license information is retained
 * in original form.
 *
 * If you modify this file, you must clearly indicate your changes.
 *
 * This source code is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * $Header: /baseline/SNACC/c-lib/inc/tbl-enc.h,v 1.4 2002/10/23 10:23:51 mcphersc Exp $
 * $Log: tbl-enc.h,v $
 * Revision 1.4  2002/10/23 10:23:51  mcphersc
 * Changed BUF_TYPE to AsnBuf
 *
 * Revision 1.3  2002/10/18 13:10:32  mcphersc
 * took out long int to unsigned long
 *
 * Revision 1.2  2001/07/12 19:34:07  leonberp
 * Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
 *
 * Revision 1.1.1.1  2000/08/21 20:35:55  leonberp
 * First CVS Version of SNACC.
 *
 * Revision 1.1  1995/07/27 08:55:54  rj
 * first check-in after being merged into .../c-lib/.
 *
 */


int TblEncode PROTO ((TBL *tbl, char *modName, char *typeName, GenBuf *b, AVal *v, unsigned long *bytesEncoded));

int TblEncodeType PROTO ((TBLType *tblT, GenBuf *b, AVal *v, int implicit, unsigned long *bytesEncoded));

