/*
 * asn_oid.h
 *
 *  this file depends on asn_octs.h
 * MS 92
 * Copyright (C) 1992 Michael Sample and the University of British Columbia
 *
 * This library is free software; you can redistribute it and/or
 * modify it provided that this copyright/license information is retained
 * in original form.
 *
 * If you modify this file, you must clearly indicate your changes.
 *
 * This source code is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * $Header: /baseline/SNACC/c-lib/inc/asn-oid.h,v 1.6 2003/02/20 21:07:59 leonberp Exp $
 * $Log: asn-oid.h,v $
 * Revision 1.6  2003/02/20 21:07:59  leonberp
 * added #ifdef __cplusplus extern "C" to headers
 *
 * Revision 1.5  2002/10/23 10:23:51  mcphersc
 * Changed BUF_TYPE to AsnBuf
 *
 * Revision 1.4  2002/10/21 17:01:21  mcphersc
 * fixed unsigned short int
 *
 * Revision 1.3  2002/10/18 13:10:32  mcphersc
 * took out long int to unsigned long
 *
 * Revision 1.2  2001/07/12 19:34:03  leonberp
 * Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
 *
 * Revision 1.1.1.1  2000/08/21 20:35:54  leonberp
 * First CVS Version of SNACC.
 *
 * Revision 1.2  1995/07/27 10:24:00  rj
 * minor change to merge with type table code.
 *
 * Revision 1.1  1994/08/28  09:21:34  rj
 * first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.
 *
 */


#ifndef _asn_oid_h_
#define _asn_oid_h_

#include "asn-octs.h"

#ifdef __cplusplus
extern "C" {
#endif


typedef AsnOcts AsnOid;  /* standard oid type  */


#define ASNOID_PRESENT( aoid)	ASNOCTS_PRESENT (aoid)

AsnLen BEncAsnOid PROTO ((GenBuf *b, AsnOid *data));

void BDecAsnOid PROTO ((GenBuf *b, AsnOid *result, AsnLen *bytesDecoded, ENV_TYPE env));

#define BEncAsnOidContent( b, oid)   BEncAsnOctsContent (b, oid)


void BDecAsnOidContent PROTO ((GenBuf *b, AsnTag tag, AsnLen len, AsnOid  *result, AsnLen *bytesDecoded, ENV_TYPE env));


#define FreeAsnOid	FreeAsnOcts

void PrintAsnOid PROTO ((FILE *f, AsnOid *b, unsigned short indent));

#define AsnOidsEquiv( o1, o2) AsnOctsEquiv (o1, o2)

/* linked oid type that may be easier to use in some circumstances */
#define NULL_OID_ARCNUM	-1
typedef struct OID
{
  struct OID	*next;
  long arcNum;
#if COMPILER || TTBL
  struct Value	*valueRef;
#endif
} OID;

AsnLen EncodedOidLen PROTO ((OID *oid));

void BuildEncodedOid PROTO ((OID *oid, AsnOid *result));

void UnbuildEncodedOid PROTO ((AsnOid *eoid, OID **result));

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* conditional include */

