#
# dosfilepatch.sh
#
#
cd c-lib/inc
mv asn-universalstring.h asn-UniversalString.h
mv asn-utf8string.h asn-UTF8String.h
mv asn-bmpstring.h asn-BMPString.h
mv asn-ia5string.h asn-IA5String.h
mv asn-numericstring.h asn-NumericString.h
mv asn-printablestr.h asn-PrintableStr.h
mv asn-teltexstring.h asn-TeltexString.h
cd ../src
mv asn-universalstring.c asn-UniversalString.c
mv asn-utf8string.c asn-UTF8String.c
mv asn-bmpstring.c asn-BMPString.c
mv asn-ia5string.c asn-IA5String.c
mv asn-numericstring.c asn-NumericString.c
mv asn-printablestr.c asn-PrintableStr.c
mv asn-teletexstring.c asn-TeletexString.c
#
cd ../..
#
mv asn1specs/asn-usefulvda.asn1 asn1specs/asn-usefulVDA.asn1
#
#
mv c++-examples/vdatestdll c++-examples/vdatestDLL
#
find . -name '*.y' -print -exec dos2unix {} \;
find . -name '*.l' -print -exec dos2unix {} \;
#dos2unix compiler/core/parse-asn1.y compiler/core/parse-asn1.y
#
echo done file name changes.
# EOF dosfilepatch.sh
