/* JKG -- 7/31/03 --  */
/*  ../SNACC/compiler/back-ends/c++-gen/cxxconstraints.c  */
/*  This file contains implementations of functions for   */
/*  checking constraints and converting .asn1             */   
/*  primitives (with constraints) into valid C++ code     */
/*  Their respective prototypes are in:                   */
/*       'cxxconstraints.h' in the pwd                    */


#include "cxxconstraints.h"
#include <string.h>


/* Prints the default instantiation for a typedefined object */
void PrintTypeDefDefault PARAMS((hdr, src, td),
 FILE* hdr _AND_
 FILE* src _AND_
 TypeDef* td)
{
  src=src;
  fprintf(hdr, "//JKG::*****No applicable subtypes implemented or found******\n");
  fprintf (hdr, "typedef %s %s;\n\n", td->type->cxxTypeRefInfo->className, td->cxxTypeDefInfo->className);

}




/* Function generates the checkconstraints function for */
/*    a setOf or seqOf with size constraints set        */
void PrintCxxSetOfSizeValRangeConstraints PARAMS((hdr, src, td),
 FILE* hdr _AND_
 FILE* src _AND_
 TypeDef* td)
{
    Subtype* s_type;

    hdr=hdr;
    src=src;
    td=td;

    s_type = (Subtype*)td->type->subtypes->a.single->a.sizeConstraint->a.or->last->data;

    fprintf(hdr, "   %s(){", td->definedName);

		if(s_type->a.single->a.valueRange->lowerEndValue->valueInclusive)
        {
        
            fprintf (hdr, "           m_Lower = %d;\n", 
		    	s_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.integer);
        }
        else
        {
            fprintf (hdr, "           m_Lower = %d;\n", 
		    	s_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.integer+1);

        }

        if(s_type->a.single->a.valueRange->upperEndValue->valueInclusive)
        {
	        fprintf (hdr, "           m_Upper = %d; \n",
 		     s_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.integer);	
        }
        else
        {
	        fprintf (hdr, "           m_Upper = %d; \n",
 		     s_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.integer-1);	

        }
		fprintf (hdr, "        }\n\n");

        
        
        
        
        fprintf(hdr, "   virtual int checkConstraints(ConstraintFailList* pConstraintFails)const;\n");
        fprintf(src, "int %s::checkConstraints(ConstraintFailList*pConstraintFails)const\n{\n", td->cxxTypeDefInfo->className);
    				

        fprintf (src, "  std::string * pTmpError;\n");
        fprintf (src, "  char* ptr = checkSOfValRange(m_Lower, m_Upper);\n\n");
        fprintf (src, "  if(ptr)\n   {\n");
        fprintf (src, "     if(pConstraintFails!=NULL)\n     {\n");
        fprintf (src, "       pTmpError=pConstraintFails->Append();\n");
        fprintf (src, "       *pTmpError += ptr;\n");
        fprintf (src, "       *pTmpError += \"In function call:  %s::checkConstraints(...)\\n\";\n", td->cxxTypeDefInfo->className);
        fprintf (src, "     }\n");
        fprintf (src, "   }\n   else\n   {\n");
        
        fprintf (src, "     return checkListConstraints(pConstraintFails);\n");
        fprintf (src, "   }\n\n");
        fprintf (src, "   return checkListConstraints(pConstraintFails);\n");
		
       
		
    
    fprintf(src, "\n}\n");


}

void PrintCxxSetOfSizeSingleValConstraints PARAMS((hdr, src, td),
 FILE* hdr _AND_
 FILE* src _AND_
 TypeDef* td)
{
    Subtype* s_type;

    hdr=hdr;
    src=src;
    td=td;

    s_type = (Subtype*)td->type->subtypes->a.single->a.sizeConstraint->a.or->last->data;

    fprintf(hdr, "   %s(){m_SingleVal = %d;}\n",
            td->definedName,
            s_type->a.single->a.singleValue->basicValue->a.integer);
   
        fprintf(hdr, "   virtual int checkConstraints(ConstraintFailList* pConstraintFails)const;\n");
        fprintf(src, "int %s::checkConstraints(ConstraintFailList*pConstraintFails)const\n{\n", td->cxxTypeDefInfo->className);
    				

        fprintf (src, "  std::string * pTmpError;\n");
        fprintf (src, "  char* ptr = checkSOfSingleVal(m_SingleVal);\n\n");
        fprintf (src, "  if(ptr)\n   {\n");
        fprintf (src, "     if(pConstraintFails!=NULL)\n     {\n");
        fprintf (src, "       pTmpError=pConstraintFails->Append();\n");
        fprintf (src, "       *pTmpError += ptr;\n");
        fprintf (src, "       *pTmpError += \"In function call:  %s::checkConstraints(...)\\n\";\n", td->cxxTypeDefInfo->className);
        fprintf (src, "     }\n");
        fprintf (src, "   }\n   else\n   {\n");
        
        fprintf (src, "     return checkListConstraints(pConstraintFails);\n");
        fprintf (src, "   }\n\n");
        fprintf (src, "   return checkListConstraints(pConstraintFails);\n");
		
       
		
    
    fprintf(src, "\n}\n");


}
