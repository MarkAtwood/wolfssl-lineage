#ifndef _cxxmultipleconstraints_h_
#define _cxxmultipleconstraints_h_


#include "asn-incl.h"
#include "asn1module.h"
#include "snacc.h"
#include "limits.h"
#include "rules.h"
#include "snacc-util.h"

struct SizeConstraint
{
	long mLowerBound;
	long mUpperBound;
	int  mLowerExist;
	int  mUpperExist;
};

typedef struct SizeConstraint sizeConstraint;

void SizeConstraint_INIT PROTO((sizeConstraint* s));


char* PrintCxxPermittedAlphabetHandler PROTO(( AsnListNode* currAlpha, unsigned char* cPermittedAlphabet, int *iAlphasize));

int PrintCxxSizeConstraintHandler PROTO((FILE* hdr, FILE* src, NamedType* e, TypeDef* s, AsnListNode* node, int i, int icurrvar));

int PrintCxxMultiConstraintOrHandler PROTO((FILE* hdr, FILE* src, NamedType* e, TypeDef* s, int i));

int BasicTypeInt_DECL PROTO((FILE* hdr, FILE* src, int icurrvar, AsnListNode* curr, Subtype* currS_type));

int BasicTypeInt_INIT PROTO((FILE* hdr, FILE* src, int icurrvar, AsnListNode* curr, Subtype* currS_type));

int BasicTypeInt_CONSTRAINT PROTO((FILE* hdr, FILE* src, int icurrvar, AsnListNode* curr, Subtype* currS_type));

int BasicTypeReal_DECL PROTO((FILE* hdr, FILE* src, int icurrvar, AsnListNode* curr, Subtype* currS_type));

int BasicTypeReal_INIT PROTO((FILE* hdr, FILE* src, int icurrvar, AsnListNode* curr, Subtype* currS_type));

int BasicTypeReal_CONSTRAINT PROTO((FILE* hdr, FILE* src, int icurrvar, AsnListNode* curr, Subtype* currS_type));

int BasicTypeString_DECL PROTO((FILE* hdr, FILE* src, int icurrvar, AsnListNode* curr, Subtype* currS_type, NamedType* e, TypeDef* s));

int BasicTypeString_INIT PROTO((FILE* hdr, FILE* src, int icurrvar, AsnListNode* curr, Subtype* currS_type, NamedType* e, TypeDef* s));

int BasicTypeString_CONSTRAINT PROTO((FILE* hdr, FILE* src, int icurrvar, AsnListNode* curr, Subtype* currS_type, NamedType* e, TypeDef* s));

char* FindPermittedAlpha PROTO((AsnListNode* curr, unsigned char* cPermittedAlphabet, int *iAlphasize));

#endif