#include "cxxmultipleconstraints.h"
#include <string.h>


void SizeConstraint_INIT PARAMS((s),
	sizeConstraint* s)
{
	s->mLowerBound = 0;
	s->mUpperBound = 0;
	s->mLowerExist = 0;
	s->mUpperExist = 0;
}


char* FindPermittedAlpha PARAMS((curr, cPermittedAlphabet, iAlphasize),
	AsnListNode* curr _AND_
	unsigned char* cPermittedAlphabet _AND_
	int *iAlphasize)
{
	Subtype* currS_type=NULL;

	while(curr)
	{
		currS_type=curr->data;
	
		if(currS_type->choiceId==SUBTYPE_SINGLE && 
				currS_type->a.single->choiceId==SUBTYPEVALUE_PERMITTEDALPHABET)
		{
			AsnListNode* currAlpha;
			currAlpha=currS_type->a.single->a.permittedAlphabet->a.or->first;
	
			PrintCxxPermittedAlphabetHandler(currAlpha, cPermittedAlphabet, iAlphasize);
		}
		curr=curr->next;
	}


	return (char*)cPermittedAlphabet;
}


/*Prints the declarations for constraint variables in the header file*/
int BasicTypeString_DECL PARAMS((hdr, src, icurrvar, curr, currS_type, e, s),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type _AND_
	NamedType* e _AND_
	TypeDef* s)
{
	AsnListNode* pTmpnode;
	/*while there are nodes in the subtype list*/
	while(curr)
	{
		/*point to the current subtype*/
		currS_type=curr->data;
		
		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{

			case SUBTYPEVALUE_VALUERANGE:
				{
					fprintf(hdr, "        const char* m_var%d;\n", icurrvar++);
					fprintf(hdr, "        const char* m_var%d;\n", icurrvar++);
					break;
				}/*case SUBTYPEVALUE_VALUERANGE*/

			case SUBTYPEVALUE_SINGLEVALUE:
				{
					fprintf(hdr, "        const char* m_var%d;\n", icurrvar++);
					break;
				}/*case SUBTYPEVALUE_SINGLEVALUE*/

			case SUBTYPEVALUE_SIZECONSTRAINT:
				{
					
					pTmpnode=currS_type->a.single->a.sizeConstraint->a.or->first;
					icurrvar=PrintCxxSizeConstraintHandler(hdr, src, e, s, pTmpnode, 1, icurrvar);

					break;
				}/*case SUBTYPEVALUE_SIZECONSTRAINT*/

			default:
				{
					break;
				}/*default*/

			}/*switch(curr......SINGLE)*/
		
		}/*if(curr......SINGLE)*/

		curr=curr->next;
	}/*while(curr)*/

	src=src; /*avoids warning for unused parameter*/
	return icurrvar; 
}/*int BasicTypeString_DECL*/

/*Prints the initializers for constraint variables in the header file*/
int BasicTypeString_INIT PARAMS((hdr, src, icurrvar, curr, currS_type, e, s),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type _AND_
	NamedType* e _AND_
	TypeDef* s)
{
	AsnListNode* pTmpnode;
	/*while there are subtypes in the list*/
	while(curr)
	{
		/*points to the current subtype*/
		currS_type=curr->data;

		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
			case SUBTYPEVALUE_VALUERANGE:
				{
					fprintf (hdr, "             m_var%d = \"%s\";\n", icurrvar,
						currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.asciiText->octs);
					fprintf (hdr, "             m_var%d = \"%s\";\n", icurrvar+1,
						currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.asciiText->octs);

					icurrvar+=2;
					break;
				}/*case SUBTYPEVALUE_VALUERANGE*/

			case SUBTYPEVALUE_SINGLEVALUE:
				{
					fprintf (hdr, "             m_var%d = \"%s\";\n", icurrvar,
						currS_type->a.single->a.singleValue->basicValue->a.asciiText->octs);

					icurrvar+=1;
					break;
				}/*case SUBTYPEVALUE_SINGLEVALUE*/

			case SUBTYPEVALUE_SIZECONSTRAINT:
				{
					pTmpnode=currS_type->a.single->a.sizeConstraint->a.or->first;
					icurrvar=PrintCxxSizeConstraintHandler(hdr, src, e, s, pTmpnode, 2, icurrvar);

					break;
				}/*case SUBTYPEVALUE_SIZECONSTRAINT*/
			
			default:
				{
					break;
				}/*default*/
			
			}/*switch(curr.....SINGLE)*/

		}/*if(curr.....SINGLE)*/

		curr=curr->next;
	}/*while(curr)*/

	src=src; /*avoids warning on unused parameter*/
	return icurrvar;
}/*int BasicTypeString_INIT*/

/*implements the checkconstraints function in the source file*/
int BasicTypeString_CONSTRAINT PARAMS((hdr, src, icurrvar, curr, currS_type, e, s),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type _AND_
	NamedType* e _AND_
	TypeDef* s)
{
	AsnListNode* pTmpnode;
	/*while there are still subtypes found in the list*/
	while(curr)
	{
		currS_type=curr->data;
		
		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
				case SUBTYPEVALUE_VALUERANGE:
					{
						fprintf (src, "\n\n");
						fprintf (src, "  tmpptr = checkStringTypVRange(m_var%d, m_var%d);\n\n", icurrvar, icurrvar+1);
						fprintf (src, "  if(tmpptr)\n");
						fprintf (src, "     ptr += tmpptr;\n\n");

						fprintf (src, "  if(!tmpptr)\n");
						fprintf (src, "  {\n");
						fprintf (src, "		failed = 0;\n");
						fprintf (src, "  }\n\n");


						icurrvar+=2;
						break;
					}/*case SUBTYPEVALUE_VALUERANGE*/
				case SUBTYPEVALUE_SINGLEVALUE:
					{
						fprintf (src, "\n\n");
						fprintf (src, "  tmpptr = checkStringTypSingleVal(m_var%d);\n\n", icurrvar);
						fprintf (src, "  if(tmpptr)\n");
						fprintf (src, "     ptr += tmpptr;\n\n");

						fprintf (src, "  if(!tmpptr)\n");
						fprintf (src, "  {\n");
						fprintf (src, "		failed = 0;\n");
						fprintf (src, "  }\n\n");
						
						icurrvar+=1;
						break;
					}/*case SUBTYPEVALUE_SINGLEVALUE*/


				case SUBTYPEVALUE_SIZECONSTRAINT:
					{

						pTmpnode=currS_type->a.single->a.sizeConstraint->a.or->first;
						icurrvar=PrintCxxSizeConstraintHandler(hdr, src, e, s, pTmpnode, 3, icurrvar);
					
						break;
					}/*case SUBTYPEVALUE_SIZECONSTRAINT*/

				default:
					{
						fprintf (src, "\n  tmpptr=NULL;\n\n");
						break;
					}/*default*/
			}/*switch(curr......choiceId)*/
		}/*if(curr.....SINGLE)*/
		



		curr=curr->next;
	}/*while(curr)*/


	hdr=hdr;/*avoids warning for unused parameter*/
	return icurrvar;
}/*int BasicTypeString_CONSTRAINT*/



/*Prints the declarations for constraint variables in the header file*/
int BasicTypeBool_DECL PARAMS((hdr, src, icurrvar, curr, currS_type),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type)
{
	/*while there are nodes in the subtype list*/
	while(curr)
	{
		/*point to current subtype*/
		currS_type=curr->data;
		
		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
			case SUBTYPEVALUE_SINGLEVALUE:
				{
					fprintf(hdr, "        bool m_var%d;\n", icurrvar++);
					break;
				}/*case SUBTYPEVALUE_SINGLEVALUE*/
			default:
				{
					break;
				}/*default*/
		
			}/*switch(curr......choiceId)*/
	
		}/*if(curr....SINGLE)*/
	
		curr=curr->next;
	}/*while(curr)*/


	src=src; /*avoids warning for unused parameter*/
	return icurrvar; 
}/*int BasicTypeBool_DECL*/

/*Prints the initializers for constraint variables in the header file*/
int BasicTypeBool_INIT PARAMS((hdr, src, icurrvar, curr, currS_type),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type)
{
	/*while there are subtypes in the list*/
	while(curr)
	{
		/*point to current subtype*/
		currS_type=curr->data;

		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
			case SUBTYPEVALUE_SINGLEVALUE:
				{
					fprintf (hdr, "           m_var%d = %d;\n", icurrvar, 
						currS_type->a.single->a.singleValue->basicValue->a.integer);	
					
					icurrvar+=1;
					break;
				}/*case SUBTYPE_SINGLEVALUE*/
			default:
				{
					break;
				}/*default*/
			
			}/*switch(curr....SINGLE)*/
		
		}/*if(curr....SINGLE)*/
		
		curr=curr->next;
	
	}/*while(curr)*/

	src=src; /*avoids warning on unused parameter*/
	return icurrvar;
}/*int BasicTypeBool_INIT*/

/*implements the checkconstraints function in the source file*/
int BasicTypeBool_CONSTRAINT PARAMS((hdr, src, icurrvar, curr, currS_type),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type)
{
	/*while there are still subtypes found in the list*/
	while(curr)
	{
		/*point to the current subtype*/
		currS_type=curr->data;
		
		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
				case SUBTYPEVALUE_SINGLEVALUE:
					{
						fprintf (src, "\n\n");
						fprintf (src, "  tmpptr = checkBoolSingleVal(m_var%d);\n\n", icurrvar);
						fprintf (src, "  if(tmpptr)\n");
						fprintf (src, "     ptr += tmpptr;\n\n");

						icurrvar+=1;
						break;
					}/*case SUBTYPEVALUE_SINGLEVALUE*/
				default:
					{
						break;
					}/*default*/
			
			}/*switch(curr.....SINGLE)*/
		
		}/*if(curr......SINGLE)*/

		/*if the value met the constraint, then we flag for success*/
		fprintf (src, "  if(!tmpptr)\n");
		fprintf (src, "  {\n");
		fprintf (src, "		failed = 0;\n");
		fprintf (src, "  }\n\n");

		curr=curr->next;
	}/*while(curr)*/

	hdr=hdr;/*avoids warning for unused parameter*/
	return icurrvar;
}/*int BasicTypeBool_CONSTRAINT*/


/*Prints the declaration for the constraints variables in the header file*/
int BasicTypeReal_DECL PARAMS((hdr, src, icurrvar, curr, currS_type),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type)
{
	/*while there are still subtype found in the list*/
	while(curr)
	{
		/*point to the current subtype*/
		currS_type=curr->data;
		
		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
			case SUBTYPEVALUE_VALUERANGE:
				{
					fprintf(hdr, "        double m_var%d;\n", icurrvar++);
					fprintf(hdr, "        double m_var%d;\n", icurrvar++);
					break;
				}/*case SUBTYPEVALUE_VALUERANGE*/
			case SUBTYPEVALUE_SINGLEVALUE:
				{
					fprintf(hdr, "        double m_var%d;\n", icurrvar++);
					break;
				}/*case SUBTYPEVALUE_SINGLEVALUE*/
			default:
				{
					break;
				}/*default*/

			}/*switch(curr......SINGLE)*/

		}/*if(curr......SINGLE)*/

		curr=curr->next;

	}/*while(curr)*/

	src=src;/*avoids warning for unused parameter*/ 
	return icurrvar;
}/*int BasicTypeReal_DECL*/

/*Prints the initializers for the consraint variables in the header file*/
int BasicTypeReal_INIT PARAMS((hdr, src, icurrvar, curr, currS_type),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type)
{
	/*while there are still subtypes found in the list*/
	while(curr)
	{
		/*point to the current subtype*/
		currS_type=curr->data;

		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
			case SUBTYPEVALUE_VALUERANGE:
			{
					/*if the lower or upper limit is a min or a max then we set it to long min/max respectively*/
					if(currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->choiceId==BASICVALUE_SPECIALINTEGER)
					{
						currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.integer=LONG_MIN;
					}

					if(currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->choiceId==BASICVALUE_SPECIALINTEGER)
					{
						currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.integer=LONG_MAX;
					}

					/*if the values are not inclusive, then we adjust the upper and lower limit*/
					if(currS_type->a.single->a.valueRange->lowerEndValue->valueInclusive)
					{
    
				        fprintf (hdr, "           m_var%d = %d;\n", icurrvar,
		    			currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.integer);
					}
					else
					{
						fprintf (hdr, "           m_var%d = %d;\n", icurrvar,
		    			currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.integer+1);

					}

					if(currS_type->a.single->a.valueRange->upperEndValue->valueInclusive)
					{
						fprintf (hdr, "           m_var%d = %d; \n", icurrvar+1,
 						currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.integer);	
					}
					else
					{
						fprintf (hdr, "           m_var%d = %d; \n", icurrvar+1,
 						currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.integer-1);	

					}
					icurrvar+=2;
					break;
				}/*case SUBTYPEVALUE_VALUERANGE*/
			case SUBTYPEVALUE_SINGLEVALUE:
				{
					fprintf (hdr, "           m_var%d = %d;\n", icurrvar, 
						currS_type->a.single->a.singleValue->basicValue->a.integer);	
					
					icurrvar+=1;
					break;
				}/*case SUBTYPEVALUE_SINGLEVALUE*/
			default:
				{
					break;
				}/*default*/
			
			}/*switch(curr.....SINGLE)*/

		}/*if(curr.....SINGLE)*/

		curr=curr->next;
	
	}/*while(curr)*/

	src=src;/*avoids warning for unused parameter*/

	return icurrvar;
}/*int BasicTypeReal_INIT*/

/*Implements the checkconstraints function in the source file*/
int BasicTypeReal_CONSTRAINT PARAMS((hdr, src, icurrvar, curr, currS_type),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type)
{
	/*while there are still subtypes in the list*/
	while(curr)
	{
		/*point to current subtype*/
		currS_type=curr->data;
		
		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
				case SUBTYPEVALUE_VALUERANGE:
					{
						fprintf (src, "\n\n");
						fprintf (src, "  tmpptr = checkRealValRange(m_var%d, m_var%d);\n\n", icurrvar, icurrvar+1);
						fprintf (src, "  if(tmpptr)\n");
						fprintf (src, "     ptr += tmpptr;\n\n");

						icurrvar+=2;
						break;
					}/*case SUBTYPE_VALUERANGE*/
				case SUBTYPEVALUE_SINGLEVALUE:
					{
						fprintf (src, "\n\n");
						fprintf (src, "  tmpptr = checkRealSingleVal(m_var%d);\n\n", icurrvar);
						fprintf (src, "  if(tmpptr)\n");
						fprintf (src, "     ptr += tmpptr;\n\n");

						icurrvar+=1;
						break;
					}/*case SUBTYPE_SINGLEVALUE*/
				default:
					{
						break;
					}/*default*/
			
			}/*switch(curr.....SINGLE)*/
		
		}/*if(curr.......SINGLE)*/

		/*if the value met the constraint then we flag for success*/
		fprintf (src, "  if(!tmpptr)\n");
		fprintf (src, "  {\n");
		fprintf (src, "		failed = 0;\n");
		fprintf (src, "  }\n\n");

		curr=curr->next;
	
	}/*while(curr)*/

	hdr=hdr;/*avoids warning on unused parameter*/

	return icurrvar;
}/*int BasicTypeReal_CONSTRAINT*/

/*Prints out the declaration of the constraint variables in the header file*/
int BasicTypeInt_DECL PARAMS((hdr, src, icurrvar, curr, currS_type),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type)
{
	/*while there are still subtyes found in the list*/
	while(curr)
	{
		/*point to the current subtype*/
		currS_type=curr->data;
		
		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
			case SUBTYPEVALUE_VALUERANGE:
				{
					fprintf(hdr, "        long m_var%d;\n", icurrvar++);
					fprintf(hdr, "        long m_var%d;\n", icurrvar++);
					break;
				}/*case SUBTYPE_VALUERANGE*/
			case SUBTYPEVALUE_SINGLEVALUE:
				{
					fprintf(hdr, "        long m_var%d;\n", icurrvar++);
					break;
				}/*case SUBTYPE_SINGLEVALUE*/

			case SUBTYPEVALUE_CONTAINED:
			default:
				{
					break;
				}/*default*/
			
			}/*switch(curr......SINGLE)*/

		}/*if(curr.......SINGLE)*/

		curr=curr->next;
	
	}/*while(curr*/

	src=src;/*avoids warning on unused parameter*/ 
	
	return icurrvar;
}/*int BasicTypeInt_DECL*/

/*Prints the initializers for the constraint variables in the header file*/
int BasicTypeInt_INIT PARAMS((hdr, src, icurrvar, curr, currS_type),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type)
{
	/*while there are still elements found in the list*/
	while(curr)
	{
		/*point to the current subtype*/
		currS_type=curr->data;

		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
			case SUBTYPEVALUE_VALUERANGE:
				{
					/*if the lower or upper limit are a min or max, then we set them to long min/max respectively*/
					if(currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->choiceId==BASICVALUE_SPECIALINTEGER)
					{
						currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.integer=LONG_MIN;
					}

					if(currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->choiceId==BASICVALUE_SPECIALINTEGER)
					{
						currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.integer=LONG_MAX;
					}

					/*if the lower or upper limit are not inclusive, then we adjust them*/
					if(currS_type->a.single->a.valueRange->lowerEndValue->valueInclusive)
					{
    
				        fprintf (hdr, "           m_var%d = %d;\n", icurrvar,
		    			currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.integer);
					}
					else
					{
						fprintf (hdr, "           m_var%d = %d;\n", icurrvar,
		    			currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.integer+1);

					}

					if(currS_type->a.single->a.valueRange->upperEndValue->valueInclusive)
					{
						fprintf (hdr, "           m_var%d = %d; \n", icurrvar+1,
 						currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.integer);	
					}
					else
					{
						fprintf (hdr, "           m_var%d = %d; \n", icurrvar+1,
 						currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.integer-1);	

					}

					icurrvar+=2;
					break;
				}/*case SUBTYPEVALUE_VALUERANGE*/
			case SUBTYPEVALUE_SINGLEVALUE:
				{
					fprintf (hdr, "           m_var%d = %d;\n", icurrvar, 
						currS_type->a.single->a.singleValue->basicValue->a.integer);	
					
					icurrvar+=1;
					break;
				}/*case SUBTYPEVALUE_SINGLEVALUE*/
			
			case SUBTYPEVALUE_CONTAINED:
			default:
				{
					break;
				}/*default*/

			}/*switch(curr......SINGLE)*/

		}/*if(curr......SINGLE)*/				

		curr=curr->next;
	}/*while(curr)*/

	src=src;/*avoids warning for unused parameter*/
	return icurrvar;
}/*int BasicTypeInt_INIT*/

/*Implements the checkconstraints function in the source file*/
int BasicTypeInt_CONSTRAINT PARAMS((hdr, src, icurrvar, curr, currS_type),
	FILE* hdr _AND_
	FILE* src _AND_
	int icurrvar _AND_
	AsnListNode* curr _AND_
	Subtype* currS_type)
{
	/*while there are subtypes found in the list*/
	while(curr)
	{
		/*point to the current subtype*/
		currS_type=curr->data;
		
		if(currS_type->choiceId==SUBTYPE_SINGLE)
		{
			switch(currS_type->a.single->choiceId)
			{
				case SUBTYPEVALUE_VALUERANGE:
					{
						fprintf (src, "\n\n");
						fprintf (src, "  tmpptr = checkIntValRange(m_var%d, m_var%d);\n\n", icurrvar, icurrvar+1);
						fprintf (src, "  if(tmpptr)\n");
						fprintf (src, "     ptr += tmpptr;\n\n");

						icurrvar+=2;
						break;
					}/*case SUBTYPEVALUE_VALUERANGE*/
				case SUBTYPEVALUE_SINGLEVALUE:
					{
						fprintf (src, "\n\n");
						fprintf (src, "  tmpptr = checkIntSingleVal(m_var%d);\n\n", icurrvar);
						fprintf (src, "  if(tmpptr)\n");
						fprintf (src, "     ptr += tmpptr;\n\n");

						icurrvar+=1;
						break;
					}/*case SUBTYPEVALUE_SINGLEVALUE*/
				default:
				{
					break;
				}/*default*/

			}/*switch(curr........SINGLE)*/

		}/*if(curr.......SINGLE)*/

		/*if the value met one of the constraints then we flag success*/
		fprintf (src, "  if(!tmpptr)\n");
		fprintf (src, "  {\n");
		fprintf (src, "		failed = 0;\n");
		fprintf (src, "  }\n\n");

		curr=curr->next;

	}/*while(curr)*/

	hdr=hdr;/*avoids warning for unused parameter*/
	return icurrvar;
}/*int BasicTypeInt_CONSTRAINT*/

/*assembles all permitted alphabets into one larger inclusive alphabet*/
char* PrintCxxPermittedAlphabetHandler PARAMS((currAlpha, cPermittedAlphabet, iAlphaSize),
	AsnListNode* currAlpha _AND_
	unsigned char* cPermittedAlphabet _AND_
	int *iAlphasize)
{
	Subtype* currS_type;
	int found = 0;
	int x = 0;

	/************************************/
	/*        To avoid warning          */

		    currAlpha=currAlpha;

	/*    Reference all Parameters      */
	/************************************/

	/*while there are alphabets found*/
	while(currAlpha)
	{
		currS_type=currAlpha->data;
		if(currS_type->choiceId==SUBTYPE_SINGLE &&
			currS_type->a.single->choiceId==SUBTYPEVALUE_SINGLEVALUE)
		{
			/*concatenate the alphabets together*/
			char* temp = currS_type->a.single->a.singleValue->basicValue->a.asciiText->octs;
			
			int tempSize = strlen(temp);
	
			while(tempSize)
			{
				found = 0;

				for(x = 0; x < *iAlphasize; x++)
				{
					if(cPermittedAlphabet[x] == temp[tempSize - 1])
						found = 1;
				}

				if(found == 0)
				{
					cPermittedAlphabet[*iAlphasize] = temp[tempSize - 1];
					*iAlphasize += 1;
				}

				tempSize--;
			}				

		}/*if(curr.......SINGLEVALUE)*/

		if(currS_type->choiceId==SUBTYPE_SINGLE &&
			currS_type->a.single->choiceId==SUBTYPEVALUE_VALUERANGE)
		{
			char* temp;
			unsigned char lower;
			unsigned char upper;
			unsigned char c_alpha;

			/*concatenate the alphabets together*/
			temp=currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.asciiText->octs;
			lower=temp[0];
			
			temp=currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.asciiText->octs;
			upper=temp[0];

			for( ; lower<=upper; lower++)
			{
				found = 0;	
				c_alpha = lower;

				for(x = 0; x < *iAlphasize; x++)
				{
					if(cPermittedAlphabet[x] == c_alpha)
						found = 1;
				}

				if(found == 0)
				{
					cPermittedAlphabet[*iAlphasize] = c_alpha;
					*iAlphasize += 1;
				}
			}


		}/*if(curr.......VALUERANGE)*/

		currAlpha=currAlpha->next;
	}/*while(currAlpha)*/

	
	return (char*)cPermittedAlphabet;
}/*char* PrintCxxPermittedAlphabetHandler*/

/*Handles Size Constraints*/
int PrintCxxSizeConstraintHandler PARAMS((hdr, src, e, s, node, i, icurrvar),
	FILE* hdr _AND_
	FILE* src _AND_
	NamedType* e _AND_
	TypeDef* s _AND_
	AsnListNode* node _AND_
	int i _AND_
	int icurrvar)
{
	Subtype* currS_type;

	/************************************/
	/**    To avoid warning             */
		
			hdr=hdr;
			src=src;
			e=e;
			s=s;
			node=node;
			i=i;
			icurrvar=icurrvar;

	/*    Reference all Parameters      */
	/************************************/


	switch(i)
	{

		/* case 1 takes care of declaring the variables in the header */
	case(1):
		{
			while(node)
			{
				currS_type=node->data;

				if(currS_type->a.single->choiceId==SUBTYPEVALUE_VALUERANGE)
				{
					fprintf (hdr, "        unsigned int m_var%d;\n", icurrvar);
					fprintf (hdr, "        unsigned int m_var%d;\n", icurrvar+1);
					icurrvar+=2;
				}
				else/*singlevalue size constraint*/
				{
					fprintf (hdr, "        unsigned int m_var%d;\n", icurrvar);
					icurrvar+=1;
				}/*if..else*/
			
				
				node=node->next;
			}/*while(node)*/
			
			break;
		}/*case(1)*/

		/* case 2 takes care of initializing the variables in the header */
	case(2):
		{
			while(node)
			{
				currS_type=node->data;
				
				if(currS_type->a.single->choiceId==SUBTYPEVALUE_VALUERANGE)
				{
					fprintf (hdr, "             m_var%d = %d;\n", icurrvar,
						 currS_type->a.single->a.valueRange->lowerEndValue->endValue->basicValue->a.integer);
					fprintf (hdr, "             m_var%d = %d;\n", icurrvar+1,
						 currS_type->a.single->a.valueRange->upperEndValue->endValue->basicValue->a.integer);
					icurrvar+=2;
				}
				else/*singlevalue size constraint*/
				{
					fprintf (hdr, "             m_var%d = %d;\n", icurrvar, 
							currS_type->a.single->a.singleValue->basicValue->a.integer);
					icurrvar+=1;
				}/*if..else*/

				node=node->next;
			}/*while(node)*/

			break;
		}/*case(2)*/

		/* case 3 takes care of coding the checkconstraints function in src */
	case(3):
		{
			while(node)
			{
				currS_type=node->data;
				fprintf (src, "\n\n");
							
		        if(currS_type->a.single->choiceId==SUBTYPEVALUE_VALUERANGE)
				{
					fprintf (src, "  tmpptr = checkStringTypSize(m_var%d, m_var%d);\n\n", icurrvar, icurrvar+1);
					icurrvar+=2;
				}
				else/*singlevalue size constraint*/
				{
					fprintf (src, "  tmpptr = checkStringTypSize(m_var%d);\n\n", icurrvar);
					icurrvar+=1;
				}/*if..else*/
							
				/*if the value met the constraint we flag for success*/
				fprintf (src, "  if(tmpptr)\n");
				fprintf (src, "     ptr += tmpptr;\n\n");

				fprintf (src, "  if(!tmpptr)\n");
				fprintf (src, "  {\n");
				fprintf (src, "		failed = 0;\n");
				fprintf (src, "  }\n\n");

				node=node->next;
			}/*while(node)*/

			break;
		}/*case(3)*/
	default:
		{
			break;
		}/*default*/

	}/*switch(i)*/

	return icurrvar;
}/*int PrintCxxSizeConstraintHandler*/

/*Handles constraints found in the subtypes of primitives*/
int PrintCxxMultiConstraintOrHandler PARAMS((hdr, src, e, s, i),
	FILE* hdr _AND_
	FILE* src _AND_
	NamedType* e _AND_
	TypeDef* s _AND_
	int i)
{
	int returnvalue=0;
	char* cUnderscore;
	

	/*AsnListNode* pTmpnode;*/

	/************************************************/
	/*to avoid warnings in case any unused variables*/
	hdr=hdr;
	src=src;
	e=e;
	s=s;
	i=i;
	/************************************************/


    /* if a minus symbol is found, convert it to an underscore*/
    cUnderscore=strchr(s->definedName, '-');

    if(cUnderscore)
    {
        cUnderscore[0] = '_';

    }
    /* if a minus symbol is found, convert it to an underscore*/
    cUnderscore=strchr(e->type->cxxTypeRefInfo->className, '-');
    if(cUnderscore)
    {
        cUnderscore[0] = '_';
    }
    /* if a minus symbol is found, convert it to an underscore*/
    cUnderscore=strchr(e->type->cxxTypeRefInfo->fieldName, '-');
    if(cUnderscore)
    {
        cUnderscore[0] = '_';
    }


	/*print the generic header for the generated class*/
	fprintf (hdr, "  class %s_%s: public %s  {\n",
				 e->type->cxxTypeRefInfo->className, 
				 e->type->cxxTypeRefInfo->fieldName, 
				 e->type->cxxTypeRefInfo->className);


	fprintf (hdr, "\n"); 
	fprintf (hdr, "    private:\n");


	switch(e->type->basicType->choiceId)
	{
	
	case BASICTYPE_INTEGER:
		{
			int icurrvar=1;
			Subtype* s_type;
			Subtype* currS_type=NULL;
			Subtype* andS_type=NULL;
			AsnListNode* curr;
			AsnListNode* and_curr;
			s_type=e->type->subtypes; 
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeInt_DECL(hdr, src, icurrvar, curr, currS_type);

					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeInt_DECL(hdr, src, icurrvar, curr, currS_type);
			}	
		
		
			fprintf (hdr, "		public:\n");
			fprintf (hdr, "        %s_%s(%sType val=0):%s(val)\n        {\n",
				 e->type->cxxTypeRefInfo->className,
				 e->type->cxxTypeRefInfo->fieldName,
   				 e->type->cxxTypeRefInfo->className,
				 e->type->cxxTypeRefInfo->className);

			icurrvar=1;
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeInt_INIT(hdr, src, icurrvar, curr, currS_type);

					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeInt_INIT(hdr, src, icurrvar, curr, currS_type);
			}	
		
			if (i==1)
			{
				fprintf (src, "int %s::%s_%s::checkConstraints(ConstraintFailList* pConstraintFails)const\n", s->definedName, e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			}
			else/*not in a contained class*/
			{
				fprintf (src, "int %s_%s::checkConstraints(ConstraintFailList* pConstraintFails)const\n", e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			}/*if..else*/

			/*generates if the constraints failed to print an error*/
			fprintf (src, "{\n");
			fprintf (src, "/* if failed is 1, then constraints failed */\n");
			fprintf (src, "  int failed=1;\n");
			fprintf (src, "  std::string * pTmpError;\n");
			fprintf (src, "  std::string  ptr;\n");

			fprintf (src, "  char* tmpptr;\n");
	
			icurrvar=1;
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeInt_CONSTRAINT(hdr, src, icurrvar, curr, currS_type);

					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeInt_CONSTRAINT(hdr, src, icurrvar, curr, currS_type);
			}	
				
			
			fprintf (src, "  if(failed)\n   {\n");
			fprintf (src, "     if(pConstraintFails!=NULL)\n     {\n");
			fprintf (src, "       pTmpError=pConstraintFails->Append();\n");
			fprintf (src, "       *pTmpError = ptr;\n");
			fprintf (src, "       *pTmpError += \"In function call:  %s_%s::checkConstraints(...)\\n\";\n", e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			fprintf (src, "     }\n");
			fprintf (src, "   }\n   else\n   {\n");
			fprintf (src, "     return 0;\n");
			fprintf (src, "   }\n\n");
			fprintf (src, "   return 1;\n");
			fprintf (src, "}\n\n");

			fprintf (hdr, "        }\n\n");
	        fprintf (hdr, "        virtual int checkConstraints(ConstraintFailList* pConstraintFails)const;");

			fprintf (hdr, "\n");

			returnvalue=1;
			break;
		}/*case BASICTYPE_INTEGER*/
    
	case BASICTYPE_REAL:
		{
			int icurrvar=1;
			Subtype* s_type;
			Subtype* currS_type=NULL;
			AsnListNode* curr;
			AsnListNode* and_curr;
			Subtype* andS_type=NULL;
			s_type=e->type->subtypes; 
			
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeReal_DECL(hdr, src, icurrvar, curr, currS_type);

					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeReal_DECL(hdr, src, icurrvar, curr, currS_type);
			}
		
			fprintf (hdr, "     public:\n");
			fprintf (hdr, "        %s_%s(const double val = 0):%s(val)\n        {\n",
				 e->type->cxxTypeRefInfo->className,
				 e->type->cxxTypeRefInfo->fieldName,
   				 e->type->cxxTypeRefInfo->className,
				 e->type->cxxTypeRefInfo->className);
	
			icurrvar=1;	
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeReal_INIT(hdr, src, icurrvar, curr, currS_type);

					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeReal_INIT(hdr, src, icurrvar, curr, currS_type);
			}
	
			if (i==1)
			{
				fprintf (src, "int %s::%s_%s::checkConstraints(ConstraintFailList* pConstraintFails)const\n", s->definedName, e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			}
			else/*not contained in a class*/
			{
				fprintf (src, "int %s_%s::checkConstraints(ConstraintFailList* pConstraintFails)const\n", e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			}/*if..else*/

			fprintf (src, "{\n");
			fprintf (src, "/* if failed is 1, then constraints failed */\n");
			fprintf (src, "  int failed=1;\n");
			fprintf (src, "  std::string * pTmpError;\n");
			fprintf (src, "  std::string  ptr;\n");

			fprintf (src, "  char* tmpptr;\n");

			icurrvar=1;
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeReal_CONSTRAINT(hdr, src, icurrvar, curr, currS_type);

					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeReal_CONSTRAINT(hdr, src, icurrvar, curr, currS_type);
			}			
		
			fprintf (src, "  if(failed)\n   {\n");
			fprintf (src, "     if(pConstraintFails!=NULL)\n     {\n");
			fprintf (src, "       pTmpError=pConstraintFails->Append();\n");
			fprintf (src, "       *pTmpError = ptr;\n");
			fprintf (src, "       *pTmpError += \"In function call:  %s_%s::checkConstraints(...)\\n\";\n", e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			fprintf (src, "     }\n");
			fprintf (src, "   }\n   else\n   {\n");
			fprintf (src, "     return 0;\n");
			fprintf (src, "   }\n\n");
			fprintf (src, "   return 1;\n");
			fprintf (src, "}\n\n");

			fprintf (hdr, "        }\n\n");
			fprintf (hdr, "        virtual int checkConstraints(ConstraintFailList* pConstraintFails)const;");

			fprintf (hdr, "\n");

			returnvalue=1;

			break;
		}/*case BASICTYPE_REAL*/

	case BASICTYPE_BOOLEAN:
		{
			int icurrvar=1;
			Subtype* s_type;
			Subtype* currS_type=NULL;
			AsnListNode* curr;
			AsnListNode* and_curr;
			Subtype* andS_type=NULL;
			s_type=e->type->subtypes; 
	
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeBool_DECL(hdr, src, icurrvar, curr, currS_type);
	
					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeBool_DECL(hdr, src, icurrvar, curr, currS_type);
			}	
		
		
			fprintf (hdr, "     public:\n");
			fprintf (hdr, "        %s_%s(const bool val = false):%s(val)\n        {\n",
				 e->type->cxxTypeRefInfo->className,
				 e->type->cxxTypeRefInfo->fieldName,
   				 e->type->cxxTypeRefInfo->className,
				 e->type->cxxTypeRefInfo->className);
		
			icurrvar=1;
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeBool_INIT(hdr, src, icurrvar, curr, currS_type);
				
					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeBool_INIT(hdr, src, icurrvar, curr, currS_type);
			}	

			if (i==1)
			{
				fprintf (src, "int %s::%s_%s::checkConstraints(ConstraintFailList* pConstraintFails)const\n", s->definedName, e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			}
			else/*not contained in a class*/
			{
				fprintf (src, "int %s_%s::checkConstraints(ConstraintFailList* pConstraintFails)const\n", e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			}/*if..else*/

			fprintf (src, "{\n");
			fprintf (src, "/* if failed is 1, then constraints failed */\n");
			fprintf (src, "  int failed=1;\n");
			fprintf (src, "  std::string * pTmpError;\n");
			fprintf (src, "  std::string  ptr;\n");

			fprintf (src, "  char* tmpptr;\n");
	
			icurrvar=1;
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeBool_CONSTRAINT(hdr, src, icurrvar, curr, currS_type);
					
					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeBool_CONSTRAINT(hdr, src, icurrvar, curr, currS_type);
			}	

			fprintf (src, "  if(failed)\n   {\n");
			fprintf (src, "     if(pConstraintFails!=NULL)\n     {\n");
			fprintf (src, "       pTmpError=pConstraintFails->Append();\n");
			fprintf (src, "       *pTmpError = ptr;\n");
			fprintf (src, "       *pTmpError += \"In function call:  %s_%s::checkConstraints(...)\\n\";\n", e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			fprintf (src, "     }\n");
			fprintf (src, "   }\n   else\n   {\n");
			fprintf (src, "     return 0;\n");
			fprintf (src, "   }\n\n");
			fprintf (src, "   return 1;\n");
			fprintf (src, "}\n\n");


			fprintf (hdr, "        }\n\n");
		    fprintf (hdr, "        virtual int checkConstraints(ConstraintFailList* pConstraintFails)const;");

			fprintf (hdr, "\n");

			returnvalue=1;

			break;
		}/*case BASICTYPE_BOOLEAN*/
	

	case BASICTYPE_GRAPHIC_STR:				 
	case BASICTYPE_GENERAL_STR:
	case BASICTYPE_OBJECTDESCRIPTOR:
	case BASICTYPE_VIDEOTEX_STR:
	case BASICTYPE_T61_STR:
	case BASICTYPE_UTF8_STR: 
	case BASICTYPE_OCTETSTRING:
	case BASICTYPE_NUMERIC_STR:
    case BASICTYPE_PRINTABLE_STR:
    case BASICTYPE_BMP_STR:
    case BASICTYPE_VISIBLE_STR:
    case BASICTYPE_UNIVERSAL_STR:
    case BASICTYPE_IA5_STR:
		{
			int icurrvar=1;
			int bAlphafound=0;

			unsigned char cPermittedAlphabet[500];
			char cAlpha[1000];
			int iAlphasize = 0;
			int iSort1 = 0;
			int iSort2 = 0;
			unsigned char cSort = 0x00;
			int j = 0;
			Subtype* s_type;
			Subtype* currS_type=NULL;
			Subtype* andS_type=NULL;
			AsnListNode* curr;
			AsnListNode* and_curr;
			char* cTmp;
		
			s_type=e->type->subtypes;

			iSort2 = iSort2;

			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					cTmp=FindPermittedAlpha(curr, cPermittedAlphabet, &iAlphasize);
					
					and_curr=and_curr->next;
				}
			}
			else
			{
				curr=s_type->a.or->first;
				FindPermittedAlpha(curr, cPermittedAlphabet, &iAlphasize);
			}

			
			
			if(iAlphasize > 0)
			{
				bAlphafound=1;
				
		
				for(iSort1 = 0; iSort1 < iAlphasize; iSort1++)
				{
					for(iSort2 = (iSort1 +1); iSort2 < iAlphasize; iSort2++)
					{
						if(cPermittedAlphabet[iSort1] > cPermittedAlphabet[iSort2])
						{	
							cSort = cPermittedAlphabet[iSort2];
							cPermittedAlphabet[iSort2] = cPermittedAlphabet[iSort1];
							cPermittedAlphabet[iSort1] = cSort;
						}
					}

				}

				for(iSort1 = 0; iSort1 < iAlphasize; iSort1++)
				{
					if(iSort1 == 0)
						j += sprintf(cAlpha+j, "0x%x", cPermittedAlphabet[iSort1]);
					else
						j += sprintf(cAlpha+j, ",0x%x", cPermittedAlphabet[iSort1]);
				}

			}
		
			if(bAlphafound==1)
			{
				fprintf(hdr, "        mutable char* m_Alpha;\n");
				fprintf(hdr, "        long m_AlphaSize;\n");
			}

			s_type=e->type->subtypes; 

			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeString_DECL(hdr, src, icurrvar, curr, currS_type, e, s);
					
					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeString_DECL(hdr, src, icurrvar, curr, currS_type, e, s);
			}
	
			fprintf (hdr, "     public:\n");
			fprintf (hdr, "        %s_%s():%s()\n        {\n",
				 e->type->cxxTypeRefInfo->className,
				 e->type->cxxTypeRefInfo->fieldName,
				 e->type->cxxTypeRefInfo->className);

			if(bAlphafound==1)
			{
				fprintf(hdr, "             const char temp[] = {%s};\n", cAlpha);
				fprintf(hdr, "             m_AlphaSize = sizeof(temp);\n");
				fprintf(hdr, "             m_Alpha = new char[m_AlphaSize + 1];\n");
				fprintf(hdr, "             strncpy(m_Alpha, temp, m_AlphaSize);\n" );
				fprintf(hdr, "             m_Alpha[m_AlphaSize] = '\\0';\n");
			}
		

			icurrvar=1;
			
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeString_INIT(hdr, src, icurrvar, curr, currS_type, e, s);
						
					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeString_INIT(hdr, src, icurrvar, curr, currS_type, e, s);
			}



			fprintf (hdr, "        }\n\n");

			fprintf (hdr, "   %s_%s& operator=(const char* str)\n", e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			fprintf (hdr, "       { %s::operator=(str); return *this;}\n",e->type->cxxTypeRefInfo->className);
			fprintf (hdr, "   %s_%s& operator=(const std::string& str)\n",e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName );
			fprintf (hdr, "       { %s::operator=(str); return *this;}\n",e->type->cxxTypeRefInfo->className);

			if (i==1)
			{
				fprintf (src, "int %s::%s_%s::checkConstraints(ConstraintFailList* pConstraintFails)const\n", s->definedName, e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			}
			else/*not contained in a class*/
			{
				fprintf (src, "int %s_%s::checkConstraints(ConstraintFailList* pConstraintFails)const\n", e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			}/*if..else*/

			fprintf (src, "{\n");
			fprintf (src, "/* if failed is 1, then constraints failed */\n");
			fprintf (src, "  int failed=1;\n");
			fprintf (src, "  std::string * pTmpError;\n");
			fprintf (src, "  std::string  ptr;\n");

			fprintf (src, "  char* tmpptr;\n");
	

			icurrvar=1;
		
			if(s_type->choiceId==SUBTYPE_AND)
			{
				and_curr=s_type->a.and->first;
				while(and_curr)
				{	
					andS_type=and_curr->data;
					curr=andS_type->a.or->first;
					icurrvar=BasicTypeString_CONSTRAINT(hdr, src, icurrvar, curr, currS_type, e, s);
						
					and_curr=and_curr->next;
				}
			}
			else
			{	
				curr=s_type->a.or->first;
				icurrvar=BasicTypeString_CONSTRAINT(hdr, src, icurrvar, curr, currS_type, e, s);
			}


		
			if(bAlphafound==1)
			{	
				fprintf (src, "\n\n");
				fprintf (src, "  tmpptr = checkStringTypPermittedAlpha(m_Alpha, m_AlphaSize);\n\n");
				fprintf (src, "  if(tmpptr)\n");
				fprintf (src, "     ptr += tmpptr;\n\n");
	
				fprintf (src, "  if(!tmpptr)\n");
				fprintf (src, "  {\n");
				fprintf (src, "		failed = 0;\n");
				fprintf (src, "  }\n\n");
			}

			fprintf (src, "  if(!check())\n");
			fprintf (src, "  {\n");
			fprintf (src, "    ptr = \"____________\\nAlphabet Error\\n____________\\n--Error-- : Value is not within the %s alphabet\\n\";\n", e->type->cxxTypeRefInfo->className);
			fprintf (src, "    failed = 1;\n");
			fprintf (src, "  }\n\n");
	
			fprintf (src, "  if(failed)\n   {\n");
			fprintf (src, "     if(pConstraintFails!=NULL)\n     {\n");
			fprintf (src, "       pTmpError=pConstraintFails->Append();\n");
			fprintf (src, "       *pTmpError = ptr;\n");
			fprintf (src, "       *pTmpError += \"In function call:  %s_%s::checkConstraints(...)\\n\";\n", e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
			fprintf (src, "     }\n");
			fprintf (src, "   }\n   else\n   {\n");
			fprintf (src, "     return 0;\n");
			fprintf (src, "   }\n\n");
			fprintf (src, "   return 1;\n");
			fprintf (src, "}\n\n");
	
	        fprintf (hdr, "        virtual int checkConstraints(ConstraintFailList* pConstraintFails)const;");

			fprintf (hdr, "\n");

			returnvalue=1;

			break;
		}/*	case BASICTYPE_NUMERIC_STR:   *\
		  * case BASICTYPE_PRINTABLE_STR: *
		  *	case BASICTYPE_BMP_STR:       *
		  *	case BASICTYPE_VISIBLE_STR:   *
		  *	case BASICTYPE_UNIVERSAL_STR: *
		  *	case BASICTYPE_IA5_STR:       * 
		 \*                               */                 

	default:
		{
			returnvalue=0;
			break;
		}/*default*/
	
	}/*switch(e->type->basicType->choiceId)*/

	fprintf (hdr, "\n    };\n\n  ");
    

    /* Last we declare an instance of the internal class we */
    /*   just created                                       */
	if(i==0)
	{		
        fprintf (hdr, "typedef ");
    }/*if(i==0)*/
 
    fprintf (hdr, "  %s_%s		", e->type->cxxTypeRefInfo->className,
	   		 e->type->cxxTypeRefInfo->fieldName);

    if (e->type->cxxTypeRefInfo->isPtr)
    {
        fprintf (hdr, "*");
    }/*if (e->type->cxxTypeRefInfo->isPtr)*/

	fprintf (hdr, "%s;\n", e->type->cxxTypeRefInfo->fieldName);
	fprintf (hdr, "\n\n\n");
	fprintf (src, "\n\n");

	return returnvalue;
	
}/*int PrintCxxMultiConstraintOrHandler*/

