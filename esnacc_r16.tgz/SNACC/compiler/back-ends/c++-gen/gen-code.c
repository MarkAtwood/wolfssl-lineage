
/*
 *   compiler/back_ends/c++_gen/gen_code.c - routines for printing C++ code from type trees
 *
 *   assumes that the type tree has already been run through the
 *   c++ type generator (c++_gen/types.c).
 *
 *  This was hastily written - it has some huge routines in it.
 *  Needs a lot of cleaning up and modularization...
 *
 * Mike Sample
 * 92
 * Copyright (C) 1991, 1992 Michael Sample
 *           and the University of British Columbia
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * INSERT_VDA_COMMENTS
 *
 *
 * $Header: /baseline/SNACC/compiler/back-ends/c++-gen/gen-code.c,v 1.97 2003/08/07 16:25:36 colestor Exp $
 * $Log: gen-code.c,v $
 * Revision 1.97  2003/08/07 16:25:36  colestor
 * Fixed "%d" string reference in file production to "%s" (missed one).
 *
 * Revision 1.96  2003/07/28 11:13:51  colestor
 * Changes to complete handing of the "--snacc namespace" compiler directive.
 * Also, updates to handle ASN.1 constant integer tag designations for C++/C.
 *
 * Revision 1.95  2003/07/07 17:17:20  nicholar
 * Removed unused global variable
 *
 * Revision 1.94  2003/07/07 14:52:35  nicholar
 * Eliminated headers and cleaned up include references
 *
 * Revision 1.93  2003/02/03 13:15:27  leonberp
 * changes for Visual Studio .NET
 *
 * Revision 1.92  2003/01/27 16:49:14  leonberp
 * added Init() calls from Clear() and added code for default member initialization to be included in next release (1.6?)
 *
 * Revision 1.91  2003/01/21 13:39:23  leonberp
 * backed out changes
 *
 * Revision 1.90  2003/01/17 06:03:01  leonberp
 * cleanup
 *
 * Revision 1.89  2003/01/17 01:16:04  leonberp
 * FIXED A TON of warnings
 *
 * Revision 1.88  2003/01/06 20:12:14  leonberp
 * AsnBuf const changes
 *
 * Revision 1.87  2002/12/22 01:21:54  colestor
 * (RWC)Updated PrintXML(...) details to better match specification for SEQUENCE OF and SET OF logic.
 *
 * Revision 1.86  2002/12/19 18:18:24  colestor
 * (RWC) Partial Updat for PrintXML according to specifications.
 *
 * Revision 1.85  2002/12/17 20:28:18  leonberp
 * made BEnc() and BEncContent() const
 *
 * Revision 1.84  2002/12/16 20:54:33  leonberp
 * moved most in-line code from asn-buf.h to asn-fileseg.cpp and asn-rvsbuf.cpp and added clear(),operator= to AsnBuf
 *
 * Revision 1.83  2002/12/16 13:44:34  mcphersc
 * fixed line 2358 - too many arguments to format
 *
 * Revision 1.82  2002/12/12 22:00:58  leonberp
 * fixed default bitstring support added AsnBits::soloBitCheck()
 *
 * Revision 1.81  2002/12/10 19:06:48  leonberp
 * fixed Init() bug were some pointer elements where not being initialized to NULL
 *
 * Revision 1.80  2002/12/10 17:06:30  leonberp
 * fixed indefinite length context specific ANY decoding for SETs as well as Sequences
 *
 * Revision 1.79  2002/12/10 16:08:13  leonberp
 * fixed indefinite length context specific ANY decoding
 *
 * Revision 1.78  2002/12/06 18:11:46  leonberp
 * fixed append renamed it splice
 *
 * Revision 1.77  2002/12/05 15:18:07  nicholar
 * Eliminated unused variable warning.
 *
 * Revision 1.76  2002/12/03 21:27:35  leonberp
 * renamed AsnBuf::insert to AsnBuf::append
 *
 * Revision 1.75  2002/11/22 21:09:45  leonberp
 * fixed bug in code generation of BDecContent and BEncContent for choices that contain ANYs
 *
 * Revision 1.74  2002/11/18 21:00:36  leonberp
 * fixed bug where init and clear routines were generating code for non-pointer members
 *
 * Revision 1.73  2002/11/07 16:27:35  leonberp
 * replace old code for set sorting with new stuff
 *
 * Revision 1.72  2002/11/01 15:08:10  mcphersc
 * fixed compiler warnings and erros not caught by microsoft compiler
 *
 * Revision 1.71  2002/10/30 14:19:36  mcphersc
 * Took out some unused code and variables
 *
 * Revision 1.70  2002/10/29 16:37:06  mcphersc
 * changed include reference to imported list
 *
 * Revision 1.69  2002/10/28 20:50:58  leonberp
 * Ok.. I think this is the final fix for OCTET/BIT STRING CONTAINING
 *
 * Revision 1.68  2002/10/28 19:57:02  leonberp
 * Added BITSTRING CONTAINING support and fixed CONTAINED ANY DEFINED BY
 *
 * Revision 1.67  2002/10/28 18:15:32  leonberp
 * finished OCTET containing code
 *
 * Revision 1.66  2002/10/28 12:54:49  leonberp
 * fixed AsnBuf parameters to be parameters
 *
 * Revision 1.65  2002/10/23 10:21:52  mcphersc
 * changed BUF_TYPE to AsnBuf
 *
 * Revision 1.64  2002/10/21 17:26:25  mcphersc
 * fixed long int
 *
 * Revision 1.63  2002/10/09 19:38:14  leonberp
 * new AsnBuf integration
 *
 * Revision 1.62  2002/10/01 14:00:23  mcphersc
 * Modified snacc to accept either the -I import option or the original way to list the
 * asn modules on the command line
 *
 * Revision 1.61  2002/10/01 12:26:46  mcphersc
 * Modified snacc to accept either the -I import option or the original way to list the
 * asn modules on the command line
 *
 * Revision 1.60  2002/09/23 17:31:29  mcphersc
 * added asn-incl to the asn include file
 *
 * Revision 1.59  2002/09/23 17:25:45  mcphersc
 * include references now in include file
 *
 * Revision 1.58  2002/09/17 13:36:22  leonberp
 * fixed bug in code generation for free(outputBuf.DataPtr())
 *
 * Revision 1.57  2002/09/17 10:58:41  mcphersc
 * Fixed warnings
 *
 * Revision 1.56  2002/09/16 17:48:14  mcphersc
 * iFixed warnings
 *
 * Revision 1.55  2002/09/12 14:55:17  mcphersc
 * Fix compiler error
 *
 * Revision 1.54  2002/09/05 13:08:34  leonberp
 * fixed PrintSetTypeByCode() to reference the mangled name .vs. the ASN.1 name (ie. oepration_code instead of operation-code).
 *
 * Revision 1.53  2002/09/04 17:51:34  vracarl
 * got rid of c++ comments
 *
 * Revision 1.52  2002/08/29 18:38:23  leonberp
 * fixed AsnOcts derived classes to use call operator= instead of ReSet()
 *
 * Revision 1.51  2002/08/14 17:51:51  leonberp
 * changed yet again to free() DataPtr() from AsnBuf
 *
 * Revision 1.50  2002/08/14 15:30:17  leonberp
 * changed again to init AsnBuf to a length of 1 so that it will always grow and delete the buffer it was initialized with.
 *
 * Revision 1.49  2002/08/14 13:58:33  leonberp
 * changed set component max size to be VDASNACC_ENCDEC_BUFSIZE
 *
 * Revision 1.48  2002/07/02 16:58:26  leonberp
 * removed #ifdef'd code (old string fudge).
 *
 * Revision 1.47  2002/05/29 19:48:59  leonberp
 * removed PDU generation
 *
 * Revision 1.46  2002/05/15 22:13:04  leonberp
 * added support for new basicTypes to compiler
 *
 * Revision 1.45  2002/05/15 14:53:10  leonberp
 * added support for new basicTypes to compiler
 *
 * Revision 1.44  2002/05/10 16:39:38  leonberp
 * latest changes for release 2.2
 * includes integrating asn-useful into C & C++ runtime library, the compiler changes that go along with that, SnaccException changes for C++ runtime and compiler
 *
 * Revision 1.43  2002/03/19 22:33:43  rwc
 * Updates to the DER encoding of SET OFs.  They now include all tag/length bytes, no
 * longer skipping them as before (in a mis-interpretation of the specs).  Also updated
 * the test routine to test this feature (modified an existing data array).  Tested!
 *
 * Revision 1.42  2001/11/15 20:06:10  leonberp
 * changed const values to be extern'd again
 *
 * Revision 1.41  2001/10/30 15:50:08  leonberp
 * fixed copy constructors for Strings
 *
 * Revision 1.40  2001/10/25 18:48:46  leonberp
 * Changed const values to print to the header file only
 *
 * Revision 1.39  2001/10/16 03:53:39  leonberp
 * added NoChoiceCid and (void * NoChoice) to all choices for initialization
 *
 * Revision 1.38  2001/10/12 12:53:18  leonberp
 * Added Init() call in Clear() and added Clear() call in operator=
 *
 * Revision 1.37  2001/10/12 03:04:58  leonberp
 * added Clear() and calls to it in BDecContent code
 *
 * Revision 1.36  2001/10/11 13:56:54  leonberp
 * fixed PrintXML() code for UNIX
 *
 * Revision 1.35  2001/10/01 13:54:17  leonberp
 * fixed PrintSimpleMeta for UNIX
 *
 * Revision 1.34  2001/09/19 16:41:04  leonberp
 * updated Init for choices to allocate memory for the first choice type
 *
 * Revision 1.33  2001/09/19 13:14:49  leonberp
 * Added PrintCopyConstructor() function and moved member initialization to Init()
 *
 * Revision 1.32  2001/09/18 15:02:15  leonberp
 * removed more copy constructor code
 *
 * Revision 1.31  2001/09/18 13:05:40  nicholar
 * Fixed bug in PrintCloneMethod() so that the copy constructor is called rather than the default constructor.
 *
 * Revision 1.30  2001/09/10 16:40:30  leonberp
 * removed more copy constructor code
 *
 * Revision 1.29  2001/09/09 20:42:05  nicholar
 * Fixed minor bugs in output strings for ASN_THROW.
 *
 * Revision 1.28  2001/09/07 14:57:07  leonberp
 * fixed gAlternateNamespace to be a pointer
 *
 * Revision 1.27  2001/09/05 16:25:35  leonberp
 * fixed exportMember
 *
 * Revision 1.26  2001/09/05 15:52:12  leonberp
 * fixed Simple Meta code
 *
 * Revision 1.25  2001/09/04 14:43:41  mcphersc
 * Added namespce { back in
 *
 * Revision 1.24  2001/09/04 13:17:47  rwc
 * Final updates for Thread testing; including update to compiler for Print(...) methods to maintain indent integrity.
 *
 * Revision 1.23  2001/08/31 12:04:35  mcphersc
 * no message
 *
 * Revision 1.22  2001/08/30 14:10:19  mcphersc
 * Changed namespace xxx {
 *
 * to
 *
 * Using namespace xxx
 *
 * Revision 1.18  2001/08/24 15:40:26  leonberp
 * Enchanced to produce List template code instead of generating the list code
 *
 * Revision 1.17  2001/08/08 15:28:54  rwc
 * Updated to properly reflect the newly added INTEGER (for BigIntegerStr processing) feature
 * length encoding.  The old logic forced encoding to be < 127 bytes.
 *
 * Revision 1.16  2001/07/12 19:34:20  leonberp
 * Changed namespace to SNACC and added compiler options: -ns and -nons.  Also removed dead code.
 *
 * Revision 1.15  2001/06/28 21:39:31  rwc
 * Updated to remove referneces to vdacerr, which originally replaced the cerr standard error output.
 * Updated all references in macros and source that printed to vdacerr.  All code now performs an
 * ASN_THROW(...) exception.
 *
 * Revision 1.14  2001/06/18 17:46:51  rwc
 * Updated to reflect newly added C++ Exception error handling, instead of "C" longjmp and setjmp calls.
 * Changes made to both the compiler and the SNACC C++ run-time library.
 *
 * Revision 1.13  2001/05/14 11:20:11  mcphersc
 * Fixed my screw-up on line 818
 *
 * Revision 1.12  2001/05/11 16:00:46  mcphersc
 * Fixed problems with Init Any's and class statement in gen-code.
 * Gen-code not allowing for "::" in some instances
 *
 * Revision 1.11  2001/04/18 16:28:57  rwc
 * Updated test for ANY DEFINED BY updates.  Now supports default CSM_Buffer (AsnAnyBuffer) result if
 * OID is not recognized.
 *
 * Revision 1.10  2001/01/23 20:52:42  rwc
 * Updated to allow NOVDADER_RULES to disable VDA additions (except for new string
 * class handling, e.g. PrintableString; had to allow).  Several sources are now disabled from
 * the build if NOVDADER_RULES config item is chosen.  Builds, but untested.
 *
 * Revision 1.9  2001/01/23 15:54:48  rwc
 * Updated to properly add "}" on certain methods in SET OF logic; it was improperly #ifdef WIN32 disabled; Linux build failed.
 *
 * Revision 1.8  2001/01/22 20:19:00  rwc
 * Updates to test newly added ASN.1 XML output.
 *
 * Revision 1.7  2000/11/21 15:47:32  leonberp
 * fixed bug in removeCurrFromList() ..  set curr to curr->next after it's been removed.
 *
 * Revision 1.6  2000/10/27 18:19:28  rwc
 * Removed "abort()" call to avoid warning on certain ANY processing on compiled files (in SFL).
 * Added call to "throw(...)" to indicate an error.  This should never be hit, but avoids compiler warning.
 *
 * Revision 1.5  2000/10/27 13:54:50  rwc
 * removed last warning for produced .cpp/.C files.
 *
 * Revision 1.4  2000/10/24 14:54:44  rwc
 * Updated to remove high-level warnings (level 4 on MSVC++) for an easier build.
 * SOME warnings persist due to difficulty in modifying the SNACC compiler to
 * properly build clean source; also some files are built by Lex/Yacc.
 *
 * Revision 1.3  2000/10/16 18:10:41  rwc
 * removed most warnings from C++-lib, some C-lib.
 *
 * Revision 1.2  2000/08/22 20:06:45  leonberp
 * fixed default bitstring handling
 *
 * Revision 1.1.1.1  2000/08/21 20:36:06  leonberp
 * First CVS Version of SNACC.
 *
 * Revision 1.12  1997/02/28 13:39:53  wan
 * Modifications collected for new version 1.3: Bug fixes, tk4.2.
 *
 * Revision 1.11  1997/02/16 15:14:06  rj
 * made return *this after calling abort()'' a compile time option.
 *
 * Revision 1.10  1997/02/16 12:46:31  rj
 * use the TIME_WITH_SYS_TIME flag (checked and generated by configure).
 * return *this after calling abort() for compilers that don't know about this volatile function.
 * comment out unused parameters, the compiler otherwise may complain.
 *
 * Revision 1.9  1995/09/07  20:47:32  rj
 * deep copying assingment operators added.
 *
 * Revision 1.8  1995/09/07  19:25:27  rj
 * PrintCxxCode(): boolean genMeta changed to enum type MetaNameStyle. used globally in printMetaG.
 *
 * set Tcl's errorCode variable.
 *
 * Revision 1.7  1995/08/17  15:00:06  rj
 * the PDU flag belongs to the metacode, not only to the tcl interface. (type and variable named adjusted)
 *
 * Revision 1.6  1995/07/27  10:52:28  rj
 * include config.h before using its #define's :-)
 *
 * file name has been shortened for redundant part: c++-gen/gen-c++-code -> c++-gen/gen-code.
 *
 * functions used only locally made static.
 *
 * #if TCL ... #endif wrapped into #if META ... #endif, both here and in generated files.
 *
 * code changes to allow for more than one PDU (meta code), e.g. generate -create() functions.
 *
 * generate additional TclUnsetVal() function to delete OPTIONAL members and SEQUENCE OF and SET OF list elements.
 *
 * _getref() gets an additional optional argument to faciliate the different member access semantics of TclGetVal() and TclSetVal().
 *
 * the list functions Append(), Prepend(), InsertBefore() and InsertAfter() now set the current element to the element just inserted.
 *
 * changed `_' to `-' in file names.
 *
 * Revision 1.5  1995/02/18  14:45:16  rj
 * tried to make the print function's output a little more readable. [kho]
 *
 * Revision 1.4  1994/10/08  03:19:24  rj
 * since i was still irritated by cpp standing for c++ and not the C preprocessor, i renamed them to cxx (which is one known suffix for C++ source files). since the standard #define is __cplusplus, cplusplus would have been the more obvious choice, but it is a little too long.
 *
 * turned the functions order upside down to get rid of those annoying declarations.
 *
 * turned character pointers into constant character arrays.
 *
 * code for meta structures added (provides information about the generated code itself).
 *
 * code for Tcl interface added (makes use of the above mentioned meta code).
 *
 * instead of being a no-op, the no-arg-constructors (that get used by Clone()) do something useful now, namely:
 * - initialize the pointer in a choice union. (the destruktor may try to free the bogus pointer).
 * - for the same reason: initialize pointers in sequences and sets.
 *
 * to complement the destructors, T::T (const T&) and T &T::operator = (const T &) have been added to override the defaults supplied by the compiler.
 * reason: simple pointer duplication may lead to unreferenced objects and to objects referenced more than once (on which the destructors delete may choke).
 *
 * virtual inline functions (the destructor and the Clone() function) moved from inc to src because g++ turns every one of them into a static non-inline function in every file where the .h file gets included.
 *
 * made Print() const (and some other, mainly comparison functions).
 *
 * Revision 1.3  1994/09/01  00:16:29  rj
 * change of IBM ENC integrated: large inlines turned into normal functions.
 * more portable .h file inclusion.
 *
 * Revision 1.2  1994/08/31  09:49:05  rj
 * for the C++ code generated: turned TRUE/FALSE into true/false;
 * the keyword `struct' had to be removed before AsnListElmt, or gcc 2.6 wouldn't compile the generated code.
 *
 * Revision 1.1  1994/08/28  09:48:01  rj
 * first check-in. for a list of changes to the snacc-1.1 distribution please refer to the ChangeLog.
 *
 */

#include "snacc.h"

#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif

#if STDC_HEADERS || HAVE_STRING_H
#include <string.h>
#else
#include <strings.h>
#endif

#include "asn-incl.h"
#include "asn1module.h"
#include "rules.h"
#include "snacc-util.h"
#include "print.h"
#include "tag-util.h"  /* get GetTags/FreeTags/CountTags/TagByteLen */
#if META
#include "meta.h"
#endif


enum BasicTypeChoiceId ParanoidGetBuiltinType PARAMS ((t),Type *t);
void PrintConditionalIncludeOpen PROTO ((FILE *f, char *fileName));
void PrintConditionalIncludeClose PROTO ((FILE *f, char *fileName));
void PrintCxxAnyCode PROTO ((FILE *src, FILE *hdr, CxxRules *r,
							ModuleList *mods, Module *m));
void PrintCxxValueDef PROTO ((FILE *src, CxxRules *r, ValueDef *v));
void PrintCxxValueExtern PROTO ((FILE *hdr, CxxRules *r, ValueDef *v));
char *LookupNamespace PROTO ((Type *t, ModuleList *mods));

extern char *bVDAGlobalDLLExport;
extern int gNO_NAMESPACE;
extern const char *gAlternateNamespaceString;
//extern short ImportedFilesG;

static const char	bufTypeNameG[] = "AsnBuf";
static const char	lenTypeNameG[] = "AsnLen";
static const char	tagTypeNameG[] = "AsnTag";
static const char	envTypeNameG[] = "ENV_TYPE";
static long 		longJmpValG  = -100;
static const char	baseClassesG[] = ": public AsnType";

static int		printTypesG;
static int		printEncodersG;
static int		printDecodersG;
static int		printPrintersG;
static int		printFreeG;
#if META
static MetaNameStyle	printMetaG;
static MetaPDU		*meta_pdus_G;
#if TCL
static int		printTclG;
#endif
#endif /* META */



/* PIERCE added 10-27-2002 */
void PrintCxxEncodeContaining(Type *t, CxxRules *r, FILE *src);
void PrintCxxDecodeContaining(Type *t, CxxRules *r, FILE *src);


/* PIERCE added 9-4-2002 */

void PrintCxxSetTypeByCode(NamedType *defByNamedType, CxxTRI *cxxtri, FILE *src);

// normalizeValue
// 
// strip whitespace and { } from valueNation values.
//
void normalizeValue(char **normalized, char *input)
{
   int i;
   while(*input == ' ' || *input == '{' )
      input++;

   *normalized = strdup(input);
   
   i = strlen(*normalized) - 1;
   while ( (*normalized)[i] == ' ' || (*normalized)[i] == '}' )
   {
      (*normalized)[i] = 0;
      i--;
   }
}

static char *GetImportFileName (char *Impname, ModuleList *mods)
{
	Module *currMod;
	char *fileName = NULL;
    FOR_EACH_LIST_ELMT (currMod, mods)
	{
		/* Find the import Module in the Modules and
		 * return the header file name
		 */
		if ((strcmp(Impname, currMod->modId->name) == 0))
		{
			/* Set the file name and break */
			fileName = currMod->cxxHdrFileName;
			break;
		}
	}
	return fileName;
}

/* RWC; added 7/25/03 */
static Module *GetImportModuleRef (char *Impname, ModuleList *mods)
{
	Module *currMod=NULL;
    FOR_EACH_LIST_ELMT (currMod, mods)
	{
		/* Find the import Module in the Modules and
		 * return the header file name
		 */
		if ((strcmp(Impname, currMod->modId->name) == 0))
		{
			break;
		}
	}
	return currMod;
}

/* PIERCE added 8-22-2001 */
void PrintCopyConstructor(FILE *hdr, FILE *src, char *className)
{
   fprintf(hdr, "   %s(const %s& that);\n", className, className);
   fprintf(src,"%s::%s(const %s &that)\n{\n",className, className,className);
   fprintf(src,"   Init();\n");
   fprintf(src,"   *this = that;\n}\n");
}
void PrintSimpleMeta(FILE *hdr, char *className,int exportMember)
{
   char *ptr="";   /* NOT DLL Exported, or ignored on Unix. */

   /* The member is exported for AsnSetOf and AsnSeqOf */

   if (bVDAGlobalDLLExport != NULL && exportMember == 1) 
   {
      ptr = bVDAGlobalDLLExport;
      fprintf (hdr,
        "public:\n  %s virtual const char * typeName(void) const { return \"%s\"; }\n",
         ptr, className);
   }
   else
   {
      fprintf (hdr,
        "public:\n  virtual const char * typeName(void) const { return \"%s\"; }\n", className);
   }
}

static void
PrintHdrComment PARAMS ((hdr, m),
    FILE *hdr _AND_
    Module *m)
{
    time_t now = time (NULL);

    fprintf (hdr, "//   NOTE: this is a machine generated file--editing not recommended\n");
    fprintf (hdr, "//\n");
    fprintf (hdr, "// %s - class definitions for ASN.1 module %s\n", m->cxxHdrFileName, m->modId->name);
    fprintf (hdr, "//\n");
    fprintf (hdr, "//   This file was generated by snacc on %s", ctime (&now));
    fprintf (hdr, "//   UBC snacc by Mike Sample\n");
    fprintf (hdr, "//   A couple of enhancements made by IBM European Networking Center\n"); /* 20.8.93 Thomas Meyer */
    fprintf (hdr, "\n");


} /* PrintHdrComment */

static void
PrintSrcComment PARAMS ((src, m),
    FILE *src _AND_
    Module *m)
{
    time_t now = time (NULL);

    fprintf (src, "//   NOTE: this is a machine generated file--editing not recommended\n");
    fprintf (src, "//\n");
    fprintf (src, "// %s - class member functions for ASN.1 module %s\n", m->cxxSrcFileName, m->modId->name);
    fprintf (src, "//\n");
    fprintf (src, "//   This file was generated by snacc on %s", ctime (&now));
    fprintf (src, "//   UBC snacc written by Mike Sample\n");
    fprintf (src, "//   A couple of enhancements made by IBM European Networking Center\n"); /* 20.8.93 Thomas Meyer */
    fprintf (src, "\n");

} /* PrintSrcComment */


static void
PrintSrcIncludes PARAMS ((src, if_IBM_ENC (srcdb COMMA) mods, m),
    FILE *src _AND_
    if_IBM_ENC (FILE *srcdb _AND_)
    ModuleList *mods _AND_
    Module *m)
{
#ifdef _IBM_ENC_
    size_t length;
    char *inclstring;
	
#endif /* _IBM_ENC_ */

	mods = mods;
	if (m->cxxHdrFileName)
		fprintf (src, "#include \"%s\"\n", m->cxxHdrFileName);


#ifdef _IBM_ENC_
#include "./ibm_editor/print_src_includes.h"
#endif /* _IBM_ENC_ */
    m = m;  /*AVOIDS warning.*/
} /* PrintSrcIncludes */


static void
PrintTypeDecl PARAMS ((f, td),
    FILE *f _AND_
    TypeDef *td)
{
    switch (td->type->basicType->choiceId)
    {
        case BASICTYPE_COMPONENTSOF:
        case BASICTYPE_SELECTION:
        case BASICTYPE_UNKNOWN:
        case BASICTYPE_MACRODEF:
        case BASICTYPE_MACROTYPE:
            return; /* do nothing */

        default:
            if (IsNewType (td->type))
                fprintf (f, "class %s;\n", td->cxxTypeDefInfo->className);
    }

} /* PrintTypeDecl */


static void
PrintCxxType PARAMS ((hdr, mods, m, r, td, parent, t),
    FILE *hdr _AND_
    ModuleList *mods _AND_
    Module *m _AND_
    CxxRules *r _AND_
    TypeDef *td _AND_
    Type *parent _AND_
    Type *t)
{
    char *pszNamespace=NULL;

    pszNamespace = LookupNamespace(t, mods);

    if (pszNamespace)
    {
        fprintf (hdr, "%s::%s		", pszNamespace, t->cxxTypeRefInfo->className);
    }
    else
    {
        fprintf (hdr, "%s		", t->cxxTypeRefInfo->className);
    }           // END IF BASICTYPE_IMPORTTYPEREF

    if (t->cxxTypeRefInfo->isPtr)
        fprintf (hdr, "*");

    parent = parent;td = td;r = r;m = m;mods=mods;  /*AVOIDS warning.*/
} /* PrintCxxType */


#ifdef _IBM_ENC_
static void
PrintCxxTypedb PARAMS ((srcdb, mods, m, r, td, parent, t),
    FILE *srcdb _AND_
    ModuleList *mods _AND_
    Module *m _AND_
    CxxRules *r _AND_
    TypeDef *td _AND_
    Type *parent _AND_
    Type *t)
{
#include "./ibm_editor/print_cxx_type_db.h"
} /* PrintCxxTypedb */
#endif


/*
 *  Uses the Constructor that takes no args.
 *  Assumes file f is positioned inside a class definition.
 *  All Classes get this to support the ANY type.
 */
static void
PrintCloneMethod PARAMS ((hdr, src, td),
    FILE *hdr _AND_
    FILE *src _AND_
    TypeDef *td)
{
//    fprintf (hdr, "  AsnType		*Clone() const;\n\n", td->cxxTypeDefInfo->className);
    fprintf (hdr, "  AsnType		*Clone() const;\n\n");

    fprintf (src, "AsnType *%s::Clone() const\n", td->cxxTypeDefInfo->className);
    fprintf (src, "{\n");
    fprintf (src, "  return new %s(*this);\n", td->cxxTypeDefInfo->className);
    fprintf (src, "}\n\n");
} /* PrintCloneMethod */


/*
 * prints inline definition of constructors if this class is
 * derived from a library class.
 * assumes FILE *f is positioned in the derived class definition (.h)
 *
 * 12/92 MS - added overloaded "=" ops for string types.
 */
static void
PrintDerivedConstructors PARAMS ((f, r, td),
    FILE *f _AND_
    CxxRules *r _AND_
    TypeDef *td)
{
    enum BasicTypeChoiceId typeId;
    char *derivedClassName;
    char *baseClassName;


    typeId = GetBuiltinType (td->type);
    derivedClassName = td->cxxTypeDefInfo->className;
    baseClassName = td->type->cxxTypeRefInfo->className;

    /* every class gets the no-arg constructor */
#if TCL
    if (printTclG && typeId == BASICTYPE_ENUMERATED)
    {
	fprintf (f, "#if TCL\n");
	fprintf (f, "			%s(): %s (_nmdescs[0].value) {}\n", derivedClassName, baseClassName);
	fprintf (f, "#else\n");
    }
    if (printTclG && typeId == BASICTYPE_ENUMERATED)
      fprintf (f, "#endif\n");
#endif /* TCL */

    switch (typeId)
    {
        case BASICTYPE_BOOLEAN:
            fprintf (f, "			%s(): %s() {}\n", derivedClassName, baseClassName);
            fprintf (f, "			%s (bool b): %s (b) {}\n", derivedClassName, baseClassName);
            break;

        case BASICTYPE_ENUMERATED:
        case BASICTYPE_INTEGER:
            fprintf (f, "			%s(): %s() {}\n", derivedClassName, baseClassName);
            fprintf (f, "			%s (int i): %s (i) {}\n", derivedClassName, baseClassName);
            break;

        case BASICTYPE_REAL:
            fprintf (f, "			%s(): %s() {}\n", derivedClassName, baseClassName);
            fprintf (f, "			%s (double d): %s (d) {}\n", derivedClassName, baseClassName);
            break;

	     case BASICTYPE_OCTETSTRING:
            fprintf (f, "			%s(): %s() {}\n", derivedClassName, baseClassName);
            fprintf (f, "			%s (const char *str): %s (str) {}\n", derivedClassName, baseClassName);

            fprintf (f, "			%s (const char *str, const size_t len): %s (str, len) {}\n", derivedClassName, baseClassName);

            fprintf (f, "			%s (const %s &o): %s (o) {}\n", derivedClassName, derivedClassName, baseClassName);

            /* include overloading of = op. MS 12/92 */
			
            fprintf (f, "        %s		&operator = (const %s &o)	{ AsnOcts::operator=(o); return *this; }\n", derivedClassName, derivedClassName);
			fprintf (f, "        %s		&operator = (const char *str)	{ AsnOcts::operator=(str); return *this; }\n", derivedClassName);
            break;

        case BASICTYPE_BITSTRING:
           {    
              char *nblFlag="nblFlag = false;";
              if (HasNamedElmts (td->type))
                 nblFlag = "nblFlag = true;";
            fprintf (f, "			%s(): %s() {%s}\n", derivedClassName, baseClassName,nblFlag);

            fprintf (f, "			%s (const size_t bits): %s (bits) {%s}\n", derivedClassName, baseClassName, nblFlag);

            fprintf (f, "			%s (const char *str, const size_t bitLen): %s (str, bitLen) {%s}\n", derivedClassName, baseClassName, nblFlag);
            fprintf (f, "        %s (const %s &o):%s(o) { /* construct from AsnBits */ }\n", derivedClassName, baseClassName, baseClassName);

            /* Copy constructor for classes that inherit AsnBits is not necessary
             *
             * fprintf (f, "			%s (const %s &b): %s (b) {%s}\n",  derivedClassName, derivedClassName, baseClassName, nblFlag);
             */
           }
            break;

        case BASICTYPE_OID:
            /* TBD: Fix this code -PIERCE
             
            fprintf (f, "			%s(): %s() {}\n", derivedClassName, baseClassName);
            fprintf (f, "			%s (const char *encOid, size_t len): %s (encOid, len) {}\n", derivedClassName, baseClassName);
            fprintf (f, "			%s (const %s &o): %s (o) {}\n", derivedClassName, baseClassName, baseClassName);
            fprintf (f, "			%s (unsigned long  a1, unsigned long  a2, long a3=-1, long a4=-1, long a5=-1, long a6=-1, long a7=-1, long a8=-1, long a9=-1, long a10=-1, long a11=-1): %s (a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11) {}\n", baseClassName, derivedClassName, baseClassName);
            fprintf (f, "  %s		&operator = (const %s &o)	{ ReSet (o); return *this; }\n", derivedClassName, derivedClassName);
            */
            printf("TBD: Attempt was made to generate code for a tagged OID outside of a SEQ or SET\n");
            break;


        default:
            /* do nothing */
            break;
    }

    r = r;  /*AVOIDS warning.*/
} /* PrintDerivedConstructors */

#if DEPRECATED
static void
PrintCxxEocEncoders PARAMS ((src, td, t, bufVarName),
    FILE *src _AND_
    TypeDef *td _AND_
    Type *t _AND_
    char *bufVarName)
{
    TagList *tl;
    Tag *tag;
    int stoleChoiceTags;

    /*
     * get all the tags on this type
     */
    tl = (TagList*) GetTags (t, &stoleChoiceTags);

	 /* eSNACC 1.5 does not encode indefinite length
	  *
    if (!stoleChoiceTags)
    {
        FOR_EACH_LIST_ELMT (tag, tl)
            if (tag->form == CONS)
               fprintf (src, "      BEncEocIfNec (b);\n");
    }
	 */

    FreeTags (tl);

    bufVarName=bufVarName;td=td;  /*AVOIDS warning.*/
} /* PrintCxxEocEncoders */
#endif

static int
HasShortLen PARAMS ((t),
    Type *t)
{
    enum BasicTypeChoiceId typesType;
    /*
     * efficiency hack - use simple length (1 byte)
     * encoded for type (almost) guaranteed to have
     * encoded lengths of 0 <= len <= 127
     */
    typesType = GetBuiltinType (t);
    /*RWC;8/9/01;REMOVED when INTEGER made AsnOcts;return typesType == BASICTYPE_BOOLEAN || typesType == BASICTYPE_INTEGER || typesType == BASICTYPE_NULL || typesType == BASICTYPE_REAL || typesType == BASICTYPE_ENUMERATED; */
    return typesType == BASICTYPE_BOOLEAN || typesType == BASICTYPE_NULL || typesType == BASICTYPE_REAL || typesType == BASICTYPE_ENUMERATED;
} /* HasShortLen */


/*
 * prints length encoding code.  Primitives always use
 * definite length and constructors get "ConsLen"
 * which can be configured at compile to to be indefinite
 * or definite.  Primitives can also be "short" (isShort is true)
 * in which case a fast macro is used to write the length.
 * Types for which isShort apply are: boolean, null and
 * (almost always) integer and reals
 */
static void
PrintCxxLenEncodingCode PARAMS ((f, isCons, isShort, lenVarName, bufVarName),
    FILE *f _AND_
    int isCons _AND_
    int isShort _AND_
    char *lenVarName _AND_
    char *bufVarName)
{
    if (isCons)
        fprintf (f, "    %s += BEncConsLen (%s, %s);\n", lenVarName, bufVarName, lenVarName);
    else
    {
        if (isShort)
        {
            fprintf (f, "    BEncDefLenTo127 (%s, %s);\n", bufVarName, lenVarName);
            fprintf (f, "    %s++;\n", lenVarName);
        }
        else
            fprintf (f, "    %s += BEncDefLen (%s, %s);\n", lenVarName, bufVarName, lenVarName);
    }
} /* PrintCxxLenEncodingCode */


/*
 * prints last tag's encoding code first
 */
static void
PrintCxxTagAndLenList PARAMS ((src, t, tagList, lenVarName, bufVarName),
    FILE *src _AND_
    Type *t _AND_
    TagList *tagList _AND_
    char *lenVarName _AND_
    char *bufVarName)
{
    char *classStr;
    char *formStr;
    Tag *tg;
    Tag *last;
    int tagLen;
    int isShort;

    if ((tagList == NULL) || LIST_EMPTY (tagList))
        return;

    /*
     * efficiency hack - use simple length (1 byte)
     * encoded for type (almost) guaranteed to have
     * encoded lengths of 0 <= len <= 127
     */
    isShort = HasShortLen (t);

    /*
     * since encoding backward encode tags backwards
     */
    last = (Tag*)LAST_LIST_ELMT (tagList);
    FOR_EACH_LIST_ELMT_RVS (tg, tagList)
    {
        classStr = Class2ClassStr (tg->tclass);

        if (tg->form == CONS)
        {
            formStr = Form2FormStr (CONS);
            PrintCxxLenEncodingCode (src, TRUE, isShort, lenVarName, bufVarName);
        }
        else /* PRIM or ANY_FORM */
        {
            formStr = Form2FormStr (PRIM);
            PrintCxxLenEncodingCode (src, FALSE, isShort, lenVarName, bufVarName);
        }

/*      GetTags sets the form properly now
        if (IsPrimitiveByDefOrRef (t) && (tg == last))
        {
            formStr = Form2FormStr (PRIM);
            PrintCxxLenEncodingCode (src, FALSE, isShort, lenVarName, bufVarName);
        }
        else
        {
            formStr = Form2FormStr (CONS);
            PrintCxxLenEncodingCode (src, TRUE, isShort, lenVarName, bufVarName);
        }
*/

        fprintf (src, "\n");

        //RWC;tagLen = TagByteLen (tg->code);

        if (tg->tclass == UNIV)
            fprintf (src, "    %s += BEncTag%d (%s, %s, %s, %s);\n", lenVarName, tagLen, bufVarName, classStr, formStr, DetermineCode(tg, &tagLen, 0));
                                                                //RWC;Code2UnivCodeStr (tg->code));
        else
            fprintf (src, "    %s += BEncTag%d (%s, %s, %s, %s);\n", lenVarName, tagLen, bufVarName, classStr, formStr, DetermineCode(tg, &tagLen, 1));
                                                                //RWC;tg->code);
    }

} /* PrintCxxTagAndLenList */


/*
 *  Recursively walks through tags, printing lower lvl tags
 *  first (since encoding is done backwards).
 *
 */
static void
PrintCxxTagAndLenEncodingCode PARAMS ((src, td, t, lenVarName, bufVarName),
    FILE *src _AND_
    TypeDef *td _AND_
    Type *t _AND_
    char *lenVarName _AND_
    char *bufVarName)
{
    TagList *tl;
    int stoleChoiceTags;

    /*
     * get all the tags on this type
     */
    tl = (TagList*) GetTags (t, &stoleChoiceTags);

    /*
     * leave choice elmt tag enc to encoding routine
     */
    if (!stoleChoiceTags)
        PrintCxxTagAndLenList (src, t, tl, lenVarName, bufVarName);

    FreeTags (tl);

    td=td;  /*AVOIDS warning.*/
} /* PrintCxxTagAndLenEncodingCode */


/*
 * used to figure out local variables to declare
 * for decoding tags/len pairs on type t
 */
static int
CxxCountVariableLevels PARAMS ((t),
    Type *t)
{
    if (GetBuiltinType (t) == BASICTYPE_CHOICE)
        return CountTags (t) +1; /* since must decode 1 internal tag type */
    else
        return CountTags (t);
} /* CxxCountVariableLevels */


/*
 * returns true if elmts curr following
 *  onward are all optional ow. false
 */
static int
RestAreTailOptional PARAMS ((e),
    NamedTypeList *e)
{
    NamedType *elmt;
    void *tmp;
    int retVal;

    if (e == NULL)
        return TRUE;

    tmp = (void*)CURR_LIST_NODE (e);
    retVal = TRUE;
    AsnListNext (e);
    FOR_REST_LIST_ELMT (elmt, e)
    {
        if ((!elmt->type->optional) && (elmt->type->defaultVal == NULL))
        {
            retVal = FALSE;
            break;
        }
    }
    SET_CURR_LIST_NODE (e, tmp); /* reset list to orig loc */
    return retVal;
}


/*
 * prints typedef or new class given an ASN.1  type def of a primitive type
 * or typeref.  Uses inheritance to cover re-tagging and named elmts.
 */
static void
PrintCxxSimpleDef PARAMS ((hdr, src, if_IBM_ENC (hdrdb COMMA srcdb COMMA) if_META (m COMMA) r, td),
    FILE *hdr _AND_
    FILE *src _AND_
    if_IBM_ENC (FILE *hdrdb _AND_)
    if_IBM_ENC (FILE *srcdb _AND_)
    if_META (Module *m _AND_)
    CxxRules *r _AND_
    TypeDef *td)
{
    Tag *tag;
    TagList *tags;
    char *formStr;
    char *classStr;
    int tagLen;
    int i;
    CNamedElmt *n;
    int stoleChoiceTags;
    int elmtLevel;
    enum BasicTypeChoiceId typeId;

    fprintf (hdr, "/* ");
    SpecialPrintType (hdr, td, td->type);
    fprintf (hdr, " */\n");

    /* check if has been re-tagged
     *   eg Foo ::= [APPLICATION 2] IMPLICIT REAL
     * or if it has named elmts in which case a new class must
     * be defined
     *  eg Foo ::= INTEGER { one (1), two (2), three (3) }
     */

    if (IsNewType (td->type))
    {
	     int	hasNamedElmts;

        char *ptr="";   /* NOT DLL Exported, or ignored on Unix. */
        if (bVDAGlobalDLLExport) 
            ptr = bVDAGlobalDLLExport;

        fprintf (hdr, "class %s %s: public %s\n", ptr, td->cxxTypeDefInfo->className, td->type->cxxTypeRefInfo->className);
        fprintf (hdr, "{\n");
        fprintf (hdr, "public:\n");

        /*
         * must explicitly call constructors for base class
         */
        PrintDerivedConstructors (hdr, r, td);

        /* do named elmts enum if any */
        /* for types with named elements, inherit from the base
         * class and define and enum eg:
         * Foo ::= INTEGER { one (1), two (2), five (5) }
         *  ->
         * class Foo: public AsnInt
         * {
         * public:
         *		Foo(): AsnInt() {}
         *		Foo (int val): AsnInt (int val) {}
         *    enum { one = 1, two = 2, five = 5 };
         * };
         * or
         * Foo2 ::= [APPLICATION 2] INTEGER
         * -->
         * class Foo: public AsnInt
         * {
         * public:
         *		Foo(): AsnInt() {}
         *		Foo (int val): AsnInt (int val) {}
         *     AsnLen	BEnc { ....... } <-- holds new tag enc/dec
         *     void	BDec { ....... }   <--/
         *     int	BEncPdu { ....... }
         *     int	BDecPdu { ....... }
         * };
         * (must 'inherit' constructors explicitly)
         */

        if ((hasNamedElmts = HasNamedElmts (td->type)) != 0)
        {
            fprintf (hdr, "  enum\n");
            fprintf (hdr, "  {\n");
            FOR_EACH_LIST_ELMT (n, td->type->cxxTypeRefInfo->namedElmts)
            {
                fprintf (hdr, "    %s = %d", n->name, n->value);
                if (n != (CNamedElmt *)LAST_LIST_ELMT (td->type->cxxTypeRefInfo->namedElmts))
                    fprintf (hdr, ",\n");
                else
                    fprintf (hdr, "\n");
            }
            fprintf (hdr, "  };\n");
        }
#if META
	if (printMetaG)
	{
	    const char	*T, *t;
	    int a3;

	    fprintf (hdr, "\n");
	    fprintf (hdr, "#if META\n");
	    fprintf (src, "#if META\n\n");

	    fprintf (src, "static AsnType *create%s()\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  return new %s;\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "}\n\n");

	    if ((hasNamedElmts = HasNamedElmts (td->type)))
	    {
		fprintf (hdr, "  static const AsnNameDesc	_nmdescs[];\n");

		fprintf (src, "const AsnNameDesc %s::_nmdescs[] =\n", td->cxxTypeDefInfo->className);
		fprintf (src, "{\n");
		FOR_EACH_LIST_ELMT (n, td->type->cxxTypeRefInfo->namedElmts)
#if 0 /* (no asn1 names available!) */
		    if (printMetaG == META_backend_names)
		    else /* META_asn1_names */
#endif
			fprintf (src, "  \"%s\", %s, // %d\n", n->name, n->name, n->value);
		fprintf (src, "  NULL, -1\n");
		fprintf (src, "};\n\n");
	    }

	    switch (GetBuiltinType (td->type))
	    {
		case BASICTYPE_BOOLEAN:
		    T = "BOOLEAN";
		    t = "Bool";
		    a3 = FALSE;
		    break;
		case BASICTYPE_ENUMERATED:
		    T = "ENUMERATED";
		    t = "Enum";
		    a3 = TRUE;
		    break;
		case BASICTYPE_INTEGER:
		    T = "INTEGER";
		    t = "Int";
		    a3 = TRUE;
		    break;
		case BASICTYPE_REAL:
		    T = "REAL";
		    t = "Real";
		    a3 = FALSE;
		    break;
		case BASICTYPE_OCTETSTRING:
		    T = "OCTET_STRING";
		    t = "Octs";
		    a3 = FALSE;
		    break;
		case BASICTYPE_BITSTRING:
		    T = "BIT_STRING";
          t = "Bits";
		    a3 = TRUE;
		    break;
		case BASICTYPE_OID:
		    T = "OID";
		    t = "Oid";
		    a3 = FALSE;
	    	default:
		    T =
		    t = "?";
		    a3 = FALSE;
	    }

	    fprintf (hdr, "  static const Asn%sTypeDesc	_desc;\n", t);
	    fprintf (hdr, "  const AsnTypeDesc	*_getdesc() const;\n");

	    fprintf (src, "const Asn%sTypeDesc %s::_desc\n", t, td->cxxTypeDefInfo->className);
	    fprintf (src, "(\n");
	    fprintf (src, "  &%sModuleDesc,\n", m->cxxname);
	    if (printMetaG == META_backend_names)
		fprintf (src, "  \"%s\", // `%s'\n", td->cxxTypeDefInfo->className, td->definedName);
	    else /* META_asn1_names */
		fprintf (src, "  \"%s\", // `%s'\n", td->definedName, td->cxxTypeDefInfo->className);
	    fprintf (src, "  %s,\n", isMetaPDU (m->modId->name, td->definedName, meta_pdus_G) ? "true" : "false");
	    fprintf (src, "  AsnTypeDesc::%s,\n", T);
	    fprintf (src, "  create%s", td->cxxTypeDefInfo->className);
	    if (a3)
		fprintf (src, ",\n  %s", hasNamedElmts ? "_nmdescs" : "NULL");
	    fprintf (src, "\n);\n\n");

	    fprintf (src, "const AsnTypeDesc *%s::_getdesc() const\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  return &_desc;\n");
	    fprintf (src, "}\n\n");

	    fprintf (hdr, "#endif // META\n");
	    fprintf (src, "#endif // META\n\n");

#if TCL
#endif
	}
#endif /* META */

        /*
         * Re-do BerEncode, BerDeocode, BerDecodePdu and BerDecodePdu
         * if this type has been re-tagged
         */
        if ((IsDefinedByLibraryType (td->type) && !HasDefaultTag (td->type))
	  || (IsTypeRef (td->type) && ((td->type->tags != NULL) && !LIST_EMPTY (td->type->tags))))
        {
            /* only BerEn/Decode BerEn/DecodePdu need to be re-done if tags are different */

            /* print clone routine for ANY mgmt */
            PrintCloneMethod (hdr, src, td);

            tags = GetTags (td->type, &stoleChoiceTags);
            typeId = GetBuiltinType (td->type);

            /* do BerEncode function */
            if (printEncodersG)
            {
                fprintf (hdr, "  %s		B%s (%s &b) const;\n", lenTypeNameG, r->encodeBaseName, bufTypeNameG);
                fprintf (src, "%s %s::B%s (%s &b) const\n", lenTypeNameG, td->cxxTypeDefInfo->className, r->encodeBaseName, bufTypeNameG);
                fprintf (src, "{\n");
/*                fprintf (src, "    FUNC(\"%s::B%s\");\n", td->cxxTypeDefInfo->className, r->encodeBaseName); */
                fprintf (src, "    %s l=0;\n", lenTypeNameG);

                /* eSNACC 1.5 does not encode INDEFINITE LENGTH
                 * PrintCxxEocEncoders (src, td, td->type, "b");
                 */

                fprintf (src, "    l = BEncContent (b);\n");

                /* encode each tag/len pair if any */
                if (!stoleChoiceTags)
                {
                    FOR_EACH_LIST_ELMT_RVS (tag, tags)
                    {
                        classStr = Class2ClassStr (tag->tclass);

                        if (tag->form == ANY_FORM)
                        {
                            formStr = Form2FormStr (PRIM);
                            PrintCxxLenEncodingCode (src, FALSE, HasShortLen (td->type), "l", "b");
                        }
                        else
                        {
                            formStr = Form2FormStr (tag->form);
                            PrintCxxLenEncodingCode (src, TRUE, HasShortLen (td->type), "l", "b");
                        }

                        fprintf (src, "\n");
                        //RWC;tagLen = TagByteLen (tag->code);

                        if (tag->tclass == UNIV)
                            fprintf (src, "    l += BEncTag%d (b, %s, %s, %s);\n", tagLen, classStr, formStr, DetermineCode(tag, &tagLen, 0));//RWC;Code2UnivCodeStr (tag->code));
                        else
                            fprintf (src, "    l += BEncTag%d (b, %s, %s, %s);\n", tagLen, classStr, formStr, DetermineCode(tag, &tagLen, 1));//RWC;tag->code);
                    }
                }
                fprintf (src, "    return l;\n");
                fprintf (src, "}\n\n");
            }
            /* end of BEnc function */

            /* Do BDec function */
            if (printDecodersG)
            {
                fprintf (hdr, "  void			B%s (const %s &b, %s &bytesDecoded);\n", r->decodeBaseName, bufTypeNameG, lenTypeNameG);// envTypeNameG);
                fprintf (src, "void %s::B%s (const %s &b, %s &bytesDecoded)\n", td->cxxTypeDefInfo->className, r->decodeBaseName, bufTypeNameG, lenTypeNameG);//, envTypeNameG);
                fprintf (src, "{\n");
                fprintf (src, "    FUNC(\"%s::B%s\");\n", td->cxxTypeDefInfo->className, r->decodeBaseName); 
                fprintf (src, "    %s tag;\n", tagTypeNameG);

                /* print extra locals for redundant lengths */
                for (i = 1; (tags != NULL) && (i <= LIST_COUNT (tags)); i++)
                    fprintf (src, "    %s elmtLen%d;\n", lenTypeNameG, i);
                if (typeId == BASICTYPE_CHOICE)
                    fprintf (src, "    %s elmtLen%d;\n", lenTypeNameG, i++);
                fprintf (src, "\n");

                /*  decode tag/length pair (s) */
                elmtLevel = 0;
                if (!stoleChoiceTags)
                {
                    FOR_EACH_LIST_ELMT (tag, tags)
                    {
                        classStr = Class2ClassStr (tag->tclass);


                        if (tag->form == ANY_FORM)
                            formStr = Form2FormStr (PRIM);
                        else
                            formStr = Form2FormStr (tag->form);

                        fprintf (src, "    if (((tag = BDecTag (b, bytesDecoded)) != ");

                        if (tag->tclass == UNIV)
                        {
                            fprintf (src, "MAKE_TAG_ID (%s, %s, %s))", classStr, formStr, DetermineCode(tag, NULL, 0));//RWC;Code2UnivCodeStr (tag->code));
                            if (tag->form == ANY_FORM)
                                fprintf (src, "\n        && (tag != MAKE_TAG_ID (%s, %s, %s)))\n", classStr, Form2FormStr (CONS), DetermineCode(tag, NULL, 0));//RWC;Code2UnivCodeStr (tag->code));
                            else
                                fprintf (src, ")\n");
                        }
                        else
                        {
                            fprintf (src, "MAKE_TAG_ID (%s, %s, %s))", classStr, formStr, DetermineCode(tag, NULL, 1));//RWC;tag->code);
                            if (tag->form == ANY_FORM)
                                fprintf (src, "\n        && (tag != MAKE_TAG_ID (%s, %s, %s)))\n", classStr, Form2FormStr (CONS), DetermineCode(tag, NULL, 1));//RWC;tag->code);
                            else
                                fprintf (src, ")\n");
                        }

                        fprintf (src, "    {\n");
                        fprintf (src, "        throw InvalidTagException(typeName(), tag, STACK_ENTRY);\n");
                        fprintf (src, "    }\n");
                        fprintf (src, "    elmtLen%d = BDecLen (b, bytesDecoded);\n", ++elmtLevel);
                    }
                }

                /* decode first tag from CHOICE's content */
                if (typeId == BASICTYPE_CHOICE)
                {
                    fprintf (src, "    tag = BDecTag (b, bytesDecoded);\n");
                    fprintf (src, "    elmtLen%d = BDecLen (b, bytesDecoded);\n", ++elmtLevel);
                }

                fprintf (src, "    B%s (b, tag, elmtLen%d, bytesDecoded);\n", r->decodeContentBaseName, i-1);

                /* grab any EOCs that match redundant, indef lengths */
                for (i = elmtLevel-1; i > 0; i--)
                {
                    fprintf (src, "    if (elmtLen%d == INDEFINITE_LEN)\n", i);
                    fprintf (src, "        BDecEoc (b, bytesDecoded);\n");
                }

                fprintf (src, "}\n\n");
            }
            /* end of BDec function */

            FreeTags (tags);
        }
        /* close class def */
        fprintf (hdr, "};\n\n\n");

    }
    else  /* isomorphic with referenced type, so just to a typedef */
    {

#if META
	if (printMetaG)
	{
	    fprintf (hdr, "#if META\n");
	    fprintf (src, "#if META\n\n");

	    fprintf (src, "static AsnType *create%s()\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  return new %s;\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "}\n\n");

	    fprintf (hdr, "struct %s: public %s\n", td->cxxTypeDefInfo->className, td->type->cxxTypeRefInfo->className);
	    fprintf (hdr, "{\n");

	    PrintDerivedConstructors (hdr, r, td);

        PrintCloneMethod (hdr, src, td);

	    fprintf (hdr, "  static const AsnAliasTypeDesc	_desc;\n");
	    fprintf (hdr, "  const AsnTypeDesc	*_getdesc() const;\n");

	    fprintf (src, "const AsnAliasTypeDesc %s::_desc\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "(\n");
	    fprintf (src, "  &%sModuleDesc,\n", m->cxxname);
	    if (printMetaG == META_backend_names)
		fprintf (src, "  \"%s\", // `%s'\n", td->cxxTypeDefInfo->className, td->definedName);
	    else /* META_asn1_names */
		fprintf (src, "  \"%s\", // `%s'\n", td->definedName, td->cxxTypeDefInfo->className);
	    fprintf (src, "  %s,\n", isMetaPDU (m->modId->name, td->definedName, meta_pdus_G) ? "true" : "false");
	    fprintf (src, "  AsnTypeDesc::ALIAS,\n");
	    fprintf (src, "  create%s,\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "  &%s::_desc\n);\n\n", td->type->cxxTypeRefInfo->className);

	    fprintf (src, "const AsnTypeDesc *%s::_getdesc() const\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  return &_desc;\n");
	    fprintf (src, "}\n\n");

	    fprintf (hdr, "};\n\n");

	    fprintf (hdr, "#else // META\n\n");
	    fprintf (src, "#endif // META\n\n");
	}
#endif /* META */

       fprintf (hdr, "typedef %s %s;\n\n", td->type->cxxTypeRefInfo->className, td->cxxTypeDefInfo->className);

#if META
	if (printMetaG)
	    fprintf (hdr, "#endif // META\n\n");
#endif /* META */
    }
} /* PrintCxxSimpleDef */

static void
PrintCxxChoiceDefCode (FILE *src, FILE *hdr, ModuleList *mods, Module *m, CxxRules *r ,
    TypeDef *td,Type *parent, Type *choice, int novolatilefuncs)
{
    NamedType *e;
    char *classStr;
    char *formStr;
    char *codeStr;
    int tagLen, i;
    Tag *tag;
    TagList *tags;
    char *varName;
    CxxTRI *cxxtri;
    int elmtLevel=0;
    int varCount, tmpVarCount;
    int stoleChoiceTags;
    enum BasicTypeChoiceId tmpTypeId;
    NamedType *defByNamedType;
    /* put class spec in hdr file */
    char *ptr="";   /* NOT DLL Exported, or ignored on Unix. */
    if (bVDAGlobalDLLExport != NULL) 
       ptr = bVDAGlobalDLLExport;

    fprintf (hdr, "class %s %s%s\n", ptr, td->cxxTypeDefInfo->className, baseClassesG);
    fprintf (hdr, "{\n");
    fprintf (hdr, "public:\n");

    /* write out choiceId enum type */

    fprintf (hdr, "  enum %s\n", r->choiceIdEnumName);
    fprintf (hdr, "  {\n");
    /* fprintf (hdr, "     NoChoiceCid=-1,\n");
	  */
    FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
    {
        fprintf (hdr, "     %s = %d", e->type->cxxTypeRefInfo->choiceIdSymbol, e->type->cxxTypeRefInfo->choiceIdValue);
        if (e != (NamedType*)LAST_LIST_ELMT (choice->basicType->a.choice))
            fprintf (hdr, ",\n");
        else
            fprintf (hdr, "\n");
    }
    fprintf (hdr, "  };\n\n");

    /* write out the choice Id field */
    /*     fprintf (hdr, "protected:\n"); */
    fprintf (hdr, "  enum %s	%s;\n", r->choiceIdEnumName, r->choiceIdFieldName);

    /* write out the choice element anonymous union */
    fprintf (hdr, "  union\n");
    fprintf (hdr, "  {\n");
    FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
    {
        fprintf (hdr, "     ");
        PrintCxxType (hdr, mods, m, r, td, choice, e->type);
        fprintf (hdr, "%s;\n", e->type->cxxTypeRefInfo->fieldName);
    }
    fprintf (hdr, "  };\n\n");

#if META
    if (printMetaG)
    {
	fprintf (hdr, "#if META\n");
	fprintf (src, "#if META\n\n");

	fprintf (hdr, "  static const AsnChoiceTypeDesc	_desc;\n");
	fprintf (hdr, "  static const AsnChoiceMemberDesc	_mdescs[];\n\n");
	fprintf (hdr, "  const AsnTypeDesc		*_getdesc() const;\n");
	fprintf (hdr, "  AsnType			*_getref (const char *membername, bool create = false);\n\n");

	fprintf (src, "static AsnType *create%s()\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	fprintf (src, "  return new %s;\n", td->cxxTypeDefInfo->className);
	fprintf (src, "}\n\n");

	fprintf (src, "const AsnChoiceMemberDesc %s::_mdescs[] =\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
	    if (printMetaG == META_backend_names)
		fprintf (src, "  AsnChoiceMemberDesc (\"%s\", &%s::_desc), // `%s'\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className, e->fieldName ? e->fieldName : "");
	    else /* META_asn1_names */
		fprintf (src, "  AsnChoiceMemberDesc (\"%s\", &%s::_desc), // `%s'\n", e->fieldName ? e->fieldName : e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className, e->type->cxxTypeRefInfo->fieldName);
	fprintf (src, "  AsnChoiceMemberDesc()\n");
	fprintf (src, "};\n\n");

	fprintf (src, "const AsnChoiceTypeDesc %s::_desc\n", td->cxxTypeDefInfo->className);
	fprintf (src, "(\n");
	fprintf (src, "  &%sModuleDesc,\n", m->cxxname);
	if (printMetaG == META_backend_names)
	    fprintf (src, "  \"%s\", // `%s'\n", td->cxxTypeDefInfo->className, td->definedName);
	else /* META_asn1_names */
	    fprintf (src, "  \"%s\", // `%s'\n", td->definedName, td->cxxTypeDefInfo->className);
	fprintf (src, "  %s,\n", isMetaPDU (m->modId->name, td->definedName, meta_pdus_G) ? "true" : "false");
	fprintf (src, "  AsnTypeDesc::CHOICE,\n");
	fprintf (src, "  create%s,\n", td->cxxTypeDefInfo->className);
	fprintf (src, "  _mdescs\n");
	fprintf (src, ");\n\n");

	fprintf (src, "const AsnTypeDesc *%s::_getdesc() const\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	fprintf (src, "  return &_desc;\n");
	fprintf (src, "}\n\n");

	fprintf (src, "AsnType *%s::_getref (const char *membername, bool create)\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	fprintf (src, "  ChoiceIdEnum newCid = (ChoiceIdEnum)_desc.choicebyname (membername);\n");
	fprintf (src, "  if (newCid == -1)\n");
	fprintf (src, "    return NULL;\n");
	fprintf (src, "  if (newCid == choiceId)\n");
	fprintf (src, "  {\n");
	fprintf (src, "    switch (choiceId)\n");
	fprintf (src, "    {\n");
	FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
	{
	    fprintf (src, "      case %sCid:\n", e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "        return %s;\n", e->type->cxxTypeRefInfo->fieldName);
	}
	fprintf (src, "      default:\n");
	fprintf (src, "        return NULL;\n");
	fprintf (src, "    }\n");
	fprintf (src, "  }\n");
	fprintf (src, "  else\n");
	fprintf (src, "  {\n");
	fprintf (src, "    if (create)\n");
	fprintf (src, "    {\n");
	fprintf (src, "//      switch (choiceId)\n");
	fprintf (src, "//      {\n");
	FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
	{
	    fprintf (src, "//        case %sCid:\n", e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "//          delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "//          %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "//          break;\n");
	}
	fprintf (src, "//        default:\n");
	fprintf (src, "//          return NULL;\n");
	fprintf (src, "//      }\n");
	e = FIRST_LIST_ELMT (choice->basicType->a.choice);
	fprintf (src, "      // simply delete any member, the virtual function table takes care of the rest:\n");
	fprintf (src, "      delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
	fprintf (src, "      %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
	fprintf (src, "      switch (choiceId = newCid)\n");
	fprintf (src, "      {\n");
	FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
	{
	    fprintf (src, "        case %sCid:\n", e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "          return %s = new %s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className);
	}
	fprintf (src, "        default: // internal error!\n");
	fprintf (src, "          return NULL;\n");
	fprintf (src, "      }\n");
	fprintf (src, "    }\n");
	fprintf (src, "    else\n");
	fprintf (src, "      return NULL;\n");
	fprintf (src, "  }\n");
	fprintf (src, "}\n\n");

#if TCL
	if (printTclG)
	{
	    fprintf (hdr, "#if TCL\n");
	    fprintf (src, "#if TCL\n\n");

	    fprintf (hdr, "  int			TclGetDesc (Tcl_DString *) const;\n");
	    fprintf (hdr, "  int			TclGetVal (Tcl_Interp *) const;\n");
	    fprintf (hdr, "  int			TclSetVal (Tcl_Interp *, const char *valstr);\n\n");

	    fprintf (src, "int %s::TclGetDesc (Tcl_DString *valstr) const\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  Tcl_DStringAppendElement (valstr, (char*)_desc.choicebyvalue (choiceId));\n");
	    fprintf (src, "  // hack: since all members are pointers, we don't have to check for its type via choiceId, because all we want to know is whether it's NULL or not:\n");
	    e = FIRST_LIST_ELMT (choice->basicType->a.choice);
	    fprintf (src, "  Tcl_DStringAppendElement (valstr, %s ? \"valid\" : \"void\");\n", e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "  return TCL_OK;\n");
	    fprintf (src, "}\n\n");

	    fprintf (src, "int %s::TclGetVal (Tcl_Interp *interp) const\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  switch (choiceId)\n");
	    fprintf (src, "  {\n");
	    FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
	    {
		fprintf (src, "    case %sCid:\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "      if (%s)\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "        if (%s->TclGetVal (interp) != TCL_OK)\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "          return TCL_ERROR;\n");
		fprintf (src, "      break;\n");
	    }
	    fprintf (src, "    default:\n");
	    fprintf (src, "      Tcl_SetResult (interp, \"illegal choiceId in %s\", TCL_STATIC);\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "      Tcl_SetErrorCode (interp, \"SNACC\", \"ILLCHOICE\", NULL);\n");
	    fprintf (src, "      return TCL_ERROR;\n");
	    fprintf (src, "  }\n");
	    fprintf (src, "  Tcl_DString valstr;\n");
	    fprintf (src, "  Tcl_DStringInit (&valstr);\n");
	    fprintf (src, "  Tcl_DStringAppendElement (&valstr, (char*)_desc.choicebyvalue (choiceId));\n");
	    fprintf (src, "  Tcl_DStringAppendElement (&valstr, interp->result);\n");
	    fprintf (src, "  Tcl_ResetResult (interp);\n");
	    fprintf (src, "  Tcl_DStringResult (interp, &valstr);\n");
	    fprintf (src, "  return TCL_OK;\n");
	    fprintf (src, "}\n\n");

	    fprintf (src, "int %s::TclSetVal (Tcl_Interp *interp, const char *valstr)\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  Args elem;\n");
	    fprintf (src, "  if (Tcl_SplitList (interp, (char*)valstr, &elem.c, &elem.v) != TCL_OK)\n");
	    fprintf (src, "    return TCL_ERROR;\n");
	    fprintf (src, "  if (elem.c != 2)\n");
	    fprintf (src, "  {\n");
	    fprintf (src, "    sprintf (interp->result, \"syntax error: expected a pair, but it's got %%d element(s)\", elem.c);\n");
	    fprintf (src, "    return TCL_ERROR;\n");
	    fprintf (src, "  }\n");
	    fprintf (src, "  AsnType *member = _getref (elem.v[0], true);\n");
	    fprintf (src, "  if (!member)\n");
	    fprintf (src, "  {\n");
	    fprintf (src, "    Tcl_AppendResult (interp, \"illegal choice \", elem.v[0], \" for %s\", NULL);\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "    Tcl_SetErrorCode (interp, \"SNACC\", \"ILLCHOICE\", NULL);\n");
	    fprintf (src, "    return TCL_ERROR;\n");
	    fprintf (src, "  }\n");
	    fprintf (src, "  return member->TclSetVal (interp, elem.v[1]);\n");
	    fprintf (src, "}\n\n");

	    fprintf (hdr, "#endif // TCL\n");
	    fprintf (src, "#endif // TCL\n\n");
	}
#endif /* TCL */

	fprintf (hdr, "#endif // META\n");
	fprintf (src, "#endif // META\n\n");
    }
#endif /* META */

    fprintf (hdr, "\n");

    /* constructors and destructor */

    fprintf (hdr, "   %s() {Init();}\n", td->cxxTypeDefInfo->className);
    /* PIERCE 8-22-2001 */
    PrintCopyConstructor(hdr, src, td->cxxTypeDefInfo->className);
	 PrintSimpleMeta(hdr,td->cxxTypeDefInfo->className,0);

	/* Init() member function
	 */
    fprintf (hdr, "   void Init(void);\n");
    fprintf (src, "void %s::Init(void)\n", td->cxxTypeDefInfo->className);
    fprintf (src, "{\n");
    fprintf (src, "   // initialize choice to no choiceId to first choice and set pointer to NULL\n");
    e = FIRST_LIST_ELMT (choice->basicType->a.choice);
    fprintf (src, "  choiceId = %sCid;\n", e->type->cxxTypeRefInfo->fieldName);
    fprintf (src, "  %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
    fprintf (src, "}\n\n");
    
    /* virutal destructor
	 */
    fprintf (hdr, "   virtual ~%s() {Clear();}\n\n", td->cxxTypeDefInfo->className);

    /* Clear() member
     */
    fprintf (hdr, "   void Clear();\n\n");

    fprintf (src, "void %s::Clear()\n", td->cxxTypeDefInfo->className);
    fprintf (src, "{\n");
    fprintf (src, "  switch (choiceId)\n");
    fprintf (src, "  {\n");

    FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
    {
	    fprintf (src, "    case %s:\n", e->type->cxxTypeRefInfo->choiceIdSymbol);
	    if (e->type->cxxTypeRefInfo->isPtr)
       {
	       fprintf (src, "      delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
          fprintf (src, "      %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
       }
	    fprintf (src, "      break;\n");
    }

    fprintf (src, "  } // end of switch\n");
	 fprintf (src, "} // end of Clear()\n");
    fprintf (src, "\n");

    /* print clone routine for ANY mgmt */
    PrintCloneMethod (hdr, src, td);

    fprintf (hdr, "  %s		&operator = (const %s &that);\n", td->cxxTypeDefInfo->className, td->cxxTypeDefInfo->className);

    fprintf (src, "%s &%s::operator = (const %s &that)\n", td->cxxTypeDefInfo->className, td->cxxTypeDefInfo->className, td->cxxTypeDefInfo->className);
    fprintf (src, "{\n");
    fprintf (src, "  if (this != &that)\n");
    fprintf (src, "  {\n");
    fprintf (src, "    Clear();\n");
    
    e = FIRST_LIST_ELMT (choice->basicType->a.choice);
    fprintf (src, "    // Check first type in choice to determine if choice is empty\n");
    fprintf (src, "    if (that.%s != NULL)\n", e->type->cxxTypeRefInfo->fieldName);
    fprintf (src, "    {\n");
    fprintf (src, "       switch (choiceId = that.choiceId)\n");
    fprintf (src, "       {\n");

    FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
    {
	   fprintf (src, "         case %s:\n", e->type->cxxTypeRefInfo->choiceIdSymbol);
	   if (e->type->cxxTypeRefInfo->isPtr)
	   {
	      fprintf (src, "           %s = new %s(*that.%s);\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className,
            e->type->cxxTypeRefInfo->fieldName);
      }
	   else
	      fprintf (src, "           %s = that.%s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->fieldName);
	   fprintf (src, "           break;\n");
    }

    fprintf (src, "       }// end of switch\n");
    fprintf (src, "     }// end of if\n");
    fprintf (src, "  }\n");
    fprintf (src, "\n");
    fprintf (src, "  return *this;\n");
    fprintf (src, "}\n\n");

    /* BerEncodeContent */
    if (printEncodersG)
    {
        fprintf (hdr, "  %s		B%s (%s &b) const;\n", lenTypeNameG, r->encodeContentBaseName, bufTypeNameG);

        fprintf (src, "%s\n", lenTypeNameG);
        fprintf (src, "%s::B%s (%s &b) const\n", td->cxxTypeDefInfo->className, r->encodeContentBaseName, bufTypeNameG);
        fprintf (src, "{\n");
        fprintf (src, "    FUNC(\"%s::B%s (%s &b)\");\n", td->cxxTypeDefInfo->className, r->encodeContentBaseName, bufTypeNameG);

        /* print local vars */
        fprintf (src, "  %s l=0;\n", lenTypeNameG);

        fprintf (src, "  switch (%s)\n", r->choiceIdFieldName);
        fprintf (src, "  {\n");
        FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
        {
            cxxtri =  e->type->cxxTypeRefInfo;
            fprintf (src, "    case %s:\n", cxxtri->choiceIdSymbol);

            varName = cxxtri->fieldName;

            /* eSNACC 1.5 does not encode indefinite length
             *
             * PrintCxxEocEncoders (src, td, e->type, "b");
             */

            /* encode content */
            tmpTypeId = GetBuiltinType (e->type);
            if (tmpTypeId == BASICTYPE_ANYDEFINEDBY)
            {
               defByNamedType = e->type->basicType->a.anyDefinedBy->link;
               PrintCxxSetTypeByCode(defByNamedType, cxxtri, src);
            }
            else if (tmpTypeId == BASICTYPE_ANY)
            {
                fprintf (src, "    l = %s", varName);
                if (cxxtri->isPtr)
                    fprintf (src, "->");
                else
                    fprintf (src, ".");

                fprintf (src, "B%s (b);\n", r->encodeBaseName);
            }
            else if ( (tmpTypeId == BASICTYPE_OCTETCONTAINING) ||
                      (tmpTypeId == BASICTYPE_BITCONTAINING))
            {
               PrintCxxEncodeContaining(e->type, r, src);
            }
            else
            {
                fprintf (src, "      l = %s", varName);
                if (cxxtri->isPtr)
                    fprintf (src, "->");
                else
                    fprintf (src, ".");

                fprintf (src, "B%s (b);\n", r->encodeContentBaseName);
            }


            /* encode tag (s) & len (s) */
            PrintCxxTagAndLenEncodingCode (src, td, e->type, "l", "b");


            fprintf (src, "      break;\n\n");
        }
        fprintf (src, "      default:\n");
		  fprintf (src, "         throw EXCEPT(\"Choice is empty\", ENCODE_ERROR);\n");
        fprintf (src, "  } // end switch\n");


        fprintf (src, "  return l;\n");
        fprintf (src, "} // %s::B%s\n\n\n", td->cxxTypeDefInfo->className, r->encodeContentBaseName);
    }
    /* end of BerEncodeContent method */

    /* BerDecodeContent */
    if (printDecodersG)
    {
        fprintf (hdr, "  void			B%s (const %s &b, %s tag, %s elmtLen, %s &bytesDecoded/*, s env*/);\n", r->decodeContentBaseName, bufTypeNameG, tagTypeNameG, lenTypeNameG, lenTypeNameG);//, envTypeNameG);

        fprintf (src, "void %s::B%s (const %s &b, %s tag, %s elmtLen0, %s &bytesDecoded/*, s env*/)\n", td->cxxTypeDefInfo->className, r->decodeContentBaseName, bufTypeNameG, tagTypeNameG, lenTypeNameG, lenTypeNameG);//, envTypeNameG);

        fprintf (src, "{\n");
        fprintf (src, "   FUNC(\"%s::B%s()\");\n",td->cxxTypeDefInfo->className, r->decodeContentBaseName); 
        fprintf (src, "   Clear();\n");
        /* print local vars */
        /* count max number of extra length var nec
         * by counting tag/len pairs on components of the CHOICE
         */
        varCount = 0;
        FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
        {
            tmpVarCount = CxxCountVariableLevels (e->type);
            if (tmpVarCount > varCount)
                varCount = tmpVarCount;
        }
        /* write extra length vars - remeber choice content
         * decoders are passed the 'key' tag so need one less
         * than max var count.
         */
        for (i = 1; i < varCount; i++)
            fprintf (src, "  %s elmtLen%d;\n", lenTypeNameG, i);

        /* switch on given tag - choices always have the key tag decoded */
        fprintf (src, "  switch (tag)\n");
        fprintf (src, "  {\n");
        FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
        {
            cxxtri =  e->type->cxxTypeRefInfo;

            tags = GetTags (e->type, &stoleChoiceTags);

            if (LIST_EMPTY (tags))
            {
                fprintf (src, "    // ANY Type?\n");
                fprintf (src, "    case MAKE_TAG_ID (?, ?, ?):\n");
            }
            else
            {
                tag = (Tag*)FIRST_LIST_ELMT (tags);
                classStr = Class2ClassStr (tag->tclass);

                formStr = Form2FormStr (tag->form);

                if (tag->tclass == UNIV)
                    codeStr = DetermineCode(tag, NULL, 0);//RWC;Code2UnivCodeStr (tag->code);
                else
                    codeStr = DetermineCode(tag, NULL, 1);

                if (tag->form == ANY_FORM)
                {
                    fprintf (src, "    case MAKE_TAG_ID (%s, %s, %s):\n", classStr, Form2FormStr (PRIM), codeStr);
                    fprintf (src, "    case MAKE_TAG_ID (%s, %s, %s):\n", classStr, Form2FormStr (CONS), codeStr);
                }
                else
                    fprintf (src, "    case MAKE_TAG_ID (%s, %s, %s):\n", classStr, formStr, codeStr);
                /*RWC;else
                {
                    if (tag->form == ANY_FORM)
                    {
                        fprintf (src, "    case MAKE_TAG_ID (%s, %s, %d):\n", classStr, Form2FormStr (PRIM), tag->code);
                        fprintf (src, "    case MAKE_TAG_ID (%s, %s, %d):\n", classStr, Form2FormStr (CONS), tag->code);
                    }
                    else
                        fprintf (src, "    case MAKE_TAG_ID (%s, %s, %d):\n", classStr, formStr, tag->code);
                }*RWC;*/

                /* now decode extra tags/length pairs */
                AsnListFirst (tags);
                AsnListNext (tags);
                elmtLevel = 0;
                if (stoleChoiceTags)
                {
                    FOR_REST_LIST_ELMT (tag, tags)
                    {
                        classStr = Class2ClassStr (tag->tclass);

                        formStr = Form2FormStr (tag->form);

                        if (tag->tclass == UNIV)
                            codeStr = DetermineCode(tag, NULL, 0);//RWC;Code2UnivCodeStr (tag->code);
                        else
                            codeStr = DetermineCode(tag, NULL, 1);

                        if (tag->form == ANY_FORM)
                        {
                            fprintf (src, "    case MAKE_TAG_ID (%s, %s, %s):\n", classStr, Form2FormStr (PRIM), codeStr);
                            fprintf (src, "    case MAKE_TAG_ID (%s, %s, %s):\n", classStr, Form2FormStr (CONS), codeStr);
                        }
                        else
                            fprintf (src, "    case MAKE_TAG_ID (%s, %s, %s):\n", classStr, formStr, codeStr);
                        /*RWC;else
                        {
                            if (tag->form == ANY_FORM)
                            {
                                fprintf (src, "    case MAKE_TAG_ID (%s, %s, %d):\n", classStr, Form2FormStr (PRIM), tag->code);
                                fprintf (src, "    case MAKE_TAG_ID (%s, %s, %d):\n", classStr, Form2FormStr (CONS), tag->code);
                            }
                            else
                                fprintf (src, "    case MAKE_TAG_ID (%s, %s, %d):\n", classStr, formStr, tag->code);
                        }*/
                    }
                }
                else /* didn't steal nested choice's tags */
                {
                    FOR_REST_LIST_ELMT (tag, tags)
                    {
                        classStr = Class2ClassStr (tag->tclass);
                        codeStr = DetermineCode(tag, NULL, 0);//RWC;Code2UnivCodeStr (tag->code);

                        formStr = Form2FormStr (tag->form);

                        fprintf (src, "      tag = BDecTag (b, bytesDecoded);\n");
                        if (tag->form == ANY_FORM)
                        {
                            if (tag->tclass == UNIV)
                            {
                                fprintf (src, "      if ((tag != MAKE_TAG_ID (%s, %s, %s))\n",  classStr, Form2FormStr (PRIM), codeStr);
                                fprintf (src, "          && (tag != MAKE_TAG_ID (%s, %s, %s)))\n", classStr, Form2FormStr (CONS), codeStr);
                            }
                            else
                            {
                                fprintf (src, "      if ((tag != MAKE_TAG_ID (%s, %s, %s))\n", classStr, Form2FormStr (PRIM), DetermineCode(tag, NULL, 1));//RWC;tag->code);
                                fprintf (src, "          && (tag != MAKE_TAG_ID (%s, %s, %s)))\n", classStr, Form2FormStr (CONS), DetermineCode(tag, NULL, 1));//RWC;tag->code);
                            }

                        }
                        else
                        {
                            if (tag->tclass == UNIV)
                                fprintf (src, "      if (tag != MAKE_TAG_ID (%s, %s, %s))\n", classStr, formStr, codeStr);
                            else
                                fprintf (src, "      if (tag != MAKE_TAG_ID (%s, %s, %s))\n", classStr, formStr, DetermineCode(tag, NULL, 1));//RWC;tag->code);
                        }

                        fprintf (src, "      {\n");
                        
                        fprintf (src, "        throw InvalidTagException(typeName(), tag, STACK_ENTRY);\n");
                        fprintf (src, "      }\n\n");

                        fprintf (src, "      elmtLen%d = BDecLen (b, bytesDecoded);\n", ++elmtLevel);
                    }
                }
            }
            /*
             * if the choices element is another choice &&
             * we didn't steal its tags then we must grab
             * the key tag out of the contained CHOICE
             */
            if (!stoleChoiceTags && (GetBuiltinType (e->type) == BASICTYPE_CHOICE))
            {
                fprintf (src, "      tag = BDecTag (b, bytesDecoded);\n");
                fprintf (src, "      elmtLen%d = BDecLen (b, bytesDecoded);\n", ++elmtLevel);
            }

            varName = cxxtri->fieldName;

            /* set choice id for to this elment */
            fprintf (src, "      %s = %s;\n", r->choiceIdFieldName, cxxtri->choiceIdSymbol);

            /* alloc elmt if nec */
            if (cxxtri->isPtr)
                fprintf (src, "  %s = new %s;\n", varName, cxxtri->className);

            /* decode content */
            tmpTypeId = GetBuiltinType (e->type);
            if (tmpTypeId == BASICTYPE_ANYDEFINEDBY)
            {
                /*
                 * must check for another EOC for ANYs
                 * since the any decode routines decode
                 * their own first tag/len pair
                 */
                elmtLevel++;

                defByNamedType = e->type->basicType->a.anyDefinedBy->link;
                PrintCxxSetTypeByCode(defByNamedType, cxxtri, src);

                fprintf (src, "      %s", varName);
                if (cxxtri->isPtr)
                    fprintf (src, "->");
                else
                    fprintf (src, ".");
                fprintf (src, "B%s (b, bytesDecoded);\n",  r->decodeBaseName);
            }
            else if (tmpTypeId == BASICTYPE_ANY)
            {
                elmtLevel++;
                fprintf (src, "        %s", varName);
                if (cxxtri->isPtr)
                   fprintf (src, "->");
                else
                   fprintf (src, ".");
                fprintf (src, "B%s (b, bytesDecoded);\n",  r->decodeBaseName);
            }
            else if ( (tmpTypeId == BASICTYPE_OCTETCONTAINING) ||
							 (tmpTypeId == BASICTYPE_BITCONTAINING) )
            {
               PrintCxxDecodeContaining(e->type, r, src);
            }
            else
            {
                fprintf (src, "        %s", varName);
                if (cxxtri->isPtr)
                    fprintf (src, "->");
                else
                    fprintf (src, ".");

                fprintf (src, "B%s (b, tag, elmtLen%d, bytesDecoded);\n",  r->decodeContentBaseName, elmtLevel);
            }

            /* decode Eoc (s) */
            for (i = elmtLevel-1; i >= 0; i--)
            {
                fprintf (src, "      if (elmtLen%d == INDEFINITE_LEN)\n", i);
                fprintf (src, "        BDecEoc (b, bytesDecoded);\n");
            }

            fprintf (src, "      break;\n\n");
            FreeTags (tags);
        }

        fprintf (src, "    default:\n");
        fprintf (src, "        throw InvalidTagException(typeName(), tag, STACK_ENTRY);\n");
        fprintf (src, "      break;\n");
        fprintf (src, "  } // end switch\n");
        fprintf (src, "} // %s::B%s\n\n\n", td->cxxTypeDefInfo->className, r->decodeContentBaseName);
    }
    /* end of code for printing BDecodeContent method */

    /* do BEnc function */
    if (printEncodersG)
    {
        fprintf (hdr, "  %s		B%s (%s &b) const;\n", lenTypeNameG, r->encodeBaseName, bufTypeNameG);
        fprintf (src, "%s %s::B%s (%s &b) const\n", lenTypeNameG, td->cxxTypeDefInfo->className, r->encodeBaseName, bufTypeNameG);
        fprintf (src, "{\n");
        fprintf (src, "    %s l=0;\n", lenTypeNameG);
        fprintf (src, "    l = B%s (b);\n", r->encodeContentBaseName);

        /* encode each tag/len pair if any */
        FOR_EACH_LIST_ELMT_RVS (tag, choice->tags)
        {
            classStr = Class2ClassStr (tag->tclass);
            formStr = Form2FormStr (CONS);  /* choices are constructed */
            //RWC;tagLen = TagByteLen (tag->code);

            fprintf (src, "    l += BEncConsLen (b, l);\n");

            if (tag->tclass == UNIV)
                fprintf (src, "    l += BEncTag%d (b, %s, %s, %s);\n", tagLen, classStr, formStr, DetermineCode(tag, &tagLen, 0));//RWC;Code2UnivCodeStr (tag->code));
            else
                fprintf (src, "    l += BEncTag%d (b, %s, %s, %s);\n", tagLen, classStr, formStr, DetermineCode(tag, &tagLen, 1));//RWC;tag->code);
        }
        fprintf (src, "    return l;\n");
        fprintf (src, "}\n\n");
    }
    /* end of BEnc function */

    /* Do BDec function */
    if (printDecodersG)
    {
        fprintf (hdr, "  void			B%s (const %s &b, %s &bytesDecoded);\n", r->decodeBaseName, bufTypeNameG, lenTypeNameG);

        fprintf (src, "void %s::B%s (const %s &b, %s &bytesDecoded)\n", td->cxxTypeDefInfo->className, r->decodeBaseName, bufTypeNameG, lenTypeNameG);//, envTypeNameG);
        fprintf (src, "{\n");

        if (choice->tags->count > 0)
           fprintf (src, "    FUNC(\"%s::B%s\")\n", td->cxxTypeDefInfo->className, r->decodeBaseName);

        fprintf (src, "    %s elmtLen;\n", lenTypeNameG);
        fprintf (src, "    %s tag;\n", tagTypeNameG);

        /* print extra locals for redundant lengths */
        for (i = 1; (choice->tags != NULL) && (i <= LIST_COUNT (choice->tags)); i++)
        {
            fprintf (src, "    %s extraLen%d;\n", lenTypeNameG, i);
        }
        fprintf (src, "\n");

        /*  decode tag/length pair (s) */
        elmtLevel = 0;
        FOR_EACH_LIST_ELMT (tag, choice->tags)
        {
            classStr = Class2ClassStr (tag->tclass);
            formStr = Form2FormStr (CONS);  /* choices are constructed */
            fprintf (src,"   AsnTag tagId = BDecTag (b, bytesDecoded);\n");
            fprintf (src, "    if (tagId != ");
            if (tag->tclass == UNIV)
                fprintf (src, "MAKE_TAG_ID (%s, %s, %s))", classStr, formStr, DetermineCode(tag, NULL, 0));//RWC;Code2UnivCodeStr (tag->code));
            else
                fprintf (src, "MAKE_TAG_ID (%s, %s, %s))", classStr, formStr, DetermineCode(tag, NULL, 1));//RWC;tag->code);
            fprintf (src, "    {\n");
            
            fprintf (src, "          throw InvalidTagException(typeName(), tagId, STACK_ENTRY);\n");
            
            /* fprintf (src, "          ASN_THROW(%d, \"%s::B%s: ERROR - wrong tag\", NULL);\n", 
                longJmpValG--, td->cxxTypeDefInfo->className, r->decodeBaseName);
            */
              fprintf (src, "    }\n");
            fprintf (src, "    extraLen%d = BDecLen (b, bytesDecoded);\n", ++elmtLevel);
        }

        /* decode identifying tag from choice body */
        fprintf (src, "    /*  CHOICEs are a special case - grab identifying tag */\n");
        fprintf (src, "    /*  this allows easier handling of nested CHOICEs */\n");
        fprintf (src, "    tag = BDecTag (b, bytesDecoded);\n");
        fprintf (src, "    elmtLen = BDecLen (b, bytesDecoded);\n");
        fprintf (src, "    B%s (b, tag, elmtLen, bytesDecoded);\n", r->decodeContentBaseName);

        /* grab any EOCs that match redundant, indef lengths */
        for (i = elmtLevel; i > 0; i--)
        {
            fprintf (src, "    if (extraLen%d == INDEFINITE_LEN)\n", i);
            fprintf (src, "        BDecEoc (b, bytesDecoded);\n");
        }

        fprintf (src, "}\n\n");
    }
    /* end of BDec function */

    /* ostream printing routine */
    if (printPrintersG)
    {
        fprintf (hdr, "  void			Print (std::ostream &os) const;\n");

        fprintf (src, "void %s::Print (std::ostream &os) const\n", td->cxxTypeDefInfo->className);
        fprintf (src, "{\n");
        /*    fprintf (src, "  os << \"{\" << endl;\n") */
        fprintf (src, "  threadLock();\n");
        fprintf (src, "  switch (choiceId)\n");
        fprintf (src, "  {\n");
        FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
        {
            fprintf (src, "    case %s:\n", e->type->cxxTypeRefInfo->choiceIdSymbol);

            /* value notation so print the choice elmts field name */
            if (e->fieldName != NULL)
                fprintf (src, "      os << \"%s \";\n", e->fieldName);

            if (e->type->cxxTypeRefInfo->isPtr)
	    {
                fprintf (src, "      if (%s)\n", e->type->cxxTypeRefInfo->fieldName);
                fprintf (src, "        os << *%s;\n", e->type->cxxTypeRefInfo->fieldName);
                fprintf (src, "      else\n");
                fprintf (src, "        os << \"-- void3 --\\n\";\n");
	    }
            else
                fprintf (src, "      os << %s;\n", e->type->cxxTypeRefInfo->fieldName);

            fprintf (src, "      break;\n\n");
        }
        fprintf (src, "  } // end of switch\n");

        /*    fprintf (src, "  os << \"}\" << endl;\n") */
        fprintf (src, "  threadUnlock();\n");
        fprintf (src, "} // %s::Print\n\n", td->cxxTypeDefInfo->className);
        /* ################################################################## */
         
        /* RWC;1/12/00; ADDED XML output capability. */
        fprintf (hdr, "  void			PrintXML (std::ostream &os, const char *lpszTitle=NULL) const;\n");

        fprintf (src, "void %s::PrintXML (std::ostream &os, const char *lpszTitle) const\n", td->cxxTypeDefInfo->className);
        fprintf (src, "{\n");
        /*    fprintf (src, "  os << \"{\" << endl;\n") */
        //RWC;OLD;fprintf (src, "  os << \"<%s-CHOICE>\";\n", td->cxxTypeDefInfo->className);
        fprintf (src, "  if (lpszTitle)\n");
        fprintf (src, "  {\n");
        fprintf (src, "     os << \"<\" << lpszTitle;\n");
        //RWC;fprintf (src, "     if (typeName() && strlen(typeName()))\n");
        //RWC;fprintf (src, "     {\n");
        fprintf (src, "        os << \" typeName=\\\"%s\\\" type=\\\"CHOICE\\\">\";\n", td->cxxTypeDefInfo->className);
        //RWC;fprintf (src, "     }\n");
        fprintf (src, "  }\n");
        fprintf (src, "  else\n");
        fprintf (src, "        os << \"<%s type=\\\"CHOICE\\\">\";\n", td->cxxTypeDefInfo->className);
        //RWC;fprintf (src, "  os << \"-\" << std::endl;\n");
        fprintf (src, "  switch (choiceId)\n");
        fprintf (src, "  {\n");
        FOR_EACH_LIST_ELMT (e, choice->basicType->a.choice)
        {
            fprintf (src, "    case %s:\n", e->type->cxxTypeRefInfo->choiceIdSymbol);

            /* value notation so print the choice elmts field name */
            /* if (e->fieldName != NULL)
                fprintf (src, "      os << \"%s \";\n", e->fieldName); */

            if (e->type->cxxTypeRefInfo->isPtr)
            {
                fprintf (src, "      if (%s)\n", e->type->cxxTypeRefInfo->fieldName);
                fprintf (src, "        %s->PrintXML(os", e->type->cxxTypeRefInfo->fieldName);
                if (e->fieldName != NULL)
                   fprintf (src, ",\"%s\");\n", e->fieldName);
                else
                   fprintf (src, ");\n");
                fprintf (src, "      else\n");
                fprintf (src, "      {\n");

                if (e->fieldName != NULL)
                {
                    fprintf (src, "        os << \"<%s -- void3 -- /%s>\" << std::endl;\n", e->fieldName, e->fieldName);
                    //RWC;fprintf (src, "        os << \"-- void3 --</%s>\" << std::endl;\n", e->fieldName);
                }
                else
                {
                    fprintf (src, "        os << \"<%s -- void3 -- /%s>\" << std::endl;\n", 
                             e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->fieldName);
                    //RWC;fprintf (src, "        os << \"-- void3 --</%s>\" << std::endl;\n", e->type->cxxTypeRefInfo->fieldName);
                }
                
                fprintf (src, "      }\n");
            }
            else
                fprintf (src, "      %s.PrintXML(os, \"%s\");\n", e->type->cxxTypeRefInfo->fieldName, e->fieldName);

            fprintf (src, "      break;\n\n");
        }
        fprintf (src, "  } // end of switch\n");
        fprintf (src, "  if (lpszTitle)\n");
        fprintf (src, "     os << \"</\" << lpszTitle << \">\";\n");
        fprintf (src, "  else\n");
        fprintf (src, "        os << \"</%s>\";\n", td->cxxTypeDefInfo->className);
        //RWC;fprintf (src, "  os << \"</%s-CHOICE>\" << std::endl;\n", td->cxxTypeDefInfo->className);

        /*    fprintf (src, "  os << \"}\" << endl;\n") */
        fprintf (src, "} // %s::PrintXML\n\n", td->cxxTypeDefInfo->className);
        /* END XML Print capability. */
        /* ################################################################## */
    }
    /* end of Print Method code */

    /* close class definition */
    fprintf (hdr, "};\n\n\n");
	novolatilefuncs = novolatilefuncs;

    parent=parent;  /*AVOIDS warning.*/
} /* PrintCxxChoiceDefCode */



static void
PrintCxxSeqDefCode (FILE *src, FILE *hdr, ModuleList *mods, Module *m,
    CxxRules *r ,TypeDef *td, Type *parent, Type *seq, int novolatilefuncs)
{
    NamedType *e;
    char *classStr;
    char *formStr;
    char *codeStr;
    int tagLen, i=0;
    Tag *tag;
    TagList *tags;
    char *varName;
    CxxTRI *cxxtri=NULL;
    int elmtLevel=0;
    int varCount, tmpVarCount;
    int stoleChoiceTags;
    int inTailOptElmts;
    enum BasicTypeChoiceId tmpTypeId;
    NamedType *defByNamedType;
    NamedType *tmpElmt;
    int allOpt;

    /* put class spec in hdr file */
    char *ptr="";   /* NOT DLL Exported, or ignored on Unix. */
    if (bVDAGlobalDLLExport != NULL) 
       ptr = bVDAGlobalDLLExport;

    fprintf (hdr, "class %s %s%s\n", ptr, td->cxxTypeDefInfo->className, baseClassesG);
    fprintf (hdr, "{\n");
    fprintf (hdr, "public:\n");

    /* write out the sequence elmts */
    FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
    {
        fprintf (hdr, "  ");
        PrintCxxType (hdr, mods, m, r, td, seq, e->type);
        fprintf (hdr, "%s;\n", e->type->cxxTypeRefInfo->fieldName);
    }

    fprintf (hdr, "\n");

#if META
    if (printMetaG)
    {
	fprintf (hdr, "#if META\n");
	fprintf (src, "#if META\n\n");

	fprintf (hdr, "  static const AsnSequenceTypeDesc	_desc;\n");
	fprintf (hdr, "  static const AsnSequenceMemberDesc	_mdescs[];\n");
	fprintf (hdr, "  const AsnTypeDesc		*_getdesc() const;\n");
	fprintf (hdr, "  AsnType			*_getref (const char *membername, bool create = false);\n\n");

	fprintf (src, "static AsnType *create%s()\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	fprintf (src, "  return new %s;\n", td->cxxTypeDefInfo->className);
	fprintf (src, "}\n\n");

	fprintf (src, "const AsnSequenceMemberDesc %s::_mdescs[] =\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
	    if (printMetaG == META_backend_names)
		fprintf (src, "  AsnSequenceMemberDesc (\"%s\", &%s::_desc, %s), // `%s'\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className, e->type->optional || e->type->defaultVal ? "true" : "false", e->fieldName ? e->fieldName : "");
	    else /* META_asn1_names */
		fprintf (src, "  AsnSequenceMemberDesc (\"%s\", &%s::_desc, %s), // `%s'\n", e->fieldName ? e->fieldName : e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className, e->type->optional || e->type->defaultVal ? "true" : "false", e->type->cxxTypeRefInfo->fieldName);
	fprintf (src, "  AsnSequenceMemberDesc()\n");
	fprintf (src, "};\n\n");

	fprintf (src, "const AsnSequenceTypeDesc %s::_desc\n", td->cxxTypeDefInfo->className);
	fprintf (src, "(\n");
	fprintf (src, "  &%sModuleDesc,\n", m->cxxname);
	if (printMetaG == META_backend_names)
	    fprintf (src, "  \"%s\", // `%s'\n", td->cxxTypeDefInfo->className, td->definedName);
	else /* META_asn1_names */
	    fprintf (src, "  \"%s\", // `%s'\n", td->definedName, td->cxxTypeDefInfo->className);
	fprintf (src, "  %s,\n", isMetaPDU (m->modId->name, td->definedName, meta_pdus_G) ? "true" : "false");
	fprintf (src, "  AsnTypeDesc::SEQUENCE,\n");
	fprintf (src, "  create%s,\n", td->cxxTypeDefInfo->className);
	fprintf (src, "  _mdescs\n");
	fprintf (src, ");\n\n");

	fprintf (src, "const AsnTypeDesc *%s::_getdesc() const\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	fprintf (src, "  return &_desc;\n");
	fprintf (src, "}\n\n");

	fprintf (src, "AsnType *%s::_getref (const char *membername, bool create)\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
	{
	    fprintf (src, "  if (!strcmp (membername, \"%s\"))\n", e->type->cxxTypeRefInfo->fieldName);
	    if (e->type->cxxTypeRefInfo->isPtr)
	    {
		fprintf (src, "  {\n");
		fprintf (src, "    if (!%s && create)\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "      %s = new %s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className);
		fprintf (src, "    return %s;\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "  }\n");
	    }
	    else
		fprintf (src, "    return &%s;\n", e->type->cxxTypeRefInfo->fieldName);
	}
	fprintf (src, "  return NULL;\n");
	fprintf (src, "}\n\n");

#if TCL
	if (printTclG)
	{
	    fprintf (hdr, "#if TCL\n");
	    fprintf (src, "#if TCL\n\n");

	    fprintf (hdr, "  int			TclGetDesc (Tcl_DString *) const;\n");
	    fprintf (hdr, "  int			TclGetVal (Tcl_Interp *) const;\n");
	    fprintf (hdr, "  int			TclSetVal (Tcl_Interp *, const char *valstr);\n");
	    fprintf (hdr, "  int			TclUnsetVal (Tcl_Interp *, const char *membname);\n\n");

	    fprintf (src, "int %s::TclGetDesc (Tcl_DString *valstr) const\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  Tcl_DStringStartSublist (valstr);\n\n");
	    FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
	    {
		fprintf (src, "  Tcl_DStringStartSublist (valstr);\n");
		fprintf (src, "  Tcl_DStringAppendElement (valstr, \"%s\");\n", e->type->cxxTypeRefInfo->fieldName);
		if (e->type->cxxTypeRefInfo->isPtr)
		    fprintf (src, "  Tcl_DStringAppendElement (valstr, %s ? \"valid\" : \"void\");\n", e->type->cxxTypeRefInfo->fieldName);
		else
		    fprintf (src, "  Tcl_DStringAppendElement (valstr, %s \"valid\");\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "  Tcl_DStringEndSublist (valstr);\n\n");
	    }
	    fprintf (src, "  Tcl_DStringEndSublist (valstr);\n\n");
	    fprintf (src, "  return TCL_OK;\n");
	    fprintf (src, "}\n\n");

	    fprintf (src, "int %s::TclGetVal (Tcl_Interp *interp) const\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  Tcl_DString valstr;\n\n");
	    fprintf (src, "  Tcl_DStringInit (&valstr);\n\n");
	    FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
	    {
		if (e->type->cxxTypeRefInfo->isPtr)
		{
		    fprintf (src, "  if (%s)\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "  {\n");
		    fprintf (src, "    Tcl_DStringStartSublist (&valstr);\n");
		    fprintf (src, "    Tcl_DStringAppendElement (&valstr, \"%s\");\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "    if (%s->TclGetVal (interp) != TCL_OK)\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "      goto Error;\n");
		    fprintf (src, "    Tcl_DStringAppendElement (&valstr, interp->result);\n");
		    fprintf (src, "    Tcl_ResetResult (interp);\n");
		    fprintf (src, "    Tcl_DStringEndSublist (&valstr);\n");
		    fprintf (src, "  }\n\n");
		}
		else
		{
		    fprintf (src, "  Tcl_DStringStartSublist (&valstr);\n");
		    fprintf (src, "  Tcl_DStringAppendElement (&valstr, \"%s\");\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "  if (%s.TclGetVal (interp) != TCL_OK)\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "    goto Error;\n");
		    fprintf (src, "  Tcl_DStringAppendElement (&valstr, interp->result);\n");
		    fprintf (src, "  Tcl_ResetResult (interp);\n");
		    fprintf (src, "  Tcl_DStringEndSublist (&valstr);\n\n");
		}
	    }
	    fprintf (src, "  Tcl_DStringResult (interp, &valstr);\n");
	    fprintf (src, "  return TCL_OK;\n\n");
	    fprintf (src, "Error:\n");
	    fprintf (src, "  Tcl_DStringFree (&valstr);\n");
	    fprintf (src, "  return TCL_ERROR;\n");
	    fprintf (src, "}\n\n");

	    fprintf (src, "int %s::TclSetVal (Tcl_Interp *interp, const char *valstr)\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  int i;\n");
	    fprintf (src, "  Args elems;\n");
	    fprintf (src, "  if (Tcl_SplitList (interp, (char*)valstr, &elems.c, &elems.v) != TCL_OK)\n");
	    fprintf (src, "    return TCL_ERROR;\n");
	    fprintf (src, "  Args* elempairs = new Args[elems.c];\n");
	    fprintf (src, "  for (i=0; i<elems.c; i++)\n");
	    fprintf (src, "  {\n");
	    fprintf (src, "    if (Tcl_SplitList (interp, elems.v[i], &elempairs[i].c, &elempairs[i].v) != TCL_OK)\n");
	    fprintf (src, "    {\n");
	    fprintf (src, "      delete elempairs;\n");
	    fprintf (src, "      return TCL_ERROR;\n");
	    fprintf (src, "    }\n");
	    fprintf (src, "    if (elempairs[i].c != 2)\n");
	    fprintf (src, "    {\n");
	    fprintf (src, "      sprintf (interp->result, \"syntax error in element #%%d: expected a pair, but it's got %%d element(s)\", i, elempairs[i].c);\n");
	    fprintf (src, "      delete elempairs;\n");
	    fprintf (src, "      return TCL_ERROR;\n");
	    fprintf (src, "    }\n");
	    fprintf (src, "  }\n");
	    fprintf (src, "\n");
	    fprintf (src, "  for (const AsnSequenceMemberDesc *m=_mdescs; m->name; m++)\n");
	    fprintf (src, "  {\n");
	    fprintf (src, "    int count = 0;\n");
	    fprintf (src, "    for (i=0; i<elems.c; i++)\n");
	    fprintf (src, "      if (!strcmp (elempairs[i].v[0], m->name))\n");
	    fprintf (src, "        count++;\n");
	    fprintf (src, "    if (count > 1)\n");
	    fprintf (src, "    {\n");
	    fprintf (src, "      sprintf (interp->result, \"duplicate value for member \\\"%%s\\\" in list\", m->name);\n");
	    fprintf (src, "      Tcl_SetErrorCode (interp, \"SNACC\", \"DUPMEMB\", NULL);\n");
	    fprintf (src, "      delete elempairs;\n");
	    fprintf (src, "      return TCL_ERROR;\n");
	    fprintf (src, "    }\n");
	    fprintf (src, "    if (!m->optional && count < 1)\n");
	    fprintf (src, "    {\n");
	    fprintf (src, "      sprintf (interp->result, \"mandatory member \\\"%%s\\\" is missing in list\", m->name);\n");
	    fprintf (src, "      Tcl_SetErrorCode (interp, \"SNACC\", \"MISSMAND\", NULL);\n");
	    fprintf (src, "      delete elempairs;\n");
	    fprintf (src, "      return TCL_ERROR;\n");
	    fprintf (src, "    }\n");
	    fprintf (src, "    \n");
	    fprintf (src, "  }\n");
	    fprintf (src, "\n");
	    fprintf (src, "  for (i=0; i<elems.c; i++)\n");
	    fprintf (src, "  {\n");
	    FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
	    {
		fprintf (src, "    if (!strcmp (elempairs[i].v[0], \"%s\"))\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "    {\n");
		if (e->type->cxxTypeRefInfo->isPtr)
		{
		    fprintf (src, "      if (!%s)\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "        %s = new %s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className);
		    fprintf (src, "      if (%s->TclSetVal (interp, elempairs[i].v[1]))\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "      {\n");
		    fprintf (src, "        delete elempairs;\n");
		    fprintf (src, "        return TCL_ERROR;\n");
		    fprintf (src, "      }\n");
		}
		else
		{
		    fprintf (src, "      if (%s.TclSetVal (interp, elempairs[i].v[1]))\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "      {\n");
		    fprintf (src, "        delete elempairs;\n");
		    fprintf (src, "        return TCL_ERROR;\n");
		    fprintf (src, "      }\n");
		}
		fprintf (src, "    }\n");
	    }
	    fprintf (src, "  }\n");
	    fprintf (src, "\n");
	    fprintf (src, "  // look for unmentioned optional members and delete them:\n");
	    FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
	    {
		if (e->type->optional || e->type->defaultVal)
		{
		    fprintf (src, "  {\n");
		    fprintf (src, "    bool present = false;\n");
		    fprintf (src, "    for (i=0; i<elems.c; i++)\n");
		    fprintf (src, "      if (!strcmp (elempairs[i].v[0], \"%s\"))\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "        present = true;\n");
		    fprintf (src, "    if (!present)\n");
		    fprintf (src, "    {\n");
		    fprintf (src, "      delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "      %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "    }\n");
		    fprintf (src, "  }\n");
		}
	    }
	    fprintf (src, "\n");
	    fprintf (src, "  delete elempairs;\n");
	    fprintf (src, "  return TCL_OK;\n");
	    fprintf (src, "}\n\n");

	    fprintf (src, "int %s::TclUnsetVal (Tcl_Interp *interp, const char *membernames)\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  Args elems;\n");
	    fprintf (src, "  if (Tcl_SplitList (interp, (char*)membernames, &elems.c, &elems.v) != TCL_OK)\n");
	    fprintf (src, "    return TCL_ERROR;\n");
	    fprintf (src, "\n");
	    fprintf (src, "  for (int i=0; i<elems.c; i++)\n");
	    fprintf (src, "  {\n");
	    FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
	    {
		fprintf (src, "    if (!strcmp (elems.v[i], \"%s\"))\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "    {\n");
		if (e->type->optional || e->type->defaultVal)
		{
		    fprintf (src, "        delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "        %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
		}
		else
		{
		    fprintf (src, "        return _desc.mandatmemberr (interp, elems.v[i]);\n");
		}
		fprintf (src, "    }\n");
	    }
	    fprintf (src, "  }\n");
	    fprintf (src, "  return TCL_OK;\n");
	    fprintf (src, "}\n\n");

	    fprintf (hdr, "#endif // TCL\n");
	    fprintf (src, "#endif // TCL\n\n");
	}
#endif /* TCL */

	fprintf (hdr, "#endif // META\n\n");
	fprintf (src, "#endif // META\n\n");
    }
#endif /* META */

    /* constructors and destructor: */

	/* Default constructor
	 */
    fprintf (hdr, "   %s() {Init();}\n", td->cxxTypeDefInfo->className);

	/* Init() member function 
	 */
    fprintf (hdr, "   void Init(void);\n");
    fprintf (src, "void %s::Init(void)\n", td->cxxTypeDefInfo->className);
    fprintf (src, "{\n");
    FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
    {
	   if ((e->type->cxxTypeRefInfo->isPtr))
	   {

#if TCL
		   fprintf (src, "#if TCL\n");
		   fprintf (src, "  %s = new %s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className);
		   fprintf (src, "#else\n");
		   fprintf (src, "  %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
		   fprintf (src, "#endif // TCL\n");
#else
   
       /* Default member initialization is a work in progress for eSNACC 1.6
        */
#ifdef _R1_6_DEF_MEMBER_INIT

         /* initialize default members to their default values */
         
         if (e->type->defaultVal != NULL)
         {
            Value *defVal = GetValue(e->type->defaultVal->value);
           
            /* HANDLE DEFAULT VALUE DECODING FOR DER by initializing the respective members to their default
             * values.
             */
             switch(ParanoidGetBuiltinType(e->type))
             {
                case BASICTYPE_INTEGER:
                case BASICTYPE_ENUMERATED:
                     fprintf(src," %s = new %s(%d);\n", 
                        e->type->cxxTypeRefInfo->fieldName, 
                        e->type->cxxTypeRefInfo->className,
                        defVal->basicValue->a.integer);
                     break;
                case BASICTYPE_BOOLEAN:
                     fprintf(src," %s = new %s(%s);\n", 
                        e->type->cxxTypeRefInfo->fieldName, 
                        e->type->cxxTypeRefInfo->className,
                        defVal->basicValue->a.boolean == 0 ? "false": "true");
                     break;
                case BASICTYPE_BITSTRING:
                {
                   NamedNumberList *pNNL = GetNamedElmts(e->type);
                   BasicValue *pBV;
                   pBV = GetLastNamedNumberValue(pNNL);

                   if (defVal->basicValue->choiceId == BASICVALUE_VALUENOTATION &&
                       pBV != NULL)
                   {
                      char *defBitStr;
                      normalizeValue(&defBitStr, defVal->basicValue->a.valueNotation->octs);

                      fprintf(src," %s = new %s(%d);\n", 
                        e->type->cxxTypeRefInfo->fieldName, 
                        e->type->cxxTypeRefInfo->className,
                       pBV->a.integer);

                      fprintf(src, " %s->SetBit(%s::%s);\n",
                        e->type->cxxTypeRefInfo->fieldName,
                        e->type->cxxTypeRefInfo->className,
                        defBitStr);

                      free(defBitStr);
                   }
                   else
                      printf("\nWARNING: unsupported use of default BIT STRING\n");
               }
               break;
             } /* end switch */
         }
         else
         {
            fprintf (src, "  %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
         }
        /* end of default member initialization */

#else /* _R2_3_DEF_MEMBER_INIT */

         fprintf (src, "  %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
#endif

    
#endif /* TCL */
	   }
    }
    fprintf (src, "}\n\n");

	/* virtual destructor
	*/
    fprintf (hdr, "   virtual ~%s() {Clear();}\n", td->cxxTypeDefInfo->className);
    /* Clear() member
     */
    fprintf (hdr, "   void Clear();\n");

    fprintf (src, "void %s::Clear()\n", td->cxxTypeDefInfo->className);
    fprintf (src, "{\n");
    FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
	 if (e->type->cxxTypeRefInfo->isPtr)
    {
	    fprintf (src, "  delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
    }
    fprintf (src, " Init();\n");
    fprintf (src, "}\n\n");

    /* PIERCE 8-22-2001 */
    PrintCopyConstructor(hdr, src, td->cxxTypeDefInfo->className);
    PrintSimpleMeta(hdr, td->cxxTypeDefInfo->className,0);

    /* print clone routine for ANY mgmt */
    PrintCloneMethod (hdr, src, td);
    
    /* print operator = overload */
    fprintf (hdr, "  %s		&operator = (const %s &that);\n", td->cxxTypeDefInfo->className, td->cxxTypeDefInfo->className);
    fprintf (src, "%s &%s::operator = (const %s &that)\n", td->cxxTypeDefInfo->className, td->cxxTypeDefInfo->className, td->cxxTypeDefInfo->className);
    fprintf (src, "{\n");
    fprintf (src, "  if (this != &that)\n");
    fprintf (src, "  {\n");
    fprintf (src, "    Clear();\n");
    FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
    {
	    if (e->type->cxxTypeRefInfo->isPtr)
       {
	    fprintf (src, "    if (that.%s)\n", e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "    {\n");
	    fprintf (src, "      if (!%s)\n", e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "        %s = new %s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className);
	    fprintf (src, "      *%s = *that.%s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "    }\n");
	    fprintf (src, "    else\n");
	    fprintf (src, "    {\n");
	    fprintf (src, "      delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "      %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
	    fprintf (src, "    }\n");
       }
	    else
       {
	       fprintf (src, "    %s = that.%s;\n", e->type->cxxTypeRefInfo->fieldName, 
             e->type->cxxTypeRefInfo->fieldName);
       }
    }
    fprintf (src, "  }\n");
    fprintf (src, "\n");
    fprintf (src, "  return *this;\n");
    fprintf (src, "}\n\n");

    /* BerEncodeContent method */
    if (printEncodersG)
    {
        fprintf (hdr, "  %s		B%s (%s &b) const;\n", lenTypeNameG, r->encodeContentBaseName, bufTypeNameG);

        fprintf (src, "%s\n", lenTypeNameG);
        fprintf (src, "%s::B%s (%s &b) const\n", td->cxxTypeDefInfo->className, r->encodeContentBaseName, bufTypeNameG);

        fprintf (src, "{\n");

        /* print local vars */
        fprintf (src, "  %s totalLen = 0;\n", lenTypeNameG);
        fprintf (src, "  %s l=0;\n\n", lenTypeNameG);

        FOR_EACH_LIST_ELMT_RVS (e, seq->basicType->a.sequence)
        {
            cxxtri =  e->type->cxxTypeRefInfo;

            varName = cxxtri->fieldName;

            /* print optional test if nec */
            if (e->type->defaultVal != NULL)
            {
               Value *defVal = GetValue(e->type->defaultVal->value);
               /** PIERCE added DER DEFAULT encoding rules 8-16-2000 
                **/

               /* HANDLE DEFAULT VALUE ENCODING FOR DER
                */
               switch(ParanoidGetBuiltinType(e->type))
               {
                  case BASICTYPE_INTEGER:
                  case BASICTYPE_ENUMERATED:
                     fprintf(src,"  if ( %s(%s) && *%s != %d )\n  {\n", 
                        cxxtri->optTestRoutineName,
                        varName, varName, defVal->basicValue->a.integer);
                     break;
                  case BASICTYPE_BITSTRING:
                     {
                        if (defVal->basicValue->choiceId == BASICVALUE_VALUENOTATION)
                        {
                           char *defBitStr;
                           normalizeValue(&defBitStr, defVal->basicValue->a.valueNotation->octs);
                           fprintf(src,"  if ( %s(%s) && (! %s->soloBitCheck(%s::%s)) ) \n  {\n",
                               cxxtri->optTestRoutineName, varName, varName, cxxtri->className, defBitStr);
                           free(defBitStr);
                        }
                        else
                           printf("\nWARNING: unsupported use of default BIT STRING\n");
                     }
                     break;
                  case BASICTYPE_BOOLEAN:
                     fprintf(src,"  if ( %s(%s) && *%s != %s )\n  {\n", 
                        cxxtri->optTestRoutineName, varName, varName, defVal->basicValue->a.boolean ? "true" : "false");
                     break;
					   default:
							/* TBD print error? */
							break;
               }
            }
            else if (e->type->optional)            
	         {
                fprintf (src, "  if (%s (%s))\n", cxxtri->optTestRoutineName, varName);
                fprintf (src, "  {\n");
	         }
            

            /* eSNACC 1.5 does not encode indefinite length
             *
             * PrintCxxEocEncoders (src, td, e->type, "b");
             */

            /* encode content */
            tmpTypeId = GetBuiltinType (e->type);
            if (tmpTypeId == BASICTYPE_ANYDEFINEDBY)
            {

                defByNamedType = e->type->basicType->a.anyDefinedBy->link;
               
                PrintCxxSetTypeByCode(defByNamedType, cxxtri, src);

                fprintf (src, "    l = %s", varName);
                if (cxxtri->isPtr)
                    fprintf (src, "->");
                else
                    fprintf (src, ".");
                fprintf (src, "B%s (b);\n", r->encodeBaseName);
            }
            else if (tmpTypeId == BASICTYPE_ANY)
            {
                fprintf (src, "    l = %s", varName);
                if (cxxtri->isPtr)
                    fprintf (src, "->");
                else
                    fprintf (src, ".");

                fprintf (src, "B%s (b);\n", r->encodeBaseName);
            }
            else if ( (tmpTypeId == BASICTYPE_OCTETCONTAINING) ||
                      (tmpTypeId == BASICTYPE_BITCONTAINING))
            {
               PrintCxxEncodeContaining(e->type, r, src);
            }
            else
            {
                fprintf (src, "    l = %s", varName);
                if (cxxtri->isPtr)
                    fprintf (src, "->");
                else
                    fprintf (src, ".");

                fprintf (src, "B%s (b);\n", r->encodeContentBaseName);
            }


            /* encode tag (s) & len (s) */
            PrintCxxTagAndLenEncodingCode (src, td, e->type, "l", "b");


            fprintf (src, "    totalLen += l;\n");

            /* close optional test if nec */
            if (e->type->optional || (e->type->defaultVal != NULL))
                fprintf (src, "  }\n\n");
            else
                fprintf (src, "\n");
        }
        fprintf (src, "  return totalLen;\n");
        fprintf (src, "} // %s::B%s\n\n\n", td->cxxTypeDefInfo->className, r->encodeContentBaseName);
    }
    /* end of BerEncodeContent method printing code */

    /* write BerDecodeContent to src */
    if (printDecodersG)
    {
        fprintf (hdr, "  void			B%s (const %s &b, %s tag, %s elmtLen, %s &bytesDecoded);\n\n", r->decodeContentBaseName, bufTypeNameG, tagTypeNameG, lenTypeNameG, lenTypeNameG);//, envTypeNameG);

        fprintf (src, "void %s::B%s (const %s &b, %s /*tag0*/, %s elmtLen0, %s &bytesDecoded)\n", td->cxxTypeDefInfo->className, r->decodeContentBaseName, bufTypeNameG, tagTypeNameG, lenTypeNameG, lenTypeNameG);//, envTypeNameG);

        fprintf (src, "{\n");
        fprintf (src, "  FUNC(\" %s::B%s\");\n", td->cxxTypeDefInfo->className, r->decodeContentBaseName);
        fprintf (src, "  Clear();\n");

        /* print local vars */
        fprintf (src, "  %s tag1;\n", tagTypeNameG);
        fprintf (src, "  %s seqBytesDecoded = 0;\n", lenTypeNameG);
        /* count max number of extra length var nec */
        varCount = 0;
        FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
        {
            tmpVarCount = CxxCountVariableLevels (e->type);

            if (tmpVarCount > varCount)
                varCount = tmpVarCount;
        }
        /* write extra length vars */
        for (i = 1; i <= varCount; i++)
            fprintf (src, "  %s elmtLen%d;\n", lenTypeNameG, i);

        /* handle empty seq */
        if ((seq->basicType->a.sequence == NULL) || LIST_EMPTY (seq->basicType->a.sequence))
        {
            fprintf (src, "  if (elmtLen0 == INDEFINITE_LEN)\n");
            fprintf (src, "    BDecEoc (b, bytesDecoded);\n");
            fprintf (src, "  else if (elmtLen0 != 0)\n");
            fprintf (src, "  {\n");
            fprintf (src, "          throw EXCEPT(\"Expected an empty sequence\", DECODE_ERROR);\n");
            fprintf (src, "  }\n");

        }
        else
        {
            /*  check if all elmts are optional */
            AsnListFirst (seq->basicType->a.sequence);
            inTailOptElmts = IsTailOptional (seq->basicType->a.sequence);
            e = (NamedType*)FIRST_LIST_ELMT (seq->basicType->a.sequence);

            tmpTypeId = GetBuiltinType (e->type);

            if (!inTailOptElmts)
            {
                if (((tmpTypeId == BASICTYPE_ANY) || (tmpTypeId == BASICTYPE_ANYDEFINEDBY)) && (CountTags (e->type) == 0))
                {
                    if ((e->type->optional) && (e != (NamedType*)LAST_LIST_ELMT (seq->basicType->a.sequence)))
                        fprintf (src, "<untagged optional ANY - you must fix this>\n");
                }
                else
                    fprintf (src, "  tag1 = BDecTag (b, seqBytesDecoded);\n\n");
            }
            else
            {
                fprintf (src, "  if (elmtLen0 == 0)\n");
                fprintf (src, "    return;\n");
                fprintf (src, "  else\n");
                fprintf (src, "  {\n");
                if (((tmpTypeId == BASICTYPE_ANY) || (tmpTypeId == BASICTYPE_ANYDEFINEDBY)) && (CountTags (e->type) == 0))
                {
                    if ((e->type->optional) && (e != (NamedType*)LAST_LIST_ELMT (seq->basicType->a.sequence)))
                        fprintf (src, "<untagged optional ANY - you must fix this>\n");
                }
                else
                    fprintf (src, "    tag1 = BDecTag (b, seqBytesDecoded);\n\n");
                fprintf (src, "    if ((elmtLen0 == INDEFINITE_LEN) && (tag1 == EOC_TAG_ID))\n");
                fprintf (src, "    {\n");
                fprintf (src, "      BDEC_2ND_EOC_OCTET (b, seqBytesDecoded);\n");
                fprintf (src, "      bytesDecoded += seqBytesDecoded;\n");
                fprintf (src, "      return;\n");
                fprintf (src, "    }\n");
                fprintf (src, "  }\n\n");
            }


            FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
            {
                cxxtri =  e->type->cxxTypeRefInfo;
                elmtLevel = 0;

                tags = GetTags (e->type, &stoleChoiceTags);

                if (LIST_EMPTY (tags))
                    fprintf (src, "  // ANY type\n");
                else
                {
                    tag = (Tag*)FIRST_LIST_ELMT (tags);
                    classStr = Class2ClassStr (tag->tclass);
                    codeStr = DetermineCode(tag, NULL, 0);//RWC;Code2UnivCodeStr (tag->code);

                    formStr = Form2FormStr (tag->form);

                    fprintf (src, "  if (");
                    if (tag->tclass == UNIV)
                    {
                        if (tag->form == ANY_FORM)
                        {
                            fprintf (src, "(tag1 == MAKE_TAG_ID (%s, %s, %s))\n", classStr, Form2FormStr (PRIM), codeStr);
                            fprintf (src, "    || (tag1 == MAKE_TAG_ID (%s, %s, %s))", classStr, Form2FormStr (CONS), codeStr);
                        }
                        else
                            fprintf (src, "(tag1 == MAKE_TAG_ID (%s, %s, %s))", classStr, formStr, codeStr);
                    }
                    else
                    {
                        if (tag->form == ANY_FORM)
                        {
                            fprintf (src, "(tag1 == MAKE_TAG_ID (%s, %s, %s))\n", classStr, Form2FormStr (PRIM), DetermineCode(tag, NULL, 1));//RWC;tag->code);
                            fprintf (src, "    || (tag1 == MAKE_TAG_ID (%s, %s, %s))", classStr, Form2FormStr (CONS), DetermineCode(tag, NULL, 1));//RWC;tag->code);
                        }
                        else
                            fprintf (src, "(tag1 == MAKE_TAG_ID (%s, %s, %s))", classStr, formStr, DetermineCode(tag, NULL, 1));//RWC;tag->code);
                    }


                    /* now decode extra tags/length pairs */
                    AsnListFirst (tags);
                    AsnListNext (tags);
                    if (stoleChoiceTags)
                    {
                        FOR_REST_LIST_ELMT (tag, tags)
                        {
                            fprintf (src, "\n    || ");
                            classStr = Class2ClassStr (tag->tclass);

                            formStr = Form2FormStr (tag->form);

                            if (tag->tclass == UNIV)
                                codeStr = DetermineCode(tag, NULL, 0);//RWC;Code2UnivCodeStr (tag->code);
                            else
                                codeStr = DetermineCode(tag, NULL, 1);
                            if (tag->form == ANY_FORM)
                            {
                                fprintf (src, "(tag1 == MAKE_TAG_ID (%s, %s, %s))\n", classStr, Form2FormStr (PRIM), codeStr);
                                fprintf (src, "    || (tag1 == MAKE_TAG_ID (%s, %s, %s))", classStr, Form2FormStr (CONS), codeStr);
                            }
                            else
                                fprintf (src, "(tag1 == MAKE_TAG_ID (%s, %s, %s))", classStr, formStr, codeStr);
                            /*RWC;else
                            {
                                if (tag->form == ANY_FORM)
                                {
                                    fprintf (src, "(tag1 == MAKE_TAG_ID (%s, %s, %d))\n", classStr, Form2FormStr (PRIM), tag->code);
                                    fprintf (src, "    || (tag1 == MAKE_TAG_ID (%s, %s, %d))", classStr, Form2FormStr (CONS), tag->code);
                                }
                                else
                                    fprintf (src, "(tag1 == MAKE_TAG_ID (%s, %s, %d))", classStr, formStr, tag->code);
                            }*/
                        }
                        fprintf (src, ")\n");
                        fprintf (src, "  {\n");
                        fprintf (src, "    elmtLen%d = BDecLen (b, seqBytesDecoded);\n", ++elmtLevel);
                    }

                    else /* didn't steal nested choice's tags */
                    {
                        fprintf (src, ")\n");
                        fprintf (src, "  {\n");
                        fprintf (src, "    elmtLen%d = BDecLen (b, seqBytesDecoded);\n", ++elmtLevel);

                        FOR_REST_LIST_ELMT (tag, tags)
                        {
                            classStr = Class2ClassStr (tag->tclass);
                            formStr = Form2FormStr (tag->form);

                            fprintf (src, "    tag1 = BDecTag (b, seqBytesDecoded);\n\n");
                            if (tag->tclass == UNIV)
                                codeStr = DetermineCode(tag, NULL, 0);//RWC;Code2UnivCodeStr (tag->code);
                            else
                                codeStr = DetermineCode(tag, NULL, 1);
                            if (tag->form == ANY_FORM)
                            {
                                fprintf (src, "    if ((tag1 != MAKE_TAG_ID (%s, %s, %s))\n", classStr, Form2FormStr (PRIM), codeStr);
                                fprintf (src, "       && (tag1 != MAKE_TAG_ID (%s, %s, %s)))\n", classStr, Form2FormStr (CONS), codeStr);
                            }
                            else
                                fprintf (src, "    if (tag1 != MAKE_TAG_ID (%s, %s, %s))\n", classStr, formStr, codeStr);
                            /*RWC;else
                            {
                                if (tag->form == ANY_FORM)
                                {
                                    fprintf (src, "    if ((tag1 != MAKE_TAG_ID (%s, %s, %d))\n",  classStr, Form2FormStr (PRIM), tag->code);
                                    fprintf (src, "      && (tag1 != MAKE_TAG_ID (%s, %s, %d)))\n", classStr, Form2FormStr (CONS), tag->code);
                                }
                                else
                                    fprintf (src, "    if (tag1 != MAKE_TAG_ID (%s, %s, %d))\n", classStr, formStr, tag->code);
                            }*/

                            fprintf (src, "    {\n");
                           
                            fprintf (src, "          throw InvalidTagException(typeName(), tag1, STACK_ENTRY);\n");
                            fprintf (src, "    }\n\n");
                            fprintf (src, "    elmtLen%d = BDecLen (b, seqBytesDecoded);\n", ++elmtLevel);
                        }
                    }
                }
                /*
                 * if this seq element is CHOICE &&
                 * we didn't steal its tags then we must grab
                 * the key tag out of the contained CHOICE
                 */
                if (!stoleChoiceTags && (GetBuiltinType (e->type) == BASICTYPE_CHOICE))
                {
                    fprintf (src, "    tag1 = BDecTag (b, seqBytesDecoded);\n");
                    fprintf (src, "    elmtLen%d = BDecLen (b, seqBytesDecoded);\n", ++elmtLevel);
                }

                varName = cxxtri->fieldName;

                /* decode content */
                if (cxxtri->isPtr)
                {
                   if (e->type->defaultVal)
                   {
                      fprintf(src, "  // delete default value\n");
                      fprintf(src, "  delete %s;\n", varName);
                   }
                   fprintf (src, "  %s = new %s;\n", varName, cxxtri->className);
                }

                /* decode content */
                tmpTypeId = GetBuiltinType (e->type);
                if (tmpTypeId == BASICTYPE_ANYDEFINEDBY)
                {
                    /*
                     * must check for another EOC for ANYs
                     * since the any decode routines decode
                     * their own first tag/len pair
                     */
                    elmtLevel++;

                    defByNamedType = e->type->basicType->a.anyDefinedBy->link;
              
                    PrintCxxSetTypeByCode(defByNamedType, cxxtri, src);

                    fprintf (src, "  %s", varName);
                    if (cxxtri->isPtr)
                        fprintf (src, "->");
                    else
                        fprintf (src, ".");
                    fprintf (src, "B%s (b, seqBytesDecoded);\n",  r->decodeBaseName);

                }
                else if (tmpTypeId == BASICTYPE_ANY)
                {
                   elmtLevel++;
                    fprintf (src, "  %s", varName);
                    if (cxxtri->isPtr)
                        fprintf (src, "->");
                    else
                        fprintf (src, ".");
                    fprintf (src, "B%s (b, seqBytesDecoded);\n",  r->decodeBaseName);
                }
                else if ( (tmpTypeId == BASICTYPE_OCTETCONTAINING) ||
					   		  (tmpTypeId == BASICTYPE_BITCONTAINING) )
                {
                   PrintCxxDecodeContaining(e->type, r, src);
                }
                else
                {
                    fprintf (src, "    %s", varName);
                    if (cxxtri->isPtr)
                        fprintf (src, "->");
                    else
                        fprintf (src, ".");
             
                    fprintf (src, "B%s (b, tag1, elmtLen%d, seqBytesDecoded);\n",  r->decodeContentBaseName, elmtLevel);
                }

                /* decode Eoc (s) */
                for (i = elmtLevel-1; i > 0; i--)
                {
                    fprintf (src, "    if (elmtLen%d == INDEFINITE_LEN)\n", i);
                    fprintf (src, "      BDecEoc (b, seqBytesDecoded);\n\n");
                }

                /*
                 * print code for getting the next tag
                 */
                inTailOptElmts = RestAreTailOptional (seq->basicType->a.sequence);
                if  (e != (NamedType*)LAST_LIST_ELMT (seq->basicType->a.sequence))
                {
                    tmpElmt = (NamedType*)NEXT_LIST_ELMT (seq->basicType->a.sequence);
                    tmpTypeId = GetBuiltinType (tmpElmt->type);
                    if (!inTailOptElmts)
                    {
                        if ((tmpTypeId == BASICTYPE_ANY || tmpTypeId == BASICTYPE_ANYDEFINEDBY) && CountTags (tmpElmt->type) == 0)
                        {
                            /* don't get a tag since ANY's decode their own */
                            if (e->type->optional || (tmpElmt->type->optional && tmpElmt != (NamedType*)LAST_LIST_ELMT (seq->basicType->a.sequence)))
                                /* let this cause a compile error in the generated code */
                                fprintf (src, "  <problems with untagged ANY that is optional or follows an optional sequence element - you must fix this>\n");
                        }
                        else
                            fprintf (src, "    tag1 = BDecTag (b, seqBytesDecoded);\n");
                    }
                    else
                    {
                        fprintf (src, "    if (seqBytesDecoded == elmtLen0)\n");
                        fprintf (src, "    {\n");
                        fprintf (src, "      bytesDecoded += seqBytesDecoded;\n");
                        fprintf (src, "      return;\n");
                        fprintf (src, "    }\n");
                        fprintf (src, "    else\n");
                        fprintf (src, "    {\n");

                        if ((tmpTypeId == BASICTYPE_ANY || tmpTypeId == BASICTYPE_ANYDEFINEDBY) && !CountTags (tmpElmt->type))
                        {
                            /* don't get a tag since ANY's decode their own */
                            if (e->type->optional || (tmpElmt->type->optional && tmpElmt != (NamedType *)LAST_LIST_ELMT (seq->basicType->a.sequence)))
                            {
                                /*
                                 * let this cause a compile error in the generated code
                                 */
                                fprintf (src, "  <problems with untagged ANY that is optional or follows an optional sequence element - you must fix this>\n");
                            }
                            fprintf (src, "      tag1 = b.PeekByte();\n\n");
                            fprintf (src, "      if ((elmtLen0 == INDEFINITE_LEN) && (tag1 == EOC_TAG_ID))\n");
                            fprintf (src, "      {\n");
                            fprintf (src, "        BDecEoc (b, seqBytesDecoded);\n\n");
                            fprintf (src, "        bytesDecoded += seqBytesDecoded;\n");
                            fprintf (src, "        return;\n");
                            fprintf (src, "      }\n");

                        }
                        else
                        {
                            fprintf (src, "      tag1 = BDecTag (b, seqBytesDecoded);\n\n");
                            fprintf (src, "      if ((elmtLen0 == INDEFINITE_LEN) && (tag1 == EOC_TAG_ID))\n");
                            fprintf (src, "      {\n");
                            fprintf (src, "        BDEC_2ND_EOC_OCTET (b, seqBytesDecoded);\n");
                            fprintf (src, "        bytesDecoded += seqBytesDecoded;\n");
                            fprintf (src, "        return;\n");
                            fprintf (src, "      }\n");
                        }
                        fprintf (src, "    }\n");

                    }
                }


                /*
                 * close tag check if (if there is one) and
                 * print else clause to handle missing non-optional elmt
                 * errors
                 */
                tmpTypeId = GetBuiltinType (e->type);
                if ((tmpTypeId == BASICTYPE_ANYDEFINEDBY || tmpTypeId == BASICTYPE_ANY) && !CountTags (e->type))
                {
                    /* do nothing - no tag check if stmt to close */
                    fprintf (src, "\n\n");
                }
                else if (!e->type->optional && !e->type->defaultVal)
                {
                    fprintf (src, "  }\n"); /* end of tag check if */
                    fprintf (src, "  else\n");
                    fprintf (src, "  {\n");
                    
                    fprintf (src, "      throw EXCEPT(\"SEQUENCE is missing non-optional elmt\", DECODE_ERROR);\n");

                    fprintf (src, "  }\n\n");
                }
                else
                    fprintf (src, "  }\n\n"); /* end of tag check if */

                FreeTags (tags);
            }

            /* for last elmt only */
            fprintf (src, "  bytesDecoded += seqBytesDecoded;\n");
            fprintf (src, "  if (elmtLen0 == INDEFINITE_LEN)\n");
            fprintf (src, "  {\n");
            fprintf (src, "    BDecEoc (b, bytesDecoded);\n");
            fprintf (src, "    return;\n");
            fprintf (src, "  }\n");
            fprintf (src, "  else if (seqBytesDecoded != elmtLen0)\n");
            fprintf (src, "  {\n");
            fprintf (src, "    throw EXCEPT(\"Length discrepancy on sequence\", DECODE_ERROR);\n");
            fprintf (src, "  }\n");
            fprintf (src, "  else\n");
            fprintf (src, "    return;\n");

        } /* end of non-empty set else clause */

        fprintf (src, "} // %s::B%s\n\n", td->cxxTypeDefInfo->className, r->decodeContentBaseName);
    }
    /* end of code for printing ber decode content method */

    /* do BEnc function */
    if (printEncodersG)
    {
        fprintf (hdr, "  %s		B%s (%s &b) const;\n", lenTypeNameG, r->encodeBaseName, bufTypeNameG);

        fprintf (src, "%s %s::B%s (%s &b) const\n", lenTypeNameG, td->cxxTypeDefInfo->className, r->encodeBaseName,  bufTypeNameG);
        fprintf (src, "{\n");
        fprintf (src, "  %s l=0;\n", lenTypeNameG);
        fprintf (src, "  l = B%s (b);\n", r->encodeContentBaseName);

        /* encode each tag/len pair if any */
        FOR_EACH_LIST_ELMT_RVS (tag, seq->tags)
        {
            classStr = Class2ClassStr (tag->tclass);
            formStr = Form2FormStr (CONS);  /* seq's are constructed */
            //RWC;tagLen = TagByteLen (tag->code);

            fprintf (src, "  l += BEncConsLen (b, l);\n");

            if (tag->tclass == UNIV)
                fprintf (src, "  l += BEncTag%d (b, %s, %s, %s);\n", tagLen, classStr, formStr, DetermineCode(tag, &tagLen, 0));//RWC;Code2UnivCodeStr (tag->code));
            else
                fprintf (src, "  l += BEncTag%d (b, %s, %s, %s);\n", tagLen, classStr, formStr, DetermineCode(tag, &tagLen, 1));//RWC;tag->code);
        }
        fprintf (src, "  return l;\n");
        fprintf (src, "}\n\n");
    }
    /* end of BEnc function */

    /* Do BDec function */
    if (printDecodersG)
    {
        fprintf (hdr, "  void			B%s (const %s &b, %s &bytesDecoded);\n", r->decodeBaseName, bufTypeNameG, lenTypeNameG);//, envTypeNameG);

        fprintf (src, "void %s::B%s (const %s &b, %s &bytesDecoded)\n", td->cxxTypeDefInfo->className, r->decodeBaseName,  bufTypeNameG, lenTypeNameG);//, envTypeNameG);
        fprintf (src, "{\n");
        fprintf (src, "  FUNC(\" %s::B%s\");\n", td->cxxTypeDefInfo->className, r->decodeBaseName); 
        fprintf (src, "  %s tag;\n", tagTypeNameG);

        /* print extra locals for redundant lengths */
        for (i = 1; (seq->tags != NULL) && (i <= LIST_COUNT (seq->tags)); i++)
            fprintf (src, "  %s elmtLen%d;\n", lenTypeNameG, i);
        fprintf (src, "\n");

        /*  decode tag/length pair (s) */
        elmtLevel = 0;
        FOR_EACH_LIST_ELMT (tag, seq->tags)
        {
            classStr = Class2ClassStr (tag->tclass);
            formStr = Form2FormStr (CONS);  /* seqs are constructed */

            fprintf (src, "  if ((tag = BDecTag (b, bytesDecoded)) != ");

            if (tag->tclass == UNIV)
                fprintf (src, "MAKE_TAG_ID (%s, %s, %s))\n", classStr, formStr, DetermineCode(tag, NULL, 0));//RWC;Code2UnivCodeStr (tag->code));
            else
                fprintf (src, "MAKE_TAG_ID (%s, %s, %s))\n", classStr, formStr, DetermineCode(tag, NULL, 1));//RWC;tag->code);
            fprintf (src, "  {\n");
            fprintf (src, "    throw InvalidTagException(typeName(), tag, STACK_ENTRY);\n");
            fprintf (src, "  }\n");

            fprintf (src, "  elmtLen%d = BDecLen (b, bytesDecoded);\n", ++elmtLevel);
        }

        fprintf (src, "  B%s (b, tag, elmtLen%d, bytesDecoded);\n", r->decodeContentBaseName, elmtLevel);

        /* grab any EOCs that match redundant, indef lengths */
        for (i = elmtLevel-1; i > 0; i--)
        {
            fprintf (src, "  if (elmtLen%d == INDEFINITE_LEN)\n", i);
            fprintf (src, "    BDecEoc (b, bytesDecoded);\n");
        }

        fprintf (src, "}\n\n");
    }
    /* end of BDec function */

    /* write code for printing */
    if (printPrintersG)
    {
        fprintf (hdr, "  void		Print (std::ostream &os) const;\n");

        fprintf (src, "void %s::Print (std::ostream &os) const\n", 
                 td->cxxTypeDefInfo->className);
        fprintf (src, "{\n");
        fprintf (src, "  threadLock();\n");
        allOpt = AllElmtsOptional (seq->basicType->a.sequence);
        if (allOpt)
            fprintf (src, "  int nonePrinted = true;\n");
        fprintf (src, "  os << \"{ -- SEQUENCE --\" << std::endl;\n");
        fprintf (src, "  indentG = (short)(indentG + stdIndentG);\n\n");

        FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
        {
           inTailOptElmts = IsTailOptional (seq->basicType->a.sequence);

           if (e->type->cxxTypeRefInfo->isPtr)
           {
              fprintf (src, "  if (%s (%s))\n", 
                       cxxtri->optTestRoutineName, 
                       e->type->cxxTypeRefInfo->fieldName);
           }

           fprintf (src, "  {\n");

           if (allOpt)
           {
              if (e != FIRST_LIST_ELMT (seq->basicType->a.sequence))
              {
                 fprintf (src, "    if (!nonePrinted)\n");
                 fprintf (src, "      os << \",\" << std::endl;\n");
              }
//              fprintf (src, "    nonePrinted = false;\n", i);
              fprintf (src, "    nonePrinted = false;\n");
           }
           /* cannot be first elmt ow allOpt is true */
           else if (inTailOptElmts) 
           {
              fprintf (src, "    os << \",\"<< std::endl;\n");
           }

           fprintf (src, "    Indent (os, indentG);\n");

           if (e->fieldName != NULL)
           {
              fprintf (src, "    os << \"%s \";\n", e->fieldName);
           }

           if (e->type->cxxTypeRefInfo->isPtr)
           {
              fprintf (src, "    os << *%s;\n", 
                       e->type->cxxTypeRefInfo->fieldName);
           }
           else
           {
              fprintf (src, "    os << %s;\n", 
                       e->type->cxxTypeRefInfo->fieldName);
           }

           if (e != LAST_LIST_ELMT (seq->basicType->a.sequence) &&
              (!e->type->cxxTypeRefInfo->isPtr) )
           {
              fprintf (src, "    os << \",\" << std::endl;\n");
           }
           fprintf (src, "  }\n");

           if (e->type->cxxTypeRefInfo->isPtr)
           {
              fprintf (src, "  else\n");
              fprintf (src, "  {\n");
              fprintf (src, "    Indent (os, indentG);\n");
              if (e->fieldName != NULL)
                 fprintf (src, "    os << \"%s \";\n", e->fieldName);
              fprintf (src, "    os << \"-- void --\";\n");
              if (e != LAST_LIST_ELMT (seq->basicType->a.sequence))
                 fprintf (src, "    os << \",\" << std::endl;\n");
              else
                 fprintf (src, "    os << std::endl;\n");
              fprintf (src, "  }\n");
           }

           fprintf (src, "\n");

           if (e == LAST_LIST_ELMT (seq->basicType->a.sequence))
              fprintf (src, "  os << std::endl;\n");
	}

        fprintf (src, "  indentG =  (short)(indentG - stdIndentG);\n");
        fprintf (src, "  Indent (os, indentG);\n");
        fprintf (src, "  os << \"}\";\n");
        fprintf (src, "  threadUnlock();\n");
        fprintf (src, "} // %s::Print\n\n\n", td->cxxTypeDefInfo->className);

        /* ##################################################################
          
          RWC;1/12/00; ADDED XML output capability. */

        fprintf (hdr, "  void		PrintXML (std::ostream &os, const char *lpszTitle=NULL) const;\n");

        fprintf (src,"void %s::PrintXML (std::ostream &os, \n", td->cxxTypeDefInfo->className);
        fprintf (src,"                   const char *lpszTitle) const\n");
        fprintf (src, "{\n");
        allOpt = AllElmtsOptional (seq->basicType->a.sequence);
        fprintf (src, "  if (lpszTitle)\n");
        fprintf (src, "  {\n");
        fprintf (src, "     os << \"<\" << lpszTitle;\n");
        fprintf (src, "     if (typeName() && strlen(typeName()))\n");
        fprintf (src, "     {\n");
        fprintf (src, "        os << \" typeName=\\\"\" << typeName() << \"\\\"\";\n");
        fprintf (src, "     }\n");
        fprintf (src, "  }\n");
        fprintf (src, "  else\n");
        fprintf (src, "  {\n");
        fprintf (src, "     os << \"<NONE\";\n");
        fprintf (src, "  }\n");
        fprintf (src, "  if (typeName() && strlen(typeName()))\n");
        fprintf (src, "  {\n");
        fprintf (src, "     if (typeName() && strlen(typeName()))\n");
        fprintf (src, "     {\n");
        fprintf (src, "        os << \"<\" << typeName();\n");
        fprintf (src, "     }\n");
        fprintf (src, "  }\n");
        fprintf (src, " os << \" type=\\\"SEQUENCE\\\">\" << std::endl;\n");
        FOR_EACH_LIST_ELMT (e, seq->basicType->a.sequence)
        {
          inTailOptElmts = IsTailOptional (seq->basicType->a.sequence);
          if (e->type->cxxTypeRefInfo->isPtr)
          {
             fprintf (src, "  if (%s (%s))\n", cxxtri->optTestRoutineName, 
                      e->type->cxxTypeRefInfo->fieldName);
             fprintf (src, "  {\n");
             fprintf (src, "    %s->PrintXML(os", 
                      e->type->cxxTypeRefInfo->fieldName);

             if (e->fieldName != NULL)
                 fprintf (src, ", \"%s\"", e->fieldName);
                   
             fprintf (src, ");\n");
             fprintf (src, "  }\n");
          }
          else
          {
             fprintf (src, "    %s.PrintXML(os", e->type->cxxTypeRefInfo->fieldName);
             if (e->fieldName != NULL)
                fprintf (src, ", \"%s\"", e->fieldName);
             fprintf (src, ");\n");
          }
          fprintf (src, "\n");
        }
        fprintf (src, "  if (lpszTitle)\n");
        fprintf (src, "  {\n");
        fprintf (src, "     os << \"</\" << lpszTitle << \">\" << std::endl;\n");
        fprintf (src, "  }\n");
        fprintf (src, "  else\n");
        fprintf (src, "     if (typeName() && strlen(typeName()))\n");
        fprintf (src, "     {\n");
        fprintf (src, "        os << \"</\" << typeName() << \">\" << std::endl;\n");
        fprintf (src, "     }\n");
        fprintf (src, "} // %s::PrintXML\n\n\n", td->cxxTypeDefInfo->className);
       /* END XML Print capability.
       ################################################################## */
    }
    /* end of print method code printer */

    /* close class definition */
    fprintf (hdr, "};\n\n\n");
	novolatilefuncs = novolatilefuncs;
    parent=parent; /*AVOIDS warning.*/
} /* PrintCxxSeqDefCode */


static void
PrintCxxSetDefCode (FILE *src, FILE *hdr, ModuleList *mods, Module *m,
    CxxRules *r, TypeDef *td, Type *parent, Type *set, int novolatilefuncs)
{
    NamedType *e;
    char *classStr;
    char *formStr;
    char *codeStr;
    int tagLen, i=0;
    Tag *tag;
    TagList *tags;
    char *varName;
    CxxTRI *cxxtri=NULL;
    int elmtLevel=0;
    int varCount, tmpVarCount;
    int stoleChoiceTags;
    int inTailOptElmts;
    int mandatoryElmtCount;
    enum BasicTypeChoiceId tmpTypeId;
    NamedType *defByNamedType;
    int allOpt;

    /* put class spec in hdr file */
    char *ptr="";   /* NOT DLL Exported, or ignored on Unix. */
    if (bVDAGlobalDLLExport != NULL) 
       ptr = bVDAGlobalDLLExport;

    fprintf (hdr, "class %s %s%s\n", ptr, td->cxxTypeDefInfo->className, baseClassesG);
    fprintf (hdr, "{\n");
    fprintf (hdr, "public:\n");

    /* write out the set elmts */
    FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
    {
        fprintf (hdr, "  ");
        PrintCxxType (hdr, mods, m, r, td, set, e->type);
        fprintf (hdr, "%s;\n", e->type->cxxTypeRefInfo->fieldName);
    }

    fprintf (hdr, "\n");

#if META
    if (printMetaG)
    {
	fprintf (hdr, "#if META\n");
	fprintf (src, "#if META\n\n");

	fprintf (hdr, "  static const AsnSetTypeDesc	_desc;\n");
	fprintf (hdr, "  static const AsnSetMemberDesc	_mdescs[];\n");
	fprintf (hdr, "  const AsnTypeDesc		*_getdesc() const;\n");
	fprintf (hdr, "  AsnType			*_getref (const char *membername, bool create = false);\n\n");

	fprintf (src, "static AsnType *create%s()\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	fprintf (src, "  return new %s;\n", td->cxxTypeDefInfo->className);
	fprintf (src, "}\n\n");

	fprintf (src, "const AsnSetMemberDesc %s::_mdescs[] =\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
	    if (printMetaG == META_backend_names)
		fprintf (src, "  AsnSetMemberDesc (\"%s\", &%s::_desc, %s), // `%s'\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className, e->type->optional || e->type->defaultVal ? "true" : "false", e->fieldName ? e->fieldName : "");
	    else /* META_asn1_names */
		fprintf (src, "  AsnSetMemberDesc (\"%s\", &%s::_desc, %s), // `%s'\n", e->fieldName ? e->fieldName : e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className, e->type->optional || e->type->defaultVal ? "true" : "false", e->type->cxxTypeRefInfo->fieldName);
	fprintf (src, "  AsnSetMemberDesc()\n");
	fprintf (src, "};\n\n");

	fprintf (src, "const AsnSetTypeDesc %s::_desc\n", td->cxxTypeDefInfo->className);
	fprintf (src, "(\n");
	fprintf (src, "  &%sModuleDesc,\n", m->cxxname);
	if (printMetaG == META_backend_names)
	    fprintf (src, "  \"%s\", // `%s'\n", td->cxxTypeDefInfo->className, td->definedName);
	else /* META_asn1_names */
	    fprintf (src, "  \"%s\", // `%s'\n", td->definedName, td->cxxTypeDefInfo->className);
	fprintf (src, "  %s,\n", isMetaPDU (m->modId->name, td->definedName, meta_pdus_G) ? "true" : "false");
	fprintf (src, "  AsnTypeDesc::SET,\n");
	fprintf (src, "  create%s,\n", td->cxxTypeDefInfo->className);
	fprintf (src, "  _mdescs\n");
	fprintf (src, ");\n\n");

	fprintf (src, "const AsnTypeDesc *%s::_getdesc() const\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	fprintf (src, "  return &_desc;\n");
	fprintf (src, "}\n\n");

	fprintf (src, "AsnType *%s::_getref (const char *membername, bool create)\n", td->cxxTypeDefInfo->className);
	fprintf (src, "{\n");
	FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
	{
	    fprintf (src, "  if (!strcmp (membername, \"%s\"))\n", e->type->cxxTypeRefInfo->fieldName);
	    if (e->type->cxxTypeRefInfo->isPtr)
	    {
		fprintf (src, "  {\n");
		fprintf (src, "    if (!%s && create)\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "      %s = new %s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className);
		fprintf (src, "    return %s;\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "  }\n");
	    }
	    else
		fprintf (src, "    return &%s;\n", e->type->cxxTypeRefInfo->fieldName);
	}
	fprintf (src, "  return NULL;\n");
	fprintf (src, "}\n\n");

#if TCL
	if (printTclG)
	{
	    fprintf (hdr, "#if TCL\n");
	    fprintf (src, "#if TCL\n\n");

	    fprintf (hdr, "  int			TclGetDesc (Tcl_DString *) const;\n");
	    fprintf (hdr, "  int			TclGetVal (Tcl_Interp *) const;\n");
	    fprintf (hdr, "  int			TclSetVal (Tcl_Interp *, const char *valstr);\n");
	    fprintf (hdr, "  int			TclUnsetVal (Tcl_Interp *, const char *membernames);\n\n");

	    fprintf (src, "int %s::TclGetDesc (Tcl_DString *valstr) const\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  Tcl_DStringStartSublist (valstr);\n\n");
	    FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
	    {
		fprintf (src, "  Tcl_DStringStartSublist (valstr);\n");
		fprintf (src, "  Tcl_DStringAppendElement (valstr, \"%s\");\n", e->type->cxxTypeRefInfo->fieldName);
		if (e->type->cxxTypeRefInfo->isPtr)
		    fprintf (src, "  Tcl_DStringAppendElement (valstr, %s ? \"valid\" : \"void\");\n", e->type->cxxTypeRefInfo->fieldName);
		else
		    fprintf (src, "  Tcl_DStringAppendElement (valstr, \"valid\");\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "  Tcl_DStringEndSublist (valstr);\n\n");
	    }
	    fprintf (src, "  Tcl_DStringEndSublist (valstr);\n\n");
	    fprintf (src, "  return TCL_OK;\n");
	    fprintf (src, "}\n\n");

	    fprintf (src, "int %s::TclGetVal (Tcl_Interp *interp) const\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  Tcl_DString valstr;\n\n");
	    fprintf (src, "  Tcl_DStringInit (&valstr);\n\n");
	    FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
	    {
		if (e->type->cxxTypeRefInfo->isPtr)
		{
		    fprintf (src, "  if (%s)\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "  {\n");
		    fprintf (src, "    Tcl_DStringStartSublist (&valstr);\n");
		    fprintf (src, "    Tcl_DStringAppendElement (&valstr, \"%s\");\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "    if (%s->TclGetVal (interp) != TCL_OK)\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "      goto Error;\n");
		    fprintf (src, "    Tcl_DStringAppendElement (&valstr, interp->result);\n");
		    fprintf (src, "    Tcl_ResetResult (interp);\n");
		    fprintf (src, "    Tcl_DStringEndSublist (&valstr);\n");
		    fprintf (src, "  }\n\n");
		}
		else
		{
		    fprintf (src, "  Tcl_DStringStartSublist (&valstr);\n");
		    fprintf (src, "  Tcl_DStringAppendElement (&valstr, \"%s\");\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "  if (%s.TclGetVal (interp) != TCL_OK)\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "    goto Error;\n");
		    fprintf (src, "  Tcl_DStringAppendElement (&valstr, interp->result);\n");
		    fprintf (src, "  Tcl_ResetResult (interp);\n");
		    fprintf (src, "  Tcl_DStringEndSublist (&valstr);\n\n");
		}
	    }
	    fprintf (src, "  Tcl_DStringResult (interp, &valstr);\n");
	    fprintf (src, "  return TCL_OK;\n\n");
	    fprintf (src, "Error:\n");
	    fprintf (src, "  Tcl_DStringFree (&valstr);\n");
	    fprintf (src, "  return TCL_ERROR;\n");
	    fprintf (src, "}\n\n");

	    fprintf (src, "int %s::TclSetVal (Tcl_Interp *interp, const char *valstr)\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  int i;\n");
	    fprintf (src, "  Args elems;\n");
	    fprintf (src, "  if (Tcl_SplitList (interp, (char*)valstr, &elems.c, &elems.v) != TCL_OK)\n");
	    fprintf (src, "    return TCL_ERROR;\n");
	    fprintf (src, "  Args* elempairs = new Args[elems.c];\n");
	    fprintf (src, "  for (i=0; i<elems.c; i++)\n");
	    fprintf (src, "  {\n");
	    fprintf (src, "    if (Tcl_SplitList (interp, elems.v[i], &elempairs[i].c, &elempairs[i].v) != TCL_OK)\n");
	    fprintf (src, "    {\n");
	    fprintf (src, "      delete elempairs;\n");
	    fprintf (src, "      return TCL_ERROR;\n");
	    fprintf (src, "    }\n");
	    fprintf (src, "    if (elempairs[i].c != 2)\n");
	    fprintf (src, "    {\n");
	    fprintf (src, "      sprintf (interp->result, \"syntax error in element #%%d: expected a pair, but it's got %%d element(s)\", i, elempairs[i].c);\n");
	    fprintf (src, "      delete elempairs;\n");
	    fprintf (src, "      return TCL_ERROR;\n");
	    fprintf (src, "    }\n");
	    fprintf (src, "  }\n");
	    fprintf (src, "\n");
	    fprintf (src, "  for (const AsnSetMemberDesc *m=_mdescs; m->name; m++)\n");
	    fprintf (src, "  {\n");
	    fprintf (src, "    int count = 0;\n");
	    fprintf (src, "    for (i=0; i<elems.c; i++)\n");
	    fprintf (src, "      if (!strcmp (elempairs[i].v[0], m->name))\n");
	    fprintf (src, "        count++;\n");
	    fprintf (src, "    if (count > 1)\n");
	    fprintf (src, "    {\n");
	    fprintf (src, "      sprintf (interp->result, \"duplicate value for member \\\"%%s\\\" in list\", m->name);\n");
	    fprintf (src, "      Tcl_SetErrorCode (interp, \"SNACC\", \"DUPMEMB\", NULL);\n");
	    fprintf (src, "      delete elempairs;\n");
	    fprintf (src, "      return TCL_ERROR;\n");
	    fprintf (src, "    }\n");
	    fprintf (src, "    if (!m->optional && count < 1)\n");
	    fprintf (src, "    {\n");
	    fprintf (src, "      sprintf (interp->result, \"mandatory member \\\"%%s\\\" is missing in list\", m->name);\n");
	    fprintf (src, "      Tcl_SetErrorCode (interp, \"SNACC\", \"MISSMAND\", NULL);\n");
	    fprintf (src, "      delete elempairs;\n");
	    fprintf (src, "      return TCL_ERROR;\n");
	    fprintf (src, "    }\n");
	    fprintf (src, "    \n");
	    fprintf (src, "  }\n");
	    fprintf (src, "\n");
	    fprintf (src, "  for (i=0; i<elems.c; i++)\n");
	    fprintf (src, "  {\n");
	    FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
	    {
		fprintf (src, "    if (!strcmp (elempairs[i].v[0], \"%s\"))\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "    {\n");
		if (e->type->cxxTypeRefInfo->isPtr)
		{
		    fprintf (src, "      if (!%s)\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "        %s = new %s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className);
		    fprintf (src, "      if (%s->TclSetVal (interp, elempairs[i].v[1]))\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "      {\n");
		    fprintf (src, "        delete elempairs;\n");
		    fprintf (src, "        return TCL_ERROR;\n");
		    fprintf (src, "      }\n");
		}
		else
		{
		    fprintf (src, "      if (%s.TclSetVal (interp, elempairs[i].v[1]))\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "      {\n");
		    fprintf (src, "        return TCL_ERROR;\n");
		    fprintf (src, "        delete elempairs;\n");
		    fprintf (src, "      }\n");
		}
		fprintf (src, "    }\n");
	    }
	    fprintf (src, "  }\n");
	    fprintf (src, "\n");
	    fprintf (src, "  // look for unmentioned optional members and delete them:\n");
	    FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
	    {
		if (e->type->optional || e->type->defaultVal)
		{
		    fprintf (src, "  {\n");
		    fprintf (src, "    bool present = false;\n");
		    fprintf (src, "    for (i=0; i<elems.c; i++)\n");
		    fprintf (src, "      if (!strcmp (elempairs[i].v[0], \"%s\"))\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "        present = true;\n");
		    fprintf (src, "    if (!present)\n");
		    fprintf (src, "    {\n");
		    fprintf (src, "      delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "      %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "    }\n");
		    fprintf (src, "  }\n");
		}
	    }
	    fprintf (src, "\n");
	    fprintf (src, "  delete elempairs;\n");
	    fprintf (src, "  return TCL_OK;\n");
	    fprintf (src, "}\n\n");

	    fprintf (src, "int %s::TclUnsetVal (Tcl_Interp *interp, const char *membernames)\n", td->cxxTypeDefInfo->className);
	    fprintf (src, "{\n");
	    fprintf (src, "  Args elems;\n");
	    fprintf (src, "  if (Tcl_SplitList (interp, (char*)membernames, &elems.c, &elems.v) != TCL_OK)\n");
	    fprintf (src, "    return TCL_ERROR;\n");
	    fprintf (src, "\n");
	    fprintf (src, "  for (int i=0; i<elems.c; i++)\n");
	    fprintf (src, "  {\n");
	    FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
	    {
		fprintf (src, "    if (!strcmp (elems.v[i], \"%s\"))\n", e->type->cxxTypeRefInfo->fieldName);
		fprintf (src, "    {\n");
		if (e->type->optional || e->type->defaultVal)
		{
		    fprintf (src, "      delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
		    fprintf (src, "      %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
		}
		else
		{
		    fprintf (src, "      return _desc.mandatmemberr (interp, elems.v[i]);\n");
		}
		fprintf (src, "    }\n");
	    }
	    fprintf (src, "  }\n");
	    fprintf (src, "  return TCL_OK;\n");
	    fprintf (src, "}\n\n");

	    fprintf (hdr, "#endif // TCL\n");
	    fprintf (src, "#endif // TCL\n\n");
	}
#endif /* TCL */

	fprintf (hdr, "#endif // META\n\n");
	fprintf (src, "#endif // META\n\n");
    }
#endif /* META */

    /* Default constructor
	*/
    fprintf (hdr, "   %s(){Init();}\n", td->cxxTypeDefInfo->className);

	/* Init() member function
	 */
	 fprintf (hdr, "   void Init(void);\n");
    fprintf (src, "void %s::Init(void)\n", td->cxxTypeDefInfo->className);
    fprintf (src, "{\n");
    FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
    {
      if (e->type->cxxTypeRefInfo->isPtr)
      {
#if TCL
           fprintf (src, "#if TCL\n");
           fprintf (src, "  %s = new %s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className);
           fprintf (src, "#else // TCL\n");
           fprintf (src, "  %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
#else
           if (e->type->defaultVal != NULL)
           {
               Value *defVal = GetValue(e->type->defaultVal->value);
           
               /* HANDLE DEFAULT VALUE DECODING FOR DER by initializing the respective members to their default
                * values.
                */
                switch(ParanoidGetBuiltinType(e->type))
                {
                   case BASICTYPE_INTEGER:
                   case BASICTYPE_ENUMERATED:
                        fprintf(src," %s = new %s(%d);\n", 
                           e->type->cxxTypeRefInfo->fieldName, 
                           e->type->cxxTypeRefInfo->className,
                           defVal->basicValue->a.integer);
                        break;
                   case BASICTYPE_BOOLEAN:
                        fprintf(src," %s = new %s(%s);\n", 
                           e->type->cxxTypeRefInfo->fieldName, 
                           e->type->cxxTypeRefInfo->className,
                           defVal->basicValue->a.boolean == 0 ? "false": "true");
                        break;
                   case BASICTYPE_BITSTRING:
                   {
                      NamedNumberList *pNNL = GetNamedElmts(e->type);
                      BasicValue *pBV;
                      pBV = GetLastNamedNumberValue(pNNL);

                      if (defVal->basicValue->choiceId == BASICVALUE_VALUENOTATION &&
                          pBV != NULL)
                      {
                         char *defBitStr;
                         normalizeValue(&defBitStr, defVal->basicValue->a.valueNotation->octs);


                         fprintf(src," %s = new %s(%d);\n", 
                           e->type->cxxTypeRefInfo->fieldName, 
                           e->type->cxxTypeRefInfo->className,
                           pBV->a.integer);
                           
                         fprintf(src, " %s->SetBit(%s::%s);\n",
                            e->type->cxxTypeRefInfo->fieldName,
                            e->type->cxxTypeRefInfo->className,
                            defBitStr);

                         free(defBitStr);
                      }
                      else
                         printf("\nWARNING: unsupported use of default BIT STRING\n");
                  }
                  break;
                }
         }
         else
         {
             fprintf (src, "  %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
         }
#endif
      }
    }
    fprintf (src, "}\n\n");

    /* PIERCE added 8-22-2001
     
       Simple META support */
	 PrintCopyConstructor(hdr, src, td->cxxTypeDefInfo->className);
    PrintSimpleMeta(hdr, td->cxxTypeDefInfo->className,0);

    /* virtual destructor
	 */
    fprintf (hdr, "  virtual ~%s() {Clear();}\n", td->cxxTypeDefInfo->className);
    /* Clear() member
     */
    fprintf (hdr, "  void Clear();\n");

    fprintf (src, "void %s::Clear()\n", td->cxxTypeDefInfo->className);
    fprintf (src, "{\n");
    FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
	 if (e->type->cxxTypeRefInfo->isPtr)
    {
	    fprintf (src, "  delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
  	    fprintf (src, "  %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
    }
    fprintf (src, "}\n\n");

    /* print clone routine for ANY mgmt */
    PrintCloneMethod (hdr, src, td);

    fprintf (hdr, "  %s		&operator = (const %s &that);\n", td->cxxTypeDefInfo->className, td->cxxTypeDefInfo->className);

    fprintf (src, "%s &%s::operator = (const %s &that)\n", td->cxxTypeDefInfo->className, td->cxxTypeDefInfo->className, td->cxxTypeDefInfo->className);
    fprintf (src, "{\n");
    fprintf (src, "  if (this != &that)\n");
    fprintf (src, "  {\n");
    fprintf (src, "    Clear();\n");
    FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
    {
	   if (e->type->cxxTypeRefInfo->isPtr)
      {
	      fprintf (src, "    if (that.%s)\n", e->type->cxxTypeRefInfo->fieldName);
	      fprintf (src, "    {\n");
	      fprintf (src, "      if (!%s)\n", e->type->cxxTypeRefInfo->fieldName);
	      fprintf (src, "        %s = new %s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->className);
	      fprintf (src, "      *%s = *that.%s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->fieldName);
	      fprintf (src, "    }\n");
	      fprintf (src, "    else\n");
	      fprintf (src, "    {\n");
	      fprintf (src, "      delete %s;\n", e->type->cxxTypeRefInfo->fieldName);
	      fprintf (src, "      %s = NULL;\n", e->type->cxxTypeRefInfo->fieldName);
	      fprintf (src, "    }\n");
	   }
	   else
      {
	    fprintf (src, "    %s = that.%s;\n", e->type->cxxTypeRefInfo->fieldName, e->type->cxxTypeRefInfo->fieldName);
      }
    }
    fprintf (src, "  }\n");
    fprintf (src, "\n");
    fprintf (src, "  return *this;\n");
    fprintf (src, "}\n\n");

    /* BerEncode */
    if (printEncodersG)
    {
        /* int tmpCount=0; */

        fprintf (hdr, "  %s		B%s (%s &b) const;\n", lenTypeNameG, r->encodeContentBaseName, bufTypeNameG);

        fprintf (src, "%s %s::B%s (%s &b) const\n", lenTypeNameG, td->cxxTypeDefInfo->className, r->encodeContentBaseName, bufTypeNameG);
        fprintf (src, "{\n");

        /* print local vars */
        fprintf (src, "  %s totalLen = 0;\n", lenTypeNameG);
        fprintf (src, "  %s l=0;\n\n", lenTypeNameG);

      
        /* PIERCE changed 11-05-2002
         *   use an std::list of AsnBuf instead of an array of CSM_Buffers to 
         *   sort the elements of the set.
         */
        fprintf (src, "    std::list<AsnBuf> bufList;\n");
        fprintf (src, "    std::list<AsnBuf>::iterator iBuf;\n");
        
        FOR_EACH_LIST_ELMT_RVS (e, set->basicType->a.set)
        {
            cxxtri =  e->type->cxxTypeRefInfo;

            varName = cxxtri->fieldName;

            /* print optional test if nec*/
            if (e->type->optional || (e->type->defaultVal != NULL))
            {
                fprintf (src, "  if (%s (%s))\n", cxxtri->optTestRoutineName, varName);
                fprintf (src, "  {\n");
            }

            /* encode Eoc (s) if nec */

            fprintf(src, "    iBuf = bufList.insert(bufList.begin(), AsnBuf());\n");
            
            /* eSNACC 1.5 does not encode indefinite length
             *
             * PrintCxxEocEncoders (src, td, e->type, "b");
             */

            /* encode content */
            tmpTypeId = GetBuiltinType (e->type);
            if (tmpTypeId == BASICTYPE_ANYDEFINEDBY)
            {
                defByNamedType = e->type->basicType->a.anyDefinedBy->link;
                PrintCxxSetTypeByCode(defByNamedType, cxxtri, src);

                fprintf (src, "    l = %s", varName);
                if (cxxtri->isPtr)
                    fprintf (src, "->");
                else
                    fprintf (src, ".");
                fprintf (src, "B%s (*iBuf);\n", r->encodeBaseName);

                /* PIERCE: if DER not used we may want to do:
                 *
                else
                fprintf (src, "B%s (b);\n", r->encodeBaseName);
                 */

            }
            else if (tmpTypeId == BASICTYPE_ANY)
            {
                fprintf (src, "    l = %s", varName);
                if (cxxtri->isPtr)
                    fprintf (src, "->");
                else
                    fprintf (src, ".");

                fprintf (src, "B%s (*iBuf);\n", r->encodeBaseName);
            }
            else if ( (tmpTypeId == BASICTYPE_OCTETCONTAINING) ||
                      (tmpTypeId == BASICTYPE_BITCONTAINING))
            {
               PrintCxxEncodeContaining(e->type, r, src);
            }
            else
            {
                fprintf (src, "    l = %s", varName);
                if (cxxtri->isPtr)
                    fprintf (src, "->");
                else
                    fprintf (src, ".");

                fprintf (src, "B%s (*iBuf);\n", r->encodeContentBaseName);
                
                /* PIERCE: if DER not used we may want to do:
                 *
		          else
                  fprintf (src, "B%s (b);\n", r->encodeContentBaseName);
                 */
            }

            /* encode tag (s) & len (s) */

            PrintCxxTagAndLenEncodingCode (src, td, e->type, "l", "(*iBuf)");
            /* PIERCE: if DER not used we may want to do:
             *
            else
            PrintCxxTagAndLenEncodingCode (src, td, e->type, "l", "b");
             */

            fprintf (src, "    totalLen += l;\n");


            /** NOW, encode for SET DER rule ordering.*/
            /** RWC; Buffers handle files or memory. **/
            
            /** PIERCE: replaced logic
            fprintf (src, "        SNACC_BUFRESET_READ(&outputBuf);\n");
            fprintf (src, "        SM_ReadFromAsnBuf(tmpEnc[iii], outputBuf,outputBuf.DataLen(),NULL);\n");
            fprintf (src, "        SNACC_BUFRESET_WRITE(&outputBuf);\n");
            fprintf (src, "        iii++;\n");
            **/

            /* close optional test if nec */
            if (e->type->optional || (e->type->defaultVal != NULL))
                fprintf (src, "  }\n\n");
            else
                fprintf (src, "\n");
        }
#if 0
            /** LAST, Order for SET DER rule ordering.*/
            /**   re-order all elements, add to "b".*/
            fprintf (src, "      vdasnacc_sortSet(tmpEnc, iii);\n");
            
            /** These "SET" components are now ordered in ascending order, 
             ** ready to be loaded into the output buffer. (RWC; TBD; make output 
             ** buffers accept these allocated buffers directly, no copy). 
             **/ 

            fprintf (src, "      tmpCount = iii;  /** REMEMBER how many we have**/\n");
            fprintf (src, "      for (iii=0; iii < tmpCount; iii++)\n");
            fprintf (src, "         SM_WriteToAsnBuf(tmpEnc[iii], b);\n");

            fprintf (src, "      for (iii=0; iii < tmpCount; iii++) delete tmpEnc[iii];\n");
            fprintf (src, "      free(outputBuf.DataPtr());\n");
#endif      
            fprintf (src, "    sortSet(bufList);\n");
            fprintf (src, "    iBuf = bufList.begin();\n");
            fprintf (src, "    while(iBuf != bufList.end())\n");
            fprintf (src, "    {\n");
            fprintf (src, "       iBuf->ResetMode();\n");
            fprintf (src, "       b.splice(*iBuf);\n");
            fprintf (src, "       iBuf++;\n");
            fprintf (src, "    }\n");

        /** internal definition bracket for "tmpCount".**/
        
        fprintf (src, "  return totalLen;\n");
        fprintf (src, "} // %s::B%s\n\n\n", td->cxxTypeDefInfo->className, r->encodeContentBaseName);
    }
    /* end of BerEncodeContent */

    /* write BerDecodeContent */
    if (printDecodersG)
    {
        fprintf (hdr, "  void			B%s (const %s &b, %s tag, %s elmtLen, %s &bytesDecoded);\n\n", r->decodeContentBaseName, bufTypeNameG, tagTypeNameG, lenTypeNameG, lenTypeNameG);//, envTypeNameG);

        fprintf (src, "void %s::B%s (const %s &b, %s /*tag0*/, %s elmtLen0, %s &bytesDecoded)\n", td->cxxTypeDefInfo->className, r->decodeContentBaseName, bufTypeNameG, tagTypeNameG, lenTypeNameG, lenTypeNameG);//, envTypeNameG);
        fprintf (src, "{\n");
        fprintf (src, "   FUNC(\"%s::B%s\");\n",td->cxxTypeDefInfo->className, r->decodeContentBaseName); 
        fprintf (src, "   Clear();\n");

        /* print local vars */
        fprintf (src, "  %s tag1;\n", tagTypeNameG);
        fprintf (src, "  %s setBytesDecoded = 0;\n", lenTypeNameG);
        fprintf (src, "  unsigned int mandatoryElmtsDecoded = 0;\n");
        /* count max number of extra length var nec */
        varCount = 0;
        FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
        {
            tmpVarCount = CxxCountVariableLevels (e->type);
            if (tmpVarCount > varCount)
                varCount = tmpVarCount;
        }
        /* write extra length vars */
        for (i = 1; i <= varCount; i++)
            fprintf (src, "  %s elmtLen%d;\n", lenTypeNameG, i);
        fprintf (src, "\n");

        /* handle empty set */
        if ((set->basicType->a.set == NULL) || LIST_EMPTY (set->basicType->a.set))
        {
            fprintf (src, "  if (elmtLen0 == INDEFINITE_LEN)\n");
            fprintf (src, "    BDecEoc (b, bytesDecoded);\n");
            fprintf (src, "  else if (elmtLen0 != 0)\n");
            fprintf (src, "  {\n");
            
            fprintf (src, "    throw EXCEPT(\"Expected an empty sequence\", DECODE_ERROR);\n");
            fprintf (src, "  }\n");

/*   forget about potential extension types for now
            fprintf (src, "  if (elmtLen0 == INDEFINITE_LEN)\n");
            fprintf (src, "  {\n");
            fprintf (src, "    tag1 = BDecTag (b, bytesDecoded);\n\n");
            fprintf (src, "    if (tag1 == EOC_TAG_ID)\n");
            fprintf (src, "      BDEC_2ND_EOC_OCTET (b, bytesDecoded)\n");
            fprintf (src, "    else\n");
            fprintf (src, "      BerDiscardElmt (b, bytesDecoded);\n\n");
            fprintf (src, "  }\n");
            fprintf (src, "  else\n");
            fprintf (src, "  {\n");
            fprintf (src, "    BufSkip (b, elmtLen0);\n");
            fprintf (src, "    bytesDecoded += elmtLen0;\n");
            fprintf (src, "  }\n");
*/
        }
        else
        {
            fprintf (src, "  for (; (setBytesDecoded < elmtLen0) || (elmtLen0 == INDEFINITE_LEN); )\n");
            fprintf (src, "  {\n");
            fprintf (src, "    tag1 = BDecTag (b, setBytesDecoded);\n\n");
            fprintf (src, "    if ((elmtLen0 == INDEFINITE_LEN) && (tag1 == EOC_TAG_ID))\n");
            fprintf (src, "    {\n");
            fprintf (src, "      BDEC_2ND_EOC_OCTET (b, setBytesDecoded);\n");
            fprintf (src, "      break; /* exit for loop */\n");
            fprintf (src, "    }\n");

            fprintf (src, "    elmtLen1 = BDecLen (b, setBytesDecoded);\n");
            fprintf (src, "    switch (tag1)\n");
            fprintf (src, "    {\n");
            mandatoryElmtCount = 0;
            FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
            {
                cxxtri =  e->type->cxxTypeRefInfo;

                tags = GetTags (e->type, &stoleChoiceTags);

                if (LIST_EMPTY (tags))
                {
                    fprintf (src, "      // ANY Type ?\n");
                    fprintf (src, "      case MAKE_TAG_ID (?, ?, ?):\n");
                }
                else
                {
                    tag = (Tag*)FIRST_LIST_ELMT (tags);
                    classStr = Class2ClassStr (tag->tclass);
                    formStr = Form2FormStr (tag->form);

                    if (tag->tclass == UNIV)
                        codeStr = DetermineCode(tag, NULL, 0);//RWC;Code2UnivCodeStr (tag->code);
                    else
                        codeStr = DetermineCode(tag, NULL, 1);
                    if (tag->form == ANY_FORM)
                    {
                        fprintf (src, "      case MAKE_TAG_ID (%s, %s, %s):\n", classStr, Form2FormStr (PRIM), codeStr);
                        fprintf (src, "      case MAKE_TAG_ID (%s, %s, %s):\n", classStr, Form2FormStr (CONS), codeStr);
                    }
                    else
                        fprintf (src, "      case MAKE_TAG_ID (%s, %s, %s):\n", classStr, formStr, codeStr);
                    /*RWC;else
                    {
                        if (tag->form == ANY_FORM)
                        {
                            fprintf (src, "      case MAKE_TAG_ID (%s, %s, %d):\n", classStr, Form2FormStr (PRIM), tag->code);
                            fprintf (src, "      case MAKE_TAG_ID (%s, %s, %d):\n", classStr, Form2FormStr (CONS), tag->code);
                        }
                        else
                            fprintf (src, "      case MAKE_TAG_ID (%s, %s, %d):\n", classStr, formStr, tag->code);
                    }*/

                    /* now decode extra tags/length pairs */
                    AsnListFirst (tags);
                    AsnListNext (tags);
                    elmtLevel = 1;
                    if (stoleChoiceTags)
                    {
                        FOR_REST_LIST_ELMT (tag, tags)
                        {
                            classStr = Class2ClassStr (tag->tclass);

                            formStr = Form2FormStr (tag->form);

                            if (tag->tclass == UNIV)
                                codeStr = DetermineCode(tag, NULL, 0);//RWC;Code2UnivCodeStr (tag->code);
                            else
                                codeStr = DetermineCode(tag, NULL, 1);
                            if (tag->form == ANY_FORM)
                            {
                                fprintf (src, "      case MAKE_TAG_ID (%s, %s, %s):\n", classStr, Form2FormStr (PRIM), codeStr);
                                fprintf (src, "      case MAKE_TAG_ID (%s, %s, %s):\n", classStr, Form2FormStr (CONS), codeStr);
                            }
                            else
                                fprintf (src, "      case MAKE_TAG_ID (%s, %s, %s):\n", classStr, formStr, codeStr);
                            /*RWC;else
                            {
                                if (tag->form == ANY_FORM)
                                {
                                    fprintf (src, "      case MAKE_TAG_ID (%s, %s, %d):\n", classStr, Form2FormStr (PRIM), tag->code);
                                    fprintf (src, "      case MAKE_TAG_ID (%s, %s, %d):\n", classStr, Form2FormStr (CONS), tag->code);
                                }
                                else
                                    fprintf (src, "      case MAKE_TAG_ID (%s, %s, %d):\n", classStr, formStr, tag->code);
                            }*/
                        }
                    }
                    else /* didn't steal nested choice's tags */
                    {
                        FOR_REST_LIST_ELMT (tag, tags)
                        {
                            classStr = Class2ClassStr (tag->tclass);
                            codeStr = DetermineCode(tag, NULL, 0);//RWC;Code2UnivCodeStr (tag->code);
                            formStr = Form2FormStr (tag->form);

                            fprintf (src, "        tag1 = BDecTag (b, setBytesDecoded);\n");
                            if (tag->form == ANY_FORM)
                            {
                                if (tag->tclass == UNIV)
                                {
                                    fprintf (src, "        if ((tag1 != MAKE_TAG_ID (%s, %s, %s))\n",  classStr, Form2FormStr (PRIM), codeStr);
                                    fprintf (src, "           && (tag1 != MAKE_TAG_ID (%s, %s, %s)))\n", classStr, Form2FormStr (CONS), codeStr);
                                }
                                else
                                {
                                    fprintf (src, "        if ((tag1 != MAKE_TAG_ID (%s, %s, %s))\n", classStr, Form2FormStr (PRIM), DetermineCode(tag, NULL, 1));//RWC;tag->code);
                                    fprintf (src, "           && (tag1 != MAKE_TAG_ID (%s, %s, %s)))\n", classStr, Form2FormStr (CONS), DetermineCode(tag, NULL, 1));//RWC;tag->code);
                                }

                            }
                            else
                            {
                                if (tag->tclass == UNIV)
                                    fprintf (src, "        if (tag1 != MAKE_TAG_ID (%s, %s, %s))\n", classStr, formStr, codeStr);
                                else
                                    fprintf (src, "        if (tag1 != MAKE_TAG_ID (%s, %s, %s))\n", classStr, formStr, DetermineCode(tag, NULL, 1));//RWC;tag->code);
                            }

                            fprintf (src, "        {\n");
                            fprintf (src, "           throw InvalidTagException(typeName(), tag1, STACK_ENTRY);\n");
                            /* fprintf (src, "           ASN_THROW(%d, \"Unexpected Tag\", NULL);\n", 
                                longJmpValG--); */
                            fprintf (src, "        }\n\n");

                            fprintf (src, "        elmtLen%d = BDecLen (b, setBytesDecoded);\n", ++elmtLevel);
                        }
                    }
                }
                /*
                 * if the choices element is another choice &&
                 * we didn't steal its tags then we must grab
                 * the key tag out of the contained CHOICE
                 */
                if (!stoleChoiceTags && (GetBuiltinType (e->type) == BASICTYPE_CHOICE))
                {
                    fprintf (src, "        tag1 = BDecTag (b, setBytesDecoded);\n");
                    fprintf (src, "        elmtLen%d = BDecLen (b, setBytesDecoded);\n", ++elmtLevel);
                }

                varName = cxxtri->fieldName;

                /* decode content */
                if (cxxtri->isPtr)
                {
                   if (e->type->defaultVal)
                   {
                      fprintf(src, "  // delete default value\n");
                      fprintf(src, "  delete %s;\n", varName);
                   }
                   fprintf (src, "  %s = new %s;\n", varName, cxxtri->className);
                }

                /* decode content */
                tmpTypeId = GetBuiltinType (e->type);
                if (tmpTypeId == BASICTYPE_ANYDEFINEDBY)
                {
                    /*
                     * must check for another EOC for ANYs
                     * since the any decode routines decode
                     * their own first tag/len pair
                     */
                    elmtLevel++;

                    fprintf (src, "        %s", varName);
                    if (cxxtri->isPtr)
                        fprintf (src, "->");
                    else
                        fprintf (src, ".");

                    defByNamedType = e->type->basicType->a.anyDefinedBy->link;
                    PrintCxxSetTypeByCode(defByNamedType, cxxtri, src);

                    fprintf (src, "        %s", varName);
                    if (cxxtri->isPtr)
                        fprintf (src, "->");
                    else
                        fprintf (src, ".");
                    fprintf (src, "B%s (b, setBytesDecoded);\n",  r->decodeBaseName);
                }
                else if (tmpTypeId == BASICTYPE_ANY)
                {
                    elmtLevel++;

                    fprintf (src, "        %s", varName);
                    if (cxxtri->isPtr)
                        fprintf (src, "->");
                    else
                        fprintf (src, ".");
                    fprintf (src, "B%s (b, setBytesDecoded);\n",  r->decodeBaseName);

                }
                else if ( (tmpTypeId == BASICTYPE_OCTETCONTAINING) ||
					   		  (tmpTypeId == BASICTYPE_BITCONTAINING) )
                {
                   PrintCxxDecodeContaining(e->type, r, src);
                }
                else
                {
                    fprintf (src, "        %s", varName);
                    if (cxxtri->isPtr)
                        fprintf (src, "->");
                    else
                        fprintf (src, ".");

                    fprintf (src, "B%s (b, tag1, elmtLen%d, setBytesDecoded);\n",  r->decodeContentBaseName, elmtLevel);
                }

                /* decode Eoc (s) */
                for (i = elmtLevel-1; i >= 1; i--)
                {
                    fprintf (src, "          if (elmtLen%d == INDEFINITE_LEN)\n", i);
                    fprintf (src, "            BDecEoc (b, setBytesDecoded);\n\n");
                }

                /* keep track of decoded non-optional elmts */
                if (!e->type->optional && (e->type->defaultVal == NULL))
                {
                    mandatoryElmtCount++;
                    fprintf (src, "          mandatoryElmtsDecoded++;\n");
                }
                fprintf (src, "          break;\n\n");

                FreeTags (tags);
            } /* for each elmt */
            fprintf (src, "       default:\n");
            
            fprintf (src, "         throw InvalidTagException(typeName(), tag1, STACK_ENTRY);\n");
/*            
            fprintf (src, "         ASN_THROW(%d, \"Unexpected Tag on SET elmt\", NULL);\n", 
                longJmpValG--); */
            fprintf (src, "    } // end switch\n");
            fprintf (src, "  } // end for loop\n");
            fprintf (src, "  bytesDecoded += setBytesDecoded;\n");
            fprintf (src, "  if (mandatoryElmtsDecoded != %d)\n", mandatoryElmtCount);
            fprintf (src, "  {\n");
            
            fprintf (src, "     throw EXCEPT(\"non-optional SET element missing\", DECODE_ERROR);\n");
            
            /* fprintf (src, "     ASN_THROW(%d, \"ERROR - non-optional SET element missing\", NULL);\n", 
                longJmpValG--); */
            fprintf (src, "  }\n");

        } /* if not empty set clause */

        fprintf (src, "} // %s::B%s\n\n", td->cxxTypeDefInfo->className, r->decodeContentBaseName);
    }
    /* end of decode content method code */

    /* BerEncode */
    if (printEncodersG)
    {
        fprintf (hdr, "  %s		B%s (%s &b) const;\n", lenTypeNameG, r->encodeBaseName, bufTypeNameG);

        fprintf (src, "%s\n", lenTypeNameG);
        fprintf (src, "%s::B%s (%s &b) const\n", td->cxxTypeDefInfo->className, r->encodeBaseName, bufTypeNameG);
        fprintf (src, "{\n");
        fprintf (src, "  %s l=0;\n", lenTypeNameG);
        fprintf (src, "  l = B%s (b);\n", r->encodeContentBaseName);

        /* encode each tag/len pair if any */
        FOR_EACH_LIST_ELMT_RVS (tag, set->tags)
        {
            classStr = Class2ClassStr (tag->tclass);
            formStr = Form2FormStr (CONS);  /* set's are constructed */
            //RWC;tagLen = TagByteLen (tag->code);

            fprintf (src, "  l += BEncConsLen (b, l);\n");

            if (tag->tclass == UNIV)
                fprintf (src, "  l += BEncTag%d (b, %s, %s, %s);\n", tagLen, classStr, formStr, DetermineCode(tag, &tagLen, 0));//RWC;Code2UnivCodeStr (tag->code));
            else
                fprintf (src, "  l += BEncTag%d (b, %s, %s, %s);\n", tagLen, classStr, formStr, DetermineCode(tag, &tagLen, 1));//RWC;tag->code);
        }
        fprintf (src, "  return l;\n");
        fprintf (src, "}\n\n");
    }
    /* end of BerEncode */

    /* BerDecode */
    if (printDecodersG)
    {
        fprintf (hdr, "  void			B%s (const %s &b, %s &bytesDecoded);\n", r->decodeBaseName, bufTypeNameG, lenTypeNameG);//, envTypeNameG);

        fprintf (src, "void %s::B%s (const %s &b, %s &bytesDecoded)\n", td->cxxTypeDefInfo->className, r->decodeBaseName, bufTypeNameG, lenTypeNameG);//, envTypeNameG);
        fprintf (src, "{\n");
        fprintf (src, "   FUNC(\"%s::B%s\");\n", td->cxxTypeDefInfo->className, r->decodeBaseName);
        fprintf (src, "   %s tag;\n", tagTypeNameG);

        /* print extra locals for redundant lengths */
        for (i = 1; (set->tags != NULL) && (i <= LIST_COUNT (set->tags)); i++)
            fprintf (src, "  %s elmtLen%d;\n", lenTypeNameG, i);
        fprintf (src, "\n");

        /*  decode tag/length pair (s) */
        elmtLevel = 0;
        FOR_EACH_LIST_ELMT (tag, set->tags)
        {
            classStr = Class2ClassStr (tag->tclass);
            formStr = Form2FormStr (CONS);  /* sets are constructed */

            fprintf (src, "  if ((tag = BDecTag (b, bytesDecoded)) != ");

            if (tag->tclass == UNIV)
                fprintf (src, "MAKE_TAG_ID (%s, %s, %s))\n", classStr, formStr, DetermineCode(tag, NULL, 0));//RWC;Code2UnivCodeStr (tag->code));
            else
                fprintf (src, "MAKE_TAG_ID (%s, %s, %s))\n", classStr, formStr, DetermineCode(tag, NULL, 1));//RWC;tag->code);
            fprintf (src, "  {\n");

            fprintf (src, "        throw InvalidTagException(typeName(), tag, STACK_ENTRY);\n");

            /*fprintf (src, "        ASN_THROW(%d, \"%s::B%s: ERROR - wrong tag\", NULL);\n", 
                            longJmpValG--, td->cxxTypeDefInfo->className, r->decodeBaseName );*/
            fprintf (src, "  }\n");

            fprintf (src, "  elmtLen%d = BDecLen (b, bytesDecoded);\n", ++elmtLevel);
        }

        fprintf (src, "  B%s (b, tag, elmtLen%d, bytesDecoded);\n", r->decodeContentBaseName, i-1);

        /* grab any EOCs that match redundant, indef lengths */
        for (i = elmtLevel-1; i > 0; i--)
        {
            fprintf (src, "  if (elmtLen%d == INDEFINITE_LEN)\n", i);
            fprintf (src, "    BDecEoc (b, bytesDecoded);\n");
        }

        fprintf (src, "}\n\n");
    }
    /* end of BerDecode */

    /* write code for printing */
    if (printPrintersG)
    {
        fprintf (hdr, "  void			Print (std::ostream &os) const;\n");

        fprintf (src, "void %s::Print (std::ostream &os) const\n", td->cxxTypeDefInfo->className);
        fprintf (src, "{\n");
        fprintf (src, "  threadLock();\n");
        allOpt = AllElmtsOptional (set->basicType->a.set);
        if (allOpt)
            fprintf (src, "  int nonePrinted = true;\n");

        fprintf (src, "  os << \"{ -- SET --\" << std::endl;\n");
        fprintf (src, "  indentG = (short)(indentG + stdIndentG);\n\n");

        FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
        {
            inTailOptElmts = IsTailOptional (set->basicType->a.set);

            if (e->type->cxxTypeRefInfo->isPtr)
                fprintf (src, "  if (%s (%s))\n", cxxtri->optTestRoutineName, e->type->cxxTypeRefInfo->fieldName);

	    fprintf (src, "  {\n");

            if (allOpt)
            {
                if (e != FIRST_LIST_ELMT (set->basicType->a.set))
                {
                    fprintf (src, "    if (!nonePrinted)\n");
                    fprintf (src, "      os << \",\" << std::endl;\n");
                }
                fprintf (src, "    nonePrinted = false;\n");
//                fprintf (src, "    nonePrinted = false;\n", i);
            }
            else if (inTailOptElmts) /* cannot be first elmt ow allOpt is true */
                fprintf (src, "    os << \",\"<< std::endl;\n");

            fprintf (src, "    Indent (os, indentG);\n");

            if (e->fieldName != NULL)
                fprintf (src, "    os << \"%s \";\n", e->fieldName);

            if (e->type->cxxTypeRefInfo->isPtr)
                fprintf (src, "    os << *%s;\n", e->type->cxxTypeRefInfo->fieldName);
            else
                fprintf (src, "    os << %s;\n", e->type->cxxTypeRefInfo->fieldName);

            if (e != LAST_LIST_ELMT (set->basicType->a.set) && !inTailOptElmts && !NextIsTailOptional (set->basicType->a.set))
                fprintf (src, "    os << \",\" << std::endl;\n");

	    fprintf (src, "  }\n");

            if (e->type->cxxTypeRefInfo->isPtr)
	    {
		fprintf (src, "  else\n");
		fprintf (src, "    os << \"-- void2 --\\n\";\n");
	    }

	    fprintf (src, "\n");

            if (e == LAST_LIST_ELMT (set->basicType->a.set))
                fprintf (src, "  os << std::endl;\n");
        }
        fprintf (src, "  indentG = (short)(indentG - stdIndentG);\n");
        fprintf (src, "  Indent (os, indentG);\n");
        fprintf (src, "  os << \"}\";\n");
        fprintf (src, "  threadUnlock();\n");
        fprintf (src, "} // %s - operator <<\n\n\n", td->cxxTypeDefInfo->className);
        /* ##################################################################
           RWC;1/12/00; ADDED XML output capability. */
        fprintf (hdr, "  void PrintXML (std::ostream &os, const char *lpszTitle=NULL) const;\n");

        fprintf (src, "void %s::PrintXML (std::ostream &os, const char *lpszTitle) const\n", td->cxxTypeDefInfo->className);
        fprintf (src, "{\n");

        allOpt = AllElmtsOptional (set->basicType->a.set);
        //RWC;fprintf (src, "  os << \"<%s-SET>\";\n", td->cxxTypeDefInfo->className);
        fprintf (src, "  if (lpszTitle)\n");
        fprintf (src, "  {\n");
        //RWC;fprintf (src, "    os << lpszTitle;\n");
        fprintf (src, "     os << \"<\" << lpszTitle;\n");
        fprintf (src, "     os << \" typeName=\\\"%s\\\" type=\\\"SET\\\">\" << std::endl;\n", td->cxxTypeDefInfo->className);
        fprintf (src, "  }\n");
        fprintf (src, "  else\n");
        fprintf (src, "     os << \"<%s type=\\\"SET\\\">\" << std::endl;\n", td->cxxTypeDefInfo->className);
        FOR_EACH_LIST_ELMT (e, set->basicType->a.set)
        {
            inTailOptElmts = IsTailOptional (set->basicType->a.set);
            if (e->type->cxxTypeRefInfo->isPtr)
                fprintf (src, "  if (%s (%s))\n", cxxtri->optTestRoutineName, e->type->cxxTypeRefInfo->fieldName);
            fprintf (src, "  {\n");
            /*RWC;if (e->fieldName != NULL)
                fprintf (src, "    os << \"%s \";\n", e->fieldName);*/
            if (e->type->cxxTypeRefInfo->isPtr)
            {
                fprintf (src, "    (*%s).PrintXML(os", e->type->cxxTypeRefInfo->fieldName);
                if (e->fieldName != NULL)
                   fprintf (src, ", \"%s\"", e->fieldName);
                fprintf (src, ");\n");
            }
            else
            {
                fprintf (src, "    %s.PrintXML(os", e->type->cxxTypeRefInfo->fieldName);
                if (e->fieldName != NULL)
                   fprintf (src, ", \"%s\"", e->fieldName);
                fprintf (src, ");\n");
            }
            fprintf (src, "  }\n");
            if (e->type->cxxTypeRefInfo->isPtr)
            {
               fprintf (src, "  else\n");
               if (e->fieldName)
                  fprintf (src, "        os << \"<%s -- void2 -- />\" << std::endl;\n", e->fieldName);
               else
                  fprintf (src, "        os << \"<%s -- void2 -- />\" << std::endl;\n", e->type->cxxTypeRefInfo->fieldName);
            }
            fprintf (src, "\n");

        }      /* END For each set element */
        fprintf (src, "  if (lpszTitle)\n");
        fprintf (src, "     os << \"</\" << lpszTitle << \">\" << std::endl;\n");
        fprintf (src, "  else\n");
        fprintf (src, "     os << \"</%s>\" << std::endl;\n", td->cxxTypeDefInfo->className);
        //RWC;fprintf (src, "  os << \"</%s-SET>\" << std::endl;\n", td->cxxTypeDefInfo->className);
        fprintf (src, "} // %s::PrintXML\n\n\n", td->cxxTypeDefInfo->className);
        /* END XML Print capability.
        ################################################################## */
    }
    /* end of print method code */

    /* close class definition */
    fprintf (hdr, "};\n\n\n");
	novolatilefuncs = novolatilefuncs;
    parent=parent; /*AVOIDS warning.*/
} /* PrintCxxSetDefCode */


/*
 * PIERCE added 8-21-2001 template code to handle SET/SEQ OF
 *    
 */
static void
PrintCxxListClass (FILE *hdr,TypeDef *td,Type *lst, ModuleList *mods)
{
   char typeNameStr[256];
   char *lcn; /* list class name */
   char *ecn; /* (list) elmt class name */
   int i;
   char *ptr="";   /* RWC;VDA;NOT DLL Exported, or ignored on Unix. */
   char *pszNamespace;
   char *comments[] = \
   {"/* All SEQUENCE OF and SET OF types are handled by the AsnSeqOf and AsnSetOf\n",\
   " * templates defined in asn-list.h.  The private member function 'typeNameStr'\n",\
   " * is used by the Print() and PrintXML() to display the class name.  It's\n",\
   " * private because it will eventually be replaced by enchanced META code.\n",\
   " */\n",\
   "\0"};

   pszNamespace = LookupNamespace(lst, mods);

   lcn = td->cxxTypeDefInfo->className;

   ecn = lst->basicType->a.setOf->cxxTypeRefInfo->className;

   if (bVDAGlobalDLLExport != NULL) 
    ptr = bVDAGlobalDLLExport;

   /*
    * print comments
    */
   for (i=0; *comments[i] != '\0'; i++)
      fprintf (hdr, "%s", comments[i]);

   fprintf (hdr, "class %s : public ", lcn);

   switch (lst->basicType->choiceId)
   {
   case BASICTYPE_SEQUENCEOF:
       sprintf (typeNameStr,"\"%s\"", lcn);
       if (pszNamespace)
           fprintf (hdr, "AsnSeqOf<%s::%s>\n", pszNamespace, ecn);
       else
           fprintf (hdr, "AsnSeqOf<%s>\n", ecn);
	    break;
    case BASICTYPE_SETOF:
       sprintf (typeNameStr,"\"%s\"", lcn);
       if (pszNamespace)
           fprintf (hdr, "AsnSetOf<%s::%s>\n", pszNamespace, ecn);
       else
           fprintf (hdr, "AsnSetOf<%s>\n", ecn);
	    break;

	 default:
		 /* TBD print error? */
		 break;
   }
   fprintf (hdr, "{\n");
   PrintSimpleMeta(hdr,lcn,1);
   fprintf (hdr, "};\n\n");
}

static void
PrintCxxSetOfDefCode PARAMS ((src, hdr, if_IBM_ENC (srcdb COMMA hdrdb COMMA) mods, m, r, td, parent, setOf, novolatilefuncs),
    FILE *src _AND_
    FILE *hdr _AND_
    if_IBM_ENC (FILE *srcdb _AND_)
    if_IBM_ENC (FILE *hdrdb _AND_)
    ModuleList *mods _AND_
    Module *m _AND_
    CxxRules *r _AND_
    TypeDef *td _AND_
    Type *parent _AND_
    Type *setOf _AND_
    int novolatilefuncs)
{
	// Get rid of warnings
	novolatilefuncs = novolatilefuncs;
	parent = parent;
	m = m;
	r = r;
	mods = mods;
	src = src;
    /* do class */
	PrintCxxListClass (hdr,td,setOf, mods);
    /* PrintCxxListClass (src, hdr, if_IBM_ENC (srcdb COMMA hdrdb COMMA) mods, m, r, td, parent, setOf); */

    /* PIERCE Added list template code 8-21-2001 which implements these methods
     * so they are no longer necessary.
     */

    /* do methods */
    /* PrintCxxListMethods (src, hdr, mods, m, r, td, parent, setOf, novolatilefuncs);
     */
} /* PrintCxxSetOfDefCode */


static void
PrintCxxAnyDefCode PARAMS ((src, hdr, mods, m, r, td, parent, any),
    FILE *src _AND_
    FILE *hdr _AND_
    ModuleList *mods _AND_
    Module *m _AND_
    CxxRules *r _AND_
    TypeDef *td _AND_
    Type *parent _AND_
    Type *any)
{
    fprintf (hdr, "/* ");
    SpecialPrintType (hdr, td, td->type);
    fprintf (hdr, " */\n");
    fprintf (hdr, "typedef %s %s;\n\n", td->type->cxxTypeRefInfo->className, td->cxxTypeDefInfo->className);
    any=any;parent=parent;r=r;m=m;mods=mods;src=src;    /*AVOIDS warning.*/
} /* PrintCxxAnyDefCode */


static void
PrintCxxTypeDefCode PARAMS ((src, hdr, if_IBM_ENC (srcdb COMMA hdrdb COMMA) mods, m, r, td, novolatilefuncs),
    FILE *src _AND_
    FILE *hdr _AND_
    if_IBM_ENC (FILE *srcdb _AND_)
    if_IBM_ENC (FILE *hdrdb _AND_)
    ModuleList *mods _AND_
    Module *m _AND_
    CxxRules *r _AND_
    TypeDef *td _AND_
    int novolatilefuncs)
{

    switch (td->type->basicType->choiceId)
    {
        case BASICTYPE_BOOLEAN:  /* library type */
        case BASICTYPE_REAL:  /* library type */
        case BASICTYPE_OCTETSTRING:  /* library type */
        case BASICTYPE_NULL:  /* library type */
        case BASICTYPE_EXTERNAL:		/* library type */
        case BASICTYPE_OID:  /* library type */
        case BASICTYPE_INTEGER:  /* library type */
        case BASICTYPE_BITSTRING:  /* library type */
        case BASICTYPE_ENUMERATED:  /* library type */
        case BASICTYPE_NUMERIC_STR:  /* 22 */
        case BASICTYPE_PRINTABLE_STR: /* 23 */
        case BASICTYPE_UNIVERSAL_STR: /* 24 */
        case BASICTYPE_IA5_STR:      /* 25 */
        case BASICTYPE_BMP_STR:      /* 26 */
        case BASICTYPE_UTF8_STR:     /* 27 */
        case BASICTYPE_UTCTIME:      /* 28 tag 23 */
        case BASICTYPE_GENERALIZEDTIME: /* 29 tag 24 */
        case BASICTYPE_GRAPHIC_STR:     /* 30 tag 25 */
        case BASICTYPE_VISIBLE_STR:     /* 31 tag 26  aka ISO646String */
        case BASICTYPE_GENERAL_STR:     /* 32 tag 27 */
        case BASICTYPE_OBJECTDESCRIPTOR:	/* 33 tag 7 */
        case BASICTYPE_VIDEOTEX_STR:	/* 34 tag 21 */
        case BASICTYPE_T61_STR:			/* 35 tag 20 */
            PrintCxxSimpleDef (hdr, src, if_IBM_ENC (hdrdb COMMA srcdb COMMA) if_META (m COMMA) r, td);
            break;

        case BASICTYPE_SEQUENCEOF:  /* list types */
        case BASICTYPE_SETOF:
            PrintCxxSetOfDefCode (src, hdr, if_IBM_ENC (srcdb COMMA hdrdb COMMA) mods, m, r, td, NULL, td->type, novolatilefuncs);
            break;

        case BASICTYPE_IMPORTTYPEREF:  /* type references */
        case BASICTYPE_LOCALTYPEREF:
            /*
             * if this type has been re-tagged then
             * must create new class instead of using a typedef
             */
            PrintCxxSimpleDef (hdr, src, if_IBM_ENC (hdrdb COMMA srcdb COMMA) if_META (m COMMA) r, td);
            break;

        case BASICTYPE_ANYDEFINEDBY:  /* ANY types */
        case BASICTYPE_ANY:
/*
            fprintf (errFileG, "  ANY types require modification. ");
            fprintf (errFileG, "  The source files will have a \" ANY - Fix Me! \" comment before related code.\n\n");
*/
            PrintCxxAnyDefCode (src, hdr, mods, m, r, td, NULL, td->type);
            break;

        case BASICTYPE_CHOICE:
            PrintCxxChoiceDefCode (src, hdr, if_IBM_ENC (srcdb COMMA hdrdb COMMA) mods, m, r, td, NULL, td->type, novolatilefuncs);
            break;

        case BASICTYPE_SET:
            PrintCxxSetDefCode (src, hdr, mods, m, r, td, NULL, td->type, novolatilefuncs);
            break;

        case BASICTYPE_SEQUENCE:
            PrintCxxSeqDefCode (src, hdr, if_IBM_ENC (srcdb COMMA hdrdb COMMA) mods, m, r, td, NULL, td->type, novolatilefuncs);
            break;

        case BASICTYPE_COMPONENTSOF:
        case BASICTYPE_SELECTION:
        case BASICTYPE_UNKNOWN:
        case BASICTYPE_MACRODEF:
        case BASICTYPE_MACROTYPE:
            /* do nothing */
            break;
        default:
				/* TBD: print error? */
				break;
				
    }
} /* PrintCxxTypeDefCode */

void
PrintCxxCode PARAMS ((src, hdr, if_IBM_ENC (srcdb COMMA hdrdb COMMA) if_META (printMeta COMMA meta COMMA meta_pdus COMMA) mods, m, r, longJmpVal, printTypes, printValues, printEncoders, printDecoders, printPrinters, printFree if_TCL (COMMA printTcl), novolatilefuncs),
    FILE *src _AND_
    FILE *hdr _AND_
    if_IBM_ENC (FILE *srcdb _AND_)
    if_IBM_ENC (FILE *hdrdb _AND_)
    if_META (MetaNameStyle printMeta _AND_)
    if_META (const Meta *meta _AND_)
    if_META (MetaPDU *meta_pdus _AND_)
    ModuleList *mods _AND_
    Module *m _AND_
    CxxRules *r _AND_
    long longJmpVal _AND_
    int printTypes _AND_
    int printValues _AND_
    int printEncoders _AND_
    int printDecoders _AND_
    int printPrinters _AND_
    int printFree
    if_TCL (_AND_ int printTcl) _AND_
    int novolatilefuncs)
{
	Module *currMod;
    AsnListNode *currModTmp;
    TypeDef *td;
    ValueDef *vd;
#ifdef _IBM_ENC_
    char mm_name[40];
#endif /* _IBM_ENC_ */

    longJmpValG = longJmpVal;
    printTypesG = printTypes;
    printEncodersG = printEncoders;
    printDecodersG = printDecoders;
    printPrintersG = printPrinters;
    printFreeG = printFree;
#if META
    printMetaG = printMeta;
    meta_pdus_G = meta_pdus;
#if TCL
    printTclG = printTcl;
#endif /* TCL */
#endif /* META */

    PrintSrcComment (src, m);
    PrintHdrComment (hdr, m);
#ifdef _IBM_ENC_
    PrintSrcComment (srcdb, m);   /* 20.8.93 IBM-ENC */
    PrintHdrComment (hdrdb, m);   /* 20.8.93 IBM-ENC */

    strcpy (mm_name, m->cxxHdrFileName);
#endif /* _IBM_ENC_ */

    PrintConditionalIncludeOpen (hdr, m->cxxHdrFileName);

#if META
    if (printMetaG)
    {
	fprintf (src, "\n");
	fprintf (src, "#ifndef META\n");
	fprintf (src, "#define META	1\n");
	fprintf (src, "#endif\n");
#if TCL
	if (printTclG)
	{
	    fprintf (src, "#ifndef TCL\n");
	    fprintf (src, "#define TCL	META\n");
	    fprintf (src, "#endif\n");
	}
#endif /* TCL */
    }
#endif /* META */
	fprintf (hdr, "#include \"asn-incl.h\"\n");


    fprintf (src, "\n");    //RWC; PRINT before possible "namespace" designations.
    PrintSrcIncludes (src, if_IBM_ENC (srcdb COMMA) mods, m);

    FOR_EACH_LIST_ELMT (currMod, mods)
	{
		if ((strcmp(m->cxxHdrFileName, currMod->cxxHdrFileName) == 0))
		{
            // Code to see the import module list AND load possible "namespace" refs.
			ImportModuleList *ModLists;
			ImportModule *impMod;
			char *ImpFile = NULL;
			ModLists = currMod->imports;
            currModTmp = mods->curr;    //RWC;
			FOR_EACH_LIST_ELMT(impMod, ModLists)
			{
				ImpFile = GetImportFileName (impMod->modId->name, mods);
				if (ImpFile != NULL)
					fprintf (hdr, "#include \"%s\"\n", ImpFile);
                if (impMod->moduleRef == NULL)  // RWC; attempt to update...
                    impMod->moduleRef = GetImportModuleRef(impMod->modId->name, mods);
                if (impMod->moduleRef &&
                    impMod->moduleRef->namespaceToUse)
                {
                  fprintf(src,"using namespace %s;\n", impMod->moduleRef->namespaceToUse);
                }
			}
            mods->curr = currModTmp;    // RWC;RESET loop control
		}
		// Don't duplicate header file referenced in source
//		if ((strcmp(m->cxxHdrFileName, currMod->cxxHdrFileName) != 0))
//		{
//			if ((ImportedFilesG == FALSE) || (currMod->ImportedFlag == TRUE))
//				fprintf (hdr, "#include \"%s\"\n", currMod->cxxHdrFileName);
//		}
	}

    fprintf (hdr, "\n");

    fprintf (src, "\n");

    /* 7-09-2001 Pierce Leonberger
     *   Added code to include all SNACC generated code in the SNACC namespace.
     *   If the namespace name was overridden with the '-ns' switch then
     *   use the name specified.  If the '-nons' switch was used then don't
     *   use namespaces for SNACC generated code.
     */
    if (gNO_NAMESPACE == 0)
    {
       fprintf(hdr,"#ifndef NO_NAMESPACE\n");
       if (gAlternateNamespaceString)
       {
          fprintf(hdr,"using namespace SNACC;\n");
          fprintf(src,"using namespace SNACC;\n");
          fprintf(hdr,"namespace %s {\n", gAlternateNamespaceString);
          fprintf(src,"namespace %s {\n", gAlternateNamespaceString);
       }
       else if (m->namespaceToUse)
       {            // PRINT namespace designated in .asn1 file for this module.
          fprintf(hdr,"using namespace SNACC;\n");
          fprintf(src,"using namespace SNACC;\n");
          fprintf(hdr,"namespace %s {\n", m->namespaceToUse);
          fprintf(src,"namespace %s {\n", m->namespaceToUse);
       }
       else
       {
          fprintf(hdr,"namespace SNACC {\n"); 
	      fprintf(src,"namespace SNACC{\n"); 
       }
       fprintf(hdr,"#endif\n");
    }

    if (bVDAGlobalDLLExport)
    {
       /* RWC; VDA Enhanced to allow produced files to be DLLs exporting 
        * SNACC classes.
        */
        fprintf (hdr, 
         "// RWC; IF static refs to this class set, compiler define %s=""""\n", 
        bVDAGlobalDLLExport);

        fprintf (hdr, "#ifndef %s\n", bVDAGlobalDLLExport);
        fprintf (hdr, "#if defined(WIN32)\n");
        fprintf (hdr, "#pragma warning( disable : 4251)\n");
        if (strcmp(bVDAGlobalDLLExport, "SNACCDLL_API") == 0)
        {
           /* Special case for compatibility */
           fprintf (hdr, "#ifdef SNACCDLL_EXPORTS\n");
        }
        else
           fprintf (hdr, "#ifdef %s_EXPORTS\n", bVDAGlobalDLLExport);

       fprintf (hdr, "#define %s __declspec(dllexport)\n", bVDAGlobalDLLExport);
       fprintf (hdr, "#else\n");
       fprintf (hdr, "#define %s __declspec(dllimport)\n", bVDAGlobalDLLExport);
       fprintf (hdr, "#endif      // %s\n", bVDAGlobalDLLExport);
       fprintf (hdr, "#else       // Handle Unix...\n");
       fprintf (hdr, "#define %s \n", bVDAGlobalDLLExport);
       fprintf (hdr, "#endif      // WIN32\n");
       fprintf (hdr, "#endif      // %s\n", bVDAGlobalDLLExport);
    }       /* RWC;VDA; END Additional support for DLLs. */

    fprintf (hdr, "//------------------------------------------------------------------------------\n");
    fprintf (hdr, "// class declarations:\n\n");
    FOR_EACH_LIST_ELMT (td, m->typeDefs)
        PrintTypeDecl (hdr, td);
    fprintf (hdr, "\n");

#if META
    if (printMeta)
    {
	fprintf (hdr, "#if META\n");
	fprintf (src, "#if META\n\n");

	fprintf (hdr, "//------------------------------------------------------------------------------\n");

   char *ptr="";   /* NOT DLL Exported, or ignored on Unix. */
   if (bVDAGlobalDLLExport != NULL) 
      ptr = bVDAGlobalDLLExport;
	
   fprintf (hdr, "extern const %s AsnModuleDesc %sModuleDesc;\n", ptr, m->cxxname);

	fprintf (src, "//------------------------------------------------------------------------------\n");
	fprintf (src, "static const AsnTypeDesc *%sModuleTypes[] =\n", m->cxxname);
	fprintf (src, "{\n");
	FOR_EACH_LIST_ELMT (td, m->typeDefs)
	    fprintf (src, "  &%s::_desc,\n", td->cxxTypeDefInfo->className);
	fprintf (src, "  NULL\n");
	fprintf (src, "};\n\n");

#if 0 /* yet unused: */
	if (printMetaG == META_backend_names)
	else /* META_asn1_names */
#endif

	fprintf (src, "const AsnModuleDesc %sModuleDesc = { \"%s\", %sModuleTypes };\n\n", m->cxxname, m->modId->name, m->cxxname);

	fprintf (hdr, "#endif // META\n\n");
	fprintf (src, "#endif // META\n\n");
    }
#endif /* META */

    /* REMOVE PIERCE changed to print the Value definitions to the header file
     * 10-25-2001
     */
    if (printValues)
    {
	     fprintf (src, "//------------------------------------------------------------------------------\n");
        fprintf (src, "// value defs\n\n");
        FOR_EACH_LIST_ELMT (vd, m->valueDefs)
            PrintCxxValueDef (src, r, vd);
        fprintf (src, "\n");
    }
    /* REMOVE PIERCE changed const values to print to the header file only.  This negates the 
     * need to extern or export the const values.
     * 10-25-2001
     */
    if (printValues)
    {
	    fprintf (hdr, "//------------------------------------------------------------------------------\n");
       fprintf (hdr, "// externs for value defs\n\n");
       FOR_EACH_LIST_ELMT (vd, m->valueDefs)
            PrintCxxValueExtern (hdr, r, vd);
    }

    fprintf (hdr, "//------------------------------------------------------------------------------\n");

    fprintf (hdr, "//------------------------------------------------------------------------------\n");
    fprintf (hdr, "// class definitions:\n\n");
    fprintf (src, "//------------------------------------------------------------------------------\n");
    fprintf (src, "// class member definitions:\n\n");

    PrintCxxAnyCode (src, hdr, r, mods, m);

    FOR_EACH_LIST_ELMT (td, m->typeDefs)
        PrintCxxTypeDefCode (src, hdr, if_IBM_ENC (srcdb COMMA hdrdb COMMA) mods, m, r, td, novolatilefuncs);



   /* 7-09-2001 Pierce Leonberger
    */
   if (gNO_NAMESPACE == 0)
   {
      fprintf(hdr, "#ifndef NO_NAMESPACE\n");
      fprintf(hdr, "} // namespace close\n");
      fprintf(hdr, "#endif\n");
      fprintf(src, "#ifndef NO_NAMESPACE\n");
      fprintf(src, "} // namespace close\n");
      fprintf(src, "#endif\n");
   }

    PrintConditionalIncludeClose (hdr, m->cxxHdrFileName);

#ifdef _IBM_ENC_
    fprintf (hdrdb, "#endif\n");
#endif /* _IBM_ENC_ */

} /* PrintCxxCode */


void PrintCxxEncodeContaining(Type *t, CxxRules *r, FILE *src)
{
   
   fprintf(src, "    l += %s", t->cxxTypeRefInfo->fieldName);
   if (t->cxxTypeRefInfo->isPtr)
      fprintf(src, "->");
   else
      fprintf(src, ".");

   fprintf(src, "B%s(b);\n", r->encodeBaseName);

   /* If this is a BITSTRING CONTAINING encode a NULL octet for the unused 
    * bits
    */
   if (t->basicType->choiceId == BASICTYPE_BITCONTAINING)
   {
      fprintf(src,"    b.PutByteRvs((char) 0 ); //encode 0 for unused bits\n");
      fprintf(src,"    l++;\n");
   }
 
}

void PrintCxxDecodeContaining(Type *t, CxxRules *r, FILE *src)
{
   NamedType *defByNamedType;

   /* Encode Content of contained type */
   if (t->basicType->a.stringContaining->basicType->choiceId == 
			 BASICTYPE_ANYDEFINEDBY)
   {
      defByNamedType = 
			  t->basicType->a.stringContaining->basicType->a.anyDefinedBy->link;
      PrintCxxSetTypeByCode(defByNamedType, t->cxxTypeRefInfo, src);
   }

   if (t->basicType->choiceId == BASICTYPE_BITCONTAINING)
   {
      fprintf(src,"\n");
      fprintf(src,"    // Decode unused bits and make sure it's 0\n");
      fprintf(src,"    char unusedBits;\n");
      fprintf(src,"    unusedBits = b.GetByte();\n");
      fprintf(src,"    seqBytesDecoded++;\n");
      fprintf(src,"    if (unusedBits != '0x0')\n");
      fprintf(src,"      throw DecodeException(STACK_ENTRY);\n");
      fprintf(src,"\n");
   }

   fprintf (src, "    %s", t->cxxTypeRefInfo->fieldName);
   if (t->cxxTypeRefInfo->isPtr)
      fprintf (src, "->");
   else
      fprintf (src, ".");

   fprintf (src, "B%s (b, seqBytesDecoded);\n",  r->decodeBaseName);

}

void PrintCxxSetTypeByCode(NamedType *defByNamedType, CxxTRI *cxxtri, FILE *src)
{
   char *varName = cxxtri->fieldName;

     if (GetBuiltinType (defByNamedType->type) == BASICTYPE_OID)
     {
         fprintf (src, "    %s", varName);
         if (cxxtri->isPtr)
            fprintf (src, "->");
         else
            fprintf (src, ".");

         fprintf (src, "SetTypeByOid (");
         if (defByNamedType->type->cxxTypeRefInfo->isPtr)
             fprintf (src, " *");
         fprintf (src, "%s);\n", defByNamedType->type->cxxTypeRefInfo->fieldName);
     }
     else if (GetBuiltinType (defByNamedType->type) == BASICTYPE_INTEGER)
     {
         fprintf (src, "    %s", varName);
         if (cxxtri->isPtr)
            fprintf (src, "->");
         else
            fprintf (src, ".");

         fprintf (src, "SetTypeByInt (");
         if (defByNamedType->type->cxxTypeRefInfo->isPtr)
             fprintf (src, " *");
         fprintf (src, "%s);\n", defByNamedType->type->cxxTypeRefInfo->fieldName);
     }
     else if (GetBuiltinType (defByNamedType->type) == BASICTYPE_CHOICE)
     {
        NamedType *nt;
        Type      *t = GetType(defByNamedType->type);

        fprintf(src, "  switch (%s->choiceId)\n", defByNamedType->type->cxxTypeRefInfo->fieldName);
        fprintf(src, "  {\n");

        FOR_EACH_LIST_ELMT(nt, t->basicType->a.choice)
        {
//           enum BasicTypeChoiceId choiceId = nt->type->basicType->choiceId;
           
           fprintf(src, "   case %s::%sCid:\n", defByNamedType->type->cxxTypeRefInfo->className, nt->fieldName);
           if (nt->type->basicType->choiceId == BASICTYPE_INTEGER ||
               nt->type->basicType->choiceId == BASICTYPE_ENUMERATED)
           {
              fprintf (src, "      %s", varName);
              if (cxxtri->isPtr)
                 fprintf (src, "->");
              else
                 fprintf (src, ".");

              fprintf(src, "SetTypeByInt(*%s->%s);\n", defByNamedType->type->cxxTypeRefInfo->fieldName, nt->fieldName);
           }
           else
           {
              fprintf (src, "      %s", varName);
              if (cxxtri->isPtr)
                 fprintf (src, "->");
              else
                 fprintf (src, ".");

              fprintf(src, "SetTypeByOid(*%s->%s);\n", defByNamedType->type->cxxTypeRefInfo->fieldName, nt->fieldName);
           }
           fprintf(src, "      break;\n");

        }
        fprintf(src, "  }\n");
     }

}

//
//
char *LookupNamespace PARAMS ((t, mods),
    Type *t _AND_
    ModuleList *mods)
{
    char *pszNamespace=NULL;
    Module *mTmp=NULL;
    TypeDef *ptTmp=NULL;
    BasicType *pbtTmp2=NULL;

    //RWC; HANDLE namespace designations of specific modules on declarations,
    //      if necessary.  (May have to lookup module name to get namespace).
    pbtTmp2 = t->basicType;
    if (pbtTmp2->choiceId == BASICTYPE_SEQUENCEOF || 
        pbtTmp2->choiceId == BASICTYPE_SETOF)
        pbtTmp2 = pbtTmp2->a.sequenceOf->basicType;  // Burrow 1 more layer down for SequenceOf/SetOf
    if (pbtTmp2->choiceId == BASICTYPE_IMPORTTYPEREF)
    {                     // RWC; IF IMPORTED, then we need to check for 
                          //       optional namespace designation (only in .h)
        //RWC;DO NOT CARE;if (t->basicType->a.importTypeRef->moduleName == 0)
            FOR_EACH_LIST_ELMT (mTmp, mods)
            {
                ptTmp = LookupType(mTmp->typeDefs, 
                          pbtTmp2->a.importTypeRef->typeName); //WHAT we are looking for...
                if (ptTmp != NULL)
                    break;      //FOUND the MODULE that contains our defninition...
            }       // END FOR each module.
            if (ptTmp != NULL && mTmp != NULL && mTmp->namespaceToUse)  // FOUND our MODULE...
            {
                pszNamespace = mTmp->namespaceToUse;    // DO NOT DELETE...
            }       // IF t && mTmp && mTmp->namespaceToUse
            //RWC;impMod = LookupImportModule (currMod, bt->a.importTypeRef->moduleName);
            //RWC;impElmt = LookupImportElmtInImportElmtList (impMod->importElmts, bt->a.importTypeRef->typeName);
            //RWC;if (impElmt == NULL) /* whoa, compiler error again */
            //TypeDef*
            //LookupType PARAMS ((typeDefList, typeName),
    }           // IF BASICTYPE_IMPORTTYPEREF

    return(pszNamespace);
}       // END LookupNamespace(...)
