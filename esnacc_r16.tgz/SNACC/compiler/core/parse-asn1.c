
/*  A Bison parser, made from core/parse-asn1.y
    by GNU Bison version 1.28  */

#define YYBISON 1  /* Identify Bison output.  */

#define	BSTRING_SYM	257
#define	HSTRING_SYM	258
#define	CSTRING_SYM	259
#define	UCASEFIRST_IDENT_SYM	260
#define	LCASEFIRST_IDENT_SYM	261
#define	NAMEDMACRO_SYM	262
#define	MACRODEFBODY_SYM	263
#define	BRACEBAL_SYM	264
#define	NUMBER_ERANGE	265
#define	NUMBER_SYM	266
#define	SNACC_ATTRIBUTES	267
#define	DOT_SYM	268
#define	COMMA_SYM	269
#define	LEFTBRACE_SYM	270
#define	RIGHTBRACE_SYM	271
#define	LEFTPAREN_SYM	272
#define	RIGHTPAREN_SYM	273
#define	LEFTBRACKET_SYM	274
#define	RIGHTBRACKET_SYM	275
#define	LESSTHAN_SYM	276
#define	MINUS_SYM	277
#define	GETS_SYM	278
#define	BAR_SYM	279
#define	TAGS_SYM	280
#define	BOOLEAN_SYM	281
#define	INTEGER_SYM	282
#define	BIT_SYM	283
#define	STRING_SYM	284
#define	OCTET_SYM	285
#define	CONTAINING_SYM	286
#define	ENCODED_SYM	287
#define	NULL_SYM	288
#define	SEQUENCE_SYM	289
#define	OF_SYM	290
#define	SET_SYM	291
#define	IMPLICIT_SYM	292
#define	CHOICE_SYM	293
#define	ANY_SYM	294
#define	OBJECT_IDENTIFIER_SYM	295
#define	OPTIONAL_SYM	296
#define	DEFAULT_SYM	297
#define	COMPONENTS_SYM	298
#define	UNIVERSAL_SYM	299
#define	APPLICATION_SYM	300
#define	PRIVATE_SYM	301
#define	TRUE_SYM	302
#define	FALSE_SYM	303
#define	BEGIN_SYM	304
#define	END_SYM	305
#define	DEFINITIONS_SYM	306
#define	EXPLICIT_SYM	307
#define	ENUMERATED_SYM	308
#define	EXPORTS_SYM	309
#define	IMPORTS_SYM	310
#define	REAL_SYM	311
#define	INCLUDES_SYM	312
#define	MIN_SYM	313
#define	MAX_SYM	314
#define	SIZE_SYM	315
#define	FROM_SYM	316
#define	WITH_SYM	317
#define	COMPONENT_SYM	318
#define	PRESENT_SYM	319
#define	ABSENT_SYM	320
#define	DEFINED_SYM	321
#define	BY_SYM	322
#define	PLUS_INFINITY_SYM	323
#define	MINUS_INFINITY_SYM	324
#define	SEMI_COLON_SYM	325
#define	IA5STRING_SYM	326
#define	PRINTABLESTRING_SYM	327
#define	NUMERICSTRING_SYM	328
#define	TELETEXSTRING_SYM	329
#define	T61STRING_SYM	330
#define	VIDEOTEXSTRING_SYM	331
#define	VISIBLESTRING_SYM	332
#define	ISO646STRING_SYM	333
#define	GRAPHICSTRING_SYM	334
#define	GENERALSTRING_SYM	335
#define	BMPSTRING_SYM	336
#define	UNIVERSALSTRING_SYM	337
#define	UTF8STRING_SYM	338
#define	GENERALIZEDTIME_SYM	339
#define	UTCTIME_SYM	340
#define	EXTERNAL_SYM	341
#define	OBJECTDESCRIPTOR_SYM	342
#define	OPERATION_SYM	343
#define	ARGUMENT_SYM	344
#define	RESULT_SYM	345
#define	ERRORS_SYM	346
#define	LINKED_SYM	347
#define	ERROR_SYM	348
#define	PARAMETER_SYM	349
#define	BIND_SYM	350
#define	BINDERROR_SYM	351
#define	UNBIND_SYM	352
#define	UNBINDERROR_SYM	353
#define	ASE_SYM	354
#define	OPERATIONS_SYM	355
#define	CONSUMERINVOKES_SYM	356
#define	SUPPLIERINVOKES_SYM	357
#define	AC_SYM	358
#define	ASES_SYM	359
#define	REMOTE_SYM	360
#define	INITIATOR_SYM	361
#define	RESPONDER_SYM	362
#define	ABSTRACTSYNTAXES_SYM	363
#define	CONSUMER_SYM	364
#define	EXTENSIONS_SYM	365
#define	CHOSEN_SYM	366
#define	EXTENSION_SYM	367
#define	CRITICAL_SYM	368
#define	FOR_SYM	369
#define	DELIVERY_SYM	370
#define	SUBMISSION_SYM	371
#define	TRANSFER_SYM	372
#define	EXTENSIONATTRIBUTE_SYM	373
#define	TOKEN_SYM	374
#define	TOKENDATA_SYM	375
#define	SECURITYCATEGORY_SYM	376
#define	OBJECT_SYM	377
#define	PORTS_SYM	378
#define	BOXC_SYM	379
#define	BOXS_SYM	380
#define	PORT_SYM	381
#define	ABSTRACTOPS_SYM	382
#define	REFINE_SYM	383
#define	AS_SYM	384
#define	RECURRING_SYM	385
#define	VISIBLE_SYM	386
#define	PAIRED_SYM	387
#define	ABSTRACTBIND_SYM	388
#define	ABSTRACTUNBIND_SYM	389
#define	TO_SYM	390
#define	ABSTRACTERROR_SYM	391
#define	ABSTRACTOPERATION_SYM	392
#define	ALGORITHM_SYM	393
#define	ENCRYPTED_SYM	394
#define	SIGNED_SYM	395
#define	SIGNATURE_SYM	396
#define	PROTECTED_SYM	397
#define	OBJECTTYPE_SYM	398
#define	SYNTAX_SYM	399
#define	ACCESS_SYM	400
#define	STATUS_SYM	401
#define	DESCRIPTION_SYM	402
#define	REFERENCE_SYM	403
#define	INDEX_SYM	404
#define	DEFVAL_SYM	405
#define	ATTRIB_ASN1_TYPE_ID	406
#define	ATTRIB_C_TYPE_ID	407
#define	ATTRIB_C_TYPE_NAME_SYM	408
#define	ATTRIB_C_FIELD_NAME_SYM	409
#define	ATTRIB_IS_PDU_SYM	410
#define	ATTRIB_IS_PTR_SYM	411
#define	ATTRIB_IS_PTR_TYPEDEF_SYM	412
#define	ATTRIB_IS_PTR_TYPE_REF_SYM	413
#define	ATTRIB_IS_PTR_IN_CHOICE_SYM	414
#define	ATTRIB_IS_PTR_FOR_OPT_SYM	415
#define	ATTRIB_OPT_TEST_ROUTINE_SYM	416
#define	ATTRIB_DEFAULT_FIELD_SYM	417
#define	ATTRIB_PRINT_ROUTINE_SYM	418
#define	ATTRIB_ENCODE_ROUTINE_SYM	419
#define	ATTRIB_DECODE_ROUTINE_SYM	420
#define	ATTRIB_FREE_ROUTINE_SYM	421
#define	ATTRIB_IS_ENC_DEC_SYM	422
#define	ATTRIB_GEN_TYPEDEF_SYM	423
#define	ATTRIB_GEN_PRINT_ROUTINE_SYM	424
#define	ATTRIB_GEN_ENCODE_ROUTINE_SYM	425
#define	ATTRIB_GEN_DECODE_ROUTINE_SYM	426
#define	ATTRIB_GEN_FREE_ROUTINE_SYM	427
#define	ATTRIB_CHOICE_ID_SYMBOL_SYM	428
#define	ATTRIB_CHOICE_ID_VALUE_SYM	429
#define	ATTRIB_CHOICE_ID_ENUM_NAME_SYM	430
#define	ATTRIB_CHOICE_ID_ENUM_FIELD_NAME_SYM	431
#define	ATTRIB_IS_BIG_INT_SYM	432
#define	ATTRIB_NAMESPACE_SYM	433
#define	C_CHOICE_SYM	434
#define	C_LIST_SYM	435
#define	C_ANY_SYM	436
#define	C_ANYDEFBY_SYM	437
#define	C_LIB_SYM	438
#define	C_STRUCT_SYM	439
#define	C_TYPEDEF_SYM	440
#define	C_TYPEREF_SYM	441
#define	C_NO_TYPE_SYM	442
#define	UNKNOWN_SYM	443
#define	BITSTRING_SYM	444
#define	OCTETSTRING_SYM	445
#define	SEQUENCE_OF_SYM	446
#define	SET_OF_SYM	447
#define	ANY_DEFINED_BY_SYM	448
#define	LOCAL_TYPE_REF_SYM	449
#define	IMPORT_TYPE_REF_SYM	450

#line 28 "core/parse-asn1.y"


#include "snacc.h"

#if STDC_HEADERS || HAVE_STRING_H
#include <string.h>
#else
#include <strings.h>
#endif
//#include <stdio.h>

#include "asn-incl.h"
#include "mem.h"
#include "asn1module.h"
#include "lib-types.h"
#include "snacc-util.h"
#include "exports.h"
#include "lex-stuff.h"


int OidArcNameToNum PROTO ((char *name));
int yylex();
static void yyerror(char* s);


extern FILE* errFileG;		// Defined in snacc.c

/*
 * smallErrG
 *    used for small errors that should prevent code generation but not
 *    prevent the later error checking passes
 */
int smallErrG = FALSE;

/*
 * firstTimeThroughG
 *    used incase the asn1.lex was compiled with flex in which
 *    case the lexical analyzer must be reset for every ASN.1 file
 *    parsed, except the first
 */
static int firstTimeThroughG = TRUE;

/*
 *  modulePtrG
 *    used to hold the parsed value.  The root of the parse tree.
 */
Module *modulePtrG;


/*
 * oidElmtValDefsG
 *    used to hold integer values that are defined as arc numbers
 *    the modules object identifiers.
 * eg. FOO-MODULE { joint-iso-ccitt dod (2) foo (2) 3 2 } DEFINITIONS ::=
 *     would put dod/2 and foo/2 in the oidElmtValDefsG list
 * Note: only some oid's (modules name/import list module names)
 *       are parsed by the yacc code.  The rest are parsed later
 *       due to ambiguities that arise without type info.
// REN -- 9/23/02
ValueDefList *oidElmtValDefsG = NULL;
 */


/*
 * ApplTag
 *   used to hold APPLICATION tags that have been defined in
 *   a module.  This permits checking for the the error of
 *   using the same APPLICATION tag in 1 module.  The
 *   ApplTags list (appTagsG) is emptied for each module.
 */
typedef struct ApplTag
{
    unsigned long lineNo;
    unsigned long tagCode;
    struct ApplTag *next;
} ApplTag;

ApplTag *applTagsG  = NULL;

/*
 * Protos for ApplTag related stuff. These are defined at the
 * end  of this file
 */
void PushApplTag PROTO ((unsigned long tagCode, unsigned long lineNo));
void FreeApplTags();



/*
 * the following are globals to simplify disparity between
 * productions and produced data structure
 */

/*
 * these are used in the ValueRange subtype production
 */
static int      valueRangeUpperEndInclusiveG;
static int      valueRangeLowerEndInclusiveG;

/*
 * used to set exports flag in Type/value defs
 * exportListG holds the explicitly exported elements.
 * see SetExports routine in export.c
 */
ExportElmt *exportListG = NULL;
int         exportsParsedG;


/*
 * globals for the APPLICATION-CONTEXT macro productions
 */
static ValueList *rosAcSymmetricAsesG;
static ValueList *rosAcResponderConsumerOfG;
static ValueList *rosAcInitiatorConsumerOfG;

/*
 * used with MTSAS Extension macro
 * set to NULL for the initial parse.
 */
static AsnBool *mtsasCriticalForSubmissionG = NULL;
static AsnBool *mtsasCriticalForTransferG = NULL;
static AsnBool *mtsasCriticalForDeliveryG = NULL;

/*
 * Asn PORT macro globals
 */
static TypeOrValueList *asnConsumerG;
static TypeOrValueList *asnSupplierG;


/*
 * parseErrCountG
 *   used to prevent too many cascade errors
 */
int parseErrCountG = 0;
#define MAX_ERR 50
#define PARSE_ERROR()\
    parseErrCountG++;\
    modulePtrG->status = MOD_ERROR;\
    if (parseErrCountG > MAX_ERR)\
    {\
        fprintf (errFileG, "Ackkkkk! too many errors - bye!\n");\
        YYABORT;\
    }



#line 182 "core/parse-asn1.y"
typedef union
{
    int              intVal;
    unsigned int     uintVal;
    char            *charPtr;
    Type            *typePtr;
    NamedType       *namedTypePtr;
    NamedTypeList   *namedTypeListPtr;
    Value           *valuePtr;
    NamedValue      *namedValuePtr;
    SubtypeValue    *subtypeValuePtr;
    Subtype         *subtypePtr;
    ModuleId        *moduleId;
    OID             *oidPtr;
    OidList         *oidListPtr;
    TypeDef         *typeDefPtr;
    TypeDefList     *typeDefListPtr;
    ValueDef        *valueDefPtr;
    ValueDefList    *valueDefListPtr;
    ExportElmt      *exportList;
    ImportModule    *importModulePtr;
    ImportModuleList *importModuleListPtr;
    ImportElmt      *importElmtPtr;
    ImportElmtList  *importElmtListPtr;
    Tag             *tagPtr;
    TagList         *tagListPtr;
    Constraint      *constraintPtr;
    ConstraintList  *constraintListPtr;
    InnerSubtype    *innerSubtypePtr;
	ValueRangeEndpoint *valueRangeEndpointPtr;
    ValueList       *valueListPtr;
    TypeOrValueList *typeOrValueListPtr;
    TypeOrValue     *typeOrValuePtr;
    AsnPort         *asnPortPtr;
    AsnPortList     *asnPortListPtr;
    SnaccDirectiveList *directiveList;
	SnaccDirective	*directivePtr;
	SnaccDirectiveEnum directiveEnum;
	enum BasicTypeChoiceId basicTypeChoiceIdEnum;
	CTypeId			cTypeIdEnum;
	AsnBool			boolVal;
} YYSTYPE;
#ifndef YYDEBUG
#define YYDEBUG 1
#endif

#include <stdio.h>



#define	YYFINAL		778
#define	YYFLAG		-32768
#define	YYNTBASE	198

#define YYTRANSLATE(x) ((unsigned)(x) <= 450 ? yytranslate[x] : 398)

static const short yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,   197,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     3,     4,     5,     6,
     7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
    17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
    27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
    37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
    77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
   137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
   147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   169,   170,   171,   172,   173,   174,   175,   176,
   177,   178,   179,   180,   181,   182,   183,   184,   185,   186,
   187,   188,   189,   190,   191,   192,   193,   194,   195,   196
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     1,     2,    12,    15,    18,    20,    23,    25,    27,
    31,    33,    37,    39,    43,    47,    49,    51,    53,    55,
    60,    64,    68,    70,    72,    74,    77,    79,    84,    88,
    90,    92,    94,    96,    99,   101,   103,   106,   109,   111,
   113,   114,   121,   125,   131,   133,   135,   142,   147,   149,
   151,   153,   155,   157,   159,   161,   163,   165,   167,   169,
   171,   173,   175,   177,   179,   181,   183,   185,   187,   189,
   191,   193,   195,   198,   200,   202,   205,   207,   209,   211,
   216,   218,   222,   227,   232,   234,   236,   239,   242,   247,
   249,   252,   258,   260,   262,   264,   268,   272,   275,   278,
   280,   286,   288,   291,   295,   299,   304,   308,   312,   316,
   319,   323,   329,   332,   334,   339,   343,   346,   350,   354,
   359,   361,   363,   365,   367,   369,   371,   373,   378,   383,
   388,   390,   392,   394,   396,   398,   400,   402,   404,   406,
   408,   410,   412,   414,   416,   418,   420,   422,   425,   430,
   435,   439,   441,   445,   447,   449,   451,   453,   455,   457,
   459,   462,   467,   469,   472,   474,   477,   479,   481,   483,
   485,   488,   491,   495,   499,   501,   503,   505,   509,   517,
   519,   523,   526,   528,   531,   533,   535,   537,   539,   541,
   543,   549,   551,   553,   555,   557,   562,   564,   566,   568,
   570,   572,   574,   576,   577,   581,   583,   585,   587,   589,
   591,   593,   596,   600,   603,   605,   607,   609,   611,   613,
   615,   620,   625,   627,   629,   631,   633,   635,   637,   639,
   641,   642,   644,   646,   648,   651,   655,   659,   663,   667,
   671,   673,   675,   677,   679,   681,   683,   685,   687,   689,
   691,   693,   695,   697,   699,   701,   703,   705,   707,   709,
   711,   713,   715,   717,   719,   721,   723,   725,   727,   729,
   731,   733,   735,   737,   739,   741,   743,   745,   747,   749,
   751,   753,   755,   757,   759,   761,   763,   765,   767,   769,
   771,   773,   775,   777,   779,   781,   783,   785,   787,   789,
   791,   793,   795,   797,   799,   801,   803,   805,   807,   809,
   811,   813,   815,   817,   819,   821,   823,   825,   827,   829,
   831,   833,   835,   837,   839,   841,   843,   845,   847,   849,
   851,   853,   855,   857,   859,   861,   863,   865,   867,   869,
   871,   873,   875,   877,   879,   881,   883,   885,   887,   889,
   891,   893,   896,   901,   904,   906,   909,   911,   913,   915,
   920,   922,   927,   929,   932,   935,   937,   942,   945,   947,
   950,   952,   955,   957,   962,   965,   967,   970,   974,   979,
   984,   986,   991,   993,   995,  1004,  1009,  1017,  1019,  1025,
  1027,  1030,  1037,  1039,  1046,  1048,  1053,  1055,  1057,  1061,
  1068,  1070,  1072,  1074,  1078,  1080,  1082,  1084,  1088,  1090,
  1092,  1097,  1099,  1102,  1104,  1108,  1110,  1112,  1116,  1118,
  1120,  1122,  1124,  1127,  1129,  1132,  1134,  1137,  1139,  1142,
  1145,  1150,  1152,  1154,  1158,  1161,  1163,  1165,  1167,  1170,
  1172,  1177,  1179,  1181,  1184,  1187,  1192,  1197,  1202,  1204,
  1208,  1211,  1213,  1216,  1218,  1222,  1226,  1228,  1232,  1234,
  1238,  1240,  1243,  1247,  1252,  1254,  1257,  1261,  1266,  1268,
  1271,  1274,  1278,  1281,  1284,  1287,  1290,  1302,  1304,  1306,
  1309,  1310,  1313,  1314,  1319,  1320,  1325
};

static const short yyrhs[] = {    -1,
     0,   202,    52,   201,   200,    24,    50,   204,   205,    51,
     0,    53,    26,     0,    38,    26,     0,   306,     0,   304,
   203,     0,   293,     0,   306,     0,   179,   197,     5,     0,
   306,     0,   206,   209,   215,     0,   306,     0,    55,   207,
    71,     0,    55,     1,    71,     0,   306,     0,   208,     0,
   306,     0,   214,     0,   208,    15,   198,   214,     0,    56,
   210,    71,     0,    56,     1,    71,     0,   306,     0,   211,
     0,   306,     0,   211,   212,     0,   212,     0,   213,    62,
   198,   202,     0,   213,    15,   214,     0,   214,     0,   305,
     0,   303,     0,   317,     0,   215,   216,     0,   216,     0,
   217,     0,   217,    71,     0,     1,    71,     0,   220,     0,
   283,     0,     0,     8,    24,    50,   198,   218,     9,     0,
     8,    24,   219,     0,     8,    24,   304,    14,   219,     0,
   305,     0,   317,     0,   305,    24,   307,   198,   223,   307,
     0,   304,    14,   198,   305,     0,   221,     0,   305,     0,
   316,     0,   224,     0,   222,     0,   260,     0,   226,     0,
   227,     0,   256,     0,   233,     0,   235,     0,   236,     0,
   238,     0,   242,     0,   244,     0,   245,     0,   246,     0,
   249,     0,   250,     0,   254,     0,   257,     0,   231,     0,
   232,     0,   255,     0,    31,    30,     0,   259,     0,   258,
     0,   303,   223,     0,   223,     0,    27,     0,    28,     0,
    28,    16,   228,    17,     0,   229,     0,   228,    15,   229,
     0,   303,    18,   230,    19,     0,   303,    18,   285,    19,
     0,    12,     0,    11,     0,    23,    12,     0,    23,    11,
     0,    54,    16,   228,    17,     0,    57,     0,    29,    30,
     0,    29,    30,    16,   234,    17,     0,   228,     0,    34,
     0,    87,     0,    35,   198,    16,     0,   237,   239,    17,
     0,   237,    17,     0,   240,   307,     0,   241,     0,   240,
    15,   307,   198,   241,     0,   225,     0,   225,    42,     0,
   225,    43,   292,     0,    44,    36,   223,     0,   303,    44,
    36,   223,     0,    35,    36,   223,     0,    37,   198,    16,
     0,   243,   239,    17,     0,   243,    17,     0,    37,    36,
   223,     0,    39,   198,    16,   247,    17,     0,   248,   307,
     0,   225,     0,   248,    15,   307,   225,     0,   303,    22,
   223,     0,   251,   223,     0,   251,    38,   223,     0,   251,
    53,   223,     0,    20,   253,   252,    21,     0,   302,     0,
   285,     0,    45,     0,    46,     0,    47,     0,   306,     0,
    40,     0,    40,    67,    68,   303,     0,    31,    30,    32,
   223,     0,    29,    30,    32,   223,     0,    41,     0,    85,
     0,    86,     0,    88,     0,    74,     0,    73,     0,    72,
     0,    82,     0,    83,     0,    84,     0,    75,     0,    76,
     0,    77,     0,    78,     0,    79,     0,    80,     0,    81,
     0,   223,   261,     0,    37,   271,    36,   223,     0,    35,
   271,    36,   223,     0,    18,   262,    19,     0,   263,     0,
   262,    25,   263,     0,   264,     0,   265,     0,   266,     0,
   272,     0,   271,     0,   273,     0,   284,     0,    58,   223,
     0,   267,    14,    14,   268,     0,   269,     0,   269,    22,
     0,   270,     0,    22,   270,     0,   284,     0,    59,     0,
   284,     0,    60,     0,    61,   261,     0,    62,   261,     0,
    63,    64,   274,     0,    63,    44,   275,     0,   261,     0,
   276,     0,   277,     0,    16,   278,    17,     0,    16,    14,
    14,    14,    15,   278,    17,     0,   279,     0,   278,    15,
   279,     0,   303,   280,     0,   280,     0,   281,   282,     0,
   261,     0,   306,     0,    65,     0,    66,     0,   306,     0,
    42,     0,   303,   223,    24,   198,   284,     0,   287,     0,
   285,     0,   286,     0,   303,     0,   304,    14,   198,   303,
     0,   289,     0,   291,     0,   290,     0,   230,     0,   300,
     0,   299,     0,   301,     0,     0,    16,   288,    10,     0,
    48,     0,    49,     0,    69,     0,    70,     0,    34,     0,
   284,     0,   303,   284,     0,    16,   294,    17,     0,   294,
   295,     0,   295,     0,   296,     0,   297,     0,   298,     0,
   302,     0,   303,     0,   303,    18,   296,    19,     0,   303,
    18,   285,    19,     0,     3,     0,     4,     0,     5,     0,
    12,     0,    11,     0,     7,     0,     6,     0,     6,     0,
     0,   308,     0,   306,     0,   309,     0,   308,   309,     0,
   152,   197,   310,     0,   153,   197,   311,     0,   312,   197,
   313,     0,   314,   197,     5,     0,   315,   197,    12,     0,
   189,     0,    27,     0,    28,     0,   190,     0,   191,     0,
    34,     0,    41,     0,    57,     0,    54,     0,    35,     0,
   192,     0,    37,     0,   193,     0,    39,     0,    40,     0,
   194,     0,   195,     0,   196,     0,    74,     0,    73,     0,
    72,     0,    82,     0,    83,     0,    84,     0,    75,     0,
   180,     0,   181,     0,   182,     0,   183,     0,   184,     0,
   185,     0,   186,     0,   187,     0,   188,     0,   156,     0,
   157,     0,   158,     0,   159,     0,   160,     0,   161,     0,
   168,     0,   169,     0,   170,     0,   171,     0,   172,     0,
   173,     0,   178,     0,    48,     0,    49,     0,   154,     0,
   155,     0,   162,     0,   163,     0,   164,     0,   165,     0,
   166,     0,   167,     0,   174,     0,   176,     0,   177,     0,
   175,     0,   318,     0,   325,     0,   327,     0,   331,     0,
   333,     0,   338,     0,   353,     0,   347,     0,   358,     0,
   359,     0,   360,     0,   361,     0,   362,     0,   367,     0,
   371,     0,   380,     0,   382,     0,   384,     0,   385,     0,
   386,     0,   387,     0,   390,     0,   389,     0,   388,     0,
   391,     0,    89,     0,    94,     0,    96,     0,    98,     0,
   100,     0,   104,     0,   113,     0,   111,     0,   119,     0,
   120,     0,   121,     0,   122,     0,   123,     0,   127,     0,
   129,     0,   134,     0,   135,     0,   138,     0,   137,     0,
   139,     0,   140,     0,   141,     0,   142,     0,   143,     0,
   144,     0,    89,   319,     0,   320,   321,   323,   324,     0,
    90,   225,     0,   306,     0,    91,   322,     0,   306,     0,
   225,     0,   306,     0,    92,    16,   350,    17,     0,   306,
     0,    93,    16,   350,    17,     0,   306,     0,    94,   326,
     0,    95,   225,     0,   306,     0,    96,   328,   329,   330,
     0,    90,   225,     0,   306,     0,    91,   225,     0,   306,
     0,    97,   225,     0,   306,     0,    98,   328,   329,   332,
     0,    99,   225,     0,   306,     0,   100,   334,     0,   100,
   335,   336,     0,   101,    16,   337,    17,     0,   102,    16,
   337,    17,     0,   306,     0,   103,    16,   337,    17,     0,
   306,     0,   349,     0,   104,   339,    96,   223,    98,   223,
   340,   345,     0,   105,    16,   349,    17,     0,   106,   101,
    16,   284,    17,   341,   342,     0,   306,     0,   101,    36,
    16,   349,    17,     0,   306,     0,   343,   344,     0,   107,
   110,    36,    16,   349,    17,     0,   306,     0,   108,   110,
    36,    16,   349,    17,     0,   306,     0,   109,    16,   346,
    17,     0,   306,     0,   293,     0,   346,    15,   293,     0,
   111,   112,    62,    16,   348,    17,     0,   349,     0,   306,
     0,   284,     0,   349,    15,   284,     0,   351,     0,   306,
     0,   352,     0,   351,    15,   352,     0,   223,     0,   284,
     0,   113,   225,   354,   355,     0,   113,     0,    43,   284,
     0,   306,     0,   114,   115,   356,     0,   306,     0,   357,
     0,   356,    15,   357,     0,   117,     0,   118,     0,   116,
     0,   119,     0,   119,   223,     0,   120,     0,   120,   223,
     0,   121,     0,   121,   223,     0,   122,     0,   122,   223,
     0,   123,   363,     0,   124,    16,   364,    17,     0,   306,
     0,   365,     0,   364,    15,   365,     0,   284,   366,     0,
   125,     0,   126,     0,   306,     0,   127,   368,     0,   127,
     0,   128,    16,   351,    17,     0,   369,     0,   370,     0,
   369,   370,     0,   370,   369,     0,   102,    16,   351,    17,
     0,   103,    16,   351,    17,     0,   129,   379,   130,   372,
     0,   373,     0,   372,    15,   373,     0,   374,   375,     0,
   379,     0,   379,   131,     0,   376,     0,   375,    15,   376,
     0,   284,   366,   377,     0,   132,     0,   133,    63,   378,
     0,   379,     0,   378,    15,   379,     0,   284,     0,   134,
   381,     0,   134,   381,   223,     0,   136,    16,   364,    17,
     0,   306,     0,   135,   383,     0,   135,   383,   223,     0,
    62,    16,   364,    17,     0,   306,     0,   138,   319,     0,
   137,   326,     0,   139,    95,   223,     0,   140,   223,     0,
   141,   223,     0,   142,   223,     0,   143,   223,     0,   144,
   145,   223,   146,   392,   147,   393,   394,   395,   396,   397,
     0,   303,     0,   303,     0,   148,   284,     0,     0,   149,
   284,     0,     0,   150,    16,   351,    17,     0,     0,   151,
    16,   284,    17,     0,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   474,   476,   481,   517,   519,   520,   527,   536,   538,   541,
   543,   547,   549,   552,   563,   570,   573,   575,   578,   586,
   595,   597,   602,   605,   607,   610,   615,   622,   633,   644,
   657,   659,   660,   673,   675,   678,   680,   681,   688,   703,
   716,   718,   757,   773,   798,   800,   807,   828,   843,   845,
   855,   857,   858,   859,   862,   864,   865,   866,   867,   868,
   869,   870,   871,   872,   873,   874,   875,   876,   877,   878,
   879,   880,   881,   885,   886,   889,   896,   903,   910,   916,
   924,   930,   937,   945,   953,   957,   960,   963,   968,   979,
   986,   992,   999,  1005,  1012,  1019,  1024,  1040,  1054,  1068,
  1074,  1091,  1093,  1098,  1112,  1118,  1129,  1142,  1146,  1161,
  1176,  1190,  1207,  1220,  1226,  1241,  1256,  1282,  1323,  1332,
  1350,  1356,  1364,  1366,  1367,  1368,  1372,  1377,  1385,  1393,
  1401,  1408,  1413,  1417,  1423,  1428,  1432,  1436,  1440,  1444,
  1448,  1452,  1456,  1460,  1464,  1468,  1472,  1478,  1488,  1501,
  1517,  1524,  1540,  1552,  1554,  1555,  1556,  1557,  1558,  1561,
  1569,  1578,  1589,  1596,  1604,  1611,  1619,  1621,  1628,  1630,
  1637,  1647,  1656,  1663,  1671,  1686,  1688,  1691,  1700,  1710,
  1716,  1723,  1729,  1733,  1742,  1744,  1747,  1749,  1750,  1751,
  1763,  1775,  1777,  1780,  1782,  1795,  1810,  1812,  1813,  1814,
  1820,  1828,  1836,  1844,  1845,  1861,  1868,  1877,  1884,  1894,
  1904,  1910,  1919,  1946,  1956,  1961,  1963,  1984,  1988,  1996,
  2001,  2022,  2040,  2044,  2048,  2052,  2060,  2068,  2072,  2076,
  2080,  2087,  2089,  2092,  2098,  2105,  2112,  2118,  2124,  2130,
  2138,  2140,  2141,  2142,  2143,  2144,  2145,  2146,  2147,  2148,
  2149,  2150,  2151,  2152,  2153,  2154,  2155,  2156,  2157,  2158,
  2159,  2160,  2161,  2162,  2163,  2166,  2168,  2169,  2170,  2171,
  2172,  2173,  2174,  2175,  2178,  2180,  2181,  2182,  2183,  2184,
  2185,  2186,  2187,  2188,  2189,  2190,  2191,  2194,  2196,  2199,
  2201,  2202,  2203,  2204,  2205,  2206,  2207,  2208,  2209,  2210,
  2213,  2223,  2225,  2226,  2227,  2228,  2229,  2230,  2231,  2232,
  2233,  2234,  2235,  2236,  2237,  2238,  2239,  2240,  2241,  2242,
  2243,  2244,  2245,  2246,  2247,  2248,  2251,  2253,  2254,  2255,
  2256,  2257,  2258,  2259,  2260,  2261,  2262,  2263,  2264,  2265,
  2266,  2267,  2268,  2269,  2270,  2271,  2272,  2273,  2274,  2275,
  2276,  2284,  2288,  2304,  2306,  2309,  2311,  2315,  2317,  2321,
  2326,  2331,  2336,  2347,  2361,  2363,  2371,  2385,  2387,  2391,
  2393,  2397,  2399,  2407,  2422,  2424,  2432,  2441,  2453,  2461,
  2466,  2470,  2475,  2479,  2488,  2512,  2520,  2526,  2535,  2540,
  2543,  2547,  2552,  2555,  2560,  2563,  2568,  2572,  2578,  2590,
  2604,  2606,  2609,  2615,  2622,  2624,  2627,  2633,  2640,  2647,
  2659,  2677,  2689,  2691,  2694,  2696,  2700,  2702,  2705,  2711,
  2716,  2729,  2739,  2754,  2763,  2777,  2787,  2802,  2812,  2833,
  2843,  2848,  2851,  2857,  2864,  2873,  2879,  2884,  2896,  2907,
  2915,  2920,  2926,  2932,  2938,  2946,  2953,  2969,  2976,  2978,
  2981,  2985,  2987,  2990,  2992,  2995,  3002,  3004,  3008,  3010,
  3013,  3026,  3036,  3048,  3053,  3062,  3073,  3086,  3091,  3099,
  3111,  3124,  3135,  3147,  3158,  3172,  3182,  3208,  3230,  3251,
  3253,  3256,  3258,  3261,  3266,  3269,  3274
};
#endif


#if YYDEBUG != 0 || defined (YYERROR_VERBOSE)

static const char * const yytname[] = {   "$","error","$undefined.","BSTRING_SYM",
"HSTRING_SYM","CSTRING_SYM","UCASEFIRST_IDENT_SYM","LCASEFIRST_IDENT_SYM","NAMEDMACRO_SYM",
"MACRODEFBODY_SYM","BRACEBAL_SYM","NUMBER_ERANGE","NUMBER_SYM","SNACC_ATTRIBUTES",
"DOT_SYM","COMMA_SYM","LEFTBRACE_SYM","RIGHTBRACE_SYM","LEFTPAREN_SYM","RIGHTPAREN_SYM",
"LEFTBRACKET_SYM","RIGHTBRACKET_SYM","LESSTHAN_SYM","MINUS_SYM","GETS_SYM","BAR_SYM",
"TAGS_SYM","BOOLEAN_SYM","INTEGER_SYM","BIT_SYM","STRING_SYM","OCTET_SYM","CONTAINING_SYM",
"ENCODED_SYM","NULL_SYM","SEQUENCE_SYM","OF_SYM","SET_SYM","IMPLICIT_SYM","CHOICE_SYM",
"ANY_SYM","OBJECT_IDENTIFIER_SYM","OPTIONAL_SYM","DEFAULT_SYM","COMPONENTS_SYM",
"UNIVERSAL_SYM","APPLICATION_SYM","PRIVATE_SYM","TRUE_SYM","FALSE_SYM","BEGIN_SYM",
"END_SYM","DEFINITIONS_SYM","EXPLICIT_SYM","ENUMERATED_SYM","EXPORTS_SYM","IMPORTS_SYM",
"REAL_SYM","INCLUDES_SYM","MIN_SYM","MAX_SYM","SIZE_SYM","FROM_SYM","WITH_SYM",
"COMPONENT_SYM","PRESENT_SYM","ABSENT_SYM","DEFINED_SYM","BY_SYM","PLUS_INFINITY_SYM",
"MINUS_INFINITY_SYM","SEMI_COLON_SYM","IA5STRING_SYM","PRINTABLESTRING_SYM",
"NUMERICSTRING_SYM","TELETEXSTRING_SYM","T61STRING_SYM","VIDEOTEXSTRING_SYM",
"VISIBLESTRING_SYM","ISO646STRING_SYM","GRAPHICSTRING_SYM","GENERALSTRING_SYM",
"BMPSTRING_SYM","UNIVERSALSTRING_SYM","UTF8STRING_SYM","GENERALIZEDTIME_SYM",
"UTCTIME_SYM","EXTERNAL_SYM","OBJECTDESCRIPTOR_SYM","OPERATION_SYM","ARGUMENT_SYM",
"RESULT_SYM","ERRORS_SYM","LINKED_SYM","ERROR_SYM","PARAMETER_SYM","BIND_SYM",
"BINDERROR_SYM","UNBIND_SYM","UNBINDERROR_SYM","ASE_SYM","OPERATIONS_SYM","CONSUMERINVOKES_SYM",
"SUPPLIERINVOKES_SYM","AC_SYM","ASES_SYM","REMOTE_SYM","INITIATOR_SYM","RESPONDER_SYM",
"ABSTRACTSYNTAXES_SYM","CONSUMER_SYM","EXTENSIONS_SYM","CHOSEN_SYM","EXTENSION_SYM",
"CRITICAL_SYM","FOR_SYM","DELIVERY_SYM","SUBMISSION_SYM","TRANSFER_SYM","EXTENSIONATTRIBUTE_SYM",
"TOKEN_SYM","TOKENDATA_SYM","SECURITYCATEGORY_SYM","OBJECT_SYM","PORTS_SYM",
"BOXC_SYM","BOXS_SYM","PORT_SYM","ABSTRACTOPS_SYM","REFINE_SYM","AS_SYM","RECURRING_SYM",
"VISIBLE_SYM","PAIRED_SYM","ABSTRACTBIND_SYM","ABSTRACTUNBIND_SYM","TO_SYM",
"ABSTRACTERROR_SYM","ABSTRACTOPERATION_SYM","ALGORITHM_SYM","ENCRYPTED_SYM",
"SIGNED_SYM","SIGNATURE_SYM","PROTECTED_SYM","OBJECTTYPE_SYM","SYNTAX_SYM","ACCESS_SYM",
"STATUS_SYM","DESCRIPTION_SYM","REFERENCE_SYM","INDEX_SYM","DEFVAL_SYM","ATTRIB_ASN1_TYPE_ID",
"ATTRIB_C_TYPE_ID","ATTRIB_C_TYPE_NAME_SYM","ATTRIB_C_FIELD_NAME_SYM","ATTRIB_IS_PDU_SYM",
"ATTRIB_IS_PTR_SYM","ATTRIB_IS_PTR_TYPEDEF_SYM","ATTRIB_IS_PTR_TYPE_REF_SYM",
"ATTRIB_IS_PTR_IN_CHOICE_SYM","ATTRIB_IS_PTR_FOR_OPT_SYM","ATTRIB_OPT_TEST_ROUTINE_SYM",
"ATTRIB_DEFAULT_FIELD_SYM","ATTRIB_PRINT_ROUTINE_SYM","ATTRIB_ENCODE_ROUTINE_SYM",
"ATTRIB_DECODE_ROUTINE_SYM","ATTRIB_FREE_ROUTINE_SYM","ATTRIB_IS_ENC_DEC_SYM",
"ATTRIB_GEN_TYPEDEF_SYM","ATTRIB_GEN_PRINT_ROUTINE_SYM","ATTRIB_GEN_ENCODE_ROUTINE_SYM",
"ATTRIB_GEN_DECODE_ROUTINE_SYM","ATTRIB_GEN_FREE_ROUTINE_SYM","ATTRIB_CHOICE_ID_SYMBOL_SYM",
"ATTRIB_CHOICE_ID_VALUE_SYM","ATTRIB_CHOICE_ID_ENUM_NAME_SYM","ATTRIB_CHOICE_ID_ENUM_FIELD_NAME_SYM",
"ATTRIB_IS_BIG_INT_SYM","ATTRIB_NAMESPACE_SYM","C_CHOICE_SYM","C_LIST_SYM","C_ANY_SYM",
"C_ANYDEFBY_SYM","C_LIB_SYM","C_STRUCT_SYM","C_TYPEDEF_SYM","C_TYPEREF_SYM",
"C_NO_TYPE_SYM","UNKNOWN_SYM","BITSTRING_SYM","OCTETSTRING_SYM","SEQUENCE_OF_SYM",
"SET_OF_SYM","ANY_DEFINED_BY_SYM","LOCAL_TYPE_REF_SYM","IMPORT_TYPE_REF_SYM",
"':'","LineNo","ModuleDefinition","@1","TagDefault","ModuleIdentifier","AssignedIdentifier",
"OptionalSnaccNamespace","ModuleBody","Exports","SymbolsExported","ExportSymbolList",
"Imports","SymbolsImported","SymbolsFromModuleList","SymbolsFromModule","SymbolList",
"Symbol","AssignmentList","AssignmentOrError","Assignment","@2","MacroReference",
"TypeAssignment","ExternalTypeReference","DefinedType","Type","BuiltinType",
"NamedType","BooleanType","IntegerType","NamedNumberList","NamedNumber","SignedNumber",
"EnumeratedType","RealType","BitStringType","NamedBitList","NullType","ExternalType",
"SequenceOpening","SequenceType","ElementTypes","ElementTypeList","ElementType",
"SequenceOfType","SetOpening","SetType","SetOfType","ChoiceType","AlternativeTypes",
"AlternativeTypeList","SelectionType","TaggedType","Tag","ClassNumber","Class",
"AnyType","OctetContainingType","BitContainingType","ObjectIdentifierType","UsefulType",
"CharStrType","Subtype","SubtypeSpec","SubtypeValueSetList","SubtypeValueSet",
"SingleValue","ContainedSubtype","ValueRange","LowerEndPoint","UpperEndPoint",
"LowerEndValue","UpperEndValue","SizeConstraint","PermittedAlphabet","InnerTypeConstraints",
"SingleTypeConstraint","MultipleTypeConstraints","FullSpecification","PartialSpecification",
"TypeConstraints","NamedConstraint","Constraint","ValueConstraint","PresenceConstraint",
"ValueAssignment","Value","DefinedValue","ExternalValueReference","BuiltinValue",
"@3","BooleanValue","SpecialRealValue","NullValue","NamedValue","ObjectIdentifierValue",
"ObjIdComponentList","ObjIdComponent","NumberForm","NameForm","NameAndNumberForm",
"BinaryString","HexString","CharString","number","identifier","modulereference",
"typereference","empty","SnaccDirectives","SnaccDirectiveList","SnaccDirective",
"SnaccDirectiveAsnTypeValue","SnaccDirectiveCTypeValue","SnaccDirectiveBoolType",
"SnaccDirectiveBoolValue","SnaccDirectiveStringType","SnaccDirectiveIntegerType",
"DefinedMacroType","DefinedMacroName","RosOperationMacroType","RosOperationMacroBody",
"RosOpArgument","RosOpResult","RosOpResultType","RosOpErrors","RosOpLinkedOps",
"RosErrorMacroType","RosErrParameter","RosBindMacroType","RosBindArgument","RosBindResult",
"RosBindError","RosUnbindMacroType","RosUnbindError","RosAseMacroType","RosAseSymmetricAse",
"RosAseConsumerInvokes","RosAseSupplierInvokes","RosAseOperationList","RosAcMacroType",
"RosAcNonRoElements","RosAcRoElements","RosAcSymmetricAses","RosAcAsymmetricAses",
"RosAcInitiatorConsumerOf","RosAcResponderConsumerOf","RosAcAbstractSyntaxes",
"OidList","MtsasExtensionsMacroType","PossiblyEmptyValueList","ValueList","PossiblyEmptyTypeOrValueList",
"TypeOrValueList","TypeOrValue","MtsasExtensionMacroType","MtsasExtDefaultVal",
"MtsasExtCritical","MtsasExtCriticalityList","MtsasExtCriticality","MtsasExtensionAttributeMacroType",
"MtsasTokenMacroType","MtsasTokenDataMacroType","MtsasSecurityCategoryMacroType",
"AsnObjectMacroType","AsnPorts","AsnPortList","AsnPort","AsnPortType","AsnPortMacroType",
"AsnOperations","AsnConsumer","AsnSupplier","AsnRefineMacroType","AsnComponentList",
"AsnComponent","AsnObjectSpec","AsnPortSpecList","AsnPortSpec","AsnPortStatus",
"AsnObjectList","AsnObject","AsnAbstractBindMacroType","AsnAbstractBindPorts",
"AsnAbstractUnbindMacroType","AsnAbstractUnbindPorts","AsnAbstractOperationMacroType",
"AsnAbstractErrorMacroType","AfAlgorithmMacroType","AfEncryptedMacroType","AfSignedMacroType",
"AfSignatureMacroType","AfProtectedMacroType","SnmpObjectTypeMacroType","SnmpAccess",
"SnmpStatus","SnmpDescrPart","SnmpReferPart","SnmpIndexPart","SnmpDefValPart", NULL
};
#endif

static const short yyr1[] = {     0,
   198,   200,   199,   201,   201,   201,   202,   203,   203,   204,
   204,   205,   205,   206,   206,   206,   207,   207,   208,   208,
   209,   209,   209,   210,   210,   211,   211,   212,   213,   213,
   214,   214,   214,   215,   215,   216,   216,   216,   217,   217,
   218,   217,   217,   217,   219,   219,   220,   221,   222,   222,
   223,   223,   223,   223,   224,   224,   224,   224,   224,   224,
   224,   224,   224,   224,   224,   224,   224,   224,   224,   224,
   224,   224,   224,   224,   224,   225,   225,   226,   227,   227,
   228,   228,   229,   229,   230,   230,   230,   230,   231,   232,
   233,   233,   234,   235,   236,   237,   238,   238,   239,   240,
   240,   241,   241,   241,   241,   241,   242,   243,   244,   244,
   245,   246,   247,   248,   248,   249,   250,   250,   250,   251,
   252,   252,   253,   253,   253,   253,   254,   254,   255,   256,
   257,   258,   258,   258,   259,   259,   259,   259,   259,   259,
   259,   259,   259,   259,   259,   259,   259,   260,   260,   260,
   261,   262,   262,   263,   263,   263,   263,   263,   263,   264,
   265,   266,   267,   267,   268,   268,   269,   269,   270,   270,
   271,   272,   273,   273,   274,   275,   275,   276,   277,   278,
   278,   279,   279,   280,   281,   281,   282,   282,   282,   282,
   283,   284,   284,   285,   285,   286,   287,   287,   287,   287,
   287,   287,   287,   288,   287,   289,   289,   290,   290,   291,
   292,   292,   293,   294,   294,   295,   295,   295,   296,   297,
   298,   298,   299,   300,   301,   302,   302,   303,   304,   305,
   306,   307,   307,   308,   308,   309,   309,   309,   309,   309,
   310,   310,   310,   310,   310,   310,   310,   310,   310,   310,
   310,   310,   310,   310,   310,   310,   310,   310,   310,   310,
   310,   310,   310,   310,   310,   311,   311,   311,   311,   311,
   311,   311,   311,   311,   312,   312,   312,   312,   312,   312,
   312,   312,   312,   312,   312,   312,   312,   313,   313,   314,
   314,   314,   314,   314,   314,   314,   314,   314,   314,   314,
   315,   316,   316,   316,   316,   316,   316,   316,   316,   316,
   316,   316,   316,   316,   316,   316,   316,   316,   316,   316,
   316,   316,   316,   316,   316,   316,   317,   317,   317,   317,
   317,   317,   317,   317,   317,   317,   317,   317,   317,   317,
   317,   317,   317,   317,   317,   317,   317,   317,   317,   317,
   317,   318,   319,   320,   320,   321,   321,   322,   322,   323,
   323,   324,   324,   325,   326,   326,   327,   328,   328,   329,
   329,   330,   330,   331,   332,   332,   333,   333,   334,   335,
   335,   336,   336,   337,   338,   339,   340,   340,   341,   341,
   342,   343,   343,   344,   344,   345,   345,   346,   346,   347,
   348,   348,   349,   349,   350,   350,   351,   351,   352,   352,
   353,   353,   354,   354,   355,   355,   356,   356,   357,   357,
   357,   358,   358,   359,   359,   360,   360,   361,   361,   362,
   363,   363,   364,   364,   365,   366,   366,   366,   367,   367,
   368,   368,   368,   368,   368,   369,   370,   371,   372,   372,
   373,   374,   374,   375,   375,   376,   377,   377,   378,   378,
   379,   380,   380,   381,   381,   382,   382,   383,   383,   384,
   385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
   394,   395,   395,   396,   396,   397,   397
};

static const short yyr2[] = {     0,
     0,     0,     9,     2,     2,     1,     2,     1,     1,     3,
     1,     3,     1,     3,     3,     1,     1,     1,     1,     4,
     3,     3,     1,     1,     1,     2,     1,     4,     3,     1,
     1,     1,     1,     2,     1,     1,     2,     2,     1,     1,
     0,     6,     3,     5,     1,     1,     6,     4,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     2,     1,     1,     2,     1,     1,     1,     4,
     1,     3,     4,     4,     1,     1,     2,     2,     4,     1,
     2,     5,     1,     1,     1,     3,     3,     2,     2,     1,
     5,     1,     2,     3,     3,     4,     3,     3,     3,     2,
     3,     5,     2,     1,     4,     3,     2,     3,     3,     4,
     1,     1,     1,     1,     1,     1,     1,     4,     4,     4,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     2,     4,     4,
     3,     1,     3,     1,     1,     1,     1,     1,     1,     1,
     2,     4,     1,     2,     1,     2,     1,     1,     1,     1,
     2,     2,     3,     3,     1,     1,     1,     3,     7,     1,
     3,     2,     1,     2,     1,     1,     1,     1,     1,     1,
     5,     1,     1,     1,     1,     4,     1,     1,     1,     1,
     1,     1,     1,     0,     3,     1,     1,     1,     1,     1,
     1,     2,     3,     2,     1,     1,     1,     1,     1,     1,
     4,     4,     1,     1,     1,     1,     1,     1,     1,     1,
     0,     1,     1,     1,     2,     3,     3,     3,     3,     3,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     2,     4,     2,     1,     2,     1,     1,     1,     4,
     1,     4,     1,     2,     2,     1,     4,     2,     1,     2,
     1,     2,     1,     4,     2,     1,     2,     3,     4,     4,
     1,     4,     1,     1,     8,     4,     7,     1,     5,     1,
     2,     6,     1,     6,     1,     4,     1,     1,     3,     6,
     1,     1,     1,     3,     1,     1,     1,     3,     1,     1,
     4,     1,     2,     1,     3,     1,     1,     3,     1,     1,
     1,     1,     2,     1,     2,     1,     2,     1,     2,     2,
     4,     1,     1,     3,     2,     1,     1,     1,     2,     1,
     4,     1,     1,     2,     2,     4,     4,     4,     1,     3,
     2,     1,     2,     1,     3,     3,     1,     3,     1,     3,
     1,     2,     3,     4,     1,     2,     3,     4,     1,     2,
     2,     3,     2,     2,     2,     2,    11,     1,     1,     2,
     0,     2,     0,     4,     0,     4,     0
};

static const short yydefact[] = {     0,
   229,     0,   231,   231,     0,     7,     8,     9,     0,     0,
     2,     6,   228,   227,   226,     0,   215,   216,   217,   218,
   219,   220,     5,     4,     0,   213,   214,     0,     0,     0,
   194,     0,   195,     0,   231,   222,   221,     1,     0,   231,
    11,     0,     0,     0,     0,   231,    16,   196,    10,     0,
   230,   327,   328,   329,   330,   331,   332,   334,   333,   335,
   336,   337,   338,   339,   340,   341,   342,   343,   345,   344,
   346,   347,   348,   349,   350,   351,     0,    17,    19,    32,
    31,    18,    33,     3,     0,     0,    23,    15,    14,     1,
     0,     0,    24,    27,     0,    30,    25,     0,     0,     0,
    35,    36,    39,    40,     0,     0,     0,    22,    21,    26,
     0,     1,    38,     0,    34,    37,   230,   231,    78,    79,
     0,     0,    94,     1,     1,     1,   127,   131,     0,    90,
   137,   136,   135,   141,   142,   143,   144,   145,   146,   147,
   138,   139,   140,   132,   133,    95,   134,   231,   231,   231,
   231,   231,     0,     0,   412,   422,   424,   426,   428,   231,
   440,     0,   231,   231,   231,   231,     0,     0,     0,     0,
     0,     0,    49,    53,     0,    52,    55,    56,    70,    71,
    58,    59,    60,     0,    61,    62,     0,    63,    64,    65,
    66,    67,     0,    68,    72,    57,    69,    75,    74,    54,
     0,     0,    50,    51,   302,   303,   304,   305,   306,   307,
   309,   308,   310,   311,   312,   313,   314,   315,   316,   317,
   318,   319,   320,   321,   322,   325,   324,   323,   326,   231,
    20,    29,     0,     1,    43,     0,    45,    46,   123,   124,
   125,     0,   126,     0,    91,    73,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   355,   352,   231,
     0,   366,   364,     0,   369,   231,   231,     0,     0,   381,
   377,   231,     0,     0,     0,    77,   231,     0,   423,   425,
   427,   429,     0,   432,   430,     0,     0,     0,   439,   442,
   443,   223,   224,   225,    86,    85,   204,     0,   210,   206,
   207,   208,   209,   200,   461,   193,   192,   197,   199,   198,
   202,   201,   203,     0,     0,   465,   462,     0,   469,   466,
   471,   470,     0,   473,   474,   475,   476,     0,     0,     1,
   148,    98,     0,   102,     0,   231,   100,     0,   110,     0,
     0,     0,   117,     0,     1,     0,     0,   290,   291,   275,
   276,   277,   278,   279,   280,   292,   293,   294,   295,   296,
   297,   281,   282,   283,   284,   285,   286,   298,   301,   299,
   300,   287,   233,     1,   232,   234,     0,     0,     0,    28,
    41,     0,     0,   122,   121,     0,    81,     0,     0,     0,
     0,   107,   171,    96,     0,   111,   108,     0,     0,     0,
     0,   354,   231,   357,   231,   365,   368,     0,   371,   231,
   231,     0,     0,     0,   383,   378,     0,     0,     0,     0,
   414,   231,    76,     0,     0,     0,     0,   444,   445,     0,
    88,    87,     0,     0,   463,     0,   467,   472,     0,     0,
   168,     0,     0,     0,   152,   154,   155,   156,     0,   163,
   158,   157,   159,   160,     0,     0,   103,     0,    97,   231,
    99,     0,   109,   118,   119,   116,     0,     0,     0,     0,
   235,     0,     0,     0,     0,    44,   120,     0,    80,     0,
    93,     0,   130,   129,   150,   149,   114,     0,   231,   128,
    89,   358,   359,   356,     0,   361,   231,   370,     0,   373,
   367,     0,   376,   374,   403,     0,   384,     0,     0,     0,
     0,   231,   413,     0,   416,   411,   231,     0,   433,    94,
   409,   410,   195,     0,     0,   407,     0,     0,   205,   448,
   449,     0,   452,     0,     0,     0,   161,   172,     0,     0,
   151,     0,     0,   164,   191,   105,   211,   104,   195,     1,
     0,    48,   242,   243,   246,   250,   252,   254,   255,   247,
   249,   248,   261,   260,   259,   265,   262,   263,   264,   241,
   244,   245,   251,   253,   256,   257,   258,   236,   266,   267,
   268,   269,   270,   271,   272,   273,   274,   237,   231,   288,
   289,   238,   239,   240,    42,    82,     0,     0,    92,   112,
   231,   113,   231,     0,   363,   353,   372,   375,   379,     0,
   380,     0,   386,     0,   402,     0,   401,     0,   436,   437,
   438,   435,     0,   431,     1,     0,   446,   447,   441,     0,
   231,   451,   454,   453,   464,   468,   478,     0,   231,   174,
   176,   177,   175,   173,   153,     0,   212,     0,   106,    47,
    83,    84,     0,   406,     0,   405,   231,   404,   382,   231,
   400,   421,   419,   420,   415,   417,   434,     0,   408,   450,
     0,     0,     0,     0,   185,     0,   180,   183,   231,   231,
   186,     0,   170,   162,   165,   169,   101,   115,   360,     0,
     0,   388,   231,     0,   457,     0,   456,   455,   479,   481,
     0,   231,   178,   190,   187,   188,   184,   189,   182,   166,
   362,     0,     0,   397,   385,   418,     0,     0,   483,     0,
   181,     0,     0,   458,   459,   480,     0,   485,   231,     0,
   398,     0,     0,   482,     0,   487,     0,   231,     0,   396,
   460,     0,     0,   477,   179,     0,   390,   231,   399,     0,
     0,     0,     0,   393,   387,   231,   484,     0,     0,     0,
     0,   395,   391,   486,     0,     0,     0,   389,     0,     0,
     0,     0,   392,     0,   394,     0,     0,     0
};

static const short yydefgoto[] = {    42,
   776,    25,    11,     2,     6,    40,    45,    46,    77,    78,
    86,    92,    93,    94,    95,    96,   100,   101,   102,   475,
   235,   103,   173,   174,   276,   176,   334,   177,   178,   386,
   387,   304,   179,   180,   181,   482,   182,   183,   184,   185,
   335,   336,   337,   186,   187,   188,   189,   190,   488,   489,
   191,   192,   193,   383,   242,   194,   195,   196,   197,   198,
   199,   200,   331,   444,   445,   446,   447,   448,   449,   684,
   450,   685,   451,   452,   453,   644,   640,   641,   642,   676,
   677,   678,   679,   707,   104,   505,   306,    31,   307,   430,
   308,   309,   310,   548,     7,    16,    17,    18,    19,    20,
   311,   312,   313,    21,    33,   202,   203,   373,   374,   375,
   376,   578,   588,   377,   592,   378,   379,   204,    83,   205,
   259,   260,   405,   494,   497,   606,   206,   263,   207,   266,
   410,   501,   208,   504,   209,   271,   272,   416,   506,   210,
   274,   693,   748,   755,   756,   763,   715,   732,   211,   616,
   507,   655,   656,   526,   212,   422,   516,   665,   666,   213,
   214,   215,   216,   217,   285,   518,   519,   622,   218,   289,
   290,   291,   219,   530,   531,   532,   632,   633,   697,   724,
   533,   220,   317,   221,   320,   222,   223,   224,   225,   226,
   227,   228,   229,   638,   700,   719,   728,   736,   744
};

static const short yypact[] = {    57,
-32768,    28,    82,    36,   111,-32768,-32768,-32768,    78,    98,
-32768,-32768,-32768,-32768,-32768,   129,-32768,-32768,-32768,-32768,
-32768,   117,-32768,-32768,   106,-32768,-32768,   196,    89,   136,
-32768,   160,-32768,   168,    14,-32768,-32768,-32768,    -7,   150,
-32768,   207,   226,   498,   194,   209,   201,-32768,-32768,   206,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,   208,   266,-32768,-32768,
-32768,-32768,-32768,-32768,  1008,   146,-32768,-32768,-32768,-32768,
   213,   216,  2243,-32768,     3,-32768,-32768,   218,   262,    50,
-32768,   221,-32768,-32768,  2187,   267,  2243,-32768,-32768,-32768,
  2243,-32768,-32768,  2299,-32768,-32768,   276,   112,-32768,   277,
   264,   265,-32768,   -19,    -1,-32768,   229,-32768,   281,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,   210,   204,   225,
   225,    42,   197,   189,  2187,  2187,  2187,  2187,  2187,   179,
   -59,   511,   169,   246,   204,   210,   214,  2187,  2187,  2187,
  2187,   165,-32768,-32768,     9,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,  1423,-32768,-32768,  1562,-32768,-32768,-32768,
-32768,-32768,  1687,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
   289,   300,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,  2348,
-32768,-32768,    57,-32768,-32768,   305,-32768,-32768,-32768,-32768,
-32768,   196,-32768,   207,    16,   288,  2187,   304,   310,   291,
  2187,   312,   294,   315,   268,   207,  2187,-32768,-32768,   241,
  2187,-32768,-32768,  2187,-32768,   242,   242,   318,   319,-32768,
-32768,   234,   322,   243,   278,   304,   298,  1937,   304,   304,
   304,   304,   326,-32768,-32768,   329,   330,   332,-32768,   251,
   253,-32768,-32768,-32768,-32768,-32768,-32768,   139,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,   227,   340,-32768,  2187,   342,-32768,  2187,
-32768,-32768,  2187,   304,   304,   304,   304,  2187,   122,-32768,
-32768,-32768,   324,   118,   344,   651,-32768,  1812,-32768,   346,
  2187,  2187,   304,  2187,-32768,   167,   170,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,  2348,-32768,   173,   174,   175,-32768,
-32768,  2355,   347,-32768,-32768,    76,-32768,   351,   207,  2187,
  2187,   304,-32768,-32768,  2187,   304,-32768,  2187,  2187,   207,
    93,-32768,  2187,-32768,   273,-32768,-32768,  2187,-32768,   279,
   274,   511,   511,   358,-32768,-32768,   511,  2187,   359,   511,
-32768,   263,   304,   511,  1284,  1284,  1284,-32768,-32768,   368,
-32768,-32768,   511,   511,   304,   511,   304,   304,    -4,  2187,
-32768,   304,    15,    45,-32768,-32768,-32768,-32768,   365,   361,
-32768,-32768,-32768,    23,   511,  2187,-32768,   511,-32768,  2348,
-32768,   348,-32768,   304,   304,   304,   374,   860,    37,  2187,
-32768,   127,   380,   375,   377,-32768,-32768,   207,-32768,   109,
   373,   372,   304,   304,   304,   304,-32768,   376,   815,-32768,
-32768,-32768,-32768,-32768,   378,-32768,   297,-32768,  2187,-32768,
-32768,  2187,-32768,-32768,-32768,   382,   385,   384,   511,   148,
     2,   511,-32768,   280,-32768,-32768,   132,   157,-32768,-32768,
   304,-32768,   289,   388,   171,-32768,   172,   184,-32768,   389,
-32768,   511,   261,   198,   211,   207,   304,-32768,   387,   304,
-32768,   122,   391,-32768,-32768,   304,-32768,-32768,   511,-32768,
  2187,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,  1009,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,   390,   392,-32768,-32768,
  2348,-32768,  1284,   394,-32768,-32768,-32768,-32768,-32768,   511,
-32768,   397,-32768,  2187,-32768,   398,   385,    51,-32768,-32768,
-32768,-32768,   511,-32768,-32768,  1284,-32768,-32768,-32768,   511,
   132,   393,-32768,-32768,-32768,-32768,-32768,   259,    99,-32768,
-32768,-32768,-32768,-32768,-32768,  1190,-32768,  2062,   304,-32768,
-32768,-32768,  2187,-32768,   399,   403,  1284,-32768,-32768,     1,
-32768,-32768,-32768,-32768,   404,-32768,-32768,   254,-32768,-32768,
   130,   511,   207,   407,-32768,   212,-32768,-32768,    11,   304,
-32768,    18,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   405,
   306,-32768,   314,    51,-32768,   366,-32768,-32768,-32768,   282,
   417,    55,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,   416,   419,-32768,-32768,-32768,   511,   511,   290,   422,
-32768,   511,    82,   425,-32768,-32768,   511,   292,    55,   424,
-32768,   215,   511,-32768,   427,   293,   219,   345,    82,-32768,
-32768,  1284,   429,-32768,-32768,   411,-32768,   341,-32768,   220,
   511,   434,   343,-32768,-32768,   353,-32768,   445,   511,   430,
   355,-32768,-32768,-32768,   223,   447,   431,-32768,   511,   453,
   224,   511,-32768,   233,-32768,   470,   471,-32768
};

static const short yypgoto[] = {   -86,
-32768,-32768,-32768,   240,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,   381,-32768,    -8,-32768,   383,-32768,-32768,
    94,-32768,-32768,-32768,   -74,-32768,  -152,-32768,-32768,  -240,
     4,    -2,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
   299,-32768,  -167,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,  -242,-32768,   -58,-32768,-32768,-32768,-32768,-32768,
-32768,  -197,   147,-32768,-32768,-32768,-32768,-32768,-32768,  -241,
  -213,  -190,-32768,-32768,-32768,  -151,   -26,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,  -668,-32768,   475,   464,-32768,-32768,
-32768,-32768,-32768,   252,   608,     0,   -39,    46,  -323,-32768,
   121,-32768,-32768,-32768,-32768,-32768,-32768,-32768,  -102,-32768,
   327,-32768,-32768,-32768,-32768,-32768,-32768,   333,-32768,   349,
   230,-32768,-32768,-32768,-32768,-32768,-32768,-32768,  -398,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -410,  -155,  -417,  -123,-32768,-32768,-32768,-32768,  -187,-32768,
-32768,-32768,-32768,-32768,-32768,  -181,  -115,  -121,-32768,-32768,
   222,   235,-32768,-32768,  -119,-32768,-32768,  -153,-32768,-32768,
  -161,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768
};


#define	YYLAST		2526


static const short yytable[] = {     3,
   314,    30,   277,   107,    81,   393,   510,   525,   527,   528,
   305,   238,   461,   329,   508,   401,   247,   111,   329,   329,
   292,   293,   294,     1,    13,   233,   329,    34,   295,   296,
   175,   389,   330,   297,   251,    79,  -167,   249,   252,   254,
   298,   248,   286,   287,  -167,    81,   106,   390,     8,    12,
    98,   299,   704,    81,   731,    51,    13,    99,   539,   248,
   106,    13,     1,   541,   112,   300,   301,    81,   288,   542,
   749,    81,   329,     9,   237,   705,   706,   683,   540,     4,
    41,   279,   280,   281,   282,    47,   302,   303,    10,    82,
   478,    87,   479,   324,   325,   326,   327,     5,   231,   614,
   -12,   617,   232,    23,   402,    13,   691,   478,   406,   491,
   612,   407,   674,   236,     1,    13,   329,    13,   343,   295,
   296,    14,    15,    24,   292,   293,   294,     1,    13,    29,
    97,   298,   295,   296,    28,    13,   550,   297,    35,    14,
    15,   536,   268,   269,   298,    26,    98,   381,   481,   431,
   432,    51,    13,    99,    36,   299,   239,   240,   241,   457,
   458,    34,   610,   243,   613,   602,   662,   663,   664,   300,
   301,   623,   392,   624,   590,   591,   396,   454,    37,   440,
   441,    38,   248,   442,   443,   626,   626,   627,   628,    43,
   302,   303,    39,   258,   262,   265,   265,   270,   626,   538,
   629,     1,    13,   423,    44,   284,    14,    15,   316,   319,
   262,   258,   623,    13,   635,   384,   579,   580,   581,   582,
   583,   584,   585,   586,   587,   623,   702,   636,   703,   739,
    49,   740,     3,   702,   626,   745,   757,   610,   610,   768,
   773,    34,   435,   455,    84,   437,   487,   610,   438,   775,
   492,   -13,   534,   439,   535,   498,   619,   620,   467,    51,
    13,   695,   696,   423,    85,   650,   464,   465,   513,   466,
   250,   253,   517,   522,   522,   522,    88,   653,    89,   238,
    90,   305,   517,   108,   517,   114,   109,   470,   113,  -229,
   230,   116,   244,   245,   246,   255,   256,   643,   261,   257,
   275,   273,   283,   545,   315,   404,   547,   318,   323,   328,
   344,   409,   409,   345,   264,   483,   484,   415,   382,   391,
   485,   329,   421,   486,   750,   394,   395,   397,    34,   398,
   399,   403,   408,   412,   413,   400,   414,   417,   418,   419,
   420,   424,   237,   511,   425,   426,   607,   427,   765,   608,
   521,   521,   521,   287,   286,   434,   433,   436,   771,   456,
   459,   774,   463,   468,   495,   537,   469,   477,   480,   472,
   473,   474,   502,   509,   512,   499,   514,   529,   543,    51,
   631,   546,   544,   551,   593,   595,   594,   478,   599,   604,
   454,   634,   600,   603,   618,   589,   675,   647,   609,   610,
   611,   625,   639,   630,   646,   673,   712,   672,   651,   657,
   652,    34,    34,   659,   661,   689,    34,   626,   694,    34,
   701,   711,   713,    34,   524,   524,   524,   552,   717,   718,
   720,   722,    34,    34,   723,    34,   729,   675,   727,   733,
   738,   735,   742,   743,   751,   746,   752,   753,   493,   759,
   496,   522,   760,   598,    34,   500,   503,    34,   658,   675,
   761,   764,   769,   648,   767,   766,   770,   515,   772,   777,
   778,   517,   380,   110,   522,   476,   649,   597,   305,    34,
   687,   596,   115,   645,   710,   340,   675,   737,   721,   709,
    27,    32,   322,   385,   686,   471,   411,   321,    50,   267,
   688,   690,   669,    51,    13,   522,   716,   667,    34,   671,
   670,    34,   429,   292,   293,   294,     1,    13,   698,     0,
   631,   295,   296,     0,   428,     0,   297,     0,   521,     0,
   686,    34,     0,   298,     0,     0,     0,     0,   668,   660,
     0,    34,   605,     0,   299,     0,     0,     0,    34,     0,
     0,   521,     0,     0,     0,   725,     0,   615,   300,   301,
     0,     0,   621,     0,     0,   305,   726,     0,  -231,     0,
   730,   741,     0,     0,     0,   734,     0,     0,     0,   302,
   303,   305,   521,     0,     0,     0,    52,     0,     0,     0,
   522,    53,     0,    54,     0,    55,     0,    56,     0,   758,
     0,    57,   524,     0,     0,     0,     0,     0,    58,    34,
    59,     0,    22,     0,     0,     0,    60,    61,    62,    63,
    64,     0,    34,    22,    65,   524,    66,     0,   552,    34,
     0,    67,    68,     0,    69,    70,    71,    72,    73,    74,
    75,    76,     0,     0,     0,    34,     0,     0,   654,    48,
     0,    80,     0,     0,     0,     0,   524,     0,     0,     0,
     0,     0,     0,     0,     0,   460,     0,   521,     0,     0,
     0,    34,     0,     0,     0,     0,   621,     0,     0,     0,
     0,    34,     0,     0,   681,     0,     0,     0,     0,     0,
     0,     0,    80,   105,     0,     0,     0,     0,     0,     0,
    80,     0,   654,     0,     0,   692,     0,   105,     0,     0,
     0,     0,   201,     0,    80,     0,    34,    34,    80,     0,
     0,    34,     0,     0,   708,   681,    34,     0,     0,     0,
     0,     0,    34,     0,     0,     0,     0,     0,   714,     0,
     0,   524,     0,     0,     0,     0,     0,   681,     0,     0,
    34,     0,     0,     0,     0,     0,     0,     0,    34,     0,
     0,     0,   278,   201,   201,   201,   201,     0,    34,     0,
     0,    34,     0,     0,   681,   201,   201,   201,   201,     0,
     0,     0,     0,   747,     0,     0,     0,     0,     0,     0,
     0,   338,     0,   754,   338,     0,     0,     0,     0,     0,
   201,   762,   346,   347,   348,   349,   350,   351,   352,   353,
   354,   355,   356,   357,   358,   359,   360,   361,   362,   363,
   364,   365,   366,   367,   368,   369,   370,   371,   372,   601,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   388,     0,     0,   201,     0,     0,     0,   201,     0,
     0,     0,     0,   388,   278,     0,     0,     0,   278,     0,
     0,   278,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   201,   553,   554,     0,     0,
     0,     0,     0,   555,   556,     0,   557,     0,   558,   559,
   560,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   561,     0,     0,   562,     0,     0,     0,
     0,     0,     0,     0,   201,     0,     0,   201,     0,     0,
   201,   563,   564,   565,   566,   201,     0,     0,     0,     0,
     0,   567,   568,   569,     0,   201,     0,     0,   201,   201,
     0,   201,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   346,   347,   348,   349,
   350,   351,   352,   353,   354,   355,   356,   357,   358,   359,
   360,   361,   362,   363,   364,   365,   366,   367,   368,   369,
   370,   371,   372,     0,     0,     0,   388,   201,   201,     0,
     0,     0,   201,     0,     0,   201,   278,   490,    91,     0,
   278,     0,     0,    51,    13,   278,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   201,   329,     0,     0,     0,
     0,     0,   523,   523,   523,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   201,   570,   571,
   572,   573,   574,   575,   576,   577,     0,     0,     0,     0,
     0,     0,     0,   201,     0,   549,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   201,  -231,     0,
     0,     0,     0,     0,     0,   388,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    52,     0,     0,     0,
     0,    53,     0,    54,     0,    55,   278,    56,     0,   278,
     0,    57,     0,     0,     0,     0,     0,     0,    58,     0,
    59,     0,     0,     0,     0,     0,    60,    61,    62,    63,
    64,     0,     0,     0,    65,     0,    66,     0,     0,     0,
     0,    67,    68,   637,    69,    70,    71,    72,    73,    74,
    75,    76,     0,     0,     0,     0,     0,     0,   201,     0,
   346,   347,   348,   349,   350,   351,   352,   353,   354,   355,
   356,   357,   358,   359,   360,   361,   362,   363,   364,   365,
   366,   367,   368,   369,   370,   371,   372,     0,     0,     0,
     0,     0,   292,   293,   294,     1,    13,     0,     0,     0,
   295,   296,     0,     0,     0,   297,     0,     0,     0,     0,
   523,   682,   298,     0,     0,     0,     0,     0,     0,     0,
     0,   201,     0,   299,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   523,     0,     0,     0,   300,   301,     0,
     0,     0,     0,     0,     0,     0,   680,     0,     0,   683,
     0,     0,     0,     0,     0,   338,     0,     0,   302,   303,
   278,     0,     0,     0,   523,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    48,     0,     0,     0,     0,
   699,     0,     0,     0,     0,     0,   292,   293,   294,   117,
    13,     0,     0,     0,   295,   296,     0,     0,     0,   297,
     0,     0,     0,   118,     0,     0,   298,     0,     0,   680,
   119,   120,   121,     0,   122,     0,     0,   520,   124,     0,
   125,     0,   126,   127,   128,     0,     0,     0,     0,     0,
     0,   300,   301,     0,     0,     0,   680,   129,     0,     0,
   130,     0,     0,     0,     0,     0,     0,     0,     0,   523,
     0,     0,   302,   303,     0,   131,   132,   133,   134,   135,
   136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
   146,   147,   148,     0,     0,     0,     0,   149,     0,   150,
     0,   151,     0,   152,     0,     0,     0,   153,     0,     0,
     0,     0,     0,     0,   154,     0,   155,     0,     0,     0,
     0,     0,   156,   157,   158,   159,   160,     0,     0,     0,
   161,     0,   162,     0,     0,     0,     0,   163,   164,     0,
   165,   166,   167,   168,   169,   170,   171,   172,   117,    13,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   332,
     0,     0,   118,     0,     0,     0,     0,     0,     0,   119,
   120,   121,     0,   122,     0,     0,   123,   124,     0,   125,
     0,   126,   127,   128,     0,     0,   333,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   129,     0,     0,   130,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   131,   132,   133,   134,   135,   136,
   137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
   147,   148,     0,     0,     0,     0,   149,     0,   150,     0,
   151,     0,   152,     0,     0,     0,   153,     0,     0,     0,
     0,     0,     0,   154,     0,   155,     0,     0,     0,     0,
     0,   156,   157,   158,   159,   160,     0,     0,     0,   161,
     0,   162,     0,     0,     0,     0,   163,   164,     0,   165,
   166,   167,   168,   169,   170,   171,   172,   117,    13,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   339,     0,
     0,   118,     0,     0,     0,     0,     0,     0,   119,   120,
   121,     0,   122,     0,     0,   123,   124,     0,   125,     0,
   126,   127,   128,     0,     0,   333,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   129,     0,     0,   130,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   131,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,     0,     0,     0,     0,   149,     0,   150,     0,   151,
     0,   152,     0,     0,     0,   153,     0,     0,     0,     0,
     0,     0,   154,     0,   155,     0,     0,     0,     0,     0,
   156,   157,   158,   159,   160,     0,     0,     0,   161,     0,
   162,     0,   117,    13,     0,   163,   164,     0,   165,   166,
   167,   168,   169,   170,   171,   172,   118,     0,     0,     0,
     0,     0,     0,   119,   120,   121,     0,   122,     0,     0,
   123,   124,     0,   125,   341,   126,   127,   128,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   342,
   129,     0,     0,   130,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   131,   132,
   133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
   143,   144,   145,   146,   147,   148,     0,     0,     0,     0,
   149,     0,   150,     0,   151,     0,   152,     0,     0,     0,
   153,     0,     0,     0,     0,     0,     0,   154,     0,   155,
     0,     0,     0,     0,     0,   156,   157,   158,   159,   160,
     0,     0,     0,   161,     0,   162,     0,   117,    13,     0,
   163,   164,     0,   165,   166,   167,   168,   169,   170,   171,
   172,   118,     0,   344,     0,     0,     0,     0,   119,   120,
   121,     0,   122,     0,     0,   123,   124,     0,   125,     0,
   126,   127,   128,     0,     0,   462,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   129,     0,     0,   130,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   131,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,     0,     0,     0,     0,   149,     0,   150,     0,   151,
     0,   152,     0,     0,     0,   153,     0,     0,     0,     0,
     0,     0,   154,     0,   155,     0,     0,     0,     0,     0,
   156,   157,   158,   159,   160,     0,     0,     0,   161,     0,
   162,     0,   117,    13,     0,   163,   164,     0,   165,   166,
   167,   168,   169,   170,   171,   172,   118,     0,   344,     0,
     0,     0,     0,   119,   120,   121,     0,   122,     0,     0,
   123,   124,     0,   125,     0,   126,   127,   128,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   129,     0,     0,   130,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   131,   132,
   133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
   143,   144,   145,   146,   147,   148,     0,     0,     0,     0,
   149,     0,   150,     0,   151,     0,   152,     0,     0,     0,
   153,     0,     0,     0,     0,     0,     0,   154,     0,   155,
     0,     0,     0,     0,     0,   156,   157,   158,   159,   160,
     0,     0,     0,   161,     0,   162,     0,   117,    13,     0,
   163,   164,     0,   165,   166,   167,   168,   169,   170,   171,
   172,   118,     0,     0,     0,     0,     0,     0,   119,   120,
   121,     0,   122,     0,     0,   123,   124,     0,   125,     0,
   126,   127,   128,     0,     0,   333,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   129,     0,     0,   130,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   131,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,     0,     0,     0,     0,   149,     0,   150,     0,   151,
     0,   152,     0,     0,     0,   153,     0,     0,     0,     0,
     0,     0,   154,     0,   155,     0,     0,     0,     0,     0,
   156,   157,   158,   159,   160,     0,     0,     0,   161,     0,
   162,     0,   117,    13,     0,   163,   164,     0,   165,   166,
   167,   168,   169,   170,   171,   172,   118,     0,     0,     0,
     0,     0,     0,   119,   120,   121,     0,   122,     0,     0,
   123,   124,     0,   125,     0,   126,   127,   128,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   129,     0,     0,   130,     0,     0,     0,     0,    51,    13,
     0,     0,     0,     0,     0,     0,     0,     0,   131,   132,
   133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
   143,   144,   145,   146,   147,   148,     0,     0,     0,     0,
   149,     0,   150,     0,   151,     0,   152,     0,     0,     0,
   153,     0,     0,     0,     0,     0,     0,   154,     0,   155,
     0,     0,     0,     0,   117,   156,   157,   158,   159,   160,
     0,     0,     0,   161,     0,   162,     0,     0,     0,     0,
   163,   164,     0,   165,   166,   167,   168,   169,   170,   171,
   172,    52,     0,     0,     0,     0,    53,     0,    54,     0,
    55,     0,    56,     0,     0,     0,    57,     0,   234,     0,
     0,     0,     0,    58,     0,    59,     0,     0,     0,     0,
    51,    60,    61,    62,    63,    64,     0,     0,     0,    65,
     0,    66,     0,     0,     0,     0,    67,    68,     0,    69,
    70,    71,    72,    73,    74,    75,    76,    52,     0,     0,
     0,     0,    53,     0,    54,     0,    55,     0,    56,     0,
     0,     0,    57,     0,     0,     0,     0,     0,     0,    58,
     0,    59,     0,     0,     0,     0,     0,    60,    61,    62,
    63,    64,     0,     0,     0,    65,     0,    66,     0,     0,
     0,     0,    67,    68,     0,    69,    70,    71,    72,    73,
    74,    75,    76,    52,     0,     0,     0,     0,    53,     0,
    54,     0,    55,     0,    56,     0,     0,     0,    57,     0,
     0,     0,     0,     0,     0,    58,     0,    59,     0,     0,
     0,     0,     0,    60,    61,    62,    63,    64,     0,     0,
     0,    65,     0,    66,     0,     0,     0,     0,    67,    68,
     0,    69,    70,    71,    72,    73,    74,    75,    76,   346,
   347,   348,   349,   350,   351,   352,   353,   354,   355,   356,
   357,   358,   359,   360,   361,   362,   363,   364,   365,   366,
   367,   368,   369,   370,   371,   372
};

static const short yycheck[] = {     0,
   162,    28,   155,    90,    44,   248,   417,   425,   426,   427,
   162,   114,   336,    18,   413,   256,    36,    15,    18,    18,
     3,     4,     5,     6,     7,   112,    18,    28,    11,    12,
   105,    16,    24,    16,    36,    44,    14,   124,   125,   126,
    23,    61,   102,   103,    22,    85,    86,    32,     3,     4,
     1,    34,    42,    93,   723,     6,     7,     8,    44,    61,
   100,     7,     6,    19,    62,    48,    49,   107,   128,    25,
   739,   111,    18,    38,   114,    65,    66,    60,    64,    52,
    35,   156,   157,   158,   159,    40,    69,    70,    53,    44,
    15,    46,    17,   168,   169,   170,   171,    16,   107,    98,
    51,   512,   111,    26,   257,     7,   106,    15,   261,    17,
   509,   264,    14,   114,     6,     7,    18,     7,   193,    11,
    12,    11,    12,    26,     3,     4,     5,     6,     7,    24,
    85,    23,    11,    12,    18,     7,   460,    16,    50,    11,
    12,   146,   101,   102,    23,    17,     1,   234,   389,    11,
    12,     6,     7,     8,    19,    34,    45,    46,    47,    42,
    43,   162,    15,   118,    17,   489,   116,   117,   118,    48,
    49,    15,   247,    17,    48,    49,   251,   329,    19,    58,
    59,    14,    61,    62,    63,    15,    15,    17,    17,   197,
    69,    70,   179,   148,   149,   150,   151,   152,    15,   442,
    17,     6,     7,   278,    55,   160,    11,    12,   163,   164,
   165,   166,    15,     7,    17,   242,   180,   181,   182,   183,
   184,   185,   186,   187,   188,    15,    15,    17,    17,    15,
     5,    17,   233,    15,    15,    17,    17,    15,    15,    17,
    17,   242,   317,   330,    51,   320,   399,    15,   323,    17,
   403,    51,   434,   328,   436,   408,   125,   126,   345,     6,
     7,   132,   133,   338,    56,   589,   341,   342,   420,   344,
   124,   125,   424,   425,   426,   427,    71,   601,    71,   382,
    15,   433,   434,    71,   436,    24,    71,   374,    71,    14,
    24,    71,    16,    30,    30,    67,    16,   540,    95,    90,
   112,   105,   124,   455,   136,   260,   458,    62,    95,   145,
    22,   266,   267,    14,    90,   390,   391,   272,    14,    32,
   395,    18,   277,   398,   742,    16,    36,    16,   329,    36,
    16,    91,    91,    16,    16,    68,   103,    16,    96,    62,
    43,    16,   382,   418,    16,    16,   499,    16,   759,   502,
   425,   426,   427,   103,   102,    16,   130,    16,   769,    36,
    17,   772,    17,   197,    92,   440,   197,    21,    18,   197,
   197,   197,    99,    16,    16,    97,   114,    10,    14,     6,
   532,   456,    22,    36,     5,     9,    12,    15,    17,    93,
   542,   131,    17,    16,   115,   470,   639,   549,    17,    15,
    17,    14,    16,    15,    14,   147,   101,    15,    19,    16,
    19,   412,   413,    17,    17,    17,   417,    15,    15,   420,
    14,    17,   109,   424,   425,   426,   427,   467,    63,   148,
    14,    16,   433,   434,    16,   436,    15,   680,   149,    15,
    17,   150,    16,   151,    16,   101,    36,   107,   403,    16,
   405,   603,   110,   480,   455,   410,   411,   458,   610,   702,
   108,    17,    16,   550,   110,    36,    36,   422,    16,     0,
     0,   623,   233,    93,   626,   382,   551,   480,   630,   480,
   648,   478,   100,   542,   682,   187,   729,   729,   702,   680,
    16,    28,   166,   242,   646,   375,   267,   165,     1,   151,
   653,   657,   626,     6,     7,   657,   694,   623,   509,   631,
   630,   512,   291,     3,     4,     5,     6,     7,   672,    -1,
   672,    11,    12,    -1,   290,    -1,    16,    -1,   603,    -1,
   682,   532,    -1,    23,    -1,    -1,    -1,    -1,   625,   614,
    -1,   542,   497,    -1,    34,    -1,    -1,    -1,   549,    -1,
    -1,   626,    -1,    -1,    -1,   717,    -1,   512,    48,    49,
    -1,    -1,   517,    -1,    -1,   717,   718,    -1,    71,    -1,
   722,   733,    -1,    -1,    -1,   727,    -1,    -1,    -1,    69,
    70,   733,   657,    -1,    -1,    -1,    89,    -1,    -1,    -1,
   742,    94,    -1,    96,    -1,    98,    -1,   100,    -1,   751,
    -1,   104,   603,    -1,    -1,    -1,    -1,    -1,   111,   610,
   113,    -1,     5,    -1,    -1,    -1,   119,   120,   121,   122,
   123,    -1,   623,    16,   127,   626,   129,    -1,   668,   630,
    -1,   134,   135,    -1,   137,   138,   139,   140,   141,   142,
   143,   144,    -1,    -1,    -1,   646,    -1,    -1,   603,    42,
    -1,    44,    -1,    -1,    -1,    -1,   657,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    15,    -1,   742,    -1,    -1,
    -1,   672,    -1,    -1,    -1,    -1,   631,    -1,    -1,    -1,
    -1,   682,    -1,    -1,   639,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    85,    86,    -1,    -1,    -1,    -1,    -1,    -1,
    93,    -1,   657,    -1,    -1,   660,    -1,   100,    -1,    -1,
    -1,    -1,   105,    -1,   107,    -1,   717,   718,   111,    -1,
    -1,   722,    -1,    -1,   679,   680,   727,    -1,    -1,    -1,
    -1,    -1,   733,    -1,    -1,    -1,    -1,    -1,   693,    -1,
    -1,   742,    -1,    -1,    -1,    -1,    -1,   702,    -1,    -1,
   751,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   759,    -1,
    -1,    -1,   155,   156,   157,   158,   159,    -1,   769,    -1,
    -1,   772,    -1,    -1,   729,   168,   169,   170,   171,    -1,
    -1,    -1,    -1,   738,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   184,    -1,   748,   187,    -1,    -1,    -1,    -1,    -1,
   193,   756,   152,   153,   154,   155,   156,   157,   158,   159,
   160,   161,   162,   163,   164,   165,   166,   167,   168,   169,
   170,   171,   172,   173,   174,   175,   176,   177,   178,    15,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   244,    -1,    -1,   247,    -1,    -1,    -1,   251,    -1,
    -1,    -1,    -1,   256,   257,    -1,    -1,    -1,   261,    -1,
    -1,   264,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,   278,    27,    28,    -1,    -1,
    -1,    -1,    -1,    34,    35,    -1,    37,    -1,    39,    40,
    41,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    54,    -1,    -1,    57,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   317,    -1,    -1,   320,    -1,    -1,
   323,    72,    73,    74,    75,   328,    -1,    -1,    -1,    -1,
    -1,    82,    83,    84,    -1,   338,    -1,    -1,   341,   342,
    -1,   344,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   152,   153,   154,   155,
   156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
   166,   167,   168,   169,   170,   171,   172,   173,   174,   175,
   176,   177,   178,    -1,    -1,    -1,   389,   390,   391,    -1,
    -1,    -1,   395,    -1,    -1,   398,   399,   400,     1,    -1,
   403,    -1,    -1,     6,     7,   408,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,   418,    18,    -1,    -1,    -1,
    -1,    -1,   425,   426,   427,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   440,   189,   190,
   191,   192,   193,   194,   195,   196,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   456,    -1,   458,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   470,    71,    -1,
    -1,    -1,    -1,    -1,    -1,   478,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    89,    -1,    -1,    -1,
    -1,    94,    -1,    96,    -1,    98,   499,   100,    -1,   502,
    -1,   104,    -1,    -1,    -1,    -1,    -1,    -1,   111,    -1,
   113,    -1,    -1,    -1,    -1,    -1,   119,   120,   121,   122,
   123,    -1,    -1,    -1,   127,    -1,   129,    -1,    -1,    -1,
    -1,   134,   135,   536,   137,   138,   139,   140,   141,   142,
   143,   144,    -1,    -1,    -1,    -1,    -1,    -1,   551,    -1,
   152,   153,   154,   155,   156,   157,   158,   159,   160,   161,
   162,   163,   164,   165,   166,   167,   168,   169,   170,   171,
   172,   173,   174,   175,   176,   177,   178,    -1,    -1,    -1,
    -1,    -1,     3,     4,     5,     6,     7,    -1,    -1,    -1,
    11,    12,    -1,    -1,    -1,    16,    -1,    -1,    -1,    -1,
   603,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   614,    -1,    34,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   626,    -1,    -1,    -1,    48,    49,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   639,    -1,    -1,    60,
    -1,    -1,    -1,    -1,    -1,   648,    -1,    -1,    69,    70,
   653,    -1,    -1,    -1,   657,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,   668,    -1,    -1,    -1,    -1,
   673,    -1,    -1,    -1,    -1,    -1,     3,     4,     5,     6,
     7,    -1,    -1,    -1,    11,    12,    -1,    -1,    -1,    16,
    -1,    -1,    -1,    20,    -1,    -1,    23,    -1,    -1,   702,
    27,    28,    29,    -1,    31,    -1,    -1,    34,    35,    -1,
    37,    -1,    39,    40,    41,    -1,    -1,    -1,    -1,    -1,
    -1,    48,    49,    -1,    -1,    -1,   729,    54,    -1,    -1,
    57,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   742,
    -1,    -1,    69,    70,    -1,    72,    73,    74,    75,    76,
    77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
    87,    88,    89,    -1,    -1,    -1,    -1,    94,    -1,    96,
    -1,    98,    -1,   100,    -1,    -1,    -1,   104,    -1,    -1,
    -1,    -1,    -1,    -1,   111,    -1,   113,    -1,    -1,    -1,
    -1,    -1,   119,   120,   121,   122,   123,    -1,    -1,    -1,
   127,    -1,   129,    -1,    -1,    -1,    -1,   134,   135,    -1,
   137,   138,   139,   140,   141,   142,   143,   144,     6,     7,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,
    -1,    -1,    20,    -1,    -1,    -1,    -1,    -1,    -1,    27,
    28,    29,    -1,    31,    -1,    -1,    34,    35,    -1,    37,
    -1,    39,    40,    41,    -1,    -1,    44,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    54,    -1,    -1,    57,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    72,    73,    74,    75,    76,    77,
    78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
    88,    89,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,
    98,    -1,   100,    -1,    -1,    -1,   104,    -1,    -1,    -1,
    -1,    -1,    -1,   111,    -1,   113,    -1,    -1,    -1,    -1,
    -1,   119,   120,   121,   122,   123,    -1,    -1,    -1,   127,
    -1,   129,    -1,    -1,    -1,    -1,   134,   135,    -1,   137,
   138,   139,   140,   141,   142,   143,   144,     6,     7,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,    -1,
    -1,    20,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
    29,    -1,    31,    -1,    -1,    34,    35,    -1,    37,    -1,
    39,    40,    41,    -1,    -1,    44,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    54,    -1,    -1,    57,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    72,    73,    74,    75,    76,    77,    78,
    79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
    89,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,    98,
    -1,   100,    -1,    -1,    -1,   104,    -1,    -1,    -1,    -1,
    -1,    -1,   111,    -1,   113,    -1,    -1,    -1,    -1,    -1,
   119,   120,   121,   122,   123,    -1,    -1,    -1,   127,    -1,
   129,    -1,     6,     7,    -1,   134,   135,    -1,   137,   138,
   139,   140,   141,   142,   143,   144,    20,    -1,    -1,    -1,
    -1,    -1,    -1,    27,    28,    29,    -1,    31,    -1,    -1,
    34,    35,    -1,    37,    38,    39,    40,    41,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    53,
    54,    -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    72,    73,
    74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
    84,    85,    86,    87,    88,    89,    -1,    -1,    -1,    -1,
    94,    -1,    96,    -1,    98,    -1,   100,    -1,    -1,    -1,
   104,    -1,    -1,    -1,    -1,    -1,    -1,   111,    -1,   113,
    -1,    -1,    -1,    -1,    -1,   119,   120,   121,   122,   123,
    -1,    -1,    -1,   127,    -1,   129,    -1,     6,     7,    -1,
   134,   135,    -1,   137,   138,   139,   140,   141,   142,   143,
   144,    20,    -1,    22,    -1,    -1,    -1,    -1,    27,    28,
    29,    -1,    31,    -1,    -1,    34,    35,    -1,    37,    -1,
    39,    40,    41,    -1,    -1,    44,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    54,    -1,    -1,    57,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    72,    73,    74,    75,    76,    77,    78,
    79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
    89,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,    98,
    -1,   100,    -1,    -1,    -1,   104,    -1,    -1,    -1,    -1,
    -1,    -1,   111,    -1,   113,    -1,    -1,    -1,    -1,    -1,
   119,   120,   121,   122,   123,    -1,    -1,    -1,   127,    -1,
   129,    -1,     6,     7,    -1,   134,   135,    -1,   137,   138,
   139,   140,   141,   142,   143,   144,    20,    -1,    22,    -1,
    -1,    -1,    -1,    27,    28,    29,    -1,    31,    -1,    -1,
    34,    35,    -1,    37,    -1,    39,    40,    41,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    54,    -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    72,    73,
    74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
    84,    85,    86,    87,    88,    89,    -1,    -1,    -1,    -1,
    94,    -1,    96,    -1,    98,    -1,   100,    -1,    -1,    -1,
   104,    -1,    -1,    -1,    -1,    -1,    -1,   111,    -1,   113,
    -1,    -1,    -1,    -1,    -1,   119,   120,   121,   122,   123,
    -1,    -1,    -1,   127,    -1,   129,    -1,     6,     7,    -1,
   134,   135,    -1,   137,   138,   139,   140,   141,   142,   143,
   144,    20,    -1,    -1,    -1,    -1,    -1,    -1,    27,    28,
    29,    -1,    31,    -1,    -1,    34,    35,    -1,    37,    -1,
    39,    40,    41,    -1,    -1,    44,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    54,    -1,    -1,    57,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    72,    73,    74,    75,    76,    77,    78,
    79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
    89,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,    98,
    -1,   100,    -1,    -1,    -1,   104,    -1,    -1,    -1,    -1,
    -1,    -1,   111,    -1,   113,    -1,    -1,    -1,    -1,    -1,
   119,   120,   121,   122,   123,    -1,    -1,    -1,   127,    -1,
   129,    -1,     6,     7,    -1,   134,   135,    -1,   137,   138,
   139,   140,   141,   142,   143,   144,    20,    -1,    -1,    -1,
    -1,    -1,    -1,    27,    28,    29,    -1,    31,    -1,    -1,
    34,    35,    -1,    37,    -1,    39,    40,    41,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    54,    -1,    -1,    57,    -1,    -1,    -1,    -1,     6,     7,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    72,    73,
    74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
    84,    85,    86,    87,    88,    89,    -1,    -1,    -1,    -1,
    94,    -1,    96,    -1,    98,    -1,   100,    -1,    -1,    -1,
   104,    -1,    -1,    -1,    -1,    -1,    -1,   111,    -1,   113,
    -1,    -1,    -1,    -1,     6,   119,   120,   121,   122,   123,
    -1,    -1,    -1,   127,    -1,   129,    -1,    -1,    -1,    -1,
   134,   135,    -1,   137,   138,   139,   140,   141,   142,   143,
   144,    89,    -1,    -1,    -1,    -1,    94,    -1,    96,    -1,
    98,    -1,   100,    -1,    -1,    -1,   104,    -1,    50,    -1,
    -1,    -1,    -1,   111,    -1,   113,    -1,    -1,    -1,    -1,
     6,   119,   120,   121,   122,   123,    -1,    -1,    -1,   127,
    -1,   129,    -1,    -1,    -1,    -1,   134,   135,    -1,   137,
   138,   139,   140,   141,   142,   143,   144,    89,    -1,    -1,
    -1,    -1,    94,    -1,    96,    -1,    98,    -1,   100,    -1,
    -1,    -1,   104,    -1,    -1,    -1,    -1,    -1,    -1,   111,
    -1,   113,    -1,    -1,    -1,    -1,    -1,   119,   120,   121,
   122,   123,    -1,    -1,    -1,   127,    -1,   129,    -1,    -1,
    -1,    -1,   134,   135,    -1,   137,   138,   139,   140,   141,
   142,   143,   144,    89,    -1,    -1,    -1,    -1,    94,    -1,
    96,    -1,    98,    -1,   100,    -1,    -1,    -1,   104,    -1,
    -1,    -1,    -1,    -1,    -1,   111,    -1,   113,    -1,    -1,
    -1,    -1,    -1,   119,   120,   121,   122,   123,    -1,    -1,
    -1,   127,    -1,   129,    -1,    -1,    -1,    -1,   134,   135,
    -1,   137,   138,   139,   140,   141,   142,   143,   144,   152,
   153,   154,   155,   156,   157,   158,   159,   160,   161,   162,
   163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
   173,   174,   175,   176,   177,   178
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "bison.simple"
/* This file comes from bison-1.28.  */

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

#ifdef _MSC_VER
#pragma warning(disable: 4701)
#endif

#ifndef YYSTACK_USE_ALLOCA
#ifdef alloca
#define YYSTACK_USE_ALLOCA
#else /* alloca not defined */
#ifdef __GNUC__
#define YYSTACK_USE_ALLOCA
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi) || (defined (__sun) && defined (__i386))
#define YYSTACK_USE_ALLOCA
#include <alloca.h>
#else /* not sparc */
/* We think this test detects Watcom and Microsoft C.  */
/* This used to test MSDOS, but that is a bad idea
   since that symbol is in the user namespace.  */
#if (defined (_MSDOS) || defined (_MSDOS_)) && !defined (__TURBOC__)
#if 0 /* No need for malloc.h, which pollutes the namespace;
	 instead, just don't use alloca.  */
#include <malloc.h>
#endif
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
/* I don't know what this was needed for, but it pollutes the namespace.
   So I turned it off.   rms, 2 May 1997.  */
/* #include <malloc.h>  */
 #pragma alloca
#define YYSTACK_USE_ALLOCA
#else /* not MSDOS, or __TURBOC__, or _AIX */
#if 0
#ifdef __hpux /* haible@ilog.fr says this works for HPUX 9.05 and up,
		 and on HPUX 10.  Eventually we can turn this on.  */
#define YYSTACK_USE_ALLOCA
#define alloca __builtin_alloca
#endif /* __hpux */
#endif
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc */
#endif /* not GNU C */
#endif /* alloca not defined */
#endif /* YYSTACK_USE_ALLOCA not defined */

#ifdef YYSTACK_USE_ALLOCA
#define YYSTACK_ALLOC alloca
#else
#define YYSTACK_ALLOC malloc
#endif

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	goto yyacceptlab
#define YYABORT 	goto yyabortlab
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Define __yy_memcpy.  Note that the size argument
   should be passed with type unsigned int, because that is what the non-GCC
   definitions require.  With GCC, __builtin_memcpy takes an arg
   of type size_t, but it can handle unsigned int.  */

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(TO,FROM,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *to, char *from, unsigned int count)
{
  register char *t = to;
  register char *f = from;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif

#line 201 "bison.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#ifdef __cplusplus
#define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else /* not __cplusplus */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#endif /* not __cplusplus */
#else /* not YYPARSE_PARAM */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif /* not YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
#ifdef YYPARSE_PARAM
int yyparse (void *);
#else
int yyparse (void);
#endif
#endif

int
yyparse(YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;
  int yyfree_stacks = 0;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;	/*  the variable used to return		*/
					/*  semantic values from the action	*/
					/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = (short)yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  if (yyfree_stacks)
	    {
	      free (yyss);
	      free (yyvs);
#ifdef YYLSP_NEEDED
	      free (yyls);
#endif
	    }
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
#ifndef YYSTACK_USE_ALLOCA
      yyfree_stacks = 1;
#endif
      yyss = (short *) YYSTACK_ALLOC (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss, (char *)yyss1,
		   size * (unsigned int) sizeof (*yyssp));
      yyvs = (YYSTYPE *) YYSTACK_ALLOC (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs, (char *)yyvs1,
		   size * (unsigned int) sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) YYSTACK_ALLOC (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls, (char *)yyls1,
		   size * (unsigned int) sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 474 "core/parse-asn1.y"
{ yyval.intVal = myLineNoG; ;
    break;}
case 2:
#line 479 "core/parse-asn1.y"
{ modulePtrG->tagDefault = yyvsp[0].intVal; ;
    break;}
case 3:
#line 485 "core/parse-asn1.y"
{
         modulePtrG->modId = yyvsp[-8].moduleId;
		 modulePtrG->namespaceToUse = yyvsp[-2].charPtr;

         /*
          * Set exported flags in type/value defs as appropriate
          */
         SetExports (modulePtrG, exportListG, exportsParsedG);

         /* clean up */

         /* Free Application tag list */
         FreeApplTags();

         /*
          * Add values defined in any parsed object identifiers.
          * Only the Module name and some macro oids have been parsed,
          * the rest are just "{...}" strings at this point
          * (they will be parsed in later)
// REN -- 9/23/02
         modulePtrG->valueDefs =
             AsnListConcat (modulePtrG->valueDefs, oidElmtValDefsG);
          */

         /*
          * free list head only
// REN -- 9/23/02
         Free (oidElmtValDefsG);
          */
     ;
    break;}
case 4:
#line 518 "core/parse-asn1.y"
{ yyval.intVal = EXPLICIT_TAGS; ;
    break;}
case 5:
#line 519 "core/parse-asn1.y"
{ yyval.intVal = IMPLICIT_TAGS; ;
    break;}
case 6:
#line 521 "core/parse-asn1.y"
{
        /* default is EXPLICIT TAGS */
        yyval.intVal = EXPLICIT_TAGS;
    ;
    break;}
case 7:
#line 529 "core/parse-asn1.y"
{
        yyval.moduleId = MT (ModuleId);
        yyval.moduleId->name = yyvsp[-1].charPtr;
        yyval.moduleId->oid = yyvsp[0].oidPtr;
    ;
    break;}
case 9:
#line 538 "core/parse-asn1.y"
{ yyval.oidPtr = NULL; ;
    break;}
case 10:
#line 542 "core/parse-asn1.y"
{ yyval.charPtr = yyvsp[0].charPtr; ;
    break;}
case 11:
#line 543 "core/parse-asn1.y"
{ yyval.charPtr = NULL; ;
    break;}
case 14:
#line 554 "core/parse-asn1.y"
{
        /*
         *  allows differentiation between "EXPORTS;"
         *         (in which no exports allowed)
         *  and when the EXPORTS symbol does not appear
         *         (then all are exported)
         */
        exportsParsedG = TRUE;
    ;
    break;}
case 15:
#line 564 "core/parse-asn1.y"
{
        PARSE_ERROR();
        exportsParsedG = FALSE;
        exportListG = NULL;
        yyerrok;
    ;
    break;}
case 16:
#line 570 "core/parse-asn1.y"
{ exportsParsedG = FALSE; ;
    break;}
case 17:
#line 574 "core/parse-asn1.y"
{ exportListG = yyvsp[0].exportList; ;
    break;}
case 18:
#line 575 "core/parse-asn1.y"
{ exportListG = NULL; ;
    break;}
case 19:
#line 580 "core/parse-asn1.y"
{
        yyval.exportList = MT (ExportElmt);
        yyval.exportList->name = yyvsp[0].charPtr;
        yyval.exportList->lineNo = myLineNoG;
        yyval.exportList->next = NULL;
    ;
    break;}
case 20:
#line 587 "core/parse-asn1.y"
{
        yyval.exportList = MT (ExportElmt);
        yyval.exportList->name = yyvsp[0].charPtr;
        yyval.exportList->next = yyvsp[-3].exportList;
        yyval.exportList->lineNo = yyvsp[-1].intVal;
    ;
    break;}
case 22:
#line 598 "core/parse-asn1.y"
{
       PARSE_ERROR();
       yyerrok;
    ;
    break;}
case 24:
#line 606 "core/parse-asn1.y"
{ modulePtrG->imports = yyvsp[0].importModuleListPtr; ;
    break;}
case 26:
#line 612 "core/parse-asn1.y"
{
        APPEND (yyvsp[0].importModulePtr,yyvsp[-1].importModuleListPtr);
    ;
    break;}
case 27:
#line 616 "core/parse-asn1.y"
{
        yyval.importModuleListPtr = NEWLIST();
        APPEND (yyvsp[0].importModulePtr, yyval.importModuleListPtr);
    ;
    break;}
case 28:
#line 624 "core/parse-asn1.y"
{
        yyval.importModulePtr = MT (ImportModule);
        yyval.importModulePtr->modId   = yyvsp[0].moduleId;
        yyval.importModulePtr->lineNo = yyvsp[-1].intVal;
        yyval.importModulePtr->importElmts = yyvsp[-3].importElmtListPtr;
    ;
    break;}
case 29:
#line 635 "core/parse-asn1.y"
{
        ImportElmt *ie;

        ie = MT (ImportElmt);
        ie->name = yyvsp[0].charPtr;
        ie->lineNo = myLineNoG;
        APPEND (ie, yyvsp[-2].importElmtListPtr);
        yyval.importElmtListPtr = yyvsp[-2].importElmtListPtr;
    ;
    break;}
case 30:
#line 645 "core/parse-asn1.y"
{
        ImportElmt *ie;

        /* called for the first element only, so create list head */
        yyval.importElmtListPtr = NEWLIST();
        ie = MT (ImportElmt);
        ie->name = yyvsp[0].charPtr;
        ie->lineNo = myLineNoG;
        APPEND (ie, yyval.importElmtListPtr);
    ;
    break;}
case 33:
#line 661 "core/parse-asn1.y"
{
        /*
         * hack to make DefinedMacroNames "freeable"
         * like idents and typeref
         */
        yyval.charPtr = Malloc (strlen (yyvsp[0].charPtr)+1);
        strcpy (yyval.charPtr, yyvsp[0].charPtr);
    ;
    break;}
case 38:
#line 682 "core/parse-asn1.y"
{
        PARSE_ERROR();
        yyerrok;
    ;
    break;}
case 39:
#line 690 "core/parse-asn1.y"
{
        /*
         * a macro may produce a null type
         */
        if (yyvsp[0].typeDefPtr != NULL)
        {
            /*
             * add to head of  type def list
             */
            APPEND (yyvsp[0].typeDefPtr, modulePtrG->typeDefs);
        }

    ;
    break;}
case 40:
#line 704 "core/parse-asn1.y"
{
        /*
         * a macro may produce a null value
         */
        if (yyvsp[0].valueDefPtr != NULL)
        {
            /*
             * add to head of value def list
             */
            APPEND (yyvsp[0].valueDefPtr, modulePtrG->valueDefs);
        }
    ;
    break;}
case 41:
#line 716 "core/parse-asn1.y"
{ LexBeginMacroDefContext(); ;
    break;}
case 42:
#line 718 "core/parse-asn1.y"
{
        TypeDef *tmpTypeDef;

        /*
         *  LEXICAL TIE IN!!
         * create macro type to eliminate import resolution
         * errors msgs from other modules importing the macro.
         * (hopefully) Only the import list will link with
         * these type defs.
         * keeps macro def around incase of future processing needs
         *
         * NOTE: MACRODEFBODY_SYM returns the macro def body with
         * with "BEGIN" at the begininning and "END" at the end
         */

        /*
         * put lexical analyzer back in normal state
         */
        /*  BEGIN (INITIAL);  */
        LexBeginInitialContext();

        tmpTypeDef = MT (TypeDef);
        SetupType (&tmpTypeDef->type, BASICTYPE_MACRODEF, yyvsp[-2].intVal);
        tmpTypeDef->definedName = yyvsp[-5].charPtr;

        /*
         * keeps the macro def body
         * (all text between & including the BEGIN and END)
         * as a simple string - incase you want to fart around with
         * it.
         */
        tmpTypeDef->type->basicType->a.macroDef = yyvsp[0].charPtr;

        /*
         * put in type list
         */
        APPEND (tmpTypeDef, modulePtrG->typeDefs);

    ;
    break;}
case 43:
#line 758 "core/parse-asn1.y"
{
        TypeDef *tmpTypeDef;

        tmpTypeDef = MT (TypeDef);
        SetupType (&tmpTypeDef->type, BASICTYPE_MACRODEF, myLineNoG);
        tmpTypeDef->definedName = yyvsp[-2].charPtr;

        tmpTypeDef->type->basicType->a.macroDef = yyvsp[0].charPtr;

        /*
         * put in type list
         */
        APPEND (tmpTypeDef, modulePtrG->typeDefs);

    ;
    break;}
case 44:
#line 774 "core/parse-asn1.y"
{
        TypeDef *tmpTypeDef;

        tmpTypeDef = MT (TypeDef);
        SetupType (&tmpTypeDef->type, BASICTYPE_MACRODEF, myLineNoG);
        tmpTypeDef->definedName = yyvsp[-4].charPtr;

        tmpTypeDef->type->basicType->a.macroDef =
               (MyString) Malloc (strlen (yyvsp[-2].charPtr) + strlen (yyvsp[0].charPtr) + 2);

        strcpy (tmpTypeDef->type->basicType->a.macroDef, yyvsp[-2].charPtr);
        strcat (tmpTypeDef->type->basicType->a.macroDef, ".");
        strcat (tmpTypeDef->type->basicType->a.macroDef, yyvsp[0].charPtr);

       /*
         * put in type list
         */
        APPEND (tmpTypeDef, modulePtrG->typeDefs);

        Free (yyvsp[-2].charPtr);
        Free (yyvsp[0].charPtr);
    ;
    break;}
case 47:
#line 809 "core/parse-asn1.y"
{
        /*
         * a macro type may produce a null type
         */
        if (yyvsp[-1].typePtr != NULL)
        {
            yyval.typeDefPtr = MT (TypeDef);
            yyval.typeDefPtr->type =  yyvsp[-1].typePtr;
            yyval.typeDefPtr->type->lineNo = yyvsp[-2].intVal;
            yyval.typeDefPtr->type->attrList = yyvsp[0].directiveList;
            yyval.typeDefPtr->definedName = yyvsp[-5].charPtr;
            yyval.typeDefPtr->attrList = yyvsp[-3].directiveList;
        }
        else
            yyval.typeDefPtr = NULL;
    ;
    break;}
case 48:
#line 830 "core/parse-asn1.y"
{
        /* allocate a Type with basic type of ImportTypeRef */
        SetupType (&yyval.typePtr, BASICTYPE_IMPORTTYPEREF, yyvsp[-1].intVal);
        yyval.typePtr->basicType->a.importTypeRef = MT (TypeRef);
        yyval.typePtr->basicType->a.importTypeRef->typeName = yyvsp[0].charPtr;
        yyval.typePtr->basicType->a.importTypeRef->moduleName = yyvsp[-3].charPtr;

        /* add entry to this module's import list */
        AddPrivateImportElmt (modulePtrG, yyvsp[0].charPtr, yyvsp[-3].charPtr, yyvsp[-1].intVal);
    ;
    break;}
case 49:
#line 844 "core/parse-asn1.y"
{ yyval.typePtr = yyvsp[0].typePtr; ;
    break;}
case 50:
#line 846 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_LOCALTYPEREF, myLineNoG);
        yyval.typePtr->basicType->a.localTypeRef = MT (TypeRef);
        yyval.typePtr->basicType->a.localTypeRef->typeName = yyvsp[0].charPtr;
    ;
    break;}
case 73:
#line 882 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_OCTETSTRING, myLineNoG);
  ;
    break;}
case 76:
#line 891 "core/parse-asn1.y"
{
        yyval.namedTypePtr = MT (NamedType);
        yyval.namedTypePtr->type = yyvsp[0].typePtr;
        yyval.namedTypePtr->fieldName = yyvsp[-1].charPtr;
    ;
    break;}
case 77:
#line 897 "core/parse-asn1.y"
{
        yyval.namedTypePtr = MT (NamedType);
        yyval.namedTypePtr->type = yyvsp[0].typePtr;
    ;
    break;}
case 78:
#line 905 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_BOOLEAN, myLineNoG);
    ;
    break;}
case 79:
#line 912 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_INTEGER, myLineNoG);
        yyval.typePtr->basicType->a.integer = NEWLIST();  /* empty list */
    ;
    break;}
case 80:
#line 917 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_INTEGER, myLineNoG);
        yyval.typePtr->basicType->a.integer = yyvsp[-1].valueDefListPtr;
    ;
    break;}
case 81:
#line 926 "core/parse-asn1.y"
{
        yyval.valueDefListPtr = NEWLIST();
        APPEND (yyvsp[0].valueDefPtr, yyval.valueDefListPtr);
    ;
    break;}
case 82:
#line 931 "core/parse-asn1.y"
{
        APPEND (yyvsp[0].valueDefPtr,yyvsp[-2].valueDefListPtr);
        yyval.valueDefListPtr = yyvsp[-2].valueDefListPtr;
    ;
    break;}
case 83:
#line 939 "core/parse-asn1.y"
{
        yyval.valueDefPtr = MT (ValueDef);
        yyval.valueDefPtr->definedName = yyvsp[-3].charPtr;
        SetupValue (&yyval.valueDefPtr->value, BASICVALUE_INTEGER, myLineNoG);
        yyval.valueDefPtr->value->basicValue->a.integer = yyvsp[-1].intVal;
    ;
    break;}
case 84:
#line 946 "core/parse-asn1.y"
{
        yyval.valueDefPtr = MT (ValueDef);
        yyval.valueDefPtr->definedName = yyvsp[-3].charPtr;
        yyval.valueDefPtr->value = yyvsp[-1].valuePtr;
    ;
    break;}
case 85:
#line 955 "core/parse-asn1.y"
{
    ;
    break;}
case 86:
#line 958 "core/parse-asn1.y"
{
    ;
    break;}
case 87:
#line 961 "core/parse-asn1.y"
{
    ;
    break;}
case 88:
#line 964 "core/parse-asn1.y"
{
    ;
    break;}
case 89:
#line 970 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_ENUMERATED, myLineNoG);
        yyval.typePtr->basicType->a.enumerated = yyvsp[-1].valueDefListPtr;
    ;
    break;}
case 90:
#line 981 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_REAL, myLineNoG);
    ;
    break;}
case 91:
#line 988 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_BITSTRING, myLineNoG);
        yyval.typePtr->basicType->a.bitString = NEWLIST(); /* empty list */
    ;
    break;}
case 92:
#line 993 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_BITSTRING, myLineNoG);
        yyval.typePtr->basicType->a.bitString = yyvsp[-1].valueDefListPtr;
    ;
    break;}
case 94:
#line 1007 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_NULL, myLineNoG);
    ;
    break;}
case 95:
#line 1014 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_EXTERNAL, myLineNoG);
    ;
    break;}
case 96:
#line 1021 "core/parse-asn1.y"
{ yyval.intVal = yyvsp[-1].intVal; ;
    break;}
case 97:
#line 1026 "core/parse-asn1.y"
{
        NamedType *n;

        SetupType (&yyval.typePtr, BASICTYPE_SEQUENCE, yyvsp[-2].intVal);

        if (AsnListCount ((AsnList*)yyvsp[-1].namedTypeListPtr) != 0)
        {
            n = (NamedType*) FIRST_LIST_ELMT ((AsnList*)yyvsp[-1].namedTypeListPtr);
            n->type->lineNo = yyvsp[-2].intVal;
        }

        yyval.typePtr->basicType->a.sequence = yyvsp[-1].namedTypeListPtr;

    ;
    break;}
case 98:
#line 1041 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_SEQUENCE, yyvsp[-1].intVal);

        /* set up empty list for SEQ with no elmts */
        yyval.typePtr->basicType->a.sequence = AsnListNew (sizeof (void*));
    ;
    break;}
case 99:
#line 1056 "core/parse-asn1.y"
{
        NamedType *lastElmt;

        if (yyvsp[0].directiveList != NULL)
        {
            lastElmt = (NamedType*)LAST_LIST_ELMT (yyvsp[-1].namedTypeListPtr);
            lastElmt->type->attrList = yyvsp[0].directiveList;
        }
        yyval.namedTypeListPtr = yyvsp[-1].namedTypeListPtr;
    ;
    break;}
case 100:
#line 1070 "core/parse-asn1.y"
{
        yyval.namedTypeListPtr = NEWLIST();
        APPEND (yyvsp[0].namedTypePtr,yyval.namedTypeListPtr);
    ;
    break;}
case 101:
#line 1075 "core/parse-asn1.y"
{
        NamedType *lastElmt;

        if (yyvsp[-2].directiveList != NULL)
        {
            lastElmt = (NamedType*)LAST_LIST_ELMT (yyvsp[-4].namedTypeListPtr);
            lastElmt->type->attrList = yyvsp[-2].directiveList;
        }

       APPEND (yyvsp[0].namedTypePtr, yyvsp[-4].namedTypeListPtr);
       lastElmt = (NamedType*)LAST_LIST_ELMT (yyvsp[-4].namedTypeListPtr);
       lastElmt->type->lineNo = yyvsp[-1].intVal;
       yyval.namedTypeListPtr = yyvsp[-4].namedTypeListPtr;
    ;
    break;}
case 103:
#line 1094 "core/parse-asn1.y"
{
        yyval.namedTypePtr = yyvsp[-1].namedTypePtr;
        yyval.namedTypePtr->type->optional = TRUE;
    ;
    break;}
case 104:
#line 1099 "core/parse-asn1.y"
{
        /*
         * this rules uses NamedValue instead of Value
         * for the stupid choice value syntax (fieldname value)
         * it should be like a set/seq value (ie with
         * enclosing { }
         */
        yyval.namedTypePtr = yyvsp[-2].namedTypePtr;
        yyval.namedTypePtr->type->defaultVal = yyvsp[0].namedValuePtr;
        /*
         * could link value to the elmt type here (done in link_types.c)
         */
    ;
    break;}
case 105:
#line 1113 "core/parse-asn1.y"
{
        yyval.namedTypePtr = MT (NamedType);
        SetupType (&yyval.namedTypePtr->type, BASICTYPE_COMPONENTSOF, myLineNoG);
        yyval.namedTypePtr->type->basicType->a.componentsOf = yyvsp[0].typePtr;
    ;
    break;}
case 106:
#line 1119 "core/parse-asn1.y"
{
        yyval.namedTypePtr = MT (NamedType);
        SetupType (&yyval.namedTypePtr->type, BASICTYPE_COMPONENTSOF, myLineNoG);
        yyval.namedTypePtr->fieldName = yyvsp[-3].charPtr;
        yyval.namedTypePtr->type->basicType->a.componentsOf = yyvsp[0].typePtr;
    ;
    break;}
case 107:
#line 1131 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_SEQUENCEOF, myLineNoG);

        /* grab line number from first elmt */
        if (yyvsp[0].typePtr != NULL)
            yyval.typePtr->lineNo = yyvsp[0].typePtr->lineNo - 1;

        yyval.typePtr->basicType->a.sequenceOf = yyvsp[0].typePtr;
    ;
    break;}
case 108:
#line 1143 "core/parse-asn1.y"
{ yyval.intVal = yyvsp[-1].intVal; ;
    break;}
case 109:
#line 1148 "core/parse-asn1.y"
{
        NamedType *n;

        SetupType (&yyval.typePtr, BASICTYPE_SET, yyvsp[-2].intVal);

        /* reset first elmt's line number */
        if (AsnListCount ((AsnList*)yyvsp[-1].namedTypeListPtr) != 0)
        {
            n = (NamedType*)FIRST_LIST_ELMT ((AsnList*)yyvsp[-1].namedTypeListPtr);
            n->type->lineNo = yyvsp[-2].intVal;
        }
        yyval.typePtr->basicType->a.set = yyvsp[-1].namedTypeListPtr;
    ;
    break;}
case 110:
#line 1162 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_SET, yyvsp[-1].intVal);

        /* set up empty elmt list for SET */
        yyval.typePtr->basicType->a.set = AsnListNew (sizeof (void*));
    ;
    break;}
case 111:
#line 1178 "core/parse-asn1.y"
{
       /* does not allow SET == SET OF ANY Abrev */
        SetupType (&yyval.typePtr, BASICTYPE_SETOF, myLineNoG);

        if (yyvsp[0].typePtr != NULL)
            yyval.typePtr->lineNo = yyvsp[0].typePtr->lineNo;

        yyval.typePtr->basicType->a.setOf = yyvsp[0].typePtr;
    ;
    break;}
case 112:
#line 1192 "core/parse-asn1.y"
{
        NamedType *n;

        SetupType (&yyval.typePtr, BASICTYPE_CHOICE, yyvsp[-3].intVal);

        yyval.typePtr->basicType->a.choice = yyvsp[-1].namedTypeListPtr;

        if (AsnListCount (yyvsp[-1].namedTypeListPtr) != 0)
        {
            n = (NamedType*)FIRST_LIST_ELMT (yyvsp[-1].namedTypeListPtr);
            n->type->lineNo = yyvsp[-3].intVal;
        }
    ;
    break;}
case 113:
#line 1209 "core/parse-asn1.y"
{
        NamedType *lastElmt;
        if (yyvsp[0].directiveList != NULL)
        {
            lastElmt = (NamedType*)LAST_LIST_ELMT (yyvsp[-1].namedTypeListPtr);
            lastElmt->type->attrList = yyvsp[0].directiveList;
        }
        yyval.namedTypeListPtr = yyvsp[-1].namedTypeListPtr;
    ;
    break;}
case 114:
#line 1222 "core/parse-asn1.y"
{
        yyval.namedTypeListPtr = NEWLIST();
        APPEND (yyvsp[0].namedTypePtr, yyval.namedTypeListPtr);
    ;
    break;}
case 115:
#line 1227 "core/parse-asn1.y"
{
        NamedType *lastElmt;

        if (yyvsp[-1].directiveList != NULL)
        {
            lastElmt = (NamedType*)LAST_LIST_ELMT (yyvsp[-3].namedTypeListPtr);
            lastElmt->type->attrList = yyvsp[-1].directiveList;
        }
        APPEND (yyvsp[0].namedTypePtr,yyvsp[-3].namedTypeListPtr);
        yyval.namedTypeListPtr = yyvsp[-3].namedTypeListPtr;
    ;
    break;}
case 116:
#line 1243 "core/parse-asn1.y"
{
        /*
         * the selection type should be replaced after
         * link with actual type
         */
        SetupType (&yyval.typePtr, BASICTYPE_SELECTION, myLineNoG);

        yyval.typePtr->basicType->a.selection = MT (SelectionType);
        yyval.typePtr->basicType->a.selection->typeRef = yyvsp[0].typePtr;
        yyval.typePtr->basicType->a.selection->fieldName = yyvsp[-2].charPtr;
    ;
    break;}
case 117:
#line 1258 "core/parse-asn1.y"
{
        Tag *tag;

        /* remove next tag if any  && IMPLICIT_TAGS */
 	if ((modulePtrG->tagDefault == IMPLICIT_TAGS) &&
            (yyvsp[0].typePtr->tags != NULL) && !LIST_EMPTY (yyvsp[0].typePtr->tags))
        {
            tag = (Tag*)FIRST_LIST_ELMT (yyvsp[0].typePtr->tags); /* set curr to first */
	    AsnListFirst (yyvsp[0].typePtr->tags); /* set curr to first elmt */
            AsnListRemove (yyvsp[0].typePtr->tags);      /* remove first elmt */

            /*
             * set implicit if implicitly tagged built in type (ie not ref)
             * (this simplifies the module ASN.1 printer (print.c))
             */
            if (tag->tclass == UNIV)
                 yyvsp[0].typePtr->implicit = TRUE;

            Free (tag);
        }

        PREPEND (yyvsp[-1].tagPtr, yyvsp[0].typePtr->tags);
        yyval.typePtr = yyvsp[0].typePtr;
    ;
    break;}
case 118:
#line 1283 "core/parse-asn1.y"
{
        Tag *tag;

        /* remove next tag if any */
 	if ((yyvsp[0].typePtr->tags != NULL) && !LIST_EMPTY (yyvsp[0].typePtr->tags))
        {
            tag = (Tag*)FIRST_LIST_ELMT (yyvsp[0].typePtr->tags); /* set curr to first */
	    AsnListFirst (yyvsp[0].typePtr->tags); /* set curr to first elmt */
            AsnListRemove (yyvsp[0].typePtr->tags);      /* remove first elmt */

            if (tag->tclass == UNIV)
                 yyvsp[0].typePtr->implicit = TRUE;

            Free (tag);
        }

        /*
         * must check after linking that implicitly tagged
         * local/import type refs are not untagged choice/any etc
         */
        else if ((yyvsp[0].typePtr->basicType->choiceId == BASICTYPE_IMPORTTYPEREF) ||
                 (yyvsp[0].typePtr->basicType->choiceId == BASICTYPE_LOCALTYPEREF) ||
                 (yyvsp[0].typePtr->basicType->choiceId == BASICTYPE_SELECTION))
            yyvsp[0].typePtr->implicit = TRUE;

        /*
         *  all other implicitly tagable types should have tags
         *  to remove - if this else clause fires then it is
         *  probably a CHOICE or ANY type
         */
        else
        {
            PrintErrLoc (modulePtrG->asn1SrcFileName, yyvsp[0].typePtr->lineNo);
            fprintf (errFileG, "ERROR - attempt to implicitly reference untagged type\n");
            smallErrG = 1;
        }

        PREPEND (yyvsp[-2].tagPtr, yyvsp[0].typePtr->tags);
        yyval.typePtr = yyvsp[0].typePtr;
    ;
    break;}
case 119:
#line 1324 "core/parse-asn1.y"
{
        /* insert tag at head of list */
        yyvsp[-2].tagPtr->explicit = TRUE;
        PREPEND (yyvsp[-2].tagPtr, yyvsp[0].typePtr->tags);
        yyval.typePtr = yyvsp[0].typePtr;
    ;
    break;}
case 120:
#line 1334 "core/parse-asn1.y"
{
        yyval.tagPtr = yyvsp[-1].tagPtr;
        yyval.tagPtr->tclass = yyvsp[-2].intVal;
        yyval.tagPtr->explicit = FALSE; /* default to false */

        /*
         *  keep track of APPLICATION Tags per module
         *  should only be used once
         */
        if ((yyvsp[-2].intVal == APPL) && (yyval.tagPtr->valueRef == NULL))
        {
            PushApplTag (yyval.tagPtr->code, myLineNoG);
        }
    ;
    break;}
case 121:
#line 1352 "core/parse-asn1.y"
{
        yyval.tagPtr = MT (Tag);
        yyval.tagPtr->code = yyvsp[0].intVal;
    ;
    break;}
case 122:
#line 1357 "core/parse-asn1.y"
{
        yyval.tagPtr = MT (Tag);
        yyval.tagPtr->code = NO_TAG_CODE;
        yyval.tagPtr->valueRef = yyvsp[0].valuePtr;
    ;
    break;}
case 123:
#line 1365 "core/parse-asn1.y"
{ yyval.intVal = UNIV; ;
    break;}
case 124:
#line 1366 "core/parse-asn1.y"
{ yyval.intVal = APPL; ;
    break;}
case 125:
#line 1367 "core/parse-asn1.y"
{ yyval.intVal = PRIV; ;
    break;}
case 126:
#line 1368 "core/parse-asn1.y"
{ yyval.intVal = CNTX; ;
    break;}
case 127:
#line 1374 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_ANY, myLineNoG);
    ;
    break;}
case 128:
#line 1378 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_ANYDEFINEDBY, myLineNoG);
        yyval.typePtr->basicType->a.anyDefinedBy = MT (AnyDefinedByType);
        yyval.typePtr->basicType->a.anyDefinedBy->fieldName = yyvsp[0].charPtr;
    ;
    break;}
case 129:
#line 1387 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_OCTETCONTAINING, myLineNoG);
        yyval.typePtr->basicType->a.stringContaining = yyvsp[0].typePtr;
    ;
    break;}
case 130:
#line 1395 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_BITCONTAINING, myLineNoG);
        yyval.typePtr->basicType->a.stringContaining = yyvsp[0].typePtr;
    ;
    break;}
case 131:
#line 1403 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_OID, myLineNoG);
    ;
    break;}
case 132:
#line 1410 "core/parse-asn1.y"
{
      SetupType (&yyval.typePtr, BASICTYPE_GENERALIZEDTIME, myLineNoG);
   ;
    break;}
case 133:
#line 1414 "core/parse-asn1.y"
{
      SetupType (&yyval.typePtr, BASICTYPE_UTCTIME, myLineNoG);
   ;
    break;}
case 134:
#line 1418 "core/parse-asn1.y"
{
      SetupType (&yyval.typePtr, BASICTYPE_OBJECTDESCRIPTOR, myLineNoG);
   ;
    break;}
case 135:
#line 1425 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_NUMERIC_STR, myLineNoG);
	;
    break;}
case 136:
#line 1429 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_PRINTABLE_STR, myLineNoG);
	;
    break;}
case 137:
#line 1433 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_IA5_STR, myLineNoG);
	;
    break;}
case 138:
#line 1437 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_BMP_STR, myLineNoG);
	;
    break;}
case 139:
#line 1441 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_UNIVERSAL_STR, myLineNoG);
	;
    break;}
case 140:
#line 1445 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_UTF8_STR, myLineNoG);
	;
    break;}
case 141:
#line 1449 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_T61_STR, myLineNoG);
	;
    break;}
case 142:
#line 1453 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_T61_STR, myLineNoG);
	;
    break;}
case 143:
#line 1457 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_VIDEOTEX_STR, myLineNoG);
	;
    break;}
case 144:
#line 1461 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_VISIBLE_STR, myLineNoG);
	;
    break;}
case 145:
#line 1465 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_VISIBLE_STR, myLineNoG);
	;
    break;}
case 146:
#line 1469 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_GRAPHIC_STR, myLineNoG);
	;
    break;}
case 147:
#line 1473 "core/parse-asn1.y"
{
		SetupType (&yyval.typePtr, BASICTYPE_GENERAL_STR, myLineNoG);
	;
    break;}
case 148:
#line 1480 "core/parse-asn1.y"
{
        /*
         * append new subtype list to existing one (s) if any
         * with AND relation
         */
        AppendSubtype (&yyvsp[-1].typePtr->subtypes, yyvsp[0].subtypePtr, SUBTYPE_AND);
        yyval.typePtr = yyvsp[-1].typePtr;
    ;
    break;}
case 149:
#line 1489 "core/parse-asn1.y"
{
        Subtype *s;

        SetupType (&yyval.typePtr, BASICTYPE_SETOF, myLineNoG);
        yyval.typePtr->basicType->a.setOf = yyvsp[0].typePtr;

        /* add size constraint */
        s = MT (Subtype);
        s->choiceId = SUBTYPE_SINGLE;
        s->a.single = yyvsp[-2].subtypeValuePtr;
        AppendSubtype (&yyval.typePtr->subtypes, s, SUBTYPE_AND);
    ;
    break;}
case 150:
#line 1502 "core/parse-asn1.y"
{
        Subtype *s;

        SetupType (&yyval.typePtr, BASICTYPE_SEQUENCEOF, myLineNoG);
        yyval.typePtr->basicType->a.sequenceOf = yyvsp[0].typePtr;

        /* add size constraint */
        s = MT (Subtype);
        s->choiceId = SUBTYPE_SINGLE;
        s->a.single = yyvsp[-2].subtypeValuePtr;
        AppendSubtype (&yyval.typePtr->subtypes, s, SUBTYPE_AND);
    ;
    break;}
case 151:
#line 1519 "core/parse-asn1.y"
{
        yyval.subtypePtr = yyvsp[-1].subtypePtr;
    ;
    break;}
case 152:
#line 1526 "core/parse-asn1.y"
{
        Subtype *s;

        /* OR relation between all elmts of in  ValueSetList */

        yyval.subtypePtr = MT (Subtype);
        yyval.subtypePtr->choiceId = SUBTYPE_OR;
        yyval.subtypePtr->a.or = NEWLIST();

        s = MT (Subtype);
        s->choiceId = SUBTYPE_SINGLE;
        s->a.single = yyvsp[0].subtypeValuePtr;
        APPEND (s, yyval.subtypePtr->a.or);
    ;
    break;}
case 153:
#line 1541 "core/parse-asn1.y"
{
        Subtype *s;
        s = MT (Subtype);
        s->choiceId = SUBTYPE_SINGLE;
        s->a.single = yyvsp[0].subtypeValuePtr;
        APPEND (s, yyvsp[-2].subtypePtr->a.or);
        yyval.subtypePtr = yyvsp[-2].subtypePtr;
    ;
    break;}
case 160:
#line 1563 "core/parse-asn1.y"
{
        yyval.subtypeValuePtr = MT (SubtypeValue);
        yyval.subtypeValuePtr->choiceId = SUBTYPEVALUE_SINGLEVALUE;
        yyval.subtypeValuePtr->a.singleValue = yyvsp[0].valuePtr;
    ;
    break;}
case 161:
#line 1571 "core/parse-asn1.y"
{
        yyval.subtypeValuePtr = MT (SubtypeValue);
        yyval.subtypeValuePtr->choiceId = SUBTYPEVALUE_CONTAINED;
        yyval.subtypeValuePtr->a.contained = yyvsp[0].typePtr;
    ;
    break;}
case 162:
#line 1580 "core/parse-asn1.y"
{
        yyval.subtypeValuePtr = MT (SubtypeValue);
        yyval.subtypeValuePtr->choiceId = SUBTYPEVALUE_VALUERANGE;
        yyval.subtypeValuePtr->a.valueRange = MT (ValueRangeSubtype);
        yyval.subtypeValuePtr->a.valueRange->lowerEndValue  = yyvsp[-3].valueRangeEndpointPtr;
        yyval.subtypeValuePtr->a.valueRange->upperEndValue = yyvsp[0].valueRangeEndpointPtr;
    ;
    break;}
case 163:
#line 1591 "core/parse-asn1.y"
{
       yyval.valueRangeEndpointPtr = MT (ValueRangeEndpoint);
	   yyval.valueRangeEndpointPtr->valueInclusive = TRUE;
	   yyval.valueRangeEndpointPtr->endValue = yyvsp[0].valuePtr;
    ;
    break;}
case 164:
#line 1597 "core/parse-asn1.y"
{
       yyval.valueRangeEndpointPtr = MT (ValueRangeEndpoint);
	   yyval.valueRangeEndpointPtr->valueInclusive = FALSE;
	   yyval.valueRangeEndpointPtr->endValue = yyvsp[-1].valuePtr;
    ;
    break;}
case 165:
#line 1606 "core/parse-asn1.y"
{
       yyval.valueRangeEndpointPtr = MT (ValueRangeEndpoint);
	   yyval.valueRangeEndpointPtr->valueInclusive = TRUE;
	   yyval.valueRangeEndpointPtr->endValue = yyvsp[0].valuePtr;
    ;
    break;}
case 166:
#line 1612 "core/parse-asn1.y"
{
       yyval.valueRangeEndpointPtr = MT (ValueRangeEndpoint);
	   yyval.valueRangeEndpointPtr->valueInclusive = FALSE;
	   yyval.valueRangeEndpointPtr->endValue = yyvsp[0].valuePtr;
    ;
    break;}
case 167:
#line 1620 "core/parse-asn1.y"
{ yyval.valuePtr = yyvsp[0].valuePtr; ;
    break;}
case 168:
#line 1622 "core/parse-asn1.y"
{
        SetupValue (&yyval.valuePtr, BASICVALUE_SPECIALINTEGER, myLineNoG);
        yyval.valuePtr->basicValue->a.specialInteger =  MIN_INT;
    ;
    break;}
case 169:
#line 1629 "core/parse-asn1.y"
{ yyval.valuePtr = yyvsp[0].valuePtr; ;
    break;}
case 170:
#line 1631 "core/parse-asn1.y"
{
        SetupValue (&yyval.valuePtr, BASICVALUE_SPECIALINTEGER, myLineNoG);
        yyval.valuePtr->basicValue->a.specialInteger =  MAX_INT;
    ;
    break;}
case 171:
#line 1639 "core/parse-asn1.y"
{
        yyval.subtypeValuePtr = MT (SubtypeValue);
        yyval.subtypeValuePtr->choiceId = SUBTYPEVALUE_SIZECONSTRAINT;
        yyval.subtypeValuePtr->a.sizeConstraint = yyvsp[0].subtypePtr;
    ;
    break;}
case 172:
#line 1649 "core/parse-asn1.y"
{
        yyval.subtypeValuePtr = MT (SubtypeValue);
        yyval.subtypeValuePtr->choiceId = SUBTYPEVALUE_PERMITTEDALPHABET;
        yyval.subtypeValuePtr->a.permittedAlphabet = yyvsp[0].subtypePtr;
    ;
    break;}
case 173:
#line 1658 "core/parse-asn1.y"
{
        yyval.subtypeValuePtr = MT (SubtypeValue);
        yyval.subtypeValuePtr->choiceId = SUBTYPEVALUE_INNERSUBTYPE;
        yyval.subtypeValuePtr->a.innerSubtype = yyvsp[0].innerSubtypePtr;
    ;
    break;}
case 174:
#line 1664 "core/parse-asn1.y"
{
        yyval.subtypeValuePtr = MT (SubtypeValue);
        yyval.subtypeValuePtr->choiceId = SUBTYPEVALUE_INNERSUBTYPE;
        yyval.subtypeValuePtr->a.innerSubtype = yyvsp[0].innerSubtypePtr;
    ;
    break;}
case 175:
#line 1673 "core/parse-asn1.y"
{
        Constraint *constraint;

        /* this constrains the elmt of setof or seq of */
        yyval.innerSubtypePtr = MT (InnerSubtype);
        yyval.innerSubtypePtr->constraintType = SINGLE_CT;
        yyval.innerSubtypePtr->constraints = NEWLIST();
        constraint = MT (Constraint);
        APPEND (constraint, yyval.innerSubtypePtr->constraints);
        constraint->valueConstraints = yyvsp[0].subtypePtr;
    ;
    break;}
case 178:
#line 1693 "core/parse-asn1.y"
{
        yyval.innerSubtypePtr = MT (InnerSubtype);
        yyval.innerSubtypePtr->constraintType = FULL_CT;
        yyval.innerSubtypePtr->constraints = yyvsp[-1].constraintListPtr;
    ;
    break;}
case 179:
#line 1702 "core/parse-asn1.y"
{
        yyval.innerSubtypePtr = MT (InnerSubtype);
        yyval.innerSubtypePtr->constraintType = PARTIAL_CT;
        yyval.innerSubtypePtr->constraints = yyvsp[-1].constraintListPtr;
    ;
    break;}
case 180:
#line 1712 "core/parse-asn1.y"
{
        yyval.constraintListPtr = NEWLIST();
        APPEND (yyvsp[0].constraintPtr, yyval.constraintListPtr);
    ;
    break;}
case 181:
#line 1717 "core/parse-asn1.y"
{
        APPEND (yyvsp[0].constraintPtr, yyvsp[-2].constraintListPtr);
        yyval.constraintListPtr = yyvsp[-2].constraintListPtr;
    ;
    break;}
case 182:
#line 1725 "core/parse-asn1.y"
{
        yyval.constraintPtr = yyvsp[0].constraintPtr;
        yyval.constraintPtr->fieldRef = yyvsp[-1].charPtr;
    ;
    break;}
case 184:
#line 1735 "core/parse-asn1.y"
{
        yyval.constraintPtr = MT (Constraint);
        yyval.constraintPtr->presenceConstraint = yyvsp[0].intVal;
        yyval.constraintPtr->valueConstraints = yyvsp[-1].subtypePtr;
    ;
    break;}
case 185:
#line 1743 "core/parse-asn1.y"
{ yyval.subtypePtr = yyvsp[0].subtypePtr; ;
    break;}
case 186:
#line 1744 "core/parse-asn1.y"
{ yyval.subtypePtr = NULL; ;
    break;}
case 187:
#line 1748 "core/parse-asn1.y"
{ yyval.intVal = PRESENT_CT; ;
    break;}
case 188:
#line 1749 "core/parse-asn1.y"
{ yyval.intVal = ABSENT_CT; ;
    break;}
case 189:
#line 1750 "core/parse-asn1.y"
{ yyval.intVal = EMPTY_CT; ;
    break;}
case 190:
#line 1751 "core/parse-asn1.y"
{ yyval.intVal = OPTIONAL_CT; ;
    break;}
case 191:
#line 1765 "core/parse-asn1.y"
{
        yyval.valueDefPtr = MT (ValueDef);
        yyval.valueDefPtr->definedName = yyvsp[-4].charPtr;
        yyval.valueDefPtr->value = yyvsp[0].valuePtr;
        yyval.valueDefPtr->value->lineNo = yyvsp[-1].intVal;
        yyval.valueDefPtr->value->type = yyvsp[-3].typePtr;
    ;
    break;}
case 194:
#line 1781 "core/parse-asn1.y"
{ yyval.valuePtr =  yyvsp[0].valuePtr; ;
    break;}
case 195:
#line 1783 "core/parse-asn1.y"
{
        /*
         * for parse, may be set to BASICVALUE_IMPORTEDTYPEREF
         * by linker
         */
        SetupValue (&yyval.valuePtr, BASICVALUE_LOCALVALUEREF, myLineNoG);
        yyval.valuePtr->basicValue->a.localValueRef = MT (ValueRef);
        yyval.valuePtr->basicValue->a.localValueRef->valueName = yyvsp[0].charPtr;
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
   ;
    break;}
case 196:
#line 1797 "core/parse-asn1.y"
{
        /* Alloc value with basicValue of importValueRef */
        SetupValue (&yyval.valuePtr, BASICVALUE_IMPORTVALUEREF, yyvsp[-1].intVal);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
        yyval.valuePtr->basicValue->a.importValueRef = MT (ValueRef);
        yyval.valuePtr->basicValue->a.importValueRef->valueName = yyvsp[0].charPtr;
        yyval.valuePtr->basicValue->a.importValueRef->moduleName = yyvsp[-3].charPtr;

        /* add entry to this module's import list */
        AddPrivateImportElmt (modulePtrG, yyvsp[0].charPtr, yyvsp[-3].charPtr, yyvsp[-1].intVal);
    ;
    break;}
case 200:
#line 1815 "core/parse-asn1.y"
{
        SetupValue (&yyval.valuePtr, BASICVALUE_INTEGER, myLineNoG);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
        yyval.valuePtr->basicValue->a.integer = yyvsp[0].intVal;
    ;
    break;}
case 201:
#line 1821 "core/parse-asn1.y"
{
        SetupValue (&yyval.valuePtr, BASICVALUE_ASCIIHEX, myLineNoG);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
        yyval.valuePtr->basicValue->a.asciiHex = MT (AsnOcts);
        yyval.valuePtr->basicValue->a.asciiHex->octs = yyvsp[0].charPtr;
        yyval.valuePtr->basicValue->a.asciiHex->octetLen = strlen (yyvsp[0].charPtr);
    ;
    break;}
case 202:
#line 1829 "core/parse-asn1.y"
{
        SetupValue (&yyval.valuePtr, BASICVALUE_ASCIIBITSTRING, myLineNoG);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
        yyval.valuePtr->basicValue->a.asciiBitString = MT (AsnOcts);
        yyval.valuePtr->basicValue->a.asciiBitString->octs = yyvsp[0].charPtr;
        yyval.valuePtr->basicValue->a.asciiBitString->octetLen = strlen (yyvsp[0].charPtr);
    ;
    break;}
case 203:
#line 1837 "core/parse-asn1.y"
{
        SetupValue (&yyval.valuePtr, BASICVALUE_ASCIITEXT, myLineNoG);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
        yyval.valuePtr->basicValue->a.asciiText = MT (AsnOcts);
        yyval.valuePtr->basicValue->a.asciiText->octs = yyvsp[0].charPtr;
        yyval.valuePtr->basicValue->a.asciiText->octetLen = strlen (yyvsp[0].charPtr);
    ;
    break;}
case 204:
#line 1844 "core/parse-asn1.y"
{ LexBeginBraceBalContext(); ;
    break;}
case 205:
#line 1845 "core/parse-asn1.y"
{
        /*
         *  LEXICAL TIE IN!!
         * string returned by BRACEBAL_SYM has
         * the $1 '{' prepended and includes everything
         * upto and including '}' that balances $1
         */
        LexBeginInitialContext();
        SetupValue (&yyval.valuePtr, BASICVALUE_VALUENOTATION, myLineNoG);
        yyval.valuePtr->basicValue->a.valueNotation = MT (AsnOcts);
        yyval.valuePtr->basicValue->a.valueNotation->octs = yyvsp[0].charPtr;
        yyval.valuePtr->basicValue->a.valueNotation->octetLen = strlen (yyvsp[0].charPtr);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
    ;
    break;}
case 206:
#line 1863 "core/parse-asn1.y"
{
        SetupValue (&yyval.valuePtr, BASICVALUE_BOOLEAN, myLineNoG);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
        yyval.valuePtr->basicValue->a.boolean =  TRUE;
    ;
    break;}
case 207:
#line 1869 "core/parse-asn1.y"
{
        SetupValue (&yyval.valuePtr, BASICVALUE_BOOLEAN, myLineNoG);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
        yyval.valuePtr->basicValue->a.boolean = FALSE;
    ;
    break;}
case 208:
#line 1879 "core/parse-asn1.y"
{
        SetupValue (&yyval.valuePtr, BASICVALUE_SPECIALREAL, myLineNoG);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
        yyval.valuePtr->basicValue->a.specialReal =  PLUS_INFINITY_REAL;
    ;
    break;}
case 209:
#line 1885 "core/parse-asn1.y"
{
        SetupValue (&yyval.valuePtr, BASICVALUE_SPECIALREAL, myLineNoG);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
        yyval.valuePtr->basicValue->a.specialReal = MINUS_INFINITY_REAL;
    ;
    break;}
case 210:
#line 1896 "core/parse-asn1.y"
{
        /* create a NULL value  */
        SetupValue (&yyval.valuePtr, BASICVALUE_NULL, myLineNoG);
        yyval.valuePtr->valueType = BASICTYPE_UNKNOWN;
    ;
    break;}
case 211:
#line 1906 "core/parse-asn1.y"
{
        yyval.namedValuePtr = MT (NamedValue);
        yyval.namedValuePtr->value = yyvsp[0].valuePtr;
    ;
    break;}
case 212:
#line 1911 "core/parse-asn1.y"
{
        yyval.namedValuePtr = MT (NamedValue);
        yyval.namedValuePtr->value = yyvsp[0].valuePtr;
        yyval.namedValuePtr->fieldName = yyvsp[-1].charPtr;
    ;
    break;}
case 213:
#line 1921 "core/parse-asn1.y"
{
        /*
         * example OID setup
         *
         * for { ccitt foo (1) bar bell (bunt) 2 }
         *
         * ccitt
         *   - arcnum is set to number from oid table (oid.c)
         * foo (1)
         *   - sets up a new value def foo defined as 1
         *   - makes oid valueref a value ref to foo (doesn't link it tho)
         * bar
         *   - makes oid valueref a value ref to bar (doesn't link it tho)
         * bell (bunt)
         *   - sets up a new value def bell defined as a val ref to bunt
         *   - makes oid valueref a value ref to bell (doesn't link it tho)
         * 2
         *  - arcnum is set to 2
         */

        yyval.oidPtr = yyvsp[-1].oidPtr;
    ;
    break;}
case 214:
#line 1948 "core/parse-asn1.y"
{
        OID *o;
        /* append component */
        for (o = yyvsp[-1].oidPtr; o->next != NULL; o = o->next)
	    ;
        o->next = yyvsp[0].oidPtr;
        yyval.oidPtr = yyvsp[-1].oidPtr;
    ;
    break;}
case 217:
#line 1964 "core/parse-asn1.y"
{
        Value *newVal;
        /*
         * if the arcName is a defined arc name like
         * ccitt or iso etc, fill in the arc number.
         * otherwise make a value ref to that named value
         */
        yyval.oidPtr = MT (OID);

        yyval.oidPtr->arcNum = OidArcNameToNum (yyvsp[0].charPtr);
        if (yyval.oidPtr->arcNum == NULL_OID_ARCNUM)
        {
            /* set up value ref to named value */
            SetupValue (&newVal, BASICVALUE_LOCALVALUEREF, myLineNoG);
            newVal->basicValue->a.localValueRef = MT (ValueRef);
            newVal->valueType = BASICTYPE_INTEGER;
            newVal->basicValue->a.localValueRef->valueName = yyvsp[0].charPtr;
            yyval.oidPtr->valueRef = newVal;
        }
    ;
    break;}
case 219:
#line 1990 "core/parse-asn1.y"
{
        yyval.oidPtr = MT (OID);
        yyval.oidPtr->arcNum = yyvsp[0].intVal;
    ;
    break;}
case 221:
#line 2003 "core/parse-asn1.y"
{
/*		Value *newVal;	// REN -- 9/23/02 */

		yyval.oidPtr = yyvsp[-1].oidPtr;

		/* shared refs to named numbers name
// REN -- 9/23/02 --
		SetupValue (&newVal, BASICVALUE_INTEGER, myLineNoG);
		newVal->basicValue->a.integer = $$->arcNum;
		newVal->valueType = BASICTYPE_INTEGER;
		AddNewValueDef (oidElmtValDefsG, $1, newVal);
		SetupValue (&newVal, BASICVALUE_LOCALVALUEREF, myLineNoG);
		newVal->basicValue->a.localValueRef = MT (ValueRef);
		newVal->basicValue->a.localValueRef->valueName = $1;

		$$->valueRef = newVal;
*/
		Free(yyvsp[-3].charPtr);		// REN -- 9/23/02 
	;
    break;}
case 222:
#line 2023 "core/parse-asn1.y"
{
/*		Value *newVal;	// REN -- 9/23/02 */

		/* shared refs to named numbers name */
		yyval.oidPtr = MT (OID);
		yyval.oidPtr->arcNum = NULL_OID_ARCNUM;

/*		AddNewValueDef (oidElmtValDefsG, $1, $3);	// REN -- 9/23/02 */

		yyval.oidPtr->valueRef = yyvsp[-1].valuePtr;

		Free(yyvsp[-3].charPtr);		// REN -- 9/23/02 
	;
    break;}
case 226:
#line 2054 "core/parse-asn1.y"
{
	if (yyvsp[0].uintVal>0x7FFFFFFF) {
	    yyerror("Warning: number out of range");
	    yyval.intVal = 0x7FFFFFFF;
	}
	;
    break;}
case 227:
#line 2061 "core/parse-asn1.y"
{
	yyerror ("Warning: number out of range");
	yyval.intVal = 0x7FFFFFFF;
	/* modulePtrG->status = MOD_ERROR; */
	;
    break;}
case 233:
#line 2089 "core/parse-asn1.y"
{ yyval.directiveList = NULL; ;
    break;}
case 234:
#line 2094 "core/parse-asn1.y"
{
        yyval.directiveList = NEWLIST();
        APPEND (yyvsp[0].directivePtr,yyval.directiveList);
	;
    break;}
case 235:
#line 2099 "core/parse-asn1.y"
{
        APPEND (yyvsp[0].directivePtr,yyvsp[-1].directiveList);
        yyval.directiveList = yyvsp[-1].directiveList;
    ;
    break;}
case 236:
#line 2107 "core/parse-asn1.y"
{
		yyval.directivePtr = MT (SnaccDirective);
		yyval.directivePtr->type = ASN1_TypeID;
		yyval.directivePtr->value.asnTypeVal = yyvsp[0].basicTypeChoiceIdEnum;
	;
    break;}
case 237:
#line 2113 "core/parse-asn1.y"
{
		yyval.directivePtr = MT (SnaccDirective);
		yyval.directivePtr->type = C_TypeID;
		yyval.directivePtr->value.cTypeVal = yyvsp[0].cTypeIdEnum;
	;
    break;}
case 238:
#line 2119 "core/parse-asn1.y"
{
		yyval.directivePtr = MT (SnaccDirective);
		yyval.directivePtr->type = yyvsp[-2].directiveEnum;
		yyval.directivePtr->value.boolVal = yyvsp[0].boolVal;
	;
    break;}
case 239:
#line 2125 "core/parse-asn1.y"
{
		yyval.directivePtr = MT (SnaccDirective);
		yyval.directivePtr->type = yyvsp[-2].directiveEnum;
		yyval.directivePtr->value.stringVal = yyvsp[0].charPtr;
	;
    break;}
case 240:
#line 2131 "core/parse-asn1.y"
{
		yyval.directivePtr = MT (SnaccDirective);
		yyval.directivePtr->type = yyvsp[-2].directiveEnum;
		yyval.directivePtr->value.integerVal = yyvsp[0].uintVal;
	;
    break;}
case 241:
#line 2139 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_UNKNOWN; ;
    break;}
case 242:
#line 2140 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_BOOLEAN; ;
    break;}
case 243:
#line 2141 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_INTEGER; ;
    break;}
case 244:
#line 2142 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_BITSTRING; ;
    break;}
case 245:
#line 2143 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_OCTETSTRING; ;
    break;}
case 246:
#line 2144 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_NULL; ;
    break;}
case 247:
#line 2145 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_OID; ;
    break;}
case 248:
#line 2146 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_REAL; ;
    break;}
case 249:
#line 2147 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_ENUMERATED; ;
    break;}
case 250:
#line 2148 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_SEQUENCE; ;
    break;}
case 251:
#line 2149 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_SEQUENCEOF; ;
    break;}
case 252:
#line 2150 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_SET; ;
    break;}
case 253:
#line 2151 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_SETOF; ;
    break;}
case 254:
#line 2152 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_CHOICE; ;
    break;}
case 255:
#line 2153 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_ANY; ;
    break;}
case 256:
#line 2154 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_ANYDEFINEDBY; ;
    break;}
case 257:
#line 2155 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_LOCALTYPEREF; ;
    break;}
case 258:
#line 2156 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_IMPORTTYPEREF; ;
    break;}
case 259:
#line 2157 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_NUMERIC_STR; ;
    break;}
case 260:
#line 2158 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_PRINTABLE_STR; ;
    break;}
case 261:
#line 2159 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_IA5_STR; ;
    break;}
case 262:
#line 2160 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_BMP_STR; ;
    break;}
case 263:
#line 2161 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_UNIVERSAL_STR; ;
    break;}
case 264:
#line 2162 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_UTF8_STR; ;
    break;}
case 265:
#line 2163 "core/parse-asn1.y"
{ yyval.basicTypeChoiceIdEnum = BASICTYPE_T61_STR; ;
    break;}
case 266:
#line 2167 "core/parse-asn1.y"
{ yyval.cTypeIdEnum = C_CHOICE; ;
    break;}
case 267:
#line 2168 "core/parse-asn1.y"
{ yyval.cTypeIdEnum = C_LIST; ;
    break;}
case 268:
#line 2169 "core/parse-asn1.y"
{ yyval.cTypeIdEnum = C_ANY; ;
    break;}
case 269:
#line 2170 "core/parse-asn1.y"
{ yyval.cTypeIdEnum = C_ANYDEFINEDBY; ;
    break;}
case 270:
#line 2171 "core/parse-asn1.y"
{ yyval.cTypeIdEnum = C_LIB; ;
    break;}
case 271:
#line 2172 "core/parse-asn1.y"
{ yyval.cTypeIdEnum = C_STRUCT; ;
    break;}
case 272:
#line 2173 "core/parse-asn1.y"
{ yyval.cTypeIdEnum = C_TYPEDEF; ;
    break;}
case 273:
#line 2174 "core/parse-asn1.y"
{ yyval.cTypeIdEnum = C_TYPEREF; ;
    break;}
case 274:
#line 2175 "core/parse-asn1.y"
{ yyval.cTypeIdEnum = C_NO_TYPE; ;
    break;}
case 275:
#line 2179 "core/parse-asn1.y"
{ yyval.directiveEnum = IsPDU; ;
    break;}
case 276:
#line 2180 "core/parse-asn1.y"
{ yyval.directiveEnum = IsPtr; ;
    break;}
case 277:
#line 2181 "core/parse-asn1.y"
{ yyval.directiveEnum = IsPtrForTypeDef; ;
    break;}
case 278:
#line 2182 "core/parse-asn1.y"
{ yyval.directiveEnum = IsPtrForTypeRef; ;
    break;}
case 279:
#line 2183 "core/parse-asn1.y"
{ yyval.directiveEnum = IsPtrInChoice; ;
    break;}
case 280:
#line 2184 "core/parse-asn1.y"
{ yyval.directiveEnum = IsPtrForOpt; ;
    break;}
case 281:
#line 2185 "core/parse-asn1.y"
{ yyval.directiveEnum = IsEncDec; ;
    break;}
case 282:
#line 2186 "core/parse-asn1.y"
{ yyval.directiveEnum = GenTypeDef; ;
    break;}
case 283:
#line 2187 "core/parse-asn1.y"
{ yyval.directiveEnum = GenPrintRoutine; ;
    break;}
case 284:
#line 2188 "core/parse-asn1.y"
{ yyval.directiveEnum = GenEncodeRoutine; ;
    break;}
case 285:
#line 2189 "core/parse-asn1.y"
{ yyval.directiveEnum = GenDecodeRoutine; ;
    break;}
case 286:
#line 2190 "core/parse-asn1.y"
{ yyval.directiveEnum = GenFreeRoutine; ;
    break;}
case 287:
#line 2191 "core/parse-asn1.y"
{ yyval.directiveEnum = IsBigInt; ;
    break;}
case 288:
#line 2195 "core/parse-asn1.y"
{ yyval.boolVal = TRUE; ;
    break;}
case 289:
#line 2196 "core/parse-asn1.y"
{ yyval.boolVal = FALSE; ;
    break;}
case 290:
#line 2200 "core/parse-asn1.y"
{ yyval.directiveEnum = C_TypeName; ;
    break;}
case 291:
#line 2201 "core/parse-asn1.y"
{ yyval.directiveEnum = C_FieldName; ;
    break;}
case 292:
#line 2202 "core/parse-asn1.y"
{ yyval.directiveEnum = OptionalTestRoutineName; ;
    break;}
case 293:
#line 2203 "core/parse-asn1.y"
{ yyval.directiveEnum = DefaultFieldName; ;
    break;}
case 294:
#line 2204 "core/parse-asn1.y"
{ yyval.directiveEnum = PrintRoutineName; ;
    break;}
case 295:
#line 2205 "core/parse-asn1.y"
{ yyval.directiveEnum = EncodeRoutineName; ;
    break;}
case 296:
#line 2206 "core/parse-asn1.y"
{ yyval.directiveEnum = DecodeRoutineName; ;
    break;}
case 297:
#line 2207 "core/parse-asn1.y"
{ yyval.directiveEnum = FreeRoutineName; ;
    break;}
case 298:
#line 2208 "core/parse-asn1.y"
{ yyval.directiveEnum = ChoiceIdSymbol; ;
    break;}
case 299:
#line 2209 "core/parse-asn1.y"
{ yyval.directiveEnum = ChoiceIdEnumName; ;
    break;}
case 300:
#line 2210 "core/parse-asn1.y"
{ yyval.directiveEnum = ChoiceIdEnumFieldName; ;
    break;}
case 301:
#line 2214 "core/parse-asn1.y"
{ yyval.directiveEnum = ChoiceIdValue; ;
    break;}
case 327:
#line 2252 "core/parse-asn1.y"
{ yyval.charPtr = "OPERATION"; ;
    break;}
case 328:
#line 2253 "core/parse-asn1.y"
{ yyval.charPtr = "ERROR"; ;
    break;}
case 329:
#line 2254 "core/parse-asn1.y"
{ yyval.charPtr = "BIND"; ;
    break;}
case 330:
#line 2255 "core/parse-asn1.y"
{ yyval.charPtr = "UNBIND"; ;
    break;}
case 331:
#line 2256 "core/parse-asn1.y"
{ yyval.charPtr = "APPLICATION-SERVICE-ELEMENT"; ;
    break;}
case 332:
#line 2257 "core/parse-asn1.y"
{ yyval.charPtr = "APPLICATION-CONTEXT"; ;
    break;}
case 333:
#line 2258 "core/parse-asn1.y"
{ yyval.charPtr = "EXTENSION"; ;
    break;}
case 334:
#line 2259 "core/parse-asn1.y"
{ yyval.charPtr = "EXTENSIONS"; ;
    break;}
case 335:
#line 2260 "core/parse-asn1.y"
{ yyval.charPtr = "EXTENSION-ATTRIBUTE"; ;
    break;}
case 336:
#line 2261 "core/parse-asn1.y"
{ yyval.charPtr = "TOKEN"; ;
    break;}
case 337:
#line 2262 "core/parse-asn1.y"
{ yyval.charPtr = "TOKEN-DATA"; ;
    break;}
case 338:
#line 2263 "core/parse-asn1.y"
{ yyval.charPtr = "SECURITY-CATEGORY"; ;
    break;}
case 339:
#line 2264 "core/parse-asn1.y"
{ yyval.charPtr = "OBJECT"; ;
    break;}
case 340:
#line 2265 "core/parse-asn1.y"
{ yyval.charPtr = "PORT"; ;
    break;}
case 341:
#line 2266 "core/parse-asn1.y"
{ yyval.charPtr = "REFINE"; ;
    break;}
case 342:
#line 2267 "core/parse-asn1.y"
{ yyval.charPtr = "ABSTRACT-BIND"; ;
    break;}
case 343:
#line 2268 "core/parse-asn1.y"
{ yyval.charPtr = "ABSTRACT-UNBIND"; ;
    break;}
case 344:
#line 2269 "core/parse-asn1.y"
{ yyval.charPtr = "ABSTRACT-OPERATION"; ;
    break;}
case 345:
#line 2270 "core/parse-asn1.y"
{ yyval.charPtr = "ABSTRACT-ERROR"; ;
    break;}
case 346:
#line 2271 "core/parse-asn1.y"
{ yyval.charPtr = "ALGORITHM"; ;
    break;}
case 347:
#line 2272 "core/parse-asn1.y"
{ yyval.charPtr = "ENCRYPTED"; ;
    break;}
case 348:
#line 2273 "core/parse-asn1.y"
{ yyval.charPtr = "SIGNED"; ;
    break;}
case 349:
#line 2274 "core/parse-asn1.y"
{ yyval.charPtr = "SIGNATURE"; ;
    break;}
case 350:
#line 2275 "core/parse-asn1.y"
{ yyval.charPtr = "PROTECTED"; ;
    break;}
case 351:
#line 2276 "core/parse-asn1.y"
{ yyval.charPtr = "OBJECT-TYPE"; ;
    break;}
case 352:
#line 2285 "core/parse-asn1.y"
{ yyval.typePtr = yyvsp[0].typePtr; ;
    break;}
case 353:
#line 2290 "core/parse-asn1.y"
{
        RosOperationMacroType *r;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ROSOPERATION, myLineNoG);
        r = yyval.typePtr->basicType->a.macroType->a.rosOperation  =
            MT (RosOperationMacroType);
        r->arguments = yyvsp[-3].namedTypePtr;
        r->result    = yyvsp[-2].namedTypePtr;
        r->errors    = yyvsp[-1].typeOrValueListPtr;
        r->linkedOps = yyvsp[0].typeOrValueListPtr;
    ;
    break;}
case 354:
#line 2305 "core/parse-asn1.y"
{ yyval.namedTypePtr = yyvsp[0].namedTypePtr; ;
    break;}
case 355:
#line 2306 "core/parse-asn1.y"
{ yyval.namedTypePtr = NULL; ;
    break;}
case 356:
#line 2310 "core/parse-asn1.y"
{ yyval.namedTypePtr = yyvsp[0].namedTypePtr; ;
    break;}
case 357:
#line 2311 "core/parse-asn1.y"
{ yyval.namedTypePtr = NULL; ;
    break;}
case 359:
#line 2317 "core/parse-asn1.y"
{ yyval.namedTypePtr = NULL; ;
    break;}
case 360:
#line 2323 "core/parse-asn1.y"
{
        yyval.typeOrValueListPtr = yyvsp[-1].typeOrValueListPtr;
    ;
    break;}
case 361:
#line 2326 "core/parse-asn1.y"
{ yyval.typeOrValueListPtr = NULL; ;
    break;}
case 362:
#line 2333 "core/parse-asn1.y"
{
        yyval.typeOrValueListPtr = yyvsp[-1].typeOrValueListPtr;
    ;
    break;}
case 363:
#line 2336 "core/parse-asn1.y"
{ yyval.typeOrValueListPtr = NULL; ;
    break;}
case 364:
#line 2349 "core/parse-asn1.y"
{
        RosErrorMacroType *r;
        /*
         * defines error macro type
         */
        SetupMacroType (&yyval.typePtr, MACROTYPE_ROSERROR, myLineNoG);
        r = yyval.typePtr->basicType->a.macroType->a.rosError = MT (RosErrorMacroType);
        r->parameter = yyvsp[0].namedTypePtr;
    ;
    break;}
case 365:
#line 2362 "core/parse-asn1.y"
{ yyval.namedTypePtr = yyvsp[0].namedTypePtr; ;
    break;}
case 366:
#line 2363 "core/parse-asn1.y"
{ yyval.namedTypePtr = NULL; ;
    break;}
case 367:
#line 2373 "core/parse-asn1.y"
{
        RosBindMacroType *r;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ROSBIND, myLineNoG);

        r = yyval.typePtr->basicType->a.macroType->a.rosBind = MT (RosBindMacroType);
        r->argument  = yyvsp[-2].namedTypePtr;
        r->result = yyvsp[-1].namedTypePtr;
        r->error  = yyvsp[0].namedTypePtr;
    ;
    break;}
case 368:
#line 2386 "core/parse-asn1.y"
{ yyval.namedTypePtr = yyvsp[0].namedTypePtr; ;
    break;}
case 369:
#line 2387 "core/parse-asn1.y"
{ yyval.namedTypePtr = NULL; ;
    break;}
case 370:
#line 2392 "core/parse-asn1.y"
{ yyval.namedTypePtr = yyvsp[0].namedTypePtr; ;
    break;}
case 371:
#line 2393 "core/parse-asn1.y"
{ yyval.namedTypePtr = NULL; ;
    break;}
case 372:
#line 2398 "core/parse-asn1.y"
{ yyval.namedTypePtr = yyvsp[0].namedTypePtr; ;
    break;}
case 373:
#line 2399 "core/parse-asn1.y"
{ yyval.namedTypePtr = NULL; ;
    break;}
case 374:
#line 2409 "core/parse-asn1.y"
{
        RosBindMacroType *r;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ROSUNBIND, myLineNoG);

        r = yyval.typePtr->basicType->a.macroType->a.rosUnbind = MT (RosBindMacroType);
        r->argument = yyvsp[-2].namedTypePtr;
        r->result = yyvsp[-1].namedTypePtr;
        r->error  = yyvsp[0].namedTypePtr;
    ;
    break;}
case 375:
#line 2423 "core/parse-asn1.y"
{ yyval.namedTypePtr = yyvsp[0].namedTypePtr; ;
    break;}
case 376:
#line 2424 "core/parse-asn1.y"
{ yyval.namedTypePtr = NULL; ;
    break;}
case 377:
#line 2434 "core/parse-asn1.y"
{
        RosAseMacroType *r;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ROSASE, myLineNoG);
        r = yyval.typePtr->basicType->a.macroType->a.rosAse  = MT (RosAseMacroType);
        r->operations = yyvsp[0].valueListPtr;
    ;
    break;}
case 378:
#line 2442 "core/parse-asn1.y"
{
        RosAseMacroType *r;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ROSASE, myLineNoG);
        r = yyval.typePtr->basicType->a.macroType->a.rosAse  = MT (RosAseMacroType);
        r->consumerInvokes = yyvsp[-1].valueListPtr;
        r->supplierInvokes = yyvsp[0].valueListPtr;
    ;
    break;}
case 379:
#line 2455 "core/parse-asn1.y"
{
        yyval.valueListPtr = yyvsp[-1].valueListPtr;
    ;
    break;}
case 380:
#line 2463 "core/parse-asn1.y"
{
        yyval.valueListPtr = yyvsp[-1].valueListPtr;
    ;
    break;}
case 381:
#line 2466 "core/parse-asn1.y"
{ yyval.valueListPtr = NULL; ;
    break;}
case 382:
#line 2472 "core/parse-asn1.y"
{
        yyval.valueListPtr = yyvsp[-1].valueListPtr;
    ;
    break;}
case 383:
#line 2475 "core/parse-asn1.y"
{ yyval.valueListPtr = NULL; ;
    break;}
case 385:
#line 2495 "core/parse-asn1.y"
{
        RosAcMacroType *r;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ROSAC, myLineNoG);
        r = yyval.typePtr->basicType->a.macroType->a.rosAc = MT (RosAcMacroType);
        r->nonRoElements = yyvsp[-6].valueListPtr;
        r->bindMacroType = yyvsp[-4].typePtr;
        r->unbindMacroType = yyvsp[-2].typePtr;
        r->remoteOperations = yyvsp[-1].valuePtr;
        r->operationsOf = rosAcSymmetricAsesG;
        r->initiatorConsumerOf = rosAcInitiatorConsumerOfG;
        r->responderConsumerOf = rosAcResponderConsumerOfG;
        r->abstractSyntaxes = yyvsp[0].oidListPtr;
    ;
    break;}
case 386:
#line 2514 "core/parse-asn1.y"
{
        yyval.valueListPtr = yyvsp[-1].valueListPtr;
    ;
    break;}
case 387:
#line 2523 "core/parse-asn1.y"
{
        yyval.valuePtr = yyvsp[-3].valuePtr;
    ;
    break;}
case 388:
#line 2527 "core/parse-asn1.y"
{
        yyval.valuePtr = NULL;
        rosAcSymmetricAsesG = NULL;
        rosAcInitiatorConsumerOfG = NULL;
        rosAcResponderConsumerOfG = NULL;
    ;
    break;}
case 389:
#line 2537 "core/parse-asn1.y"
{
        rosAcSymmetricAsesG = yyvsp[-1].valueListPtr;
    ;
    break;}
case 390:
#line 2540 "core/parse-asn1.y"
{ rosAcSymmetricAsesG = NULL; ;
    break;}
case 392:
#line 2549 "core/parse-asn1.y"
{
        rosAcInitiatorConsumerOfG = yyvsp[-1].valueListPtr;
    ;
    break;}
case 393:
#line 2552 "core/parse-asn1.y"
{ rosAcInitiatorConsumerOfG = NULL; ;
    break;}
case 394:
#line 2557 "core/parse-asn1.y"
{
        rosAcResponderConsumerOfG = yyvsp[-1].valueListPtr;
    ;
    break;}
case 395:
#line 2560 "core/parse-asn1.y"
{ rosAcResponderConsumerOfG = NULL; ;
    break;}
case 396:
#line 2565 "core/parse-asn1.y"
{
        yyval.oidListPtr = yyvsp[-1].oidListPtr;
    ;
    break;}
case 397:
#line 2568 "core/parse-asn1.y"
{ yyval.oidListPtr = NULL; ;
    break;}
case 398:
#line 2574 "core/parse-asn1.y"
{
        yyval.oidListPtr = NEWLIST();
        APPEND (yyvsp[0].oidPtr,yyval.oidListPtr);
    ;
    break;}
case 399:
#line 2579 "core/parse-asn1.y"
{
        APPEND (yyvsp[0].oidPtr, yyvsp[-2].oidListPtr);
        yyval.oidListPtr = yyvsp[-2].oidListPtr;
    ;
    break;}
case 400:
#line 2593 "core/parse-asn1.y"
{
          MtsasExtensionsMacroType *m;

          SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASEXTENSIONS, myLineNoG);
          m = yyval.typePtr->basicType->a.macroType->a.mtsasExtensions =
              MT (MtsasExtensionsMacroType);
          m->extensions = yyvsp[-1].valueListPtr;
      ;
    break;}
case 402:
#line 2606 "core/parse-asn1.y"
{ yyval.valueListPtr = NULL; ;
    break;}
case 403:
#line 2611 "core/parse-asn1.y"
{
         yyval.valueListPtr = NEWLIST();
         APPEND (yyvsp[0].valuePtr, yyval.valueListPtr);
     ;
    break;}
case 404:
#line 2616 "core/parse-asn1.y"
{
         APPEND (yyvsp[0].valuePtr,yyvsp[-2].valueListPtr);
         yyval.valueListPtr = yyvsp[-2].valueListPtr;
     ;
    break;}
case 406:
#line 2624 "core/parse-asn1.y"
{ yyval.typeOrValueListPtr = NULL; ;
    break;}
case 407:
#line 2629 "core/parse-asn1.y"
{
         yyval.typeOrValueListPtr = NEWLIST();
         APPEND (yyvsp[0].typeOrValuePtr, yyval.typeOrValueListPtr);
     ;
    break;}
case 408:
#line 2634 "core/parse-asn1.y"
{
         APPEND (yyvsp[0].typeOrValuePtr,yyvsp[-2].typeOrValueListPtr);
         yyval.typeOrValueListPtr = yyvsp[-2].typeOrValueListPtr;
     ;
    break;}
case 409:
#line 2642 "core/parse-asn1.y"
{
         yyval.typeOrValuePtr = MT (TypeOrValue);
         yyval.typeOrValuePtr->choiceId = TYPEORVALUE_TYPE;
         yyval.typeOrValuePtr->a.type = yyvsp[0].typePtr;
     ;
    break;}
case 410:
#line 2648 "core/parse-asn1.y"
{
         yyval.typeOrValuePtr = MT (TypeOrValue);
         yyval.typeOrValuePtr->choiceId = TYPEORVALUE_VALUE;
         yyval.typeOrValuePtr->a.value = yyvsp[0].valuePtr;
     ;
    break;}
case 411:
#line 2661 "core/parse-asn1.y"
{
        MtsasExtensionMacroType *m;

        SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASEXTENSION, myLineNoG);
        m = yyval.typePtr->basicType->a.macroType->a.mtsasExtension =
            MT (MtsasExtensionMacroType);
        m->elmtType = yyvsp[-2].namedTypePtr;
        m->defaultValue = yyvsp[-1].valuePtr;
        m->criticalForSubmission = mtsasCriticalForSubmissionG;
        m->criticalForTransfer = mtsasCriticalForTransferG;
        m->criticalForDelivery = mtsasCriticalForDeliveryG;

        mtsasCriticalForSubmissionG = NULL;  /* set up for next parse */
        mtsasCriticalForTransferG = NULL;
        mtsasCriticalForDeliveryG = NULL;
    ;
    break;}
case 412:
#line 2678 "core/parse-asn1.y"
{
        SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASEXTENSION, myLineNoG);
        yyval.typePtr->basicType->a.macroType->a.mtsasExtension =
            MT (MtsasExtensionMacroType);
        /*
         * all fields are NULL in the MtsasExtensionsMacroType
         * for this production
         */
    ;
    break;}
case 413:
#line 2690 "core/parse-asn1.y"
{ yyval.valuePtr = yyvsp[0].valuePtr; ;
    break;}
case 414:
#line 2691 "core/parse-asn1.y"
{ yyval.valuePtr = NULL; ;
    break;}
case 419:
#line 2707 "core/parse-asn1.y"
{
        mtsasCriticalForSubmissionG = MT (AsnBool);
        *mtsasCriticalForSubmissionG = TRUE;
    ;
    break;}
case 420:
#line 2712 "core/parse-asn1.y"
{
        mtsasCriticalForTransferG = MT (AsnBool);
        *mtsasCriticalForTransferG = TRUE;
    ;
    break;}
case 421:
#line 2717 "core/parse-asn1.y"
{
        mtsasCriticalForDeliveryG = MT (AsnBool);
        *mtsasCriticalForDeliveryG = TRUE;
    ;
    break;}
case 422:
#line 2731 "core/parse-asn1.y"
{
        MtsasExtensionAttributeMacroType *m;

        SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASEXTENSIONATTRIBUTE, myLineNoG);
        m = yyval.typePtr->basicType->a.macroType->a.mtsasExtensionAttribute =
            MT (MtsasExtensionAttributeMacroType);
        m->type = NULL;
    ;
    break;}
case 423:
#line 2740 "core/parse-asn1.y"
{
        MtsasExtensionAttributeMacroType *m;

        SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASEXTENSIONATTRIBUTE, myLineNoG);
        m = yyval.typePtr->basicType->a.macroType->a.mtsasExtensionAttribute =
            MT (MtsasExtensionAttributeMacroType);
        m->type = yyvsp[0].typePtr;
    ;
    break;}
case 424:
#line 2756 "core/parse-asn1.y"
{
        MtsasTokenMacroType *m;

        SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASTOKEN, myLineNoG);
        m = yyval.typePtr->basicType->a.macroType->a.mtsasToken = MT (MtsasTokenMacroType);
        m->type = NULL;
    ;
    break;}
case 425:
#line 2764 "core/parse-asn1.y"
{
        MtsasTokenMacroType *m;

        SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASTOKEN, myLineNoG);
        m = yyval.typePtr->basicType->a.macroType->a.mtsasToken = MT (MtsasTokenMacroType);
        m->type = yyvsp[0].typePtr;
    ;
    break;}
case 426:
#line 2779 "core/parse-asn1.y"
{
        MtsasTokenDataMacroType *m;

        SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASTOKENDATA, myLineNoG);
        m = yyval.typePtr->basicType->a.macroType->a.mtsasTokenData =
            MT (MtsasTokenDataMacroType);
        m->type = NULL;
    ;
    break;}
case 427:
#line 2788 "core/parse-asn1.y"
{
        MtsasTokenDataMacroType *m;

        SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASTOKENDATA, myLineNoG);
        m = yyval.typePtr->basicType->a.macroType->a.mtsasTokenData =
            MT (MtsasTokenDataMacroType);
        m->type = yyvsp[0].typePtr;
    ;
    break;}
case 428:
#line 2804 "core/parse-asn1.y"
{
        MtsasSecurityCategoryMacroType *m;

        SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASSECURITYCATEGORY, myLineNoG);
        m = yyval.typePtr->basicType->a.macroType->a.mtsasSecurityCategory =
            MT (MtsasSecurityCategoryMacroType);
        m->type = NULL;
    ;
    break;}
case 429:
#line 2813 "core/parse-asn1.y"
{
        MtsasSecurityCategoryMacroType *m;

        SetupMacroType (&yyval.typePtr, MACROTYPE_MTSASSECURITYCATEGORY, myLineNoG);
        m = yyval.typePtr->basicType->a.macroType->a.mtsasSecurityCategory =
            MT (MtsasSecurityCategoryMacroType);
        m->type = yyvsp[0].typePtr;
    ;
    break;}
case 430:
#line 2835 "core/parse-asn1.y"
{
        AsnObjectMacroType *a;
        SetupMacroType (&yyval.typePtr, MACROTYPE_ASNOBJECT, myLineNoG);
        a = yyval.typePtr->basicType->a.macroType->a.asnObject = MT (AsnObjectMacroType);
        a->ports = yyvsp[0].asnPortListPtr;
    ;
    break;}
case 431:
#line 2845 "core/parse-asn1.y"
{
        yyval.asnPortListPtr = yyvsp[-1].asnPortListPtr;
    ;
    break;}
case 432:
#line 2848 "core/parse-asn1.y"
{ yyval.asnPortListPtr = NULL; ;
    break;}
case 433:
#line 2853 "core/parse-asn1.y"
{
        yyval.asnPortListPtr = NEWLIST();
        APPEND (yyvsp[0].asnPortPtr, yyval.asnPortListPtr);
    ;
    break;}
case 434:
#line 2858 "core/parse-asn1.y"
{
        APPEND (yyvsp[0].asnPortPtr, yyvsp[-2].asnPortListPtr);
        yyval.asnPortListPtr = yyvsp[-2].asnPortListPtr;
    ;
    break;}
case 435:
#line 2866 "core/parse-asn1.y"
{
        yyval.asnPortPtr = MT (AsnPort);
        yyval.asnPortPtr->portValue = yyvsp[-1].valuePtr;
        yyval.asnPortPtr->portType = yyvsp[0].intVal;
    ;
    break;}
case 436:
#line 2875 "core/parse-asn1.y"
{
        /* [C] consumer */
        yyval.intVal = CONSUMER_PORT;
    ;
    break;}
case 437:
#line 2880 "core/parse-asn1.y"
{
        /* [S] supplier */
        yyval.intVal = SUPPLIER_PORT;
    ;
    break;}
case 438:
#line 2885 "core/parse-asn1.y"
{
       /* symmetric */
        yyval.intVal = SYMMETRIC_PORT;
    ;
    break;}
case 439:
#line 2898 "core/parse-asn1.y"
{
        AsnPortMacroType *a;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ASNPORT, myLineNoG);
        a = yyval.typePtr->basicType->a.macroType->a.asnPort = MT (AsnPortMacroType);
        a->abstractOps = yyvsp[0].typeOrValueListPtr;
        a->consumerInvokes = asnConsumerG;
        a->supplierInvokes = asnSupplierG;
    ;
    break;}
case 440:
#line 2908 "core/parse-asn1.y"
{
        SetupMacroType (&yyval.typePtr, MACROTYPE_ASNPORT, myLineNoG);
        yyval.typePtr->basicType->a.macroType->a.asnPort = MT (AsnPortMacroType);
    ;
    break;}
case 441:
#line 2917 "core/parse-asn1.y"
{
        yyval.typeOrValueListPtr = yyvsp[-1].typeOrValueListPtr;
    ;
    break;}
case 442:
#line 2921 "core/parse-asn1.y"
{
        yyval.typeOrValueListPtr = NULL;
        asnConsumerG = yyvsp[0].typeOrValueListPtr;
        asnSupplierG = NULL;
    ;
    break;}
case 443:
#line 2927 "core/parse-asn1.y"
{
        yyval.typeOrValueListPtr = NULL;
        asnConsumerG = yyvsp[0].typeOrValueListPtr;
        asnSupplierG = NULL;
    ;
    break;}
case 444:
#line 2933 "core/parse-asn1.y"
{
        yyval.typeOrValueListPtr = NULL;
        asnConsumerG = yyvsp[-1].typeOrValueListPtr;
        asnSupplierG = NULL;
    ;
    break;}
case 445:
#line 2939 "core/parse-asn1.y"
{
        yyval.typeOrValueListPtr = NULL;
        asnConsumerG = yyvsp[-1].typeOrValueListPtr;
        asnSupplierG = NULL;
    ;
    break;}
case 446:
#line 2948 "core/parse-asn1.y"
{
        yyval.typeOrValueListPtr = yyvsp[-1].typeOrValueListPtr;
    ;
    break;}
case 447:
#line 2955 "core/parse-asn1.y"
{
        yyval.typeOrValueListPtr = yyvsp[-1].typeOrValueListPtr;
    ;
    break;}
case 448:
#line 2971 "core/parse-asn1.y"
{
        SetupType (&yyval.typePtr, BASICTYPE_UNKNOWN, myLineNoG);
    ;
    break;}
case 456:
#line 2997 "core/parse-asn1.y"
{
       yyval.intVal = 0; /* just to quiet yacc warning */
    ;
    break;}
case 461:
#line 3015 "core/parse-asn1.y"
{
        yyval.intVal = 0; /* just to quiet yacc warning */
    ;
    break;}
case 462:
#line 3028 "core/parse-asn1.y"
{
        AsnAbstractBindMacroType *a;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ASNABSTRACTBIND, myLineNoG);
        a = yyval.typePtr->basicType->a.macroType->a.asnAbstractBind =
            MT (AsnAbstractBindMacroType);
        a->ports = yyvsp[0].asnPortListPtr;
    ;
    break;}
case 463:
#line 3037 "core/parse-asn1.y"
{
        AsnAbstractBindMacroType *a;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ASNABSTRACTBIND, myLineNoG);
        a = yyval.typePtr->basicType->a.macroType->a.asnAbstractBind =
            MT (AsnAbstractBindMacroType);
        a->ports = yyvsp[-1].asnPortListPtr;
        a->type = yyvsp[0].typePtr;
    ;
    break;}
case 464:
#line 3050 "core/parse-asn1.y"
{
        yyval.asnPortListPtr = yyvsp[-1].asnPortListPtr;
    ;
    break;}
case 465:
#line 3053 "core/parse-asn1.y"
{ yyval.asnPortListPtr = NULL; ;
    break;}
case 466:
#line 3064 "core/parse-asn1.y"
{
        AsnAbstractBindMacroType *a;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ASNABSTRACTUNBIND, myLineNoG);
        a = yyval.typePtr->basicType->a.macroType->a.asnAbstractUnbind =
            MT (AsnAbstractBindMacroType);

        a->ports = yyvsp[0].asnPortListPtr;
    ;
    break;}
case 467:
#line 3074 "core/parse-asn1.y"
{
        AsnAbstractBindMacroType *a;

        SetupMacroType (&yyval.typePtr, MACROTYPE_ASNABSTRACTUNBIND, myLineNoG);
        a = yyval.typePtr->basicType->a.macroType->a.asnAbstractUnbind =
            MT (AsnAbstractBindMacroType);

        a->ports = yyvsp[-1].asnPortListPtr;
        a->type = yyvsp[0].typePtr;
    ;
    break;}
case 468:
#line 3088 "core/parse-asn1.y"
{
        yyval.asnPortListPtr = yyvsp[-1].asnPortListPtr;
    ;
    break;}
case 469:
#line 3091 "core/parse-asn1.y"
{ yyval.asnPortListPtr = NULL; ;
    break;}
case 470:
#line 3101 "core/parse-asn1.y"
{
       yyval.typePtr = yyvsp[0].typePtr;
       yyvsp[0].typePtr->basicType->a.macroType->choiceId = MACROTYPE_ASNABSTRACTOPERATION;
    ;
    break;}
case 471:
#line 3113 "core/parse-asn1.y"
{
        SetupMacroType (&yyval.typePtr, MACROTYPE_ASNABSTRACTERROR, myLineNoG);
        yyval.typePtr->basicType->a.macroType->a.asnAbstractError = MT (RosErrorMacroType);
        yyval.typePtr->basicType->a.macroType->a.asnAbstractError->parameter = yyvsp[0].namedTypePtr;
    ;
    break;}
case 472:
#line 3126 "core/parse-asn1.y"
{
        SetupMacroType (&yyval.typePtr, MACROTYPE_AFALGORITHM, myLineNoG);
        yyval.typePtr->basicType->a.macroType->a.afAlgorithm = yyvsp[0].typePtr;
    ;
    break;}
case 473:
#line 3137 "core/parse-asn1.y"
{
        SetupMacroType (&yyval.typePtr, MACROTYPE_AFENCRYPTED, myLineNoG);
        yyval.typePtr->basicType->a.macroType->a.afEncrypted = yyvsp[0].typePtr;
    ;
    break;}
case 474:
#line 3149 "core/parse-asn1.y"
{
        SetupMacroType (&yyval.typePtr, MACROTYPE_AFSIGNED, myLineNoG);
        yyval.typePtr->basicType->a.macroType->a.afSigned = yyvsp[0].typePtr;
    ;
    break;}
case 475:
#line 3160 "core/parse-asn1.y"
{
        SetupMacroType (&yyval.typePtr, MACROTYPE_AFSIGNATURE, myLineNoG);
        yyval.typePtr->basicType->a.macroType->a.afSignature = yyvsp[0].typePtr;
    ;
    break;}
case 476:
#line 3174 "core/parse-asn1.y"
{
        SetupMacroType (&yyval.typePtr, MACROTYPE_AFPROTECTED, myLineNoG);
        yyval.typePtr->basicType->a.macroType->a.afProtected = yyvsp[0].typePtr;
    ;
    break;}
case 477:
#line 3191 "core/parse-asn1.y"
{
        SnmpObjectTypeMacroType *s;

        SetupMacroType (&yyval.typePtr, MACROTYPE_SNMPOBJECTTYPE, myLineNoG);
        s = yyval.typePtr->basicType->a.macroType->a.snmpObjectType =
            MT (SnmpObjectTypeMacroType);

        s->syntax = yyvsp[-8].typePtr;
        s->access = yyvsp[-6].intVal;
        s->status = yyvsp[-4].intVal;
        s->description = yyvsp[-3].valuePtr;
        s->reference = yyvsp[-2].valuePtr;
        s->index = yyvsp[-1].typeOrValueListPtr;
        s->defVal = yyvsp[0].valuePtr;
    ;
    break;}
case 478:
#line 3210 "core/parse-asn1.y"
{
        if (strcmp (yyvsp[0].charPtr, "read-only") == 0)
            yyval.intVal = SNMP_READ_ONLY;
        else if (strcmp (yyvsp[0].charPtr, "read-write") == 0)
            yyval.intVal = SNMP_READ_WRITE;
        else if (strcmp (yyvsp[0].charPtr, "write-only") == 0)
            yyval.intVal = SNMP_WRITE_ONLY;
        else if (strcmp (yyvsp[0].charPtr, "not-accessible") == 0)
            yyval.intVal = SNMP_NOT_ACCESSIBLE;
        else
        {
            yyerror ("ACCESS field of SNMP OBJECT-TYPE MACRO can only be one of \"read-write\", \"write-only\" or \"not-accessible\"");
            yyval.intVal = -1;
            modulePtrG->status = MOD_ERROR;
        }
        Free (yyvsp[0].charPtr);
   ;
    break;}
case 479:
#line 3232 "core/parse-asn1.y"
{
        if (strcmp (yyvsp[0].charPtr, "mandatory") == 0)
            yyval.intVal = SNMP_MANDATORY;
        else if (strcmp (yyvsp[0].charPtr, "optional") == 0)
            yyval.intVal = SNMP_OPTIONAL;
        else if (strcmp (yyvsp[0].charPtr, "obsolete") == 0)
            yyval.intVal = SNMP_OBSOLETE;
        else if (strcmp (yyvsp[0].charPtr, "deprecated") == 0)
            yyval.intVal = SNMP_DEPRECATED;
        else
        {
            yyerror ("STATUS field of SNMP OBJECT-TYPE MACRO can only be one of \"optional\", \"obsolete\" or \"deprecated\"");
            yyval.intVal = -1;
            modulePtrG->status = MOD_ERROR;
        }
        Free (yyvsp[0].charPtr);
   ;
    break;}
case 480:
#line 3252 "core/parse-asn1.y"
{ yyval.valuePtr = yyvsp[0].valuePtr; ;
    break;}
case 481:
#line 3253 "core/parse-asn1.y"
{ yyval.valuePtr = NULL; ;
    break;}
case 482:
#line 3257 "core/parse-asn1.y"
{ yyval.valuePtr = yyvsp[0].valuePtr; ;
    break;}
case 483:
#line 3258 "core/parse-asn1.y"
{ yyval.valuePtr = NULL; ;
    break;}
case 484:
#line 3263 "core/parse-asn1.y"
{
       yyval.typeOrValueListPtr  = yyvsp[-1].typeOrValueListPtr;
   ;
    break;}
case 485:
#line 3266 "core/parse-asn1.y"
{ yyval.typeOrValueListPtr = NULL; ;
    break;}
case 486:
#line 3271 "core/parse-asn1.y"
{
       yyval.valuePtr  = yyvsp[-1].valuePtr;
   ;
    break;}
case 487:
#line 3274 "core/parse-asn1.y"
{ yyval.valuePtr = NULL; ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 527 "bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;

 yyacceptlab:
  /* YYACCEPT comes here.  */
  if (yyfree_stacks)
    {
      free (yyss);
      free (yyvs);
#ifdef YYLSP_NEEDED
      free (yyls);
#endif
    }
  return 0;

 yyabortlab:
  /* YYABORT comes here.  */
  if (yyfree_stacks)
    {
      free (yyss);
      free (yyvs);
#ifdef YYLSP_NEEDED
      free (yyls);
#endif
    }
  return 1;
}
#line 3277 "core/parse-asn1.y"


void yyerror (char* s)
{
	fprintf (errFileG,
#ifdef WIN32
		"%s(%d) : %s at symbol \"%s\"\n\n",
#else
		"file \"%s\", line %d: %s at symbol \"%s\"\n\n",
#endif
		modulePtrG->asn1SrcFileName, myLineNoG, s, yytext);
}


/*
 * given a Module*, the file name associated witht the open
 * FILE *fPtr, InitAsn1Parser sets up the yacc/lex parser
 * to parse an ASN.1 module read from fPtr and write the
 * parse results into the given Module *mod.
 */
int
InitAsn1Parser PARAMS ((mod, fileName, fPtr),
    Module	*mod _AND_
    char	*fileName _AND_
    FILE	*fPtr)
{
    yyin = fPtr;

    /*
     * reset lexical analyzer input file ptr
     * (only do this on succesive calls ow yyrestart seg faults
     */
#ifdef FLEX_IN_USE
    if (!firstTimeThroughG)
        yyrestart (fPtr);

    firstTimeThroughG = FALSE;
#endif


    /*
     * init modulePtr
     */
    memzero (mod, sizeof (Module));
    modulePtrG = mod;
    mod->asn1SrcFileName = fileName;
    mod->status = MOD_NOT_LINKED;
    mod->hasAnys = FALSE;

    /* init lists to empty */
    mod->typeDefs = AsnListNew (sizeof (void*));
    mod->valueDefs = AsnListNew (sizeof (void*));

    /*
     * init export list stuff
     */
    exportListG = NULL;
    exportsParsedG = FALSE;

    /*
     * reset line number to 1
     */
    myLineNoG = 1;

    /*
     * reset error count
     */
    parseErrCountG = 0;

   /*
    * set up list to hold values defined in parsed oids
// REN -- 9/23/02
    oidElmtValDefsG = AsnListNew (sizeof (void *));
    */

    smallErrG = 0;

    return 0;

}  /* InitAsn1Parser */


/*
 * puts the applicatin tag code, tagCode, and line number it was
 * parsed at into the applTagsG list.  If the APPLICATION tag code
 * is already in the applTagsG list then an error is printed.
 * and the smallErrG flag set to prevent code production.
 */
void
PushApplTag PARAMS ((tagCode, lineNo),
    unsigned long tagCode _AND_
    unsigned long lineNo)
{
    ApplTag *l;
    ApplTag *new;
    int wasDefined = 0;

    /* make sure not already in list */
    for (l = applTagsG; l != NULL; l = l->next)
    {
        if (l->tagCode == tagCode)
        {
            PrintErrLoc (modulePtrG->asn1SrcFileName, lineNo);
            fprintf (errFileG, "ERROR - APPLICATION tags can be used only once per ASN.1 module.  The tag \"[APPLICATION %d]\" was previously used on line %d.\n", tagCode, l->lineNo);
            wasDefined = 1;
            smallErrG = 1;
        }
    }
    if (!wasDefined)
    {
        new = MT (ApplTag);
        new->lineNo = lineNo;
        new->tagCode = tagCode;
        new->next = applTagsG;
        applTagsG = new;
    }
}  /* PushApplTag */


/*
 * Empties the applTagsG list.  Usually done between modules.
 */
void
FreeApplTags()
{
    ApplTag *l;
    ApplTag *lTmp;

    for (l = applTagsG; l != NULL; )
    {
        lTmp = l->next;
        Free (l);
        l = lTmp;
    }
    applTagsG = NULL;
}  /* FreeApplTags */
