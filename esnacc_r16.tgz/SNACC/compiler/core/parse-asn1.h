typedef union
{
    int              intVal;
    unsigned int     uintVal;
    char            *charPtr;
    Type            *typePtr;
    NamedType       *namedTypePtr;
    NamedTypeList   *namedTypeListPtr;
    Value           *valuePtr;
    NamedValue      *namedValuePtr;
    SubtypeValue    *subtypeValuePtr;
    Subtype         *subtypePtr;
    ModuleId        *moduleId;
    OID             *oidPtr;
    OidList         *oidListPtr;
    TypeDef         *typeDefPtr;
    TypeDefList     *typeDefListPtr;
    ValueDef        *valueDefPtr;
    ValueDefList    *valueDefListPtr;
    ExportElmt      *exportList;
    ImportModule    *importModulePtr;
    ImportModuleList *importModuleListPtr;
    ImportElmt      *importElmtPtr;
    ImportElmtList  *importElmtListPtr;
    Tag             *tagPtr;
    TagList         *tagListPtr;
    Constraint      *constraintPtr;
    ConstraintList  *constraintListPtr;
    InnerSubtype    *innerSubtypePtr;
	ValueRangeEndpoint *valueRangeEndpointPtr;
    ValueList       *valueListPtr;
    TypeOrValueList *typeOrValueListPtr;
    TypeOrValue     *typeOrValuePtr;
    AsnPort         *asnPortPtr;
    AsnPortList     *asnPortListPtr;
    SnaccDirectiveList *directiveList;
	SnaccDirective	*directivePtr;
	SnaccDirectiveEnum directiveEnum;
	enum BasicTypeChoiceId basicTypeChoiceIdEnum;
	CTypeId			cTypeIdEnum;
	AsnBool			boolVal;
} YYSTYPE;
#define	BSTRING_SYM	257
#define	HSTRING_SYM	258
#define	CSTRING_SYM	259
#define	UCASEFIRST_IDENT_SYM	260
#define	LCASEFIRST_IDENT_SYM	261
#define	NAMEDMACRO_SYM	262
#define	MACRODEFBODY_SYM	263
#define	BRACEBAL_SYM	264
#define	NUMBER_ERANGE	265
#define	NUMBER_SYM	266
#define	SNACC_ATTRIBUTES	267
#define	DOT_SYM	268
#define	COMMA_SYM	269
#define	LEFTBRACE_SYM	270
#define	RIGHTBRACE_SYM	271
#define	LEFTPAREN_SYM	272
#define	RIGHTPAREN_SYM	273
#define	LEFTBRACKET_SYM	274
#define	RIGHTBRACKET_SYM	275
#define	LESSTHAN_SYM	276
#define	MINUS_SYM	277
#define	GETS_SYM	278
#define	BAR_SYM	279
#define	TAGS_SYM	280
#define	BOOLEAN_SYM	281
#define	INTEGER_SYM	282
#define	BIT_SYM	283
#define	STRING_SYM	284
#define	OCTET_SYM	285
#define	CONTAINING_SYM	286
#define	ENCODED_SYM	287
#define	NULL_SYM	288
#define	SEQUENCE_SYM	289
#define	OF_SYM	290
#define	SET_SYM	291
#define	IMPLICIT_SYM	292
#define	CHOICE_SYM	293
#define	ANY_SYM	294
#define	OBJECT_IDENTIFIER_SYM	295
#define	OPTIONAL_SYM	296
#define	DEFAULT_SYM	297
#define	COMPONENTS_SYM	298
#define	UNIVERSAL_SYM	299
#define	APPLICATION_SYM	300
#define	PRIVATE_SYM	301
#define	TRUE_SYM	302
#define	FALSE_SYM	303
#define	BEGIN_SYM	304
#define	END_SYM	305
#define	DEFINITIONS_SYM	306
#define	EXPLICIT_SYM	307
#define	ENUMERATED_SYM	308
#define	EXPORTS_SYM	309
#define	IMPORTS_SYM	310
#define	REAL_SYM	311
#define	INCLUDES_SYM	312
#define	MIN_SYM	313
#define	MAX_SYM	314
#define	SIZE_SYM	315
#define	FROM_SYM	316
#define	WITH_SYM	317
#define	COMPONENT_SYM	318
#define	PRESENT_SYM	319
#define	ABSENT_SYM	320
#define	DEFINED_SYM	321
#define	BY_SYM	322
#define	PLUS_INFINITY_SYM	323
#define	MINUS_INFINITY_SYM	324
#define	SEMI_COLON_SYM	325
#define	IA5STRING_SYM	326
#define	PRINTABLESTRING_SYM	327
#define	NUMERICSTRING_SYM	328
#define	TELETEXSTRING_SYM	329
#define	T61STRING_SYM	330
#define	VIDEOTEXSTRING_SYM	331
#define	VISIBLESTRING_SYM	332
#define	ISO646STRING_SYM	333
#define	GRAPHICSTRING_SYM	334
#define	GENERALSTRING_SYM	335
#define	BMPSTRING_SYM	336
#define	UNIVERSALSTRING_SYM	337
#define	UTF8STRING_SYM	338
#define	GENERALIZEDTIME_SYM	339
#define	UTCTIME_SYM	340
#define	EXTERNAL_SYM	341
#define	OBJECTDESCRIPTOR_SYM	342
#define	OPERATION_SYM	343
#define	ARGUMENT_SYM	344
#define	RESULT_SYM	345
#define	ERRORS_SYM	346
#define	LINKED_SYM	347
#define	ERROR_SYM	348
#define	PARAMETER_SYM	349
#define	BIND_SYM	350
#define	BINDERROR_SYM	351
#define	UNBIND_SYM	352
#define	UNBINDERROR_SYM	353
#define	ASE_SYM	354
#define	OPERATIONS_SYM	355
#define	CONSUMERINVOKES_SYM	356
#define	SUPPLIERINVOKES_SYM	357
#define	AC_SYM	358
#define	ASES_SYM	359
#define	REMOTE_SYM	360
#define	INITIATOR_SYM	361
#define	RESPONDER_SYM	362
#define	ABSTRACTSYNTAXES_SYM	363
#define	CONSUMER_SYM	364
#define	EXTENSIONS_SYM	365
#define	CHOSEN_SYM	366
#define	EXTENSION_SYM	367
#define	CRITICAL_SYM	368
#define	FOR_SYM	369
#define	DELIVERY_SYM	370
#define	SUBMISSION_SYM	371
#define	TRANSFER_SYM	372
#define	EXTENSIONATTRIBUTE_SYM	373
#define	TOKEN_SYM	374
#define	TOKENDATA_SYM	375
#define	SECURITYCATEGORY_SYM	376
#define	OBJECT_SYM	377
#define	PORTS_SYM	378
#define	BOXC_SYM	379
#define	BOXS_SYM	380
#define	PORT_SYM	381
#define	ABSTRACTOPS_SYM	382
#define	REFINE_SYM	383
#define	AS_SYM	384
#define	RECURRING_SYM	385
#define	VISIBLE_SYM	386
#define	PAIRED_SYM	387
#define	ABSTRACTBIND_SYM	388
#define	ABSTRACTUNBIND_SYM	389
#define	TO_SYM	390
#define	ABSTRACTERROR_SYM	391
#define	ABSTRACTOPERATION_SYM	392
#define	ALGORITHM_SYM	393
#define	ENCRYPTED_SYM	394
#define	SIGNED_SYM	395
#define	SIGNATURE_SYM	396
#define	PROTECTED_SYM	397
#define	OBJECTTYPE_SYM	398
#define	SYNTAX_SYM	399
#define	ACCESS_SYM	400
#define	STATUS_SYM	401
#define	DESCRIPTION_SYM	402
#define	REFERENCE_SYM	403
#define	INDEX_SYM	404
#define	DEFVAL_SYM	405
#define	ATTRIB_ASN1_TYPE_ID	406
#define	ATTRIB_C_TYPE_ID	407
#define	ATTRIB_C_TYPE_NAME_SYM	408
#define	ATTRIB_C_FIELD_NAME_SYM	409
#define	ATTRIB_IS_PDU_SYM	410
#define	ATTRIB_IS_PTR_SYM	411
#define	ATTRIB_IS_PTR_TYPEDEF_SYM	412
#define	ATTRIB_IS_PTR_TYPE_REF_SYM	413
#define	ATTRIB_IS_PTR_IN_CHOICE_SYM	414
#define	ATTRIB_IS_PTR_FOR_OPT_SYM	415
#define	ATTRIB_OPT_TEST_ROUTINE_SYM	416
#define	ATTRIB_DEFAULT_FIELD_SYM	417
#define	ATTRIB_PRINT_ROUTINE_SYM	418
#define	ATTRIB_ENCODE_ROUTINE_SYM	419
#define	ATTRIB_DECODE_ROUTINE_SYM	420
#define	ATTRIB_FREE_ROUTINE_SYM	421
#define	ATTRIB_IS_ENC_DEC_SYM	422
#define	ATTRIB_GEN_TYPEDEF_SYM	423
#define	ATTRIB_GEN_PRINT_ROUTINE_SYM	424
#define	ATTRIB_GEN_ENCODE_ROUTINE_SYM	425
#define	ATTRIB_GEN_DECODE_ROUTINE_SYM	426
#define	ATTRIB_GEN_FREE_ROUTINE_SYM	427
#define	ATTRIB_CHOICE_ID_SYMBOL_SYM	428
#define	ATTRIB_CHOICE_ID_VALUE_SYM	429
#define	ATTRIB_CHOICE_ID_ENUM_NAME_SYM	430
#define	ATTRIB_CHOICE_ID_ENUM_FIELD_NAME_SYM	431
#define	ATTRIB_IS_BIG_INT_SYM	432
#define	ATTRIB_NAMESPACE_SYM	433
#define	C_CHOICE_SYM	434
#define	C_LIST_SYM	435
#define	C_ANY_SYM	436
#define	C_ANYDEFBY_SYM	437
#define	C_LIB_SYM	438
#define	C_STRUCT_SYM	439
#define	C_TYPEDEF_SYM	440
#define	C_TYPEREF_SYM	441
#define	C_NO_TYPE_SYM	442
#define	UNKNOWN_SYM	443
#define	BITSTRING_SYM	444
#define	OCTETSTRING_SYM	445
#define	SEQUENCE_OF_SYM	446
#define	SET_OF_SYM	447
#define	ANY_DEFINED_BY_SYM	448
#define	LOCAL_TYPE_REF_SYM	449
#define	IMPORT_TYPE_REF_SYM	450


extern YYSTYPE yylval;
