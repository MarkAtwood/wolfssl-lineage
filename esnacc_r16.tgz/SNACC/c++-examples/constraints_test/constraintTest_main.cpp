/* JKG:  main test constraints for asn1 */
#include "constraintTest.h"
#include <iostream.h>
#include <fstream>


int constraintTest_main(int argc, char *argv[])
{
/*
    SNACC::TestSetOfNoConstraints temp_ctest;
    
    SNACC::AsnInt_A8 * ptempint;
    SNACC::AsnInt_A8 * ptempint2;
    ptempint=temp_ctest.Append();
    ptempint2=temp_ctest.Append();
    *ptempint=5;
    *ptempint2=10;
  */  
    
	SNACC::ConstraintFailList ConstraintFails;

    
    SNACC::TestSetOfConstraints temp_ctest;
    SNACC::Constraint_IntTest *my;
    SNACC::Constraint_IntTest *my2;
    my=temp_ctest.Append();
    my2=temp_ctest.Append();
    my->gauge1=20000;
    my2->gauge1=30000;  

    
    

/*
	SNACC::ConstraintIntTest temp_ctest, temp_ctest2;
	SNACC::AsnBuf buf;
	unsigned long byte_count=0;

    //SNACC::MyConstraintSet temp_ctestSet;

    temp_ctest.gauge1=30000;
    temp_ctest.gauge2=4;

    SNACC::MySeqOfTest mtest;
    

    temp_ctestSet.constraintIntTestSet->intConstraintRangeList->constraintIntTest->gauge1=30000;

    temp_ctestSet.constraintIntTestSet->intConstraintRangeList->constraintIntTest->gauge2=2;

	temp_ctest.BEnc(buf);
	temp_ctest2.BDec(buf, byte_count);

	
	std::ofstream ofs("constraintTest.bin"); 
	
    ofs<<"hi";

	ofs.close();

	
	temp_ctest.Print(std::cout);
	std::cout<<std::endl<<"**********"<<std::endl;
	temp_ctest.PrintXML(std::cout);

	std::cout<<std::endl<<"**********"<<std::endl;
    
	temp_ctest2.Print(std::cout);
	std::cout<<std::endl<<"**********"<<std::endl;
	temp_ctest2.PrintXML(std::cout);
    
	std::cout<<std::endl;
	
	  
	SNACC::IntConstraintRange icrange=-101;
	std::cout<<std::endl;

     
	//std::cout<<icrange.checkConstraints(&ConstraintFails)<<std::endl<<std::endl;
	*/
    
    temp_ctest.checkConstraints(&ConstraintFails);
    
    SNACC::ConstraintFailList* pList=&ConstraintFails;
    std::string* curr;
    pList->SetCurrToFirst();
    for(curr=pList->First(); curr!=NULL; curr=pList->GoNext())
        std::cout<<*curr<<std::endl;

  


	return 0;

 }
