// constraints_test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
int constraintTest_main(int argc, char *argv[]);

int main(int argc, char* argv[])
{


	return constraintTest_main(argc, argv);
}
