#include "asnutil.h"
#ifndef NO_THREADS
#include "vda_threads.h"
#endif
#include <strstream>

void newBufTest();
int vdatest_main(int argc, char *argv[]);
void largeTagTest(void);


using namespace SNACC;

void doubleDecodeTest(void)
{
  char buf[] = {0x04,0x01,0x31,0x04,0x01,0x32};
  AsnBuf asnBuf(buf, 6);
  AsnLen len;
  AsnOcts octs;
  try
  {
     std::cout << "*** doubleDecodeTest ***\n";
     if (octs.BDecPdu(asnBuf, len))
     {
        if (octs.c_ustr()[0] == '1')
        {
           std::cout << "First OCTET STRING value: " << octs.c_ustr()[0] << std::endl;

           if (octs.BDecPdu(asnBuf, len))
           {
              if (octs.c_ustr()[0] == '2')
              {
                 std::cout << "Second OCTET STRING value: " 
                           << octs.c_ustr()[0] << std::endl;
              }
              else
              {
                 std::cout << "Unexpected result for second OCTET STRING: "
                           << octs.c_ustr()[0] << std::endl;
              }
           }
           else
              std::cout << "Decode of second OCTET STRING failed!\n";
        }
        else
        {
           std::cout << "ERROR: Unexpected result for first OCTET STRING: "
                     << octs.c_ustr()[0] << std::endl;
        }
     }
     else
        std::cout << "Decode of double OCTET STRING encoded FAILED!\n";

     std::cout << "*** doubleDecodeTest ***\n";

  }
  catch(SnaccException &e)
  {
     std::cout << "Double decode test failed:\n";
     std::cout << "ERROR STRING: ";
     std::cout << e.what() << "\n";
     std::cout.flush();
     std::cout << "*** doubleDecodeTest ***\n";
  }
}


void octsTest(void)
{
  unsigned char buf[] = {0x04,0x14,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x30,0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x50};
  AsnBuf asnBuf((char *)buf, 22);
  size_t i;
  AsnLen len = 22;

  AsnOcts octs;
  try
  {
     std::cout << "*** start of AsnOcts tests ***\n";
     if (octs.BDecPdu(asnBuf, len))
     {
	    if (memcmp(octs.c_ustr(), &buf[2], octs.Len()) == 0)
		{
			for (i = 0; i < 20; i++)
			{
				 std::cout << "OCTET STRING value: " << octs.c_ustr()[i] << std::endl;
			}

		}
		else
		{
			for (i = 0; i < 20; i++)
			{
				std::cout << "ERROR: Unexpected result for OCTET STRING: "
					 << octs.c_ustr()[i] << std::endl;
			}
		}
     }
     else
        std::cout << "Decode of OCTET STRING encoded FAILED!\n";

     std::cout << "*** End of AsnOcts tests ***\n";

  }
  catch(SnaccException &e)
  {
     std::cout << "Octs test failed:\n";
     std::cout << "ERROR STRING: ";
     std::cout << e.what() << "\n";
     std::cout.flush();
     std::cout << "*** End of AsnOcts tests ***\n";
  }
}



int main(int argc, char *argv[])
{
	char *snmpPath=NULL;

	try
	{
		largeTagTest();
		vdatest_main(argc, argv);
		newBufTest();
		if (argc > 1)
		{
			snmpPath = argv[1];
		}
		octsTest();
		doubleDecodeTest();
		inttests();
		bittests();
#ifndef NO_THREADS
		vdaTestThreads(5);
#endif
		TestSetSorting();

		if (snmpPath != NULL)
			run_snmp_tests(snmpPath);

	}
	catch (SnaccException &e)
	{
		std::cout << "\n**** Caught SnaccException ****\n";
		std::cout << "What: " << e.what() << std::endl;
		std::cout << "Call Stack:\n";
		e.getCallStack(std::cout);
	}
	return 1;
}


void largeTagTest(void)
{
	struct tagData
	{
		const char* encData;
		size_t encLen;
		BER_CLASS tagClass;
		BER_FORM tagForm;
		unsigned long tagNum;
	};

	const unsigned int kNumTags = 4;
	const struct tagData kTagTable[kNumTags] =
	{
		{ "\x9f\x7f", 2, CNTX, PRIM, 127 },
		{ "\x7f\x81\x00", 3, APPL, CONS, 128 },
		{ "\xdf\x81\x7f", 3, PRIV, PRIM, 255 },
		{ "\x5f\xff\xff\x7f", 4, APPL, PRIM, 2097151 }	// Max tag number (0x1FFFFF)
	};

	for (unsigned int i = 0; i < kNumTags; ++i)
	{
		AsnBuf asnBuf(kTagTable[i].encData, kTagTable[i].encLen);
		AsnLen bytesDec = 0;
		AsnTag tag = BDecTag(asnBuf, bytesDec);

		AsnTag correctTag = MAKE_TAG_ID(kTagTable[i].tagClass,
			kTagTable[i].tagForm, kTagTable[i].tagNum);

		std::cout << "Large Tag Test #" << i + 1 << ":  ";
		if (tag != correctTag)
			std::cout << "*** FAILED decoding ***" << std::endl;
		else
		{
			AsnBuf encBuf;
			if (kTagTable[i].encLen == 2)
			{
				BEncTag2(encBuf, kTagTable[i].tagClass, kTagTable[i].tagForm,
					kTagTable[i].tagNum);
			}
			else if (kTagTable[i].encLen == 3)
			{
				BEncTag3(encBuf, kTagTable[i].tagClass, kTagTable[i].tagForm,
					kTagTable[i].tagNum);
			}

			if (encBuf == asnBuf)
				std::cout << "PASSED" << std::endl;
			else
				std::cout << "*** FAILED encoding ***" << std::endl;
		}
	}

	// Test whether tag value overflow is caught
	AsnBuf asnBuf("\x5f\xff\xff\xff\x7f", 5);
	AsnLen bytesDec = 0;

	std::cout << "Tag Overflow Test:  ";
	try {
		AsnTag tag = BDecTag(asnBuf, bytesDec);
		std::cout << "*** FAILED -- no exception thrown! ***" << std::endl;
	}
	catch (SnaccException& snaccE) {
		if (snaccE.m_errorCode == INVALID_TAG)
			std::cout << "PASSED" << std::endl;
		else
			std::cout << "*** FAILED -- wrong exception thrown! ***" << std::endl;
	}
}
