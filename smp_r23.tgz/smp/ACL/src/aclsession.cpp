//////////////////////////////////////////////////////////////////////////////
// aclsession.cpp
// These routines support the Session Class
// CONSTRUCTOR(s):
//   Session(void)
//   Session(CTIL::CSM_CtilMgr *pCSMIME)
// DESTRUCTOR:
//   ~Session(void)
// MEMBER FUNCTIONS:
//   usingLDAP(void)
//   usingCML(void)
//   usingAutoRetrieve(void)
//   addAC(CTIL::CSM_Buffer &o)
//   addCC(CTIL::CSM_Buffer &o)
//   addSPIF(CTIL::CSM_Buffer &o)
//   enableCML(long session)
//   enableLDAP(char *dllFilename, char *serverName, long portNumber)
//   enableAutoRetrieve(bool bAutoRetrieve)
//   getAC(AC &ac)
//   getAC(MatchInfo &matchInfo)
//   getSPIF(SPIF &spif)
//   getSPIF(MatchInfo &matchInfo)
//   getCC(ClearanceCert &cc)
//   getCC(MatchInfo &matchInfo)
//   getCacheable(Cacheable &cacheable)
//   readConfig(char *pConfigFileName)
//   findTrust(CML::ASN::DN &DN, AsnOid &Id)
//   addTrust(CML::ASN::DN &dn, AsnOid &oid)
//   displayCache(ostream &os)
//   removeCache(Cacheable &item)
//   updateCache(Cacheable &item)
//   updateTTL(Cacheable &cacheable)
//////////////////////////////////////////////////////////////////////////////

#include "acl_api.h"
#include "aclinternal.h"
#include "acltlist.h"
#include <memory>

#if defined(SunOS) || defined(Linux)
#include "dlfcn.h"
#endif

_USING_NAMESPACE_SNACC
_BEGIN_NAMESPACE_ACL

class AclCache : public ACL_VList<Cacheable>{};

//typedef ACL_VList<acl::Cacheable> AclCache;

extern void CREATE_LDAP_HANDLE(char *dllFilename, char *serverName,
                         long portNumber, ulong **SRLsessionID);
extern void DESTROY_LDAP_HANDLE(ulong *);

// CONSTRUCTOR:
//
Session::Session(CTIL::CSM_CtilMgr *pCtilMgr)
{
   m_pCache = NULL;
   m_pSRLsessionID = NULL;
   
	setCtilMgr(pCtilMgr);
 
   m_External_CML_Session = 0;
   m_bAutoRetrieveFlag = false;
   m_pCsmime = NULL;
   m_pTrustList = NULL;
   m_dms_mode = false;
   m_disable_validation = false;
   m_disable_trustlist = false;
   m_spifTTL = 336; // 2 weeks
   m_acTTL = 48;    // 2 days
   m_ccTTL = 336;   // 2 weeks
   m_eCacheMode = LOCAL_THEN_REMOTE;
   m_bUseEquivalencies = true;
   m_bSpifSignerAttr = false;
} // END OF CONSTRUCTOR

// DESTRUCTOR:
//
Session::~Session(void)
{
   if (m_pCache != NULL)
   {
      delete m_pCache;
      m_pCache = NULL;
   }
   //  m_pCsmime cannot be deleted here - it's handled by the application
   //  if (m_pCsmime != NULL)
   //      delete m_pCsmime;
   if (m_pSRLsessionID != NULL)
   {
      DESTROY_LDAP_HANDLE(m_pSRLsessionID);
	  free(m_pSRLsessionID);
   }

   // IF an internal CML Session exists destroy it.
   //
   if (m_Internal_CML_Session != 0)
   {
      CM_DestroySession(&m_Internal_CML_Session);
      m_Internal_CML_Session = 0;
   }

   delete m_pTrustList;

} // END OF DESTRUCTOR

/** FUNCTION: Session::setCtilMgr()
 *
 * Store the CSM_CtilMgr pointer in the internal CML session.
 * Note the internal CML session will be used for signature
 * verification only.
 */
void Session::setCtilMgr(CTIL::CSM_CtilMgr *pCtilMgr)
{
	FUNC("Session::setCtilMgr()");

	if (pCtilMgr)
	{
		if (m_Internal_CML_Session != 0)
		{
			CM_DestroySession(&m_Internal_CML_Session);
		}
		
 		InitSettings_struct settings;
 		memset(&settings, 0, sizeof(InitSettings_struct));
		settings.cbSize = sizeof(InitSettings_struct);
        settings.revPolicy = CM_REVCRL;
        settings.trustedCerts = NULL;
        settings.nCertCacheSize = 100;
        settings.nCrlCacheSize = 100;
        settings.certCacheTTL = 24*60*60; /* one day */
        settings.crlCacheTTL = 24*60*60; /* one day */
        settings.nMaxPaths = 12;
 		settings.pTokenObj = pCtilMgr;

		if (CM_CreateSessionExt(&m_Internal_CML_Session, &settings) 
			!= CM_NO_ERROR)
		{
		    throw ACL_EXCEPT(ACL_CML_ERROR,"CM_CreateSessionExt() failed!");
		}
	}
}
// usingLDAP:
// Returns true if LDAP is being used and
// false if it is not.
//
bool Session::usingLDAP(void)
{
   bool lRetVal=false;
   if (m_pSRLsessionID != NULL && m_disable_validation == false)
   {
      lRetVal = true;
   }
   return(lRetVal);
} // END OF MEMBER FUNCTION usingLDAP

// usingCML:
// Returns true if an external CML session is being used and
// false if it is not.
//
bool Session::usingCML(void)
{
   return (m_External_CML_Session != 0);
}
// END OF MEMBER FUNCTION usingCML

// usingAutoRetrieve:
// Returns value true if autoRetrieve is enabled
//
bool Session::usingAutoRetrieve(void)
{
   return(m_bAutoRetrieveFlag);
} // END OF MEMBER FUNCTION usingAutoRetrieve

// addAC:
//   INPUT: CTIL::CSM_Buffer - An encoded Attribute Certificate
//   OUTPUT: NONE
//   RETURN: NONE
//   THIS FUNCTION WILL CHECK CACHE (m_pCache) FOR THE PASSED ITEM THEN,
//   IF IT IS NOT FOUND, WILL ADD THE ITEM TO THE LIST
//
void Session::addAC(CTIL::CSM_Buffer &o)
{
   AC newAC(o);

   updateCache(newAC);

} // END OF MEMBER FUNCTION addAC

// addCC:
//   INPUT: CTIL::CSM_Buffer - An encoded Clearance Certificate
//   OUTPUT: NONE
//   RETURN: NONE
//   THIS FUNCTION WILL CHECK CACHE (m_pCache) FOR THE PASSED ITEM THEN,
//   IF IT IS NOT FOUND, WILL ADD THE ITEM TO THE LIST
//
void Session::addCC(CTIL::CSM_Buffer &o)
{
   ClearanceCert newCC(o);
   updateCache(newCC);
} // END OF MEMBER FUNCTION addCC

// addSPIF:
//   INPUT: CTIL::CSM_Buffer - An encoded Security Policy Information File
//   OUTPUT: NONE
//   RETURN: NONE
//   THIS FUNCTION WILL CHECK CACHE (m_pCache) FOR THE PASSED ITEM THEN,
//   IF IT IS NOT FOUND, WILL ADD THE ITEM TO THE LIST
//
void Session::addSPIF(CTIL::CSM_Buffer &o)
{
   SPIF newSPIF(o);
   updateCache(newSPIF);
} // END OF MEMBER FUNCTION addSPIF

// enableCML:
//
void Session::enableCML(long session)
{
   FUNC("Session::enableCML");
   try
   {
      m_External_CML_Session = session;
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
} // END OF MEMBER FUNCTION enableCML

// enableLDAP:
//
void Session::enableLDAP(char *dllFilename, char *serverName,
                         long portNumber)
{

   FUNC("Session::enableLDAP");
   try
   {
       if (m_pSRLsessionID)
           SRL_DestroySession(m_pSRLsessionID);

       CREATE_LDAP_HANDLE(dllFilename, serverName, 
           portNumber, &m_pSRLsessionID);
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
} // END OF MEMBER FUNCTION enableLDAP

// enableAutoRetrieve:
//
void Session::enableAutoRetrieve(bool bAutoRetrieve)
{
   m_bAutoRetrieveFlag = bAutoRetrieve;
} // END OF MEMBER FUNCTION enableAutoRetrieve

// getAC:
//
AC *Session::getAC(AC &ac)
{
   return ((AC *) getCacheable(ac));
} // END OF MEMBER FUNCTION getAC

// getSPIF:
//
SPIF *Session::getSPIF(SPIF &spif)
{
   return ((SPIF *) getCacheable(spif));

} // END OF MEMBER FUNCTION getSPIF

// getCC:
//
ClearanceCert * Session::getCC(ClearanceCert &cc)
{
   return ((ClearanceCert *) getCacheable(cc));
} // END OF MEMBER FUNCTION getCC

// getCacheable:
//
Cacheable * Session::getCacheable(Cacheable &cacheable)
{
   Cacheable *pRetVal = NULL;
   Cacheable *pCurr = NULL;

   FUNC("Session::getCacheable");
   try
   {
       if (m_pCache != NULL)
       {
          for (this->m_pCache->SetCurrToFirst();
               (pCurr = this->m_pCache->Curr()) != NULL;
               this->m_pCache->GoNext())
          {
             if ( (cacheable.type == pCurr->type) &&
                 cacheable.getHash() == pCurr->getHash() )
             {
                pRetVal = pCurr->clone();
                break;
             }
          }
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return pRetVal;

} // END OF MEMBER FUNCTION getCacheable

// readConfig:
// GET FLAGS ONLY
//
long Session::readConfig(char *pConfigFileName)
{
   char       *pDefaultConfigFile="acl.cfg";
   char        sConfigFile[ACL_PATH_LEN];
   long        lStatus=ACL_NO_ERROR;
   KwValue     kwValue;
   KwValue     dllNameValue;
   KwValue     serverNameValue;
   KwValue     portNumberValue;
   SM_RET_VAL  status=0;
   char       *ldapSection = "enableLDAP";  // Search for this section name
   char       *cacheSection = "cache";      // Search for this section name
   char       *errFmtStr =
               "invalid %s Time To Live value (%d)\n\tMust be zero or greater\n";

   FUNC("Session::readConfig");
   try
   {
       if ((strlen(pConfigFileName)) != 0)
       {
          strcpy(sConfigFile, pConfigFileName);
       }
       else
       {
          strcpy(sConfigFile, pDefaultConfigFile);
       }

       ConfigFile CfgObj(sConfigFile);

       if (CfgObj.GetKwValue("dms_mode", kwValue) == 0)
       {
          if (strcmp(kwValue,"true") == 0)
          {
             this->m_dms_mode = true;
          }
       }

       // Look in Cache section for AC, SPIF and ClearanceCertificates TTL
       // (TimeToLive) parameters
       //
       if (CfgObj.GetKwValue("ac_ttl", kwValue, cacheSection) == 0)
       {
          this->m_acTTL = atol(kwValue);
          // ENSURE THERE ARE NO TIME TO LIVE VALUES LESS THAN ZERO
          if (this->m_acTTL < 0)
          {
             char errStr[ACL_STR_BUF_LEN];
             sprintf(errStr, errFmtStr, "AC", this->m_acTTL);
             throw ACL_EXCEPT(ACL_CFG_ERROR, errStr);
          }
       }
       if (CfgObj.GetKwValue("spif_ttl", kwValue, cacheSection) == 0)
       {
          this->m_spifTTL = atol(kwValue);
          // ENSURE THERE ARE NO TIME TO LIVE VALUES LESS THAN ZERO
          if (this->m_spifTTL < 0)
          {
             char errStr[ACL_STR_BUF_LEN];
             sprintf(errStr, errFmtStr, "SPIF", this->m_acTTL);
             throw ACL_EXCEPT(ACL_CFG_ERROR, errStr);
          }
       }
       if (CfgObj.GetKwValue("cc_ttl", kwValue, cacheSection) == 0)
       {
          this->m_ccTTL = atol(kwValue);
          // ENSURE THERE ARE NO TIME TO LIVE VALUES LESS THAN ZERO
          if (this->m_ccTTL < 0)
          {
             char errStr[ACL_STR_BUF_LEN];
             sprintf(errStr, errFmtStr, "CC", this->m_acTTL);
             throw ACL_EXCEPT(ACL_CFG_ERROR, errStr);
          }
       }

       if (CfgObj.GetKwValue("enableAutoRetrieve", kwValue, ldapSection) == 0)
       {
          if (strcmp(kwValue,"true") == 0)
             this->m_bAutoRetrieveFlag = true;
       }

       // Look in the enableLDAP section for the LDAP DLL name
       //
#ifdef WIN32
       status = CfgObj.GetKwValue("windllFilename", dllNameValue, ldapSection);
#else
       status = CfgObj.GetKwValue("unixdllFilename", dllNameValue, ldapSection);
#endif
       if (status != -2) // if section was found
       {
          if (status != 0) // if dllFilename keyword wasn't found
          {
             throw ACL_EXCEPT(ACL_CFG_ERROR,
                "enableLDAP section present but,\n\tmissing dllFilename keyword");
          }

          if (CfgObj.GetKwValue("serverName", serverNameValue, ldapSection) != 0)
          {
             throw ACL_EXCEPT(ACL_CFG_ERROR,
                "enableLDAP section present but,\n\tmissing serverName keyword");
          }

          if (CfgObj.GetKwValue("portNumber", portNumberValue, ldapSection) != 0)
          {
             throw ACL_EXCEPT(ACL_CFG_ERROR,
                "enableLDAP section present but,\n\tmissing portNumber keyword");
          }
          else
          {
             long lPortNumber=0;
             long lRtn=0;
             bool bAlpha=false;

             for (int i=0; i<(int)(strlen(portNumberValue)); i++)
             {
                lRtn = isalpha(portNumberValue[i]);
                if (lRtn != 0)
                {
                   bAlpha = true;
                   break;
                }
             }

             if (bAlpha == false)
             {
                lPortNumber = atol(portNumberValue);
             }

             if ((bAlpha == true) || (lPortNumber == 0))
             {
                throw ACL_EXCEPT(ACL_CFG_ERROR,
                   "invalid LDAP port Number");
             }

             lPortNumber = atol(portNumberValue);

             enableLDAP(dllNameValue, serverNameValue, lPortNumber);
          }

       }

   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return(lStatus);
} // END OF MEMBER FUNCTION readConfig

// findTrust:
//
bool Session::findTrust(CML::ASN::DN &DN, AsnOid &Id)
{
   Trust *ptmpTrust = NULL;

   if (m_pTrustList == NULL)
      return(false);
   if (m_disable_trustlist == true)
      return(true);
   for(m_pTrustList->SetCurrToFirst(), ptmpTrust=m_pTrustList->Curr();
       ptmpTrust != NULL; ptmpTrust=m_pTrustList->GoNext())
   {
      if (DN == ptmpTrust->GetDN())
      {
         if (Id == ptmpTrust->GetOid())
         {
            return(true);
         }
      }
   }
   return(false);
} // END OF MEMBER FUNCTION findTrust

// addTrust:
// Add the new DN and OID to the trustlist if the DN and the OID
// do not already exist in the list as a pair
//
int Session::addTrust(CML::ASN::DN &dn, AsnOid &oid)
{
   Trust *ptmpTrust = NULL;
   Trust *pnewTrust = NULL;
   int retval = 0;

   if (m_pTrustList == NULL)
      m_pTrustList = new TrustList;

   for(m_pTrustList->SetCurrToFirst(), ptmpTrust=m_pTrustList->Curr();
       ptmpTrust != NULL; ptmpTrust=m_pTrustList->GoNext())
   {
      if ((dn == ptmpTrust->GetDN()) && (oid == ptmpTrust->GetOid()))
      {
         return(ACL_TRUST_EXISTS);
      }
   }

   pnewTrust = m_pTrustList->Append();
   pnewTrust->setOID(oid);
   pnewTrust->setDN(dn);

   return(retval);
} // END OF MEMBER FUNCTION addTrust

// displayCache:
//
void Session::displayCache(AclString &str)
{
   if (m_pCache != NULL)
   {
      m_pCache->SetCurrToFirst();
      while(m_pCache->Curr() != NULL)
      {
         m_pCache->Curr()->getDescription(str);
         m_pCache->GoNext();
      }
   }
   else
   {
      str << "Nothing in Cache\n";
   }
} // END OF MEMBER FUNCTION displayCache

// removeCache:
//
void Session::removeCache(Cacheable &item)
{
   // find in cache first
   //
   bool done = false;
   Cacheable *o = NULL;

   if (m_pCache != NULL)
   {
      m_pCache->SetCurrToFirst();
      while( ! done && (m_pCache->Curr() != NULL) )
      {
         o = m_pCache->Curr();
         if (o->getHash() == item.getHash())
         {
            m_pCache->RemoveCurrFromList();
            done = true;
         }
         else
         {
            m_pCache->GoNext();
         }
      }
   }
} // END OF MEMBER FUNCTION removeCache

// updateCache:
//
void Session::updateCache(Cacheable &item)
{
   bool found = false;

   FUNC("Session::updateCache");

   // find in cache first
   //
   Cacheable *o = NULL;
   try
   {
       if (m_pCache != NULL)
       {
          m_pCache->SetCurrToFirst();
          while( ! found && (m_pCache->Curr() != NULL) )
          {
             o = m_pCache->Curr();
             if (o->type == item.type)
             {
                if (o->getHash() == item.getHash())
                {
                   // Found in Cache so remove it and add item
                   found = true;

                   // Remove current element
                   m_pCache->RemoveCurrFromList();
                   m_pCache->AppendL(item.clone());
                   break;
                }
             }
             m_pCache->GoNext();
          }
       }
       else
       {
          // PIERCE
          //m_pCache = new ACL_VList<Cacheable>;
          m_pCache = new AclCache;
       }
       if (! found)
       {
          Cacheable *pNewNode = item.clone();
          this->updateTTL(*pNewNode);
          m_pCache->AppendL(pNewNode);

       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }

} // END OF MEMBER FUNCTION updateCache

// updateTTL:
//
void Session::updateTTL(Cacheable &cacheable)
{
   time_t currtime;
   time(&currtime);

   FUNC("Session::updateTTL");
   try
   {
       // IF Cacheable enum type IS UPDATED TO INCLUDE NEW TYPES
       // THEN THIS SWITCH STATEMENT SHOULD BE UPDATED AS WELL
       switch (cacheable.type)
       {
          case Cacheable::ACERT_ID:
          {
             currtime += (m_acTTL * 60 * 60); // convert TTL to seconds;
             CML::ASN::Time tmpTime(currtime);
             cacheable.m_ttl = tmpTime;
             break;
          }
          case Cacheable::ACSPIF_ID:
          {
             currtime += (m_spifTTL * 60 * 60); // convert TTL to seconds;
             CML::ASN::Time tmpTime(currtime);
             cacheable.m_ttl = tmpTime;
             break;
          }
          case Cacheable::ACLRCERT_ID:
          {
             currtime += (m_ccTTL * 60 * 60);
             CML::ASN::Time tmpTime(currtime);
             cacheable.m_ttl = tmpTime;
             break;
          }
          default:
          {
             // ERROR: UNKNOWN_ID
             throw ACL_EXCEPT(ACL_NULL_POINTER,
                "Unknown Cacheable Item type");
             break;
          }
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }

} // END OF MEMBER FUNCTION updateTTL

ACList * Session::getAC(MatchInfo &matchInfo)
{
   ACList    *retval=NULL;
   long       lFound=0;
   long       lACs=0;
   Cacheable *pTmpCache=NULL;

   // IF cache is not set to remote only then look in cache
   // first
   if (m_eCacheMode != REMOTE)
   {
      if (m_pCache != NULL)
      {
         for(m_pCache->SetCurrToFirst(), pTmpCache=m_pCache->Curr();
             pTmpCache != NULL; pTmpCache=m_pCache->GoNext())
         {
            // IS THIS AN ATTRIBUTE CERTIFICATE
            if (pTmpCache->type == Cacheable::ACERT_ID)
            {
               lACs++;  // INCREMENT THE AC COUNTER
               if (pTmpCache->matches(matchInfo))
               {
                  lFound++;
                  if (retval == NULL)
                  {
                     retval = new ACList;
                  }
                  AC *pTmpAC = (AC *) pTmpCache;
                  AC *pTAC = retval->Append();
                  *pTAC = *pTmpAC;
               }
            }
         }
      }
   }

   const CML::ASN::DN *pSubjectDN = matchInfo.getSubjectDN();

   // IF THERE IS NO MATCH OF THE PASSED DN AND OPTIONAL POLICYID, THEN NEED
   // TO GET THE AC FROM THE DIRECTORY
   if (lFound == 0 && usingLDAP() && m_eCacheMode != LOCAL && pSubjectDN != NULL)
   {
      CSM_BufferLst *pBufList = NULL;

      pBufList = LdapRequest((CML::ASN::DN *) pSubjectDN, 
          Cacheable::ACERT_ID, m_pSRLsessionID);
      if ((pBufList != NULL) && (pBufList->Count() >= 1))
      {
         CTIL::CSM_Buffer *pBuf = NULL;
         AC *pTmpAC = NULL;
         for (pBufList->SetCurrToFirst(); (pBuf = pBufList->Curr()) != NULL; pBufList->GoNext())
         {
            pTmpAC = new AC(*pBuf);
            if (pTmpAC->matches(matchInfo))
            {
               if (retval == NULL)
               {
                  retval = new ACList;
               }
               retval->AppendCopy(*pTmpAC);
               this->updateCache(*pTmpAC);
            }
            delete pTmpAC;
         }
      }
   }
   return(retval);
}

SPIFList * Session::getSPIF(MatchInfo &matchInfo)
{
   SPIFList    *retval=NULL;
   long       lFound=0;
   long       lSPIFs=0;
   Cacheable *pTmpCache=NULL;

   // IF cache is not set to remote only then look in cache
   // first
   if (m_eCacheMode != REMOTE)
   {
      if (m_pCache != NULL)
      {
         for(m_pCache->SetCurrToFirst(), pTmpCache=m_pCache->Curr();
             pTmpCache != NULL; pTmpCache=m_pCache->GoNext())
         {
            // IS THIS A SPIF
            if (pTmpCache->type == Cacheable::ACSPIF_ID)
            {
               lSPIFs++;  // INCREMENT THE SPIF COUNTER
               if (pTmpCache->matches(matchInfo))
               {
                  lFound++;
                  if (retval == NULL)
                  {
                     retval = new SPIFList;
                  }
                  SPIF *pTmpSPIF = (SPIF *) pTmpCache;
                  SPIF *pTSPIF = retval->Append();
                  *pTSPIF = *pTmpSPIF;
               }
            }
         }
      }
   }

   const CML::ASN::DN *pIssuerDN = matchInfo.getIssuerDN();

   // IF THERE IS NO MATCH OF THE PASSED DN AND OPTIONAL POLICYID, THEN NEED
   // TO GET THE SPIF FROM THE DIRECTORY
   if (lFound == 0 && usingLDAP() && m_eCacheMode != LOCAL && pIssuerDN != NULL)
   {
      CSM_BufferLst *pBufList = NULL;
      pBufList = LdapRequest( (CML::ASN::DN *) pIssuerDN, 
          Cacheable::ACSPIF_ID, m_pSRLsessionID);
      if ((pBufList != NULL) && (pBufList->Count() >= 1))
      {
         CTIL::CSM_Buffer *pBuf = NULL;
         SPIF *pTmpSPIF = NULL;
         for (pBufList->SetCurrToFirst(); (pBuf = pBufList->Curr()) != NULL; pBufList->GoNext())
         {
            pTmpSPIF = new SPIF(*pBuf);
            if (pTmpSPIF->matches(matchInfo))
            {
               if (retval == NULL)
               {
                  retval = new SPIFList;
               }
               retval->AppendCopy(*pTmpSPIF);
               this->updateCache(*pTmpSPIF);
            }
            delete pTmpSPIF;
         }
      }
   }
   return(retval);
}

CCList * Session::getCC(MatchInfo &matchInfo)
{
   CCList    *retval=NULL;
   long       lFound=0;
   long       lCCs=0;
   Cacheable *pTmpCache=NULL;

   // IF cache is not set to remote only then look in cache
   // first
   if (m_eCacheMode != REMOTE)
   {
      if (m_pCache != NULL)
      {
         for(m_pCache->SetCurrToFirst(), pTmpCache=m_pCache->Curr();
             pTmpCache != NULL; pTmpCache=m_pCache->GoNext())
         {
            // IS THIS A CLEARANCE CERTIFICATE
            if (pTmpCache->type == Cacheable::ACLRCERT_ID)
            {
               lCCs++;  // INCREMENT THE CC COUNTER
               if (pTmpCache->matches(matchInfo))
               {
                  lFound++;
                  if (retval == NULL)
                  {
                     retval = new CCList;
                  }
                  ClearanceCert *pTmpCC = (ClearanceCert *) pTmpCache;
                  ClearanceCert *pCC = retval->Append();
                  *pCC = *pTmpCC;
               }
            }
         }
      }
   }

   const CML::ASN::DN *pSubjectDN = matchInfo.getSubjectDN();

   // IF THERE IS NO MATCH OF THE PASSED DN AND OPTIONAL POLICYID, THEN NEED
   // TO GET THE CC FROM THE DIRECTORY
   if (lFound == 0 && usingLDAP() && m_eCacheMode != LOCAL && pSubjectDN != NULL)
   {
      CSM_BufferLst *pBufList = NULL;

      pBufList = LdapRequest((CML::ASN::DN *) pSubjectDN, 
          Cacheable::ACLRCERT_ID, m_pSRLsessionID);
      if ((pBufList != NULL) && (pBufList->Count() >= 1))
      {
         CTIL::CSM_Buffer *pBuf = NULL;
         ClearanceCert *pTmpCC = NULL;
         for (pBufList->SetCurrToFirst(); (pBuf = pBufList->Curr()) != NULL; pBufList->GoNext())
         {
            pTmpCC = new ClearanceCert(*pBuf);
            if (pTmpCC->matches(matchInfo))
            {
               if (retval == NULL)
               {
                  retval = new CCList;
               }
               retval->AppendCopy(*pTmpCC);
               this->updateCache(*pTmpCC);
            }
            delete pTmpCC;
         }
      }
   }
   return(retval);
}

unsigned long Session::getCMLHandle(void)
{
   FUNC("getCMLHandle()");
   try
   {
       if (m_External_CML_Session != 0)
          return m_External_CML_Session;
       else if (m_Internal_CML_Session != 0)
          return m_Internal_CML_Session;
       else
          throw ACL_EXCEPT(ACL_CML_ERROR,"No internal CML session present");
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
}
_END_NAMESPACE_ACL

// EOF aclsession.cpp

