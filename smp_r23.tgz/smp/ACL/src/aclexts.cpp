#include "acl_api.h"
#include "aclinternal.h"

_USING_NAMESPACE_SNACC
_BEGIN_NAMESPACE_ACL

CTIL::CSM_Buffer * CExtensions::getAuthorityKeyIdentifier(Extensions *pExts)
{
   FUNC("CExtensions::getAuthorityKeyIdentifier()");

   CTIL::CSM_Buffer *pRetVal = NULL;
   Extension *pExt = NULL;
   try
   {
       if (pExts)
       {
           for (pExts->SetCurrToFirst(); (pExt = pExts->Curr()) != NULL; pExts->GoNext())
           {
              if (pExt->extnId == id_ce_authorityKeyIdentifier)
              {
                 AuthorityKeyIdentifier *pSnaccAki =
                         (AuthorityKeyIdentifier *) pExt->extnValue.value;

                 if (pSnaccAki->keyIdentifier != NULL)
                 {
                    pRetVal = new CTIL::CSM_Buffer(pSnaccAki->keyIdentifier->c_str(), pSnaccAki->keyIdentifier->Len());
                 }
              }
           }
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return pRetVal;
}

CTIL::CSM_Buffer * CExtensions::getSubjectKeyIdentifier(Extensions *pExts)
{
   FUNC("CExtensions::getSubjectKeyIdentifier()");

   Extension *pExt = NULL;
   CTIL::CSM_Buffer *pRetVal = NULL;
   try
   {
       for (pExts->SetCurrToFirst(); (pExt = pExts->Curr()) != NULL; pExts->GoNext())
       {
          if (pExt->extnId == id_ce_subjectKeyIdentifier)
          {
             SubjectKeyIdentifier *pSnaccSki =
                (SubjectKeyIdentifier *) pExt->extnValue.value;
         
             if (pSnaccSki != NULL)
             {
                pRetVal = new CTIL::CSM_Buffer(pSnaccSki->c_str(), pSnaccSki->Len());
             }
          }
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return pRetVal;
}

_END_NAMESPACE_ACL

// EOF aclexts.cpp

