//////////////////////////////////////////////////////////////////////////////
// aclprint.cpp
// These routines support the PrintableLabel Class
// CONSTRUCTOR(s):
//   PrintableLabel(void)
//   PrintableLabel(SecurityLabel &secLabel, SPIF &spif)
// DESTRUCTOR:
//   ~PrintableLabel()
// MEMBER FUNCTIONS:
//    getPolicyString(void)
//    getClassificationString(void)
//    getClassificationMarkingData(void)
//    getSecurityCatTagSetList(void)
//    getPrivacyMarkString(void)
//    printLabel(ostream &os)
//    getSecurityCatTagSetStr()
//    getSecurityCatTagList()
//
// These routines support the CMarkingData Class
// MEMBER FUNCTIONS:
//    getMarkingPhrase(void)
//    getMarkingCodes(void)
//
// These routines support the CSecurityCatTagSet Class
// MEMBER FUNCTIONS:
//    getSecCatTagSetNameOID(void)
//    getSecCatTagSetString(void)
//    getSecurityCatTagList(void)
//    removeLabelAndCertValue(int tagType, int spfLACV)
//
// These routines support the CSecurityCatTag Class
// MEMBER FUNCTIONS:
//    getSecurityCatTagNameString(void)
//    getTagType(void)
//    getMarkingCode(void)
//    getMarkingQualifierList(void)
//    getTagCategoryList(void)
//
// These routines support the CTagCategory Class
// MEMBER FUNCTIONS:
//    getSecCategoryNameString(void)
//    getLACV(void)
//    getMarkingData(void)
//
// These routines support the CMarkingQualifier Class
// MEMBER FUNCTIONS:
//    getMarkingQualifier(void)
//    getQualifierCode(void)
//////////////////////////////////////////////////////////////////////////////

#include "acl_api.h"
#include "aclinternal.h"
#include "aclintexcept.h"

_USING_NAMESPACE_SNACC
_BEGIN_NAMESPACE_ACL
// CONSTRUCTOR:
//
PrintableLabel::PrintableLabel(void)
{
   m_pSPIF = NULL;
} // END OF CONSTRUCTOR

// ALTERNATE CONSTRUCTOR:
//
PrintableLabel::PrintableLabel(SecurityLabel &secLabel, SPIF &spif)
{
   m_SecLabel = secLabel;
   m_pSPIF = (SPIF *)spif.clone();
} // END OF ALTERNATE CONSTRUCTOR

// DESTRUCTOR:
//
PrintableLabel::~PrintableLabel()
{
   if (m_pSPIF != NULL)
   {
      delete m_pSPIF;
      m_pSPIF = NULL;
   }
} // END OF DESTRUCTOR

// getPolicyString:
// Returns a null terminated character string
// representing the security policy identifier.
//
char * PrintableLabel::getPolicyString(void)
{
   char *policyString=NULL;

   if (m_pSPIF == NULL)
   {
      return("");
   }

   int len = m_pSPIF->spiftoSign->securityPolicyIdData->objectIdName.length();
   if (len > 0)
   {
      policyString = new char[len+1];
      memset(policyString, 0, len+1);
      memcpy(policyString,
              m_pSPIF->spiftoSign->securityPolicyIdData->objectIdName.c_str(), len);
   }

   return(policyString);
} // END OF MEMBER FUNCTION getPolicyString

// getClassificationString:
// Returns a null terminated character string representing
// the security classification name, if present.
//
char * PrintableLabel::getClassificationString(void)
{
   SpifSecurityClassification *pSecClass=NULL;
   SpiftoSignSeqOf            *pClassifications=NULL;
   char                       *classificationString=NULL;

   FUNC("PrintableLabel::getClassificationString");
   try
   {
       // If security classification is empty, return NULL
       if (m_SecLabel.security_classification == NULL)
           return NULL;

       // Make a local pointer to the Security Classification list from this SPIF
       pClassifications = &m_pSPIF->spiftoSign->securityClassifications;

       if ((pClassifications != NULL) && (pClassifications->Count() > 0))
       {
          // Set current to point to the first in the list
          pClassifications->SetCurrToFirst();

          // Loop through each Security Classification searching for a match between
          // the labelAndCertValue fromt the SPIF and the security_classification
          // value from the label.
          for (pSecClass = pClassifications->Curr(); pSecClass != NULL;
               pSecClass = pClassifications->GoNext())
          {
             // When a match is found, create a copy of the Classification String
             // from the SPIF and break out of this loop.
             if (pSecClass->labelAndCertValue == *m_SecLabel.security_classification)
             {
                // COPY THE CLASSIFICATION NAME OUT OF THE APPROPRIATE FORMAT STRING.
                // O.K. this will seem strange.  The Classification Name can be
                // found in one of the following DirectoryString union of format
                // choices:  teletexString, printableString, universalString,
                // utf8String.  Since each of these types is derived from AsnOcts
                // and each is a pointer to the same data, by copying the contents of
                // one choice to a character string, we are in effect copying choices
                // which may have been any of the format selected.  This is why there
                // is no check here for the choiceId before doing this copy.
                //
                ;
                if (pSecClass->classificationName->teletexString->length() > 0)
                {
                   classificationString = strdup(pSecClass->classificationName->teletexString->c_str());
                }
                break;
             } // END IF (labelAndCertValue == security_classification)
          } // END FOR LOOP
       } // END OF NULL CONDITION
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }

   return(classificationString);
} // END OF MEMBER FUNCTION getClassificationString

// getMarkingData:
// Returns an ACL_List template of CMarkingData.
//   See CMarkingData for details.
//
CMarkingDataList * PrintableLabel::getMarkingData(void)
{
   SpifSecurityClassification *pSecClass=NULL;
   SpiftoSignSeqOf            *pClassifications=NULL;
   CMarkingDataList           *pCMarkingDataList=NULL;

   FUNC("PrintableLabel::getMarkingData");
   try
   {
       // If security classification is empty, return NULL
       if (m_SecLabel.security_classification == NULL)
           return NULL;

       // Make a local pointer to the Security Classification list from this SPIF
       pClassifications = &m_pSPIF->spiftoSign->securityClassifications;

       if ((pClassifications != NULL) && (pClassifications->Count() > 0))
       {
          // Set current to point to the first in the list
          pClassifications->SetCurrToFirst();

          // Loop through each Security Classification searching for a match between
          // the labelAndCertValue fromt the SPIF and the security_classification
          // value from the label.
          for (pSecClass = pClassifications->Curr(); pSecClass != NULL;
               pSecClass = pClassifications->GoNext())
          {
             // When a match is found, append to the supplied list each of the
             // MarkingData from the SPIF and break out of this loop.
             if (pSecClass->labelAndCertValue == *m_SecLabel.security_classification)
             {
                MarkingData *pTmpMarkingData=NULL;
                CMarkingData *pTmpCMarkingData=NULL;
                // markingData is optional so check it
                if ((pSecClass->markingData != NULL)
                 && (pSecClass->markingData->Count() > 0))
                {
                   pSecClass->markingData->SetCurrToFirst();
                   for (pTmpMarkingData = pSecClass->markingData->Curr();
                        pTmpMarkingData != NULL;
                        pTmpMarkingData = pSecClass->markingData->GoNext())
                   {
                      if (pCMarkingDataList == NULL)
                      {
                         pCMarkingDataList = new CMarkingDataList;
                      }
                      pTmpCMarkingData = pCMarkingDataList->Append();
                      pTmpCMarkingData->MarkingData::operator = (*pTmpMarkingData);
                   }
                   break;
                }
             } // END IF (labelAndCertValue == security_classification)
          } // END FOR LOOP
       } // END OF NULL CONDITIONAL
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }

   return(pCMarkingDataList);
} // END OF MEMBER FUNCTION getMarkingData

// :
// Returns an ACL_List template of CSecurityCatTag.
//
CSecurityCatTagSetList * PrintableLabel::getSecurityCatTagSetList(void)
{
   CSecurityCatTagSetList   *pSecurityCatTagSetList=NULL;
   SecurityCategoryTagSets  *spfTagSets=NULL;
   SecurityCategoryTagSet    tmpSecCatTagSet;
   SecurityCategoryTagSet   *spfTagSet=NULL;
   const NamedTagSet        *pLblTagSet=NULL;
   SecurityTags              lblTags;

   FUNC("PrintableLabel::getSecurityCatTagSetList");

   // TRAVERSE NamedTagSets (StandardSecurityLabel) in m_SecLabel
   //          find equivalent tagCategories and append them to
   //          a list of SecurityCatTagSet.

   try
   {
      for (m_SecLabel.getSSL().SetCurrToFirst();
           (pLblTagSet = m_SecLabel.getSSL().Curr()) != NULL;
           m_SecLabel.getSSL().GoNext())
      {
         lblTags = pLblTagSet->securityTags;
         spfTagSets = m_pSPIF->spiftoSign->securityCategoryTagSets;
         // SecurityCategoryTagSets are optional so check them
         if ((spfTagSets != NULL) && (spfTagSets->Count() > 0))
         {
            for (spfTagSets->SetCurrToFirst();
                 (spfTagSet = spfTagSets->Curr()) != NULL;
                 spfTagSets->GoNext())
            {
               tmpSecCatTagSet.SecurityCategoryTagSet::operator = (*spfTagSet);
               if (pLblTagSet->tagSetName == spfTagSet->securityCategoryTagSetName)
               {
                  SecurityCategoryTag *pTmpSecCatTag=NULL;

                  // TRAVERSE securityCategoryTags
                  tmpSecCatTagSet.securityCategoryTags.SetCurrToFirst();
                  pTmpSecCatTag = tmpSecCatTagSet.securityCategoryTags.Curr();

                  while (pTmpSecCatTag != NULL)
                  {
                     TagCategories *pTmpTagCats=NULL;
                     // TRAVERSE tagCategories
                     pTmpSecCatTag->tagCategories.SetCurrToFirst();
                     pTmpTagCats = pTmpSecCatTag->tagCategories.Curr();
                     while ( pTmpTagCats != NULL )
                     {
                        // removeLACV() will remove the LACV if it's found
                        // in the label securityTags.
                        //
                        if (CSecurityTag::removeLabelAndCertValue(lblTags,
                                          pTmpTagCats->labelAndCertValue,
                                          pTmpSecCatTag->tagType))
                        {
                           pTmpTagCats = pTmpSecCatTag->tagCategories.GoNext();
                        }
                        else
                        {
                           // LACV was not found in label securityTags so
                           // remove it from the SPIF tagCategories.
                           //
                           if (pTmpSecCatTag->tagCategories.Curr() ==
                               pTmpSecCatTag->tagCategories.Last())
                           {
                              pTmpSecCatTag->tagCategories.RemoveCurrFromList();
                              pTmpTagCats = NULL;
                           }
                           else
                           {
                              pTmpSecCatTag->tagCategories.RemoveCurrFromList();
                              pTmpTagCats = pTmpSecCatTag->tagCategories.Curr();
                           }
                        }
                     } // FOR tagCategories

                     // If all of the tagCategories for the current
                     // securityCategoryTags have been exhausted then remove it.
                     //
                     if (pTmpSecCatTag->tagCategories.Count() < 1)
                     {

                        if (tmpSecCatTagSet.securityCategoryTags.Curr() ==
                            tmpSecCatTagSet.securityCategoryTags.Last())
                        {
                           tmpSecCatTagSet.securityCategoryTags.RemoveCurrFromList();
                           pTmpSecCatTag = NULL;
                        }
                        else
                        {
                           tmpSecCatTagSet.securityCategoryTags.RemoveCurrFromList();
                           pTmpSecCatTag = tmpSecCatTagSet.securityCategoryTags.Curr();
                        }
                     }
                     else
                     {
                        pTmpSecCatTag = tmpSecCatTagSet.securityCategoryTags.GoNext();
                     }
                  }
                  // If there are securityCategoryTags present in the current
                  // tagset being checked then add the tagSet to the list to be
                  // returned.
                  if (tmpSecCatTagSet.securityCategoryTags.Count() > 0)
                  {
                     // CONSTRUCT A CSecurityCatTagSet AND
                     // ADD IT TO THE LIST TO RETURN
                     CSecurityCatTagSet *pCSecurityCatTagSet=NULL;
                     if (pSecurityCatTagSetList == NULL)
                     {
                        pSecurityCatTagSetList = new CSecurityCatTagSetList;
                     }
                     pCSecurityCatTagSet = pSecurityCatTagSetList->Append();
                     pCSecurityCatTagSet->
                        SecurityCategoryTagSet::operator = (tmpSecCatTagSet);
                  }
               } // END OF IF tagSetName
            } // FOR spfTagSets
         } // END NULL spfTagSets CONDITIONAL
      } // FOR m_SecLabel.getSSL()
   }
   catch (InternalAclException &)
   {
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }

   if ((pSecurityCatTagSetList == NULL) || (pSecurityCatTagSetList->Count() < 1))
   {
     return NULL;
   }

   return(pSecurityCatTagSetList);

} // END OF MEMBER FUNCTION getSecurityCatTagSetList

// getPrivacyMarkString:
// Returns a null terminated character string
// representing the privacy mark, if present.
//
char * PrintableLabel::getPrivacyMarkString(void)
{
   // No comparison, just from the label

   if (this->m_SecLabel.privacy_mark != NULL &&
       this->m_SecLabel.privacy_mark->pString != NULL)
   {
      return ((char *)this->m_SecLabel.privacy_mark->pString->c_str());
   }
   else
   {
      return (char *) 0;
   }
} // END OF MEMBER FUNCTION getPrivacyMarkString

// printLabel:
// Directs a formatted SecurityLabel string security
// to the ostream object 'os'. This string representation
// includes the security-classification and all security-category
// values present in the securityLabel (including applying
// all qualifiers such as prefix, suffix and separator).
// The security-policy-identifier and privacy-mark values
// are not included in this string.
//
// Note: iPosition changes donated by William Adams - NEXOR
//
// iPosition is defaulted to zero.  If not entered the function
// behaves as normal, if you enter a value of either 1,2,3,4 or 8 it will
// return the string for that marking code position.
//
void PrintableLabel::printLabel(AclString &os, int iPosition)
{
   char                   *pClassificationNameStr=NULL;
   CMarkingDataList       *pClassMarkingDataList=NULL;
   CMarkingData           *pClassMarkingData=NULL;
   char                   *pClassMarkingPhrase=NULL;
   AsnIntList             *pClassMarkingCodeList=NULL;
   bool                    bSuppressClassName=false;

   char                   *pSecCatNameStr=NULL;
   bool                    bNoNameDisplay=false;

   char                   *pTagCatMarkingPhrase=NULL;
   AsnIntList             *pTagCatMarkingCodeList=NULL;
   CMarkingQualifierList  *pCMarkingQualifierList=NULL;
   CTagCategoryList       *pCTagCategoryList=NULL;
   bool                    bNoMarkingDisplay=false;

   // This bool is set to false if the page position that was passed in to this function (iPosition)
   // equals the position specified in the marking code
   bool					   bWrongPosition = true;		// (NEXOR-wda) 20/8/01

   // This bool is used to check whether a position has been specified by the marking code since
   // if no specified position then the default position is bottom
   bool					   bPositionSpecified = false;	// (NEXOR-wda) 20/8/01

   CSecurityCatTagSetList *pCSecurityCatTagSetList=NULL;
   CSecurityCatTagSet     *pCSecurityCatTagSet=NULL;
   CSecurityCatTagList    *pCSecurityCatTagList=NULL;
   CSecurityCatTag        *pCSecurityCatTag=NULL;
   unsigned long           displayIndex=0;
   std::string             separator="/";
   StrList                *pStrList=NULL;
   StrList                *pClassMarkingPhraseStrList=NULL;

   FUNC("PrintableLabel::printLabel");
   try
   {
       pStrList = new StrList;

       // Start with the Classification Name and Marking Data associated with it
       pClassificationNameStr = getClassificationString();
       pClassMarkingDataList = getMarkingData();

       // Begin collecting Classification Name display information
       if ((pClassMarkingDataList != NULL)
        && (pClassMarkingDataList->Count() > 0))
       {
          pClassMarkingDataList->SetCurrToFirst();
          for(pClassMarkingData = pClassMarkingDataList->Curr();
              pClassMarkingData != NULL;
              pClassMarkingData = pClassMarkingDataList->GoNext())
          {
             pClassMarkingPhrase = pClassMarkingData->getMarkingPhrase();
             pClassMarkingCodeList = pClassMarkingData->getMarkingCodes();
             if ((pClassMarkingCodeList != NULL)
              && (pClassMarkingCodeList->Count() > 0))
             {
                AsnInt *pClassMarkingCode=NULL;
                pClassMarkingCodeList->SetCurrToFirst();
                for(pClassMarkingCode = pClassMarkingCodeList->Curr();
                    pClassMarkingCode != NULL;
                    pClassMarkingCode = pClassMarkingCodeList->GoNext())
                {
                   if (*pClassMarkingCode == (AsnInt)MarkingCode::suppressClassName)
                   {
                      bSuppressClassName=true;
                   }
                   if (*pClassMarkingCode == (AsnInt)MarkingCode::noNameDisplay)
                   {
                      bNoNameDisplay=true;
                   }
                   if (*pClassMarkingCode == (AsnInt)MarkingCode::noMarkingDisplay)
                   {
                      bNoMarkingDisplay=true;
                   }
               	   /**********************************************
			       // Start of changes by William Adams - NEXOR	//
			       **********************************************/

			       /**********************************************************************************
			       // Check to see if any of the marking codes are equal to the position passed in	//
			       **********************************************************************************/
			       if ( *pClassMarkingCode == iPosition )	// (NEXOR-wda) 20/8/01
			       {
			          bWrongPosition = false;
			       }

			       /**********************************************************************************
			       // Check to see if any of the marking code is top and bottom						//
			       **********************************************************************************/
			       if ( *pClassMarkingCode == (AsnInt)MarkingCode::pageTopBottom )
			       {
				      if ( ( iPosition == 1 ) || ( iPosition == 2 ) )
					      bWrongPosition = false;

			       }
			       /**********************************************************************************
			       // Check to see if any of the marking codes specify a position					//
			       **********************************************************************************/
			       if ( ( *pClassMarkingCode == 1 ) || ( *pClassMarkingCode == 2 ) || ( *pClassMarkingCode == 3 ) || ( *pClassMarkingCode == 4 ) || ( *pClassMarkingCode == 8 ) ) // (NEXOR-wda) 20/8/01
				       bPositionSpecified = true;

			       /**********************************************
			       // End of changes by William Adams - NEXOR	//
			       **********************************************/
                }
                /**********************************************
			    // Start of changes by William Adams - NEXOR //
			    **********************************************/

			    /**********************************************************************************
			    // Set the display flags depending on requested position						 //
			    // If the position asked for is not in the marking code then set display bools   //
			    // false. Check that iPosition is not zero since this is the default value and   //
			    // causes the behaviour to stay the same.										 //
			    // !( !bPositionSpecified && ( iPosition == 2 ) ) checks that a position was	 //
			    // specified, if not and the bottom (default) position was asked for then dont   //
			    // disable display of names.													 //
			    **********************************************************************************/
			    if ( iPosition && bWrongPosition && !( !bPositionSpecified && ( iPosition == 2 ) ) ) // (NEXOR-wda) 20/8/01
			    {
			    
				    if ( ( iPosition == 4 ) || ( iPosition == 8 ) || bPositionSpecified )
					    bNoNameDisplay = true;

				    bNoMarkingDisplay = true;

			    }

			    /**********************************************
			    // End of changes by William Adams - NEXOR   //
			    **********************************************/

             }
             // PROCESS THE Marking Phrase INFORMATION
             if (bNoMarkingDisplay == false) // Display Marking Phrase
             {
                // CONSTRUCT A MarkingPhrase NODE
                if (pClassMarkingPhraseStrList == NULL)
                {
                   pClassMarkingPhraseStrList = new StrList;
                }
                std::string *tmpStr=NULL;
                tmpStr = pClassMarkingPhraseStrList->Append();
                *tmpStr = pClassMarkingPhrase;
             }
          } // END OF Marking Data LOOP
       } // END OF COLLECTION OF CLASSIFICATION INFORMATION

       /**********************************************
	    // Start of changes by William Adams - NEXOR //
	    **********************************************/
	    /**********************************************************************************
	    // Also do the check here since there is not always marking data on the			 //
	    // classification so the last check would have been skipped						 //
	    **********************************************************************************/
	    if ( bWrongPosition && iPosition ) // (NEXOR-wda) 20/8/01
	    {
	    
		    if ( ( iPosition == 4 ) || ( iPosition == 8 ) || bPositionSpecified )
			    bNoNameDisplay = true;

		    bNoMarkingDisplay = true;

	    }
	    
	    // reset boolean ready for category processing
	    bWrongPosition = true;
       bPositionSpecified = false;

	    /**********************************************
	    // End of changes by William Adams - NEXOR	 //
	    **********************************************/

       // BUILD THE Classification INFORMATION PORTION OF THE LABEL STRING
       if (bSuppressClassName == false) // (9) Display Classification name
       {
          if (bNoNameDisplay == false) // (5) Display Classification Name
          {
             if (pClassificationNameStr != NULL)
             {
                std::string *pTmpString=NULL;
                pTmpString = pStrList->Append();
                *pTmpString = pClassificationNameStr;
             }
          }
       }

       if (bNoMarkingDisplay == false) // (6) Display Marking Phrase
       {
          // NOW APPEND THE MARKING PHRASE(S)
          if ((pClassMarkingPhraseStrList != NULL)
           && (pClassMarkingPhraseStrList->Count() > 0))
          {
             std::string *pTmpPtr=NULL;
             if (pStrList != NULL)
             {
                // IT SHOULD BE ANYWAY, BUT JUST TO BE SURE
                pStrList->SetCurrToFirst();
                // APPEND THE SEPARATOR TO THE FIRST STRING (Classification Name)
                pStrList->Curr()->append(separator);
             }
             pClassMarkingPhraseStrList->SetCurrToFirst();
             pTmpPtr = pClassMarkingPhraseStrList->Curr();
             while (pTmpPtr != NULL)
             {
                // IF THIS IS NOT THE LAST Marking Phrase
                if (pClassMarkingPhraseStrList->Curr() != 
                    pClassMarkingPhraseStrList->Last())
                {
               
                   pStrList->AppendCopy(*pTmpPtr);
                   pStrList->Curr()->append(separator);
                }
                else
                {
                   pStrList->AppendCopy(*pTmpPtr);
                }
                pTmpPtr = pClassMarkingPhraseStrList->GoNext();        
             }
          }
       }

       // Begin collecting Security Category display information
       // Start by gathering the list of Security Category Tag Sets
       pCSecurityCatTagSetList = getSecurityCatTagSetList();
       if (pCSecurityCatTagSetList != NULL)
       {
          // Loop through each Tag Set in the list
          pCSecurityCatTagSetList->SetCurrToFirst();
          for(pCSecurityCatTagSet = pCSecurityCatTagSetList->Curr();
              pCSecurityCatTagSet != NULL;
              pCSecurityCatTagSet = pCSecurityCatTagSetList->GoNext())
          {
             // Here we have access to each Security Category Tag Set Name OID
             // and to each Security Category Tag Set String
             //

             // Check for at least one Security Category Tag in the list
             if ((pCSecurityCatTagList =
                     pCSecurityCatTagSet->getSecurityCatTagList()) != NULL)
             {
                // Each Security Category Tag contains Marking Qualifiers
                // and a sequence of TagCategories
                pCSecurityCatTagList->SetCurrToFirst();
                for(pCSecurityCatTag = pCSecurityCatTagList->Curr();
                    pCSecurityCatTag != NULL;
                    pCSecurityCatTag = pCSecurityCatTagList->GoNext())
                {
                   std::string       *pSecCatSeparator=NULL;
                   std::string       *pSecCatPrefix=NULL;
                   std::string       *pSecCatSuffix=NULL;
                   CTagCategory      *pCTagCategory=NULL;
                   CMarkingQualifier *pCMarkingQualifier=NULL;

                   pSecCatSeparator = new std::string("/");

                   // FOR THE PURPOSES OF THIS FUNCTION WE CAN IGNORE THIS Marking
                   // Code PORTION OF Marking Qualifiers.  ACCORDING TO THE
                   // SDN.801 Rev B Markings Clarifications DOCUMENT
                   // "Only one of marking codes 1,2,3,4, & 8 is allowed
                   // within MarkingQualifiers"; AND WITHIN THIS FUNCTION WE ARE
                   // IGNORING POSITIONING Marking Codes.

                   pCMarkingQualifierList = pCSecurityCatTag->getMarkingQualifierList();
                   // Check for a least one Marking Qualifier
                   if ((pCMarkingQualifierList != NULL)
                    && (pCMarkingQualifierList->Count() > 0))
                   {
                      // Each Marking Qualifier contains a qualifier code and a
                      // Marking Qualifier
                      pCMarkingQualifierList->SetCurrToFirst();
                      for(pCMarkingQualifier = pCMarkingQualifierList->Curr();
                          pCMarkingQualifier != NULL;
                          pCMarkingQualifier = pCMarkingQualifierList->GoNext())
                      {
                         char *tmpMarkingQualifier=NULL;
                         int   tmpQualifierCode=-1;
                         tmpMarkingQualifier =
                            pCMarkingQualifier->getMarkingQualifier();
                         tmpQualifierCode = pCMarkingQualifier->getQualifierCode();
                         if (tmpMarkingQualifier != NULL)
                         {
                            if (tmpQualifierCode != -1)
                            {
                               if (tmpQualifierCode ==
                                   QualifierCode::prefixQualifier)
                               {
                                  if (pSecCatPrefix)
                                      delete pSecCatPrefix;
                                  pSecCatPrefix = new std::string(tmpMarkingQualifier);
                               }
                               if (tmpQualifierCode ==
                                   QualifierCode::suffixQualifier)
                               {
                                  if (pSecCatSuffix)
                                      delete pSecCatSuffix;
                                  pSecCatSuffix = new std::string(tmpMarkingQualifier);
                               }
                               if (tmpQualifierCode ==
                                   QualifierCode::separatorQualifier)
                               {
                                  if (pSecCatSeparator)
                                      delete pSecCatSeparator;
                                  pSecCatSeparator = new std::string(tmpMarkingQualifier);
                               }
                            } // END OF CHECK FOR Qualifier Code
                            else
                            {
                               if (tmpMarkingQualifier)
                                   delete tmpMarkingQualifier;
                               // Error condition (there should never be a
                               // Marking Code without a Marking Qualifier)
                               throw ACL_EXCEPT(ACL_NO_MARKING_QUALIFIER,
                                  "Missing Marking Qualifier in Security Label");
                            }
                            if (tmpMarkingQualifier)
                                free(tmpMarkingQualifier);
                            tmpMarkingQualifier = NULL;
                         } // END OF CHECK FOR Marking Qualifier
                         else
                         {
                            if (tmpQualifierCode != -1)
                            {
                               // Error condition (there should never be a
                               // Marking Qualifier without a Marking Code)
                               throw ACL_EXCEPT(ACL_NO_MARKING_CODE,
                                    "Missing Marking Code in Security Label");
                            }
                         }
                      } // END OF Marking Qualifier List LOOP
                   } // END OF CHECK FOR Marking Qualifiers
                   if (pCMarkingQualifierList)
                       delete pCMarkingQualifierList;
                   // Check for TagCategories
                   // For each Tag Category collect the Security Category Name and
                   // all marking phrases (if there are any), as well as any
                   // Marking Codes associated with the marking phrases.

                   pCTagCategoryList = pCSecurityCatTag->getTagCategoryList();
                   pCTagCategoryList->SetCurrToFirst();
                   for(pCTagCategory = pCTagCategoryList->Curr();
                       pCTagCategory != NULL;
                       pCTagCategory = pCTagCategoryList->GoNext())
                   {
                      CMarkingDataList *pTagCatMarkingDataList=NULL;
                      CMarkingData     *pTagCatMarkingData=NULL;
                      bool              bTagCatSuppressClassName=false;
                      bool              bTagCatNoNameDisplay=false;
                      bool              bTagCatNoMarkingDisplay=false;
                      AsnInt           *pTagCatMarkingCode=NULL;
                      std::string       separator="/";
                      StrList          *pMarkingPhraseStrList=NULL;

                      pSecCatNameStr = pCTagCategory->getSecCategoryNameString();

                      pTagCatMarkingDataList = pCTagCategory->getMarkingData();
                      if ((pTagCatMarkingDataList != NULL)
                       && (pTagCatMarkingDataList->Count() > 0))
                      {
                         std::string *pTmpStr=NULL;
                         pTagCatMarkingDataList->SetCurrToFirst();
                         for(pTagCatMarkingData = pTagCatMarkingDataList->Curr();
                             pTagCatMarkingData != NULL;
                             pTagCatMarkingData = pTagCatMarkingDataList->GoNext())
                         {
                            pTagCatMarkingPhrase = pTagCatMarkingData->getMarkingPhrase();
                            // FOR DISPLAY
                            if (pTagCatMarkingPhrase != NULL)
                            {
                               //
                               // CONSTRUCT A MarkingPhrase NODE
                               if (pMarkingPhraseStrList == NULL)
                               {
                                  pMarkingPhraseStrList = new StrList;
                               }
                               // Accumulate each Marking Phrase'
                               pTmpStr = pMarkingPhraseStrList->Append();
                               *pTmpStr = pTagCatMarkingPhrase;
                               pTmpStr = NULL;
                            }
                            pTagCatMarkingCodeList = pTagCatMarkingData->getMarkingCodes();
                            if ((pTagCatMarkingCodeList != NULL)
                             && (pTagCatMarkingCodeList->Count() > 0))
                            {
                               pTagCatMarkingCodeList->SetCurrToFirst();
                               for(pTagCatMarkingCode = pTagCatMarkingCodeList->Curr();
                                   pTagCatMarkingCode != NULL;
                                   pTagCatMarkingCode = pTagCatMarkingCodeList->GoNext())
                               {
                                  if (*pTagCatMarkingCode ==
                                      (AsnInt)MarkingCode::suppressClassName)
                                  {
                                     bTagCatSuppressClassName=true;
                                  }
                                  if (*pTagCatMarkingCode ==
                                      (AsnInt)MarkingCode::noNameDisplay)
                                  {
                                     bTagCatNoNameDisplay=true;
                                  }
                                  if (*pTagCatMarkingCode ==
                                      (AsnInt)MarkingCode::noMarkingDisplay)
                                  {
                                     bTagCatNoMarkingDisplay=true;
                                  }
                              
                                  /**********************************************
							      // Start of changes by William Adams - NEXOR //
							      **********************************************/
							      // Similar checks here for the categories as were done for the classifications
							      if ( *pTagCatMarkingCode == iPosition ) // (NEXOR-wda) 20/8/01
                                  {
								            bWrongPosition = false;
                                  }

							      if ( *pTagCatMarkingCode == (AsnInt)MarkingCode::pageTopBottom )
                                  {
								      if ( ( iPosition == 1 ) || ( iPosition == 2 ) )
									     bWrongPosition = false;

                                  }
							      if ( ( *pTagCatMarkingCode == 1 ) || ( *pTagCatMarkingCode == 2 ) || 
                                     ( *pTagCatMarkingCode == 3 ) || ( *pTagCatMarkingCode == 4 ) || 
                                     ( *pTagCatMarkingCode == 8 ) )
								           bPositionSpecified = true;
							            /**********************************************
							            // End of changes by William Adams - NEXOR   //
							            **********************************************/

                               }
                               if (pTagCatMarkingCodeList)
                                  delete pTagCatMarkingCodeList;
                            } // END OF Tag Category Marking Code LOOP
                         } // END OF Tag Category Marking Data LOOP
                      } // END OF CHECK FOR Marking Data

                      // PROCESSING ACCUMULATED Security Category INFORMATION
                      // (Security Category for Tag Category)
                      if (bTagCatSuppressClassName == true)
                      { // SET THE INDEX TO ELIMINATE THE Classification Name
                         displayIndex = 1;
                      }

				          /**********************************************
				          // Start of changes by William Adams - NEXOR	//
			             **********************************************/

				          // (NEXOR-wda) 20/8/01
				          if ( iPosition && bWrongPosition && !( !bPositionSpecified && ( iPosition == 2 ) ) )
                      {
					          if ( ( iPosition == 4 ) || ( iPosition == 8 ) || bPositionSpecified )
						          bTagCatNoNameDisplay = true;

					          bTagCatNoMarkingDisplay = true;
                      }
					       
			             bWrongPosition = true;

				          /**********************************************
				          // End of changes by William Adams - NEXOR   //
				          **********************************************/

                      // Display Security Category Name
                      if (bTagCatNoNameDisplay == false)
                      {  // Check Classification level Marking Code
                         if (bNoNameDisplay == false)
                         {
                            std::string *pTmpStr1=NULL;
                            if (pStrList != NULL && pStrList->Curr())
                            {
                               // IT SHOULD BE ANYWAY, BUT JUST TO BE SURE
                               pStrList->SetCurrToLast();
                               // APPEND THE SEPARATOR TO THE MOST RECENT STRING
                               pStrList->Curr()->append(separator);
                            }
                            if (pSecCatPrefix != NULL)
                            {
                               pStrList->AppendCopy(*pSecCatPrefix);
                               pStrList->Curr()->append(pSecCatNameStr);
                            }
                            else
                            {
                               pTmpStr1 = pStrList->Append();
                               *pTmpStr1 = pSecCatNameStr;
                               pTmpStr1 = NULL;
                            }
                         } // End of Classification level Marking Code Check
                      } // End of Security Category level Marking Code Check

                      if (bTagCatNoMarkingDisplay == false) // Display Marking Phrase
                      {
                         if ((pMarkingPhraseStrList != NULL)
                          && (pMarkingPhraseStrList->Count() > 0))
                         {
                            std::string *pTmpPtr1=NULL;
                            // IF THE LIST IS NOT EMPTY
                            if (pStrList != NULL)
                            {
                               // IT SHOULD BE ANYWAY, BUT JUST TO BE SURE
                               if (pStrList->Count() > 0)
                                  pStrList->SetCurrToLast();
                               else
                                  pStrList->Append();
                               // APPEND THE SEPARATOR TO THE MOST RECENT STRING
                               pStrList->Curr()->append(*pSecCatSeparator);
                            }
                            pMarkingPhraseStrList->SetCurrToFirst();
                            for(pTmpPtr1 = pMarkingPhraseStrList->Curr();
                                pTmpPtr1 != NULL;
                                pTmpPtr1 = pMarkingPhraseStrList->GoNext())
                            {
                               // IS THIS THE FIRST Marking Phrase
                               if (pMarkingPhraseStrList->Curr() ==
                                   pMarkingPhraseStrList->First())
                               {
                                  if (pSecCatPrefix != NULL)
                                  {
                                     pStrList->AppendCopy(*pSecCatPrefix);
                                     pStrList->Curr()->append(*pTmpPtr1);
                                  }
                                  else
                                  {
                                     pStrList->AppendCopy(*pTmpPtr1);
                                  }
                               }
                               else
                               {
                                  // IS THIS THE LAST Marking Phrase
                                  if ((pMarkingPhraseStrList->Curr() ==
                                      pMarkingPhraseStrList->Last()) && pSecCatSuffix != NULL)
                                  {
                                     pStrList->AppendCopy(*pTmpPtr1);
                                     pStrList->Curr()->append(*pSecCatSuffix);
                                  }
                                  else // MUST BE BETWEEN FIRST AND LAST
                                  {
                                     pStrList->AppendCopy(*pTmpPtr1);
                                  }
                               }
                            }
                         } // THERE WAS AT LEAST ONE Marking Phrase
                         else
                         { // THERE WAS NO Marking Phrase
                            if (pSecCatSuffix != NULL)
                            {
                               // IT SHOULD BE ANYWAY, BUT JUST TO BE SURE
                               if (pStrList->Count() > 0)
                                 pStrList->SetCurrToLast();
                               else
                                 pStrList->Append();
                               // APPEND THE SUFFIX TO THE MOST RECENT STRING
                               pStrList->Curr()->append(*pSecCatSuffix);
                            }
                         }
                      } // END OF CHECK FOR Marking Phrases
                      else
                      {  // DON'T THE Marking Phrase BUT NEED TO CHECK FOR SUFFIX
                         if (pSecCatSuffix != NULL)
                         {
                            // IT SHOULD BE ANYWAY, BUT JUST TO BE SURE
                            if (pStrList->Count() > 0)
                               pStrList->SetCurrToLast();
                            else
                               pStrList->Append();
                            // APPEND THE SUFFIX TO THE MOST RECENT STRING
                            pStrList->Curr()->append(*pSecCatSuffix);
                         }
                      } // END OF CHECK FOR Marking Phrases
                      if (pTagCatMarkingDataList)
                         delete pTagCatMarkingDataList;
                      if (pSecCatNameStr)
                          free(pSecCatNameStr);
                   } // END OF TAG CATEGORY
                   if (pCTagCategoryList)
                      delete pCTagCategoryList;
                   if (pSecCatSeparator)
                      delete(pSecCatSeparator);
                   if (pSecCatPrefix)
                      delete(pSecCatPrefix);
                   if (pSecCatSuffix)
                      delete(pSecCatSuffix);
                }
                if (pCSecurityCatTagList)
                   delete pCSecurityCatTagList;
             }
          }
          if (pCSecurityCatTagSetList)
             delete pCSecurityCatTagSetList;
       } // End collecting Security Category information
       std::string *pPtr=NULL;
       pStrList->SetCurrElmt(displayIndex);
       for(pPtr = pStrList->Curr(); pPtr != NULL; pPtr = pStrList->GoNext())
       {
          os += *pPtr;
       }
       os << "\n";

       if (pStrList)
          delete pStrList;
       if (pClassificationNameStr)
          free(pClassificationNameStr);
       if (pClassMarkingDataList)
          delete pClassMarkingDataList;
       if (pClassMarkingPhraseStrList)
          delete pClassMarkingPhraseStrList;
       if (pClassMarkingPhrase)
          free(pClassMarkingPhrase);
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }

} // END OF MEMBER FUNCTION printLabel

// getMarkingPhrase:
// Returns a null terminated character
// string representing the marking phrase.
//
char * CMarkingData::getMarkingPhrase(void)
{
    char    *pTmpMarkingPhraseStr=NULL;
    if (this->markingPhrase != NULL && this->markingPhrase->teletexString->length() > 0)
    {
       pTmpMarkingPhraseStr = strdup(this->markingPhrase->teletexString->c_str());
    }

   return(pTmpMarkingPhraseStr);
} // END OF MEMBER FUNCTION getMarkingPhrase

// getMarkingCodes:
// Returns list of marking codes.
//
AsnIntList * CMarkingData::getMarkingCodes(void)
{
   AsnIntList  *pTmpAsnIntList=NULL;
   MarkingCode *pTmpMarkingCode=NULL;
   AsnInt      *pMarkingCode=0;

   // markingCode is optional so check it
   if ((this->markingCode != NULL) && (this->markingCode->Count() > 0))
   {
      this->markingCode->SetCurrToFirst();
      for(pTmpMarkingCode = this->markingCode->Curr();
          pTmpMarkingCode != NULL;
          pTmpMarkingCode = this->markingCode->GoNext())
      {
         //
         // CONSTRUCT A CMarkingQualifier NODE
         if (pTmpAsnIntList == NULL)
         {
            pTmpAsnIntList = new AsnIntList;
         }
         pMarkingCode = pTmpAsnIntList->Append();
         // ADD THIS MarkingQualifier TO THE LIST
         pMarkingCode->AsnInt::operator = (*pTmpMarkingCode);
      }
   }
   return(pTmpAsnIntList);
} // END OF MEMBER FUNCTION getMarkingCodes

// getSecCatTagSetNameOID:
// Returns a reference to the securityCategoryTagSetName OID.
//
AsnOid & CSecurityCatTagSet::getSecCatTagSetNameOID(void)
{
   return(this->securityCategoryTagSetName);
} // END OF MEMBER FUNCTION getSecCatTagSetNameOID

// getSecCatTagSetString:
// Returns a null terminated character string
// representing the securityCategoryTagSetString, if present.
//
char * CSecurityCatTagSet::getSecCatTagSetString(void)
{
   char    *pTmpSecCatTagSetStr=NULL;

   if (this->secCatTagSetString->length() > 0)
   {
      pTmpSecCatTagSetStr = strdup(this->secCatTagSetString->c_str());
   }

   return(pTmpSecCatTagSetStr);
} // END OF MEMBER FUNCTION getSecCatTagSetString

// getSecurityCatTagList:
// Returns an ACL_List template of CSecurityCatTag.
//
CSecurityCatTagList * CSecurityCatTagSet::getSecurityCatTagList(void)
{
   CSecurityCatTagList *pSecCatTagList=NULL;
   FUNC("CSecurityCatTagSet::getSecurityCatTagList");

   SecurityCategoryTag      *spfCatTag=NULL;
   // TRAVERSE NamedTagSets (StandardSecurityLabel) in m_SecLabel
   //          find equivalent tagCategories and append them to
   //          retVal.  Return retVal when done.
   //

   // TRAVERSE securityCategoryTags to find equivalentSecCategoryTags
   //
   try
   {
       for (this->securityCategoryTags.SetCurrToFirst();
        (spfCatTag = this->securityCategoryTags.Curr()) != NULL;
        this->securityCategoryTags.GoNext() )
       {

          CSecurityCatTag *pCSecurityCatTag=NULL;
          // CONSTRUCT A CSecurityCatTag NODE
          if (pSecCatTagList == NULL)
          {
             pSecCatTagList = new CSecurityCatTagList;
          }
          pCSecurityCatTag = pSecCatTagList->Append();
          // ADD THIS SecurityCategoryTag TO THE LIST
          pCSecurityCatTag->
             SecurityCategoryTag::operator = (*spfCatTag);
       } // FOR securityCategoryTags
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return(pSecCatTagList);

} // END OF MEMBER FUNCTION getSecurityCatTagList

// removeLabelAndCertValue:
//
void CSecurityCatTagSet::removeLabelAndCertValue(int tagType,
                                                 int spfLACV)

{
   SecurityCategoryTag *pTmpSecCatTag=NULL;
   this->securityCategoryTags.SetCurrToFirst();
   for(pTmpSecCatTag = this->securityCategoryTags.Curr();
       pTmpSecCatTag != NULL;
       pTmpSecCatTag = this->securityCategoryTags.GoNext())
   {
      if (pTmpSecCatTag->tagType == (AsnInt) tagType)
      {
         TagCategories *pTmpTagCats;
         pTmpSecCatTag->tagCategories.SetCurrToFirst();
         for(pTmpTagCats = pTmpSecCatTag->tagCategories.Curr();
             pTmpTagCats != NULL;
             pTmpTagCats = pTmpSecCatTag->tagCategories.GoNext())
         {
            if (pTmpTagCats->labelAndCertValue == spfLACV)
            {
               pTmpSecCatTag->tagCategories.RemoveCurrFromList();
            }
         }
         if (pTmpSecCatTag->tagCategories.Count() == 0)
         {
            this->securityCategoryTags.RemoveCurrFromList();
         }
      }
   }
} // END OF MEMBER FUNCTION removeLabelAndCertValue

// getMarkingQualifierList:
// Returns an ACL_LIST template of CmarkingQualifier
//
CMarkingQualifierList * CSecurityCatTag::getMarkingQualifierList(void)
{
   MarkingQualifier      *pMarkingQualifier=NULL;
   CMarkingQualifierList *pMarkingQualifierList=NULL;

   FUNC("PrintableLabel::getMarkingQualifierList");
   try
   {
       if ((this->markingQualifiers != NULL)
        && (this->markingQualifiers->qualifiers != NULL))
       {
          this->markingQualifiers->qualifiers->SetCurrToFirst();
          for(pMarkingQualifier = this->markingQualifiers->qualifiers->Curr();
              pMarkingQualifier != NULL;
              pMarkingQualifier = this->markingQualifiers->qualifiers->GoNext())
          {
             CMarkingQualifier *pCMarkingQualifier=NULL;
             // CONSTRUCT A CMarkingQualifier NODE
             if (pMarkingQualifierList == NULL)
             {
                pMarkingQualifierList = new CMarkingQualifierList;
             }
             pCMarkingQualifier = pMarkingQualifierList->Append();
             // ADD THIS MarkingQualifier TO THE LIST
             pCMarkingQualifier->MarkingQualifier::operator = (*pMarkingQualifier);
          }
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }

   return(pMarkingQualifierList);
} // END OF MEMBER FUNCTION getMarkingQualifierList

// getSecurityCatTagNameString:
// Returns a null terminated character string
// representing the SecurityCategorityTagName.
//
char * CSecurityCatTag::getSecurityCatTagNameString(void)
{
   char    *pTmpSecCatTagNameStr=NULL;

   if (this->securityCategoryTagName->length() > 0)
   {
      pTmpSecCatTagNameStr = strdup(this->securityCategoryTagName->c_str());
   }

   return(pTmpSecCatTagNameStr);
} // END OF MEMBER FUNCTION getSecurityCatTagNameString

// getTagType:
// Returns an int to indicate which tagType is present.
//
int CSecurityCatTag::getTagType(void)
{
   return(this->tagType);
} // END OF MEMBER FUNCTION getTagType

// getMarkingCode:
// Returns marking code:
//     pageTop = 1,
//     pageBottom = 2,
//     pageTopBottom = 3,
//     documentEnd = 4,
//     noNameDisplay = 5,
//     noMarkingDisplay = 6,
//     unused = 7,
//     documentStart = 8,
//     suppressClassName = 9
//     marking code not present = -1
//
int CSecurityCatTag::getMarkingCode(void)
{
   int retval=-1;
   if (this->markingQualifiers != NULL)
   {
      if (this->markingQualifiers->markingCode != NULL)
      {
         retval = (int )this->markingQualifiers->markingCode;
      }
   }
   return(retval);
} // END OF MEMBER FUNCTION getMarkingCode

// getTagCategoryList:
// Returns an ACL_LIST template of CTagCategory
//
CTagCategoryList * CSecurityCatTag::getTagCategoryList(void)
{
   TagCategories    *pTmpTagCats=NULL;
   CTagCategoryList *pTagCategoryList=NULL;
   // TRAVERSE tagCategories
   this->tagCategories.SetCurrToFirst();
   for(pTmpTagCats = this->tagCategories.Curr(); pTmpTagCats != NULL;
       pTmpTagCats = this->tagCategories.GoNext())
   {
      CTagCategory *pCTagCategory=NULL;
      // CONSTRUCT A CMarkingQualifier NODE
      if (pTagCategoryList == NULL)
      {
         pTagCategoryList = new CTagCategoryList;
      }
      pCTagCategory = pTagCategoryList->Append();
      // ADD THIS MarkingQualifier TO THE LIST
      pCTagCategory->TagCategories::operator = (*pTmpTagCats);
   }
   return(pTagCategoryList);
} // END OF MEMBER FUNCTION getTagCategoryList

// getSecCategoryNameString:
// Returns a null terminated character string
// representing the secCategoryName in the SPIF.
//
char * CTagCategory::getSecCategoryNameString(void)
{
   char    *pTmpSecCatNameStr=NULL;

   if (this->secCategoryName->teletexString->length() > 0)
   {
      pTmpSecCatNameStr = strdup(this->secCategoryName->teletexString->c_str());
   }

   return(pTmpSecCatNameStr);
} // END OF MEMBER FUNCTION getSecCategoryNameString

// getLACV:
// Returns the integer value that corresponds to the
// Label And Cert Value contained in the TagCategories.
//
int CTagCategory::getLACV(void)
{
   return((int )this->labelAndCertValue);
} // END OF MEMBER FUNCTION getLACV

// getMarkingData:
// Returns an ACL_List template of CMarkingData.
// See CMarkingData for details.
//
CMarkingDataList * CTagCategory::getMarkingData(void)
{
   MarkingData      *pMarkingData=NULL;
   CMarkingDataList *pCMarkingDataList=NULL;
   // markingData is optional so check it
   if ((this->markingData != NULL)
    && (this->markingData->Count() > 0))
   {
      this->markingData->SetCurrToFirst();
      for(pMarkingData = this->markingData->Curr(); pMarkingData != NULL;
          pMarkingData = this->markingData->GoNext())
      {
         CMarkingData *pCMarkingData=NULL;
         // CONSTRUCT A CMarkingData NODE
         if (pCMarkingDataList == NULL)
         {
            pCMarkingDataList = new CMarkingDataList;
         }
         pCMarkingData = pCMarkingDataList->Append();
         // ADD THIS MarkingData TO THE LIST
         pCMarkingData->MarkingData::operator = (*pMarkingData);
      }
   }
   return(pCMarkingDataList);
} // END OF MEMBER FUNCTION getMarkingData

// getMarkingQualifier:
// Returns a null terminated character
// string representing the markingQualifier.
//
char * CMarkingQualifier::getMarkingQualifier(void)
{
   char    *pTmpMarkingQualifierStr=NULL;

   if (this->markingQualifier->teletexString->length() > 0)
   {
      pTmpMarkingQualifierStr = strdup(this->markingQualifier->teletexString->c_str());
   }

   return(pTmpMarkingQualifierStr);
} // END OF MEMBER FUNCTION getMarkingQualifier

// getQualifierCode:
// Returns a int to indicate one of the following qualifier codes.
//     prefixQualifier = 1,
//     suffixQualifier = 2,
//     separatorQualifier = 3
//     qualifier code not present = -1
//
int CMarkingQualifier::getQualifierCode(void)
{
   int retval=-1;
   if (this->qualifierCode != NULL)
   {
      retval = (int )this->qualifierCode;
   }
   return(retval);
} // END OF MEMBER FUNCTION getQualifierCode

// EOF aclprint.cpp

_END_NAMESPACE_ACL
