//////////////////////////////////////////////////////////////////////////////
// aclpubkeyinfo.cpp
// These routines support the PublicKeyInfo Class
// CONSTRUCTOR(s):
//   PublicKeyInfo()
// DESTRUCTOR:
//   ~PublicKeyInfo()
// MEMBER FUNCTIONS:
//   setPubKey(CSM_Alg &pubKeyAlg, CSM_Buffer &pubKeyBuf)
//////////////////////////////////////////////////////////////////////////////

#include "acl_api.h"

using namespace CTIL;
_USING_NAMESPACE_SNACC
_BEGIN_NAMESPACE_ACL

PublicKeyInfo::PublicKeyInfo(const CML::ASN::CertificationPath  &certPath)
{
   FUNC("PubKeyInfo::PublicKeyInfo(CML::ASN::CertificationPath &certPath)");
   try
   {
       // IF parameters were not found traverse theCACertificates to find them.
       *this = certPath.userCert.pubKeyInfo;
       if (this->algorithm.parameters == NULL)
       {
          std::list<CML::ASN::CertPair>::const_iterator i;

          for (i=certPath.caCerts.begin(); i != certPath.caCerts.end(); i++)
          {
             if (this->algorithm.parameters != NULL)
                break;

             if (i->forward->pubKeyInfo.algorithm.parameters != NULL)
             {
                this->algorithm.parameters =
                   new CTIL::CSM_Buffer(*(i->forward->pubKeyInfo.
                                         algorithm.parameters));
                break;
             }
          }
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
}

void PublicKeyInfo::setPubKey(CTIL::CSM_Alg &pubKeyAlg, CTIL::CSM_Buffer &pubKeyBuf)
{
   this->key = pubKeyBuf;
   this->algorithm = pubKeyAlg;
}

void PublicKeyInfo::setPubKey(const CML::ASN::PublicKeyInfo &cmlPKI, 
                              const CTIL::CSM_Buffer *pParams)
{
   *(CML::ASN::PublicKeyInfo *)this = cmlPKI;
   if (pParams != NULL)
   {
      // only assign incoming pParams if parameters were not present in
      // the cmlPKI to begin with.
      //
      if (algorithm.parameters == NULL)
         algorithm.parameters = new CSM_Buffer(*pParams);
   }
}

PublicKeyInfo & PublicKeyInfo::operator =(const CML::ASN::PublicKeyInfo &that)
{
   *((CML::ASN::PublicKeyInfo *)this) = that;
   return *this;
}

_END_NAMESPACE_ACL
// EOF aclpubkeyinfo.cpp
