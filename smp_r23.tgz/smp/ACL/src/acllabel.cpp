//////////////////////////////////////////////////////////////////////////////
// acllabel.cpp
// These routines support the SecurityLabel Class
// CONSTRUCTOR(s):
//   SecurityLabel(void)
//   SecurityLabel(CSM_Buffer &encodedLabel)
//   SecurityLabel(const ESSSecurityLabel &secLbl)
// DESTRUCTOR:
//   ~SecurityLabel()
// MEMBER FUNCTIONS:
//   operator=(SecurityLabel &that)
//   getSSL(void)
//   check(Session *s, SPIF &spif)
//   requiredCatCheck(RequiredCategories &reqCat, SPIF &spif)
//   excludedCatCheck(OptionalCategoryDataSeqOf &excCat, SPIF &spif)
//   findCat(AsnOid &tagsetname, TagTypeValue &tagtype,
//                     AsnInt &labelandcert)
//   tagAndLevelCheck(void)
//   isEquivApplicable(int applied)
//   getClassification(void)
//   getLabelString(const SPIF *pSPIF)
//   getPolicyId(void)
//   setSSL(StandardSecurityLabel *pNewTagSets)
//   freeFormOnlyCheck(void)
//   isIncoming(void)
//   isOutgoing(void)
//////////////////////////////////////////////////////////////////////////////

#include "acl_api.h"
#include "aclinternal.h"
#include "aclintexcept.h"

_USING_NAMESPACE_SNACC
_BEGIN_NAMESPACE_ACL

// CONSTRUCTOR:
//
SecurityLabel::SecurityLabel(void)
{
   // initialize
   m_pSNACCTmpSSL = NULL;
   m_obsAccept = false;
} // END OF CONSTRUCTOR

// ALTERNATE CONSTRUCTOR:
//
SecurityLabel::SecurityLabel(const CTIL::CSM_Buffer &encodedLabel)
{
   FUNC("SecurityLabel::SecurityLabel(CSM_Buffer &encodedLabel)");

   AsnLen bytesDecoded;
    // initialize
    m_pSNACCTmpSSL = NULL;
    m_obsAccept = false;
    SNACC::AsnBuf b(encodedLabel.Access(), encodedLabel.Length());
   
    // ASN.1 decode the provided encodedLabel
    if (BDecPdu(b, bytesDecoded) == false)
    {
       throw ACL_EXCEPT(ACL_DECODE_ERROR,"Error decoding Security Label");
    }
} // END OF ALTERNATE CONSTRUCTOR

SecurityLabel::SecurityLabel(const SNACC::AsnBuf &b)
{
   AsnLen bytesDecoded;

   FUNC("SecurityLabel::SecurityLabel(SNACC::AsnBuf &)");

   m_pSNACCTmpSSL = NULL;
   m_obsAccept = false;

   if (BDecPdu(b, bytesDecoded) == false)
   {
      throw ACL_EXCEPT(ACL_DECODE_ERROR,"Error decoding Security Label");
   }
}
// ALTERNATE CONSTRUCTOR:
//
SecurityLabel::SecurityLabel(const ESSSecurityLabel &secLbl)
{
  m_pSNACCTmpSSL = NULL;
  m_obsAccept = false;
  ESSSecurityLabel::operator=(secLbl);
} // END OF ALTERNATE CONSTRUCTOR

// DESTRUCTOR:
//
SecurityLabel::~SecurityLabel(void)
{
   if (m_pSNACCTmpSSL != NULL)
      delete m_pSNACCTmpSSL;
} // END OF CONSTRUCTOR

// operator =:
//
SecurityLabel & SecurityLabel::operator=(const SecurityLabel &that)
{
   this->ESSSecurityLabel::operator=(that);
   m_pSNACCTmpSSL = NULL;
   return (*this);
} // END OF OPERATOR OVERLOAD =

// getSSL:
//
const StandardSecurityLabel & SecurityLabel::getSSL(void)
{
   NamedTagSet  *pNewSecLblNTS = NULL;
   SecurityTag  *pNewSecLblSecTag = NULL; // Security Tag

   FUNC("SecurityLabel::getSSL");
   try
   {
       // if we've already called getSSL() just return the previous result.
       //
       if (m_pSNACCTmpSSL != NULL)
          return *m_pSNACCTmpSSL;

       // check for NULL security_categories
       if (this->security_categories == NULL) 
       {
          throw (EmptyList("Empty Security Categories List"));
       }

       SecurityCategory *pTmpSecCat = this->security_categories->First();

       // Check for MISSISecurityCategories.  If it is present the
       // security category count must be 1 and the type set to id_missiSecurityCategories.
       // 
       if ((this->security_categories->Count() == 1) &&
			(pTmpSecCat->type == id_missiSecurityCategories))
       {
		    if (pTmpSecCat->value.value)
			{
               MissiSecurityCategories *pMSC=(MissiSecurityCategories *) pTmpSecCat->value.value;
               m_pSNACCTmpSSL = new StandardSecurityLabel;
               *m_pSNACCTmpSSL = *pMSC->prbacSecurityCategories;
               return(*m_pSNACCTmpSSL);
			}
			else
			{
				 char errStr[ACL_STR_BUF_LEN];
				 errStr[0] = '\0';
				 sprintf(&errStr[0], "Security category error.%s",
					"\n\tValue is NULL.");
				 throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, &errStr[0]);
			}
       }

      // MISSI security categories were not found in the first security category
      // continue looking for NATO security categories.  If a MISSI security category
      // is found among them throw an exception. 
      //
	   this->security_categories->SetCurrToFirst();

      m_pSNACCTmpSSL = new StandardSecurityLabel;

      while ((pTmpSecCat = this->security_categories->Curr()) != NULL) 
	   {
        // IF a MISSI Security Category is found throw an exception
        //
		  if (pTmpSecCat->type == id_missiSecurityCategories)
        {
             char errStr[ACL_STR_BUF_LEN];
             errStr[0] = '\0';
             sprintf(&errStr[0], "Security category error.%s",
                "\n\tMissi and Nato security categories can not be together.");
             throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, &errStr[0]);
        }
        // ELSE IF a NATO RestrictiveTag
        //
        else if (pTmpSecCat->type == acl_id_restrictiveBitMap)
		  {
			 RestrictiveTag *pResTag = (RestrictiveTag *)pTmpSecCat->value.value;
			 
             // Find a tagSet with a tagSetName of RestrictiveTag's tagName.  If found
             // append value to tagSet.  Otherwise create the tagSet then add the value.
             pNewSecLblNTS = FindTagSet(m_pSNACCTmpSSL, pResTag->tagName); 
		
             // Tag set was not found so create it.
             if (pNewSecLblNTS == NULL)
				 pNewSecLblNTS = m_pSNACCTmpSSL->Append();

		     // Search through existing pNewSecLblNTS to make sure there is not  
		     // already a RestrictiveTag in this tagSet.
			 for (pNewSecLblNTS->securityTags.SetCurrToFirst();
			     (pNewSecLblNTS->securityTags.Curr()) != NULL;
			      pNewSecLblNTS->securityTags.GoNext())
			 {
				if (pNewSecLblNTS->securityTags.Curr()->choiceId == 
					SecurityTag::restrictivebitMapCid)
				{
                     AclString errStr;
                     errStr << "Restrictive tag already exists in tagset: \n" 
                            << "   [" << pResTag->tagName << "] \n";
					 throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr.str());
				}
			 }
             // 
             pNewSecLblSecTag = pNewSecLblNTS->securityTags.Append();
			 pNewSecLblSecTag->choiceId = SecurityTag::restrictivebitMapCid;
             pNewSecLblSecTag->restrictivebitMap = new SecurityTagSeq;
			 pNewSecLblSecTag->restrictivebitMap->attributeFlags = pResTag->attributeFlags;
		  }
		  else if (pTmpSecCat->type == acl_id_enumeratedAttributes)
		  {
			 EnumeratedTag *pEnumTag = (EnumeratedTag *)pTmpSecCat->value.value;
			 pNewSecLblNTS = FindTagSet(m_pSNACCTmpSSL, pEnumTag->tagName); 
			 if (pNewSecLblNTS == NULL)
				 pNewSecLblNTS = m_pSNACCTmpSSL->Append();
		     // Search through existing pNewSecLblNTS to make sure there is not  
		     // already an EnumeratedTag in this tagSet.
			 for (pNewSecLblNTS->securityTags.SetCurrToFirst();
			     (pNewSecLblNTS->securityTags.Curr()) != NULL;
			      pNewSecLblNTS->securityTags.GoNext())
			 {
				if (pNewSecLblNTS->securityTags.Curr()->choiceId == 
					SecurityTag::enumeratedAttributesCid)
				{
                     AclString errStr;
                     errStr << "Enumerated tag already exists in tagset: \n" 
                            << "   [" << pEnumTag->tagName << "] \n";
					 throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr.str());
				}
			 }
             pNewSecLblSecTag = pNewSecLblNTS->securityTags.Append();
             pNewSecLblSecTag->choiceId = SecurityTag::enumeratedAttributesCid;	
			 pNewSecLblSecTag->enumeratedAttributes = new SecurityTagSeq1;
			 while ((pEnumTag->attributeList.Curr()) != NULL)
			 {
                pNewSecLblSecTag->enumeratedAttributes->attributeFlags.AppendCopy(*pEnumTag->attributeList.Curr());
				pEnumTag->attributeList.GoNext();
			 }
		  }
		  else if (pTmpSecCat->type == acl_id_permissiveBitMap)
		  {
			 PermissiveTag *pPermTag = (PermissiveTag *)pTmpSecCat->value.value;
			 pNewSecLblNTS = FindTagSet(m_pSNACCTmpSSL, pPermTag->tagName); 
			 if (pNewSecLblNTS == NULL)
				 pNewSecLblNTS = m_pSNACCTmpSSL->Append();
		     // Search through existing pNewSecLblNTS to make sure there is not  
		     // already a PermissiveTag in this tagSet.
			 for (pNewSecLblNTS->securityTags.SetCurrToFirst();
			     (pNewSecLblNTS->securityTags.Curr()) != NULL;
			      pNewSecLblNTS->securityTags.GoNext())
			 {
				if (pNewSecLblNTS->securityTags.Curr()->choiceId == 
					SecurityTag::permissivebitMapCid)
				{
                     AclString errStr;
                     errStr << "Permissive tag already exists in tagset: \n" 
                            << "   [" << pPermTag->tagName << "] \n";
					 throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr.str());
				}
			 }
             pNewSecLblSecTag = pNewSecLblNTS->securityTags.Append();
             pNewSecLblSecTag->choiceId = SecurityTag::permissivebitMapCid;			 
             pNewSecLblSecTag->permissivebitMap = new SecurityTagSeq2;
			 pNewSecLblSecTag->permissivebitMap->attributeFlags = pPermTag->attributeFlags;
		  }
		  else if (pTmpSecCat->type == acl_id_freeFormField)
		  {
			 FreeFormField *pFFFTag = (FreeFormField *)pTmpSecCat->value.value;
			 TagType7Data *pTmpType7 = new TagType7Data;
			 pNewSecLblNTS = FindTagSet(m_pSNACCTmpSSL, pFFFTag->tagName); 
			 if (pNewSecLblNTS == NULL)
				 pNewSecLblNTS = m_pSNACCTmpSSL->Append();
		     // Search through existing pNewSecLblNTS to make sure there is not  
		     // already a FreeFormField in this tagSet.
			 for (pNewSecLblNTS->securityTags.SetCurrToFirst();
			     (pNewSecLblNTS->securityTags.Curr()) != NULL;
			      pNewSecLblNTS->securityTags.GoNext())
			 {
				if (pNewSecLblNTS->securityTags.Curr()->choiceId == 
					SecurityTag::freeFormFieldCid)
				{
                     AclString errStr;
                     errStr << "FreeFormField already exists in tagset: \n" 
                            << "   [" << pFFFTag->tagName << "] \n";
					 throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr.str());
				}
			 }
             pNewSecLblSecTag = pNewSecLblNTS->securityTags.Append();
             pNewSecLblSecTag->choiceId = SecurityTag::freeFormFieldCid;	
			 pNewSecLblSecTag->freeFormField = new AsnAny;
             pNewSecLblSecTag->freeFormField->value = pTmpType7;
			 if (pFFFTag->field->choiceId == Field::bitSetAttributesCid)
			 {
				 pTmpType7->choiceId = TagType7Data::bitSetAttributesCid;
				 pTmpType7->bitSetAttributes = new AsnBits;
				 *pTmpType7->bitSetAttributes = *pFFFTag->field->bitSetAttributes;
			 }
			 else if (pFFFTag->field->choiceId == Field::securityAttributesCid)
			 {
				 pTmpType7->choiceId = TagType7Data::securityAttributesCid;
				 pTmpType7->securityAttributes = new TagType7DataSetOf;
				 while ((pFFFTag->field->securityAttributes->Curr()) != NULL)
				 {
					pTmpType7->securityAttributes->AppendCopy(*pFFFTag->field->securityAttributes->Curr());
					pFFFTag->field->securityAttributes->GoNext();
				 }
			 }
		  }
          else
          {
             char errStr[ACL_STR_BUF_LEN];
             errStr[0] = '\0';
             sprintf(&errStr[0], "Unsupported security category.%s",
                "\n\tOnly id_missSecurityCategories or Nato security categories are supported");
             throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, &errStr[0]);
          }
		  this->security_categories->GoNext();
	   }// ENDLOOP
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return(*m_pSNACCTmpSSL);
} // END OF MEMBER FUNCTION getSSL

NamedTagSet * SecurityLabel::FindTagSet(SNACC::StandardSecurityLabel *pSSL, 
	   SNACC::AsnOid &tagname)
{
   NamedTagSet *pNTS = NULL;

   FUNC("SecurityLabel::FindTagSet");
   try
   {
	   pSSL->SetCurrToFirst();
	   while ((pSSL->Curr()) != NULL)
	   {
		   if (pSSL->Curr()->tagSetName == tagname)
		   {
			   return(pSSL->Curr());
		   }
		   pSSL->GoNext();
	   }
	   pNTS = pSSL->Append();
	   pNTS->tagSetName = tagname;
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return(pNTS);
}

// check:
// Checks SecurityLabel for a valid combination of values
//
bool SecurityLabel::check(Session *s, SPIF &spif)
{
   AsnOidLst TagList;

   FUNC("SecurityLabel::check");
   try
   {
       // First check to see if spif has been validated.
       if ((s->m_disable_validation == false) && (spif.isValid() == false) )
       {
          char errStr[ACL_STR_BUF_LEN];
          errStr[0] = '\0';
          sprintf(&errStr[0], "SPIF must be validated prior to calling%s",
                  "\n\tSecurityLabel::check");
          throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, &errStr[0]);
       }

       // If label PolicyId and SPIF policyId are equal
       if (this->security_policy_identifier == spif.getPolicyId())
       {
          // If securityClassification is set in the label
          //
          if (this->security_classification != NULL)
          {
             // Loop through the SPIF securityCLassifications to find a matching
             // securityClassification
             //
             SpifSecurityClassification *pSecClass = NULL;
             SpifSecurityClassification *pMatchClass = NULL;
             spif.spiftoSign->securityClassifications.SetCurrToFirst();

             while (((pSecClass = spif.spiftoSign->securityClassifications.Curr())
                != NULL) && (pMatchClass == NULL))
             {
                if ( (AsnIntType) pSecClass->labelAndCertValue ==
                   (AsnIntType)*this->security_classification)
                {
                   pMatchClass = pSecClass;
                }
                spif.spiftoSign->securityClassifications.GoNext();
             } // ENDLOOP

             // IF pMatchClass == NULL THEN SPIF does not include the security
             // classification specified in the label return ACL_LABEL_ERROR
             //
             if (pMatchClass == NULL)
             {
                char errStr[ACL_STR_BUF_LEN];
                errStr[0] = '\0';
                sprintf(&errStr[0],"SPIF does not contain classification %d",
                   (AsnIntType)*this->security_classification);

                throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, &errStr[0]);
             }

             // IF the required categories in the matching securityClassification
             // is not NULL then ensure they are present in the security label.
             //
             if (pMatchClass->requiredCategory != NULL)
             {
                requiredCatCheck(*pMatchClass->requiredCategory, spif);
             }

             // IF m_obsAccept != 1 AND pMatchClass->obsolete == 1 THEN return
             // OBS_CLASS error code.
             if ((this->m_obsAccept != true) && (pMatchClass->obsolete != NULL) &&
                (*pMatchClass->obsolete == 1) )
                throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR,
                          "Obsolete class error::check");

          }  // end If securityClassification is set in the label

          // IF securityLabel security_categories != NULL THEN (for each security
          // category value: look up the value in the SPIF; ensure that none of the
          // excluded classifications/categories listed in the SPIF for the
          // value are present in the security label; ensure that the required
          // classification/categories listed in the SPIF for the value are
          // present in the security label; enforce singleCategorySelection
          // rule listed in the SPIF for the value; and, if obs_accept == 0,
          // reject a value that is marked as obsolete in the SPIF)
          if ( (this->security_categories != NULL) &&
               (this->security_categories->Count() > 0))
          {
             // IF securityLabel security_categories->next != NULL THEN return
             // TOO_MANY_SEC_CATS error code.  (Note: SDN.801 states that there can
             // only be one securityCategory present in the securityLabel.)
             this->security_categories->SetCurrToFirst();
             if (this->security_categories->Next() != NULL)
             {
                throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR,
                          "Too many security_categories error::check");
             }

             // IF securityLabel security_categories prbacId != SPIF rbac_id THEN
             // (MissiSecurityCategories is not the SecurityCategory ANY field)
             // return RBAC_ID error.
             SecurityCategory *pTmpSecCat = this->security_categories->Curr();
             if (pTmpSecCat->type != spif.spiftoSign->rbacId)
             {
                char errStr[ACL_STR_BUF_LEN];
                AsnOid tmpOid1(pTmpSecCat->type);
                AsnOid tmpOid2(spif.spiftoSign->rbacId);

                sprintf(errStr, "%s=%s%s=%s",
                        "RBAC ID error:\n\tsecurity_categories prbacId",
                        (const char *) tmpOid1, "\n\tSPIF rbac_id", (const char *) tmpOid2);

                // do any error handling
                throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
             }

             // LOOP thru securityLabel security_categories StandardSecurityLabel
             // (NamedTagSets) linked list:
             const NamedTagSet *pSSL = NULL;
             for(getSSL().SetCurrToFirst(); (pSSL = getSSL().Curr()) != NULL;
                 getSSL().GoNext())
             {
                // Append current securityLabel tagSetName OID to end
                // of tag_lst linked list.
                // LOOP thru TagList until end of list:
                AsnOid *pTmpOid = NULL;
                for(TagList.SetCurrToFirst(),
                  pTmpOid = TagList.Curr(); pTmpOid != NULL;
                   pTmpOid = TagList.GoNext())
                {
                  // IF current TagList->oid is identical to current
                  // securityLabel tagSetName THEN (there are two NamedTagSets
                  // with the same TagSetName within the same securityCategory,
                  // so that breaks the SDN.801 processing rules) THEN
                  if (*pTmpOid == pSSL->tagSetName)
                  {
                     char errStr[ACL_STR_BUF_LEN];
                     AsnOid tmpOid1(*pTmpOid);
                     AsnOid tmpOid2(pSSL->tagSetName);

                     sprintf(errStr, "%s%s=%s%s=%s",
                             "Redundant Name (> 5000) error \n\t",
                             "Tag Set Name 1", (const char *) tmpOid1,
                             "\n\tTag Set Name 2", (const char *) tmpOid2);

                     // do any error handling
                     throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                  }
                }
                AsnOid *ptmpoid = TagList.Append();
                *ptmpoid = pSSL->tagSetName;

                // LOOP thru current securityLabel SecurityTags linked list:
                const SecurityTag *pSecTag = NULL;
                for(pSSL->securityTags.SetCurrToFirst(),
                   pSecTag = pSSL->securityTags.Curr();
                        pSecTag != NULL;
                        pSecTag = pSSL->securityTags.GoNext())
                {
                   // Get tagType and check if current securityLabel
                   // SecurityTags securityLevel != to current
                   // securityLabel securityClass
                   if (pSecTag->choiceId == SecurityTag::restrictivebitMapCid)
                   {
                      // error if securityLevel != classification
                      if (this->security_classification == NULL &&
                         pSecTag->restrictivebitMap->securityLevel != NULL)
                      {
                         char errStr[ACL_STR_BUF_LEN];
                         AsnOid tmpOid(pSSL->tagSetName);
                         long sec_level = *pSecTag->restrictivebitMap->securityLevel;
                         sprintf(errStr,"Bad Security Level:%s %s %ld%s %s",
                                 "\n\tsecurity label sec class == NULL",
                                 "but restrictive security Level is",
                                 sec_level, "\n\tTag Set Name =",
                                 (const char *) tmpOid);

                         // do error handling
                         throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                      }
                      else if (this->security_classification != NULL &&
                         pSecTag->restrictivebitMap->securityLevel != NULL &&
                         (*pSecTag->restrictivebitMap->securityLevel !=
                         *this->security_classification))
                      {
                         char errStr[ACL_STR_BUF_LEN];
                         AsnOid tmpOid(pSSL->tagSetName);
                         long sec_class = *this->security_classification;
                         long sec_level = *pSecTag->restrictivebitMap->securityLevel;

                         sprintf(errStr,"Bad Security Level:%s %ld %s %ld%s %s",
                                 "\n\tsecurity label sec class is", sec_class,
                                 "but restrictive security Level is", sec_level,
                                 "\n\tTag Set Name =", (const char *) tmpOid);

                         // do error handling
                         throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                      }

                      // Set cat_count (local long) to 0.
                      long cat_count = 0;

                      // LOOP thru attributeFlags until end of array:
                      size_t i = pSecTag->restrictivebitMap->attributeFlags.BitLen();
                      size_t j = 0;
                      for (j = 0; j <= i; j++)
                      {
                         // IF current securityLabel bit position is set to 1 THEN:
                         if (CAsnBits::checkBit(pSecTag->restrictivebitMap->
                            attributeFlags, j))
                         {
                            // LOOP thru SPIF SecurityCategoryTagSets linked list
                            // until pMatchCat != NULL OR end of list:
                            SecurityCategoryTagSet *pSecCatTag = NULL;
                            SecurityCategoryTag *owner = NULL;
                            TagCategories *pMatchCat = NULL;
                            spif.spiftoSign->securityCategoryTagSets->SetCurrToFirst();

                            while (((pSecCatTag =
                               spif.spiftoSign->securityCategoryTagSets->Curr()) !=
                               NULL) && (pMatchCat == NULL))
                            {
                               // IF current securityLabel tag_set_name == current
                               // SPIF securityCategoryTagSetName THEN (found
                               // correct SPIF SecurityCategoryTagSet)
                               if (pSSL->tagSetName ==
                                  pSecCatTag->securityCategoryTagSetName)
                               {
                                  // LOOP thru current SPIF securityCategoryTags
                                  // linked list until pMatchCat != NULL OR end of
                                  // list:
                                  SecurityCategoryTag *pSecCat = NULL;
                                  pSecCatTag->securityCategoryTags.SetCurrToFirst();
                                  while (((pSecCat =
                                     pSecCatTag->securityCategoryTags.Curr()) !=
                                     NULL) && (pMatchCat == NULL))
                                  {
                                     // IF current securityLabel tag_type ==
                                     // current SPIF tag_type THEN (found correct
                                     // SPIF SecurityCategoryTag)
                                     if (CSecurityTag::isTagTypeEqual(*pSecTag, *pSecCat))
                                     {
                                        // LOOP thru current SPIF tagCategories
                                        // linked list until pMatchCat != NULL OR
                                        // end of list:
                                        TagCategories *pTagCats = NULL;
                                        pSecCat->tagCategories.SetCurrToFirst();
                                        while (((pTagCats =
                                           pSecCat->tagCategories.Curr()) !=
                                           NULL) && (pMatchCat == NULL))
                                        {
                                           // IF current securityLabel bit position
                                           // indicated by current tagCategories
                                           // tag_label_cert is set to 1 THEN (found
                                           // correct TagCategories) set pMatchCat
                                           // to point to current SPIF tagCategories
                                           if (pTagCats->labelAndCertValue ==
                                           (const AsnIntType &) j)
                                           {
                                              pMatchCat = pTagCats;
                                              owner = pSecCat;
                                           }
                                           pSecCat->tagCategories.GoNext();
                                        } // ENDLOOP
                                     }

                                     pSecCatTag->securityCategoryTags.GoNext();
                                  } // ENDLOOP
                               }
                               spif.spiftoSign->securityCategoryTagSets->GoNext();
                            } // ENDLOOP

                            // IF pMatchCat == NULL THEN (SPIF does not include
                            // securityLabel security category value so return error)
                            if (pMatchCat == NULL)
                            {
                               char errStr[ACL_STR_BUF_LEN];
                               long labelcert = j;
                               AsnOid tmpOid(pSSL->tagSetName);
                               long tagType = pSecTag->choiceId;

                               sprintf(errStr, "%s%s=%s%s=%ld %s %s%s=0x%02X",
                                       "Bad labelAndCert value:",
                                       "\n\tTag Set Name", (const char *) tmpOid,
                                       "\n\ttagType", tagType,
                                       "(0=restrictive, 1=enumerated,",
                                       "2=permissive, or 3=freeform)\n\t",
                                       "hex labelAndCertValue",
                                       (unsigned int) labelcert);

                               // do error handling
                               throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                            }

                            // Increment cat_count.
                            cat_count++;

                            // IF owner->singleCategorySelectionPolicy == 1 AND
                            // cat_count > 1 THEN
                            if ((owner != NULL) &&
                               (owner->singleCategorySelectionPolicy != NULL) &&
                               (*owner->singleCategorySelectionPolicy == 1) &&
                               (cat_count > 1))
                            {
                               // do error handling
                               char errStr[ACL_STR_BUF_LEN];
                               long labelcert = j;
                               AsnOid tmpOid(pSSL->tagSetName);
                               long tagType = pSecTag->choiceId;

                               sprintf(errStr, "%s%s=%s%s=%ld %s %s %s=0x%02X",
                                       "Single category error",
                                       "\n\tTag Set Name", (const char *) tmpOid,
                                       "\n\ttagType", tagType, "(0=restrictive,",
                                       "1=enumerated, 2=permissive, or",
                                       "3=freeform)\n\thex labelAndCertValue",
                                       (unsigned int) labelcert);
                               throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                            }

                            // IF pMatchCat->requiredClass != NULL AND pMatchCat->
                            // requiredClass != securityLabel->sec_class THEN
                            if (pMatchCat->requiredClass != NULL)
                               if ( (this->security_classification == NULL) ||
                                  (*pMatchCat->requiredClass !=
                                  *this->security_classification))
                               {
                                  // do error handling
                                  char errStr[ACL_STR_BUF_LEN];
                                  long labelcert = j;
                                  AsnOid tmpOid(pSSL->tagSetName);
                                  long tagType = pSecTag->choiceId;

                                  sprintf(errStr, "%s%s=%s%s=%ld %s %s%s=0x%02X",
                                          "requiredClass doesn't match:",
                                          "\n\tTag Set Name", (const char *) tmpOid,
                                          "\n\ttagType", tagType,
                                          "(0=restrictive, 1=enumerated,",
                                          "2=permissive, or 3=freeform)",
                                          "\n\thex labelAndCertValue",
                                          (unsigned int) labelcert);
                                  throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                               }

                               if (this->security_classification != NULL)
                               {
                                  // IF pMatchCat->excludedClass != NULL THEN
                                  if (pMatchCat->excludedClass != NULL)
                                  {
                                     // LOOP thru pMatchCat->excludedClass linked
                                     // list until end of list:
                                     OptionalClassData *pOptClassData = NULL;
                                     pMatchCat->excludedClass->SetCurrToFirst();
                                     while ((pOptClassData =
                                        pMatchCat->excludedClass->Curr()) !=  NULL)
                                     {
                                        // IF current pMatchCat->excludedClass->
                                        // pOptClassData == securityLabel->sec_class THEN
                                        if (*pOptClassData ==
                                           *this->security_classification)
                                        {
                                           AclString errStr;
                                           AsnOid tmpOid(pSSL->tagSetName);
                                           long sec_class = *this->security_classification;
                                           long labelcert = j;

                                           errStr << "Found Excluded Classification: "
                                                  << sec_class << "\n"
                                                  << "Excluded by:\n"
                                                  << "tag_set_name=" << (const char *) tmpOid << "\n";
                                           CSecurityTag::getTagTypeStr(*pSecTag, errStr);
                                           errStr << "\nLACV=" << labelcert;
                                           // do error handling
                                           throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr.str());
                                        }
                                        pMatchCat->excludedClass->GoNext();
                                     } // ENDLOOP
                                  }  // ENDIF pMatchCat->excludedClass != NULL
                               }

                               // IF pMatchCat->excludedCategory != NULL then call
                               // excludedCatCheck to ensure that none of the excluded
                               // categories listed in the SPIF for the security
                               // category value are present in the security label.
                               if (pMatchCat->excludedCategory != NULL)
                               {
                                  excludedCatCheck(*pMatchCat->excludedCategory, spif);
                               }

                               // IF pMatchCat->requiredCategory != NULL then call
                               // requiredCatCheck to ensure that the required
                               // categories listed in the SPIF for the security
                               // category value are present in the security label.
                               if (pMatchCat->requiredCategory != NULL)
                               {
                                  requiredCatCheck(*pMatchCat->requiredCategory, spif);
                               }

                               // IF m_obsAccept != 1 AND pMatchCat->obsolete == 1 THEN
                               if ((this->m_obsAccept != true) &&
                                  (pMatchCat->obsolete != NULL) &&
                                  (*pMatchCat->obsolete == 1))
                               {
                                  char errStr[ACL_STR_BUF_LEN];
                                  AsnOid tmpOid(pSSL->tagSetName);
                                  long tagType = pSecTag->choiceId;
                                  long labelcert = j;

                                  sprintf(errStr,
                                          "%s%s=%s%s=%ld %s %s%s=0x%02X",
                                          "Obsolete category error:",
                                          "\n\tTag Set Name", (const char *) tmpOid,
                                          "\n\ttagType", tagType,
                                          "(0=restrictive, 1=enumerated,",
                                          "2=permissive, or 3=freeform)\n\t",
                                          "hex labelAndCertValue",
                                          (unsigned int) labelcert);

                                  // do error handling
                                  throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                               }
                           }
                       }
                   }
                   else if (pSecTag->choiceId ==
                      SecurityTag::enumeratedAttributesCid)
                   {

                      // error if securityLevel != classification
                      if (this->security_classification == NULL &&
                         pSecTag->enumeratedAttributes->securityLevel != NULL)
                      {
                         char errStr[ACL_STR_BUF_LEN];
                         AsnOid tmpOid(pSSL->tagSetName);
                         long sec_level = *pSecTag->enumeratedAttributes->securityLevel;
                         sprintf(errStr, "%s%s %s %ld%s %s",
                                 "Bad Security Level:\n\t",
                                 "security label sec class == NULL",
                                 "but enumerated security Level is", sec_level,
                                 "\n\tTag Set Name =", (const char *) tmpOid);

                         // do error handling
                         throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                      }
                      else if (this->security_classification != NULL &&
                         pSecTag->enumeratedAttributes->securityLevel != NULL &&
                         (*pSecTag->enumeratedAttributes->securityLevel !=
                         *this->security_classification))
                      {
                         char errStr[ACL_STR_BUF_LEN];
                         AsnOid tmpOid(pSSL->tagSetName);
                         long sec_class = *this->security_classification;
                         long sec_level = *pSecTag->enumeratedAttributes->securityLevel;

                         sprintf(errStr, "%s%s %ld %s %ld%s %s",
                                 "Bad Security Level:\n\t",
                                 "security label sec class is", sec_class,
                                 "but enumerated security Level is", sec_level,
                                 "\n\tTag Set Name =", (const char *) tmpOid);

                         // do error handling
                         throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                      }

                      // Set cat_count (local long) to 0.
                      long cat_count = 0;

                      // LOOP thru attributeFlags until end of array:
                      SecurityAttribute *pSecAttr = NULL;
                      for(pSecTag->enumeratedAttributes->attributeFlags.SetCurrToFirst(),
                         pSecAttr = pSecTag->enumeratedAttributes->attributeFlags.Curr();
                          pSecAttr != NULL;
                          pSecAttr = pSecTag->enumeratedAttributes->attributeFlags.GoNext())
                      {
                         // LOOP thru SPIF SecurityCategoryTagSets linked list
                         // until pMatchCat != NULL OR end of list:
                         SecurityCategoryTagSet *pSecCatTag = NULL;
                         SecurityCategoryTag *owner = NULL;
                         TagCategories *pMatchCat = NULL;
                         spif.spiftoSign->securityCategoryTagSets->SetCurrToFirst();

                         while (((pSecCatTag =
                            spif.spiftoSign->securityCategoryTagSets->Curr()) !=
                            NULL) && (pMatchCat == NULL))
                         {
                            // IF current securityLabel tag_set_name == current
                            // SPIF securityCategoryTagSetName THEN (found
                            // correct SPIF SecurityCategoryTagSet)
                            if (pSSL->tagSetName ==
                               pSecCatTag->securityCategoryTagSetName)
                            {
                               // LOOP thru current SPIF securityCategoryTags
                               // linked list until pMatchCat != NULL OR end of
                               // list:
                               SecurityCategoryTag *pSecCat = NULL;
                               pSecCatTag->securityCategoryTags.SetCurrToFirst();
                               while (((pSecCat =
                                  pSecCatTag->securityCategoryTags.Curr()) !=
                                  NULL) && (pMatchCat == NULL))
                               {
                                  // IF current securityLabel tag_type ==
                                  // current SPIF tag_type THEN (found correct
                                  // SPIF SecurityCategoryTag)
                                  if (CSecurityTag::isTagTypeEqual(*pSecTag, *pSecCat))
                                  {
                                     // LOOP thru current SPIF tagCategories
                                     // linked list until pMatchCat != NULL OR
                                     // end of list:
                                     TagCategories *pTagCats = NULL;
                                     pSecCat->tagCategories.SetCurrToFirst();
                                     while (((pTagCats =
                                        pSecCat->tagCategories.Curr()) !=
                                        NULL) && (pMatchCat == NULL))
                                     {
                                        // IF current SPIF labelAndCertValue ==
                                        // current securityLabel SecurityAttribute
                                        // (1rst array value) THEN (found correct
                                        // SPIF TagCategories) set pMatchCat to
                                        // point to current SPIF tagCategories
                                        if (pTagCats->labelAndCertValue ==
                                           *pSecAttr)
                                        {
                                           pMatchCat = pTagCats;
                                           owner = pSecCat;
                                        }
                                        pSecCat->tagCategories.GoNext();
                                     } // ENDLOOP
                                  }

                                  pSecCatTag->securityCategoryTags.GoNext();
                               } // ENDLOOP
                            }
                            spif.spiftoSign->securityCategoryTagSets->GoNext();
                         } // ENDLOOP

                         // IF pMatchCat == NULL THEN (SPIF does not include
                         // securityLabel security category value so return error)
                         if (pMatchCat == NULL)
                         {
                            char errStr[ACL_STR_BUF_LEN];
                            long labelcert = *pSecAttr;
                            AsnOid tmpOid(pSSL->tagSetName);
                            long tagType = pSSL->securityTags.Curr()->choiceId;

                            sprintf(errStr, "%s%s=%s%s=%ld %s %s=0x%02X",
                                    "Bad labelAndCert value:\n\t",
                                    "Tag Set Name", (const char *) tmpOid,
                                    "\n\ttagType", tagType,
                                    "(0=restrictive, 1=enumerated, 2=permissive,",
                                    "or 3=freeform)\n\thex labelAndCertValue",
                                    (unsigned int) labelcert);

                            // do error handling
                            throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                         }

                         // Increment cat_count.
                         cat_count++;

                         // IF owner->singleCategorySelectionPolicy == 1 AND
                         // cat_count > 1 THEN
                         if ((owner != NULL) &&
                            (owner->singleCategorySelectionPolicy != NULL) &&
                            (*owner->singleCategorySelectionPolicy == 1) &&
                            (cat_count > 1))
                         {
                            // do error handling
                            char errStr[ACL_STR_BUF_LEN];
                            long labelcert = *pSecAttr;
                            AsnOid tmpOid(pSSL->tagSetName);
                            long tagType = pSecTag->choiceId;

                            sprintf(errStr, "%s=%s%s=%ld %s %s=0x%02X",
                                    "Single category error:\n\tTag Set Name",
                                    (const char *) tmpOid, "\n\ttagType", tagType,
                                    "(0=restrictive, 1=enumerated, 2=permissive,",
                                    "or 3=freeform)\n\thex labelAndCertValue",
                                    (unsigned int) labelcert);
                            throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                         }

                         // IF pMatchCat->requiredClass != NULL AND pMatchCat->
                         // requiredClass != securityLabel->sec_class THEN
                         if ((pMatchCat->requiredClass != NULL) &&
                            (*pMatchCat->requiredClass !=
                            *this->security_classification))
                         {
                            char errStr[ACL_STR_BUF_LEN];
                            long labelcert = *pSecAttr;
                            AsnOid tmpOid(pSSL->tagSetName);
                            long tagType = pSecTag->choiceId;

                            sprintf(errStr, "%s=%s%s=%ld %s %s=0x%02X",
                                   "requiredClass doesn't match:\n\tTag Set Name",
                                    (const char *) tmpOid, "\n\ttagType", tagType,
                                    "(0=restrictive, 1=enumerated, 2=permissive,",
                                    "or 3=freeform)\n\thex labelAndCertValue",
                                    (unsigned int) labelcert);
                            throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                         }

                         // IF pMatchCat->excludedClass != NULL THEN
                         if (pMatchCat->excludedClass != NULL)
                         {
                            // LOOP thru pMatchCat->excludedClass linked list
                            // until end of list:
                            OptionalClassData *pOptClassData = NULL;
                            pMatchCat->excludedClass->SetCurrToFirst();
                            while ((pOptClassData =
                               pMatchCat->excludedClass->Curr()) !=  NULL)
                            {
                               // IF current pMatchCat->excludedClass->
                               // pOptClassData == securityLabel->sec_class THEN
                               if (*pOptClassData ==
                                  *this->security_classification)
                               {
                                  AclString errStr;
                                  AsnOid tmpOid(pSSL->tagSetName);
                                  long sec_class = *this->security_classification;
                                  long labelcert = *pSecAttr;

                                  errStr << "Found Excluded Classification: "
                                         << sec_class << "\n"
                                         << "Excluded by:\n"
                                         << "tag_set_name=" << (const char *) tmpOid << "\n";
                                  CSecurityTag::getTagTypeStr(*pSecTag, errStr);
                                  errStr << "\nLACV=" << labelcert;

                                  // do error handling
                                  throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr.str());
                               }
                               pMatchCat->excludedClass->GoNext();
                            } // ENDLOOP
                         }  // ENDIF pMatchCat->excludedClass != NULL

                         // IF pMatchCat->excludedCategory != NULL then call
                         // excludedCatCheck to ensure that none of the excluded
                         // categories listed in the SPIF for the security
                         // category value are present in the security label.
                         if (pMatchCat->excludedCategory != NULL)
                         {
                            excludedCatCheck(*pMatchCat->excludedCategory, spif);
                         }

                         // IF pMatchCat->requiredCategory != NULL then call
                         // requiredCatCheck to ensure that the required
                         // categories listed in the SPIF for the security
                         // category value are present in the security label.
                         if (pMatchCat->requiredCategory != NULL)
                         {
                            requiredCatCheck(*pMatchCat->requiredCategory, spif);
                         }

                         // IF m_obsAccept != 1 AND pMatchCat->obsolete == 1 THEN
                         if ((this->m_obsAccept != true) && (pMatchCat->obsolete != NULL) &&
                            (*pMatchCat->obsolete == 1))
                         {
                            char errStr[ACL_STR_BUF_LEN];
                            AsnOid tmpOid(pSSL->tagSetName);
                            long tagType = pSecTag->choiceId;
                            long labelcert = *pSecAttr;

                            sprintf(errStr, "%s=%s%s=%ld %s %s=0x%02X",
                                    "Obsolete category error: \n\tTag Set Name",
                                    (const char *) tmpOid, "\n\ttagType", tagType,
                                    "(0=restrictive, 1=enumerated, 2=permissive,",
                                    "or 3=freeform)\n\thex labelAndCertValue",
                                    (unsigned int) labelcert);

                            // do error handling
                            throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                         }
                      }
                   }
                   else if (pSecTag->choiceId ==
                      SecurityTag::permissivebitMapCid)
                   {
                      // error if securityLevel != classification
                      if (this->security_classification == NULL &&
                         pSecTag->permissivebitMap->securityLevel != NULL)
                      {
                         char errStr[ACL_STR_BUF_LEN];
                         AsnOid tmpOid(pSSL->tagSetName);
                         long sec_level = *pSecTag->permissivebitMap->securityLevel;
                         sprintf(errStr, "%s%s %s %ld %s %s",
                                 "Bad Security Level:\n\t",
                                 "security label sec class == NULL",
                                 "but permissive security Level is",
                                 sec_level, "\n\tTag Set Name =",
                                 (const char *) tmpOid);

                         // do error handling
                         throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                      }
                      else if (this->security_classification != NULL &&
                         pSecTag->permissivebitMap->securityLevel != NULL &&
                         (*pSecTag->permissivebitMap->securityLevel !=
                         *this->security_classification))
                      {
                         char errStr[ACL_STR_BUF_LEN];
                         AsnOid tmpOid(pSSL->tagSetName);
                         long sec_class = *this->security_classification;
                         long sec_level = *pSecTag->permissivebitMap->securityLevel;

                         sprintf(errStr, "%s%s %ld %s %ld%s %s",
                                 "Bad Security Level:\n\t",
                                 "security label sec class is", sec_class,
                                 "but permissive security Level is",
                                 sec_level, "\n\tTag Set Name =",
                                 (const char *) tmpOid);

                         // do error handling
                         throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                      }

                      // Set cat_count (local long) to 0.
                      long cat_count = 0;

                      // LOOP thru attributeFlags until end of array:
                      size_t i = pSecTag->permissivebitMap->attributeFlags.BitLen();
                      size_t j = 0;
                      for (j = 0; j <= i; j++)
                      {
                         // IF current securityLabel bit position is set to 1 THEN:
                         if (CAsnBits::checkBit(pSecTag->permissivebitMap->
                            attributeFlags, j))
                         {
                            // LOOP thru SPIF SecurityCategoryTagSets linked list
                            // until pMatchCat != NULL OR end of list:
                            SecurityCategoryTagSet *pSecCatTag = NULL;
                            SecurityCategoryTag *owner = NULL;
                            TagCategories *pMatchCat = NULL;
                            spif.spiftoSign->securityCategoryTagSets->SetCurrToFirst();

                            while (((pSecCatTag =
                               spif.spiftoSign->securityCategoryTagSets->Curr()) !=
                               NULL) && (pMatchCat == NULL))
                            {
                               // IF current securityLabel tag_set_name == current
                               // SPIF securityCategoryTagSetName THEN (found
                               // correct SPIF SecurityCategoryTagSet)
                               if (pSSL->tagSetName ==
                                  pSecCatTag->securityCategoryTagSetName)
                               {
                                  // LOOP thru current SPIF securityCategoryTags
                                  // linked list until pMatchCat != NULL OR end of
                                  // list:
                                  SecurityCategoryTag *pSecCat = NULL;
                                  pSecCatTag->securityCategoryTags.SetCurrToFirst();
                                  while (((pSecCat =
                                     pSecCatTag->securityCategoryTags.Curr()) !=
                                     NULL) && (pMatchCat == NULL))
                                  {
                                     // IF current securityLabel tag_type ==
                                     // current SPIF tag_type THEN (found correct
                                     // SPIF SecurityCategoryTag)
                                     if (CSecurityTag::isTagTypeEqual(*pSecTag, *pSecCat))
                                     {
                                        // LOOP thru current SPIF tagCategories
                                        // linked list until pMatchCat != NULL OR
                                        // end of list:
                                        TagCategories *pTagCats = NULL;
                                        pSecCat->tagCategories.SetCurrToFirst();
                                        while (((pTagCats =
                                           pSecCat->tagCategories.Curr()) !=
                                           NULL) && (pMatchCat == NULL))
                                        {
                                           // IF current securityLabel bit position
                                           // indicated by current tagCategories
                                           // tag_label_cert is set to 1 THEN (found
                                           // correct TagCategories) set pMatchCat to
                                           // point to current SPIF tagCategories
                                           if (pTagCats->labelAndCertValue == (AsnInt)j)
                                           {
                                              pMatchCat = pTagCats;
                                              owner = pSecCat;
                                           }
                                           pSecCat->tagCategories.GoNext();
                                        } // ENDLOOP
                                     }

                                     pSecCatTag->securityCategoryTags.GoNext();
                                  } // ENDLOOP
                               }
                               spif.spiftoSign->securityCategoryTagSets->GoNext();
                            } // ENDLOOP

                            // IF pMatchCat == NULL THEN (SPIF does not include
                            // securityLabel security category value so return error)
                            if (pMatchCat == NULL)
                            {
                               AclString errStr;
                               long labelcert = j;
                               AsnOid tmpOid(pSSL->tagSetName);


                               errStr << "SPIF does not contain value asserted in label:\n"
                                      << "tag_set_name=" << (const char *) tmpOid << "\n";
                               CSecurityTag::getTagTypeStr(*pSSL->securityTags.Curr(), errStr);
                               errStr << "\nLACV: " << labelcert;

                               // do error handling
                               throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr.str());
                            }

                            // Increment cat_count.
                            cat_count++;

                            // IF owner->singleCategorySelectionPolicy == 1 AND
                            // cat_count > 1 THEN
                            if ((owner != NULL) &&
                               (owner->singleCategorySelectionPolicy != NULL) &&
                               (*owner->singleCategorySelectionPolicy == 1) &&
                               (cat_count > 1))
                            {
                               // do error handling
                               char errStr[ACL_STR_BUF_LEN];
                               long labelcert = j;
                               AsnOid tmpOid(pSSL->tagSetName);
                               long tagType = pSecTag->choiceId;

                               sprintf(errStr, "%s=%s%s=%ld %s %s%s=0x%02X",
                                       "single category error:\n\tTag Set Name",
                                       (const char *) tmpOid, "\n\ttagType", tagType,
                                       "(0=restrictive, 1=enumerated,",
                                       "2=permissive, or 3=freeform)\n\t",
                                       "hex labelAndCertValue",
                                       (unsigned int) labelcert);
                               throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                            }

                            // IF pMatchCat->requiredClass != NULL AND pMatchCat->
                            // requiredClass != securityLabel->sec_class THEN
                            if ((pMatchCat->requiredClass != NULL) &&
                               (*pMatchCat->requiredClass !=
                               *this->security_classification))
                            {
                               char errStr[ACL_STR_BUF_LEN];
                               long labelcert = j;
                               AsnOid tmpOid(pSSL->tagSetName);
                               long tagType = pSecTag->choiceId;

                               sprintf(errStr, "%s%s=%s%s=%ld %s %s %s=0x%02X",
                                       "requiredClass doesn't match:\n\t",
                                       "Tag Set Name", (const char *) tmpOid,
                                       "\n\ttagType", tagType, "(0=restrictive,",
                                       "1=enumerated, 2=permissive, or",
                                       "3=freeform)\n\thex labelAndCertValue",
                                       (unsigned int) labelcert);
                               throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                            }

                            // IF pMatchCat->excludedClass != NULL THEN
                            if (pMatchCat->excludedClass != NULL)
                            {
                               // LOOP thru pMatchCat->excludedClass linked list
                               // until end of list:
                               OptionalClassData *pOptClassData = NULL;
                               pMatchCat->excludedClass->SetCurrToFirst();
                               while ((pOptClassData =
                                  pMatchCat->excludedClass->Curr()) !=  NULL)
                               {
                                  // IF current pMatchCat->excludedClass->
                                  // pOptClassData == securityLabel->sec_class THEN
                                  if (*pOptClassData ==
                                     *this->security_classification)
                                  {
                                     AclString errStr;
                                     AsnOid tmpOid(pSSL->tagSetName);
                                     long sec_class = *this->security_classification;
                                     long labelcert = j;

                                     errStr << "Found Excluded Classification: "
                                            << sec_class << "\n"
                                            << "Excluded by:\n"
                                            << "tag_set_name=" << (const char *) tmpOid << "\n";
                                     CSecurityTag::getTagTypeStr(*pSecTag, errStr);
                                     errStr << "\nLACV=" << labelcert;

                                     // do error handling
                                     throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr.str());
                                  }
                                  pMatchCat->excludedClass->GoNext();
                               } // ENDLOOP
                            }  // ENDIF pMatchCat->excludedClass != NULL

                            // IF pMatchCat->excludedCategory != NULL then call
                            // excludedCatCheck to ensure that none of the excluded
                            // categories listed in the SPIF for the security
                            // category value are present in the security label.
                            if (pMatchCat->excludedCategory != NULL)
                            {
                               excludedCatCheck(*pMatchCat->excludedCategory, spif);
                            }

                            // IF pMatchCat->requiredCategory != NULL then call
                            // requiredCatCheck to ensure that the required
                            // categories listed in the SPIF for the security
                            // category value are present in the security label.
                            if (pMatchCat->requiredCategory != NULL)
                            {
                               requiredCatCheck(*pMatchCat->requiredCategory, spif);
                            }

                            // IF m_obsAccept != 1 AND pMatchCat->obsolete == 1 THEN
                            if ((this->m_obsAccept != true) && (pMatchCat->obsolete)
                               && (*pMatchCat->obsolete == 1))
                            {
                               char errStr[ACL_STR_BUF_LEN];
                               AsnOid tmpOid(pSSL->tagSetName);
                               long tagType = pSecTag->choiceId;
                               long labelcert = j;

                               sprintf(errStr, "%s%s %s%s %ld %s %s%s 0x%02X",
                                       "Obsolete category error:\n\t",
                                       "Tag Set Name =", (const char *) tmpOid,
                                       "\n\ttagType =", tagType,
                                       "(0=restrictive, 1=enumerated,",
                                       "2=permissive, or 3=freeform)\n\t",
                                       "hex labelAndCertValue =",
                                       (unsigned int) labelcert);

                               // do error handling
                               throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                            }
                         }
                      }
                   }
                   else if (pSecTag->choiceId ==
                      SecurityTag::freeFormFieldCid)
                   {
                      // no securityLevel - do nothing
                   }
                   else
                   {
                      // do error handling
                      throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR,
                                "Improper Security Tag Value::check");
                   }
                }

             }// END LOOP thru StandardSecurityLabel

          }  // end if security_categories != NULL
       }
       else
       {
          // PolicyId and SPIF policyId are not equal - return error
          char errStr[ACL_STR_BUF_LEN];
          AsnOid tmpOid1(spif.getPolicyId());
          AsnOid tmpOid2(this->security_policy_identifier);
          errStr[0]='\0';
          sprintf(errStr, "PolicyID's don't match. \n\tspif policyId=%s%s=%s",
                  (const char *) tmpOid1, "\n\tseclbl policyId", (const char *) tmpOid2);
          throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
       }

   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }

   return(true);
} // END OF MEMBER FUNCTION check

// requiredCatCheck:
// This member ensures that the required categories listed in the SPIF are
// present in the security label.
//
void SecurityLabel::requiredCatCheck(RequiredCategories &reqCat, SPIF &spif)
{
   OptionalCategoryData *pCatData = NULL;
   long found_cat = 0;
   long stop_search = 0;
   long found_cat_pif = 0;

   FUNC("SecurityLabel::requiredCatCheck");
   try
   {
       reqCat.SetCurrToFirst();

       while (reqCat.Curr() != NULL)
       {
          reqCat.Curr()->categoryGroup.SetCurrToFirst();
          while (((pCatData = reqCat.Curr()->categoryGroup.Curr()) != NULL) &&
             (stop_search == 0))
          {
             // If the required category indicates that only the labelAndCertValue
             // is required ensure that the security label securityCategories
             // contains the requiredCategory securityCategoryTagSetName present
             // in the label.
             if (pCatData->categories->choiceId ==
                OptionalCategoryDataChoice::labelAndCertValueCid)
             {
                // Determine if the security label includes the current categoryGroup.
                // If findCat returns false throw an exception containing the
                // information that caused the failure.
                //
                if (findCat(pCatData->securityCategoryTagSetName, pCatData->tagType,
                   *pCatData->categories->labelAndCertValue) == false)
                {
                   if (reqCat.Curr()->operation == 3)
                   {
                      char errStr[ACL_STR_BUF_LEN];
                      AsnOid tmpOid(pCatData->securityCategoryTagSetName);
                      long tagType = pCatData->tagType;
                      long labelcert = *pCatData->categories->labelAndCertValue;

                      sprintf(errStr, "%s=%s%s=%ld%s=0x%02X",
                              "Missing required category:\n\tTag Set Name",
                              (const char *) tmpOid, "\n\ttagType", tagType,
                              "\n\thex labelAndCertValue",
                              (unsigned int) labelcert);

                      // findCat failed, do error handling
                      throw ACL_EXCEPT(ACL_REQ_CAT_NOT_FOUND, errStr);
                   }
                }
                else  // findCat returned true value
                {
                   // Increment found_cat.
                   found_cat++;

                   //IF current reqCats->operation == 1 (onlyOne) THEN
                   if (reqCat.Curr()->operation == 1)
                   {
                      if (found_cat > 1)
                      {
                         char errStr[ACL_STR_BUF_LEN];
                         AsnOid tmpOid(pCatData->securityCategoryTagSetName);
                         long tagType = pCatData->tagType;
                         long labelcert = *pCatData->categories->labelAndCertValue;

                         sprintf(errStr, "%s%s=%s%s=%ld%s=0x%02X",
                                 "operation == 1 and found_cat > 1:\n\t",
                                 "Tag Set Name", (const char *) tmpOid,
                                 "\n\ttagType", tagType,
                                 "\n\thex labelAndCertValue",
                                 (unsigned int) labelcert);

                         // findCat failed, do error handling
                         throw ACL_EXCEPT(ACL_REQ_CAT_NOT_FOUND, errStr);
                      }
                   }
                   //Elseif current reqCats->operation == 2 (oneOrMore) THEN
                   else if (reqCat.Curr()->operation == 2)
                      stop_search = 1;
                }
             }
             // ELSE (current required category == 1 (allCid), so check
             //   all SecurityTag values in SPIF indicated by current
             //   requiredCategory categoryData for inclusion in security label)
             else
             {
                // Set found_cat_pif to 0.
                found_cat_pif = 0;

                //Loop thru SPIF SecurityCategoryTagSet linked list until
                //stop_search == 1 OR end of list:
                SecurityCategoryTagSet *pSecTagSet = NULL;
                spif.spiftoSign->securityCategoryTagSets->SetCurrToFirst();

                while (((pSecTagSet =
                   spif.spiftoSign->securityCategoryTagSets->Curr()) != NULL) &&
                   (stop_search == 0))
                {
                   // if SPIF securityCategoryTagSetName equals requiredCategory
                   // securityCategoryTagSetName THEN (found correct SPIF
                   // SecurityCategoryTagSet for current requiredCategory
                   // NamedTagSet
                   if (pSecTagSet->securityCategoryTagSetName ==
                      pCatData->securityCategoryTagSetName)
                   {
                      // LOOP thru current SPIF securityCategoryTags linked
                      // list until stop_search == 1 OR end of list:
                      SecurityCategoryTag *pSecTag = NULL;
                      pSecTagSet->securityCategoryTags.SetCurrToFirst();

                      while (((pSecTag = pSecTagSet->securityCategoryTags.Curr())
                         != NULL) && (stop_search == 0))
                      {
                         // if SPIF tagType equals requiredCategory tagType
                         if (pSecTag->tagType == pCatData->tagType)
                         {
                            // Set found_cat_pif to 1.
                            found_cat_pif = 1;

                            // LOOP thru current SPIF tagCategories linked list
                            // until stop_search == 1 OR end of list:
                            TagCategories *pTagCat = NULL;
                            pSecTag->tagCategories.SetCurrToFirst();

                            while (((pTagCat = pSecTag->tagCategories.Curr())
                               != NULL) && (stop_search == 0))
                            {
                               // Call findCat to determine if the security label
                               // includes the current SPIF labelAndCertValue
                               if (findCat(pSecTagSet->securityCategoryTagSetName,
                                  pSecTag->tagType,
                                  pTagCat->labelAndCertValue) == false)
                               {
                                  if (reqCat.Curr()->operation == 3)
                                  {
                                     // findCat failed, do error handling
                                     char errStr[ACL_STR_BUF_LEN];
                                     AsnOid tmpOid(pSecTagSet->securityCategoryTagSetName);
                                     long tagType = pSecTag->tagType;
                                     long labelcert = pTagCat->labelAndCertValue;

                                     sprintf(errStr, "%s%s=%s%s=%ld%s=0x%02X",
                                             "Missing required category:\n\t",
                                             "Tag Set Name", (const char *) tmpOid,
                                             "\n\ttagType", tagType,
                                             "\n\tlabelAndCertValue",
                                             (unsigned int) labelcert);

                                     // findCat failed, do error handling
                                     throw ACL_EXCEPT(ACL_REQ_CAT_NOT_FOUND, errStr);
                                  }

                               }
                               else  // findCat returned true value
                               {
                                  // Increment found_cat.
                                  found_cat++;

                                  //IF current reqCats->operation == 1 (onlyOne)
                                  if (reqCat.Curr()->operation == 1)
                                  {
                                     if (found_cat > 1)
                                     {
                                        char errStr[ACL_STR_BUF_LEN];
                                        AsnOid tmpOid(pSecTagSet->securityCategoryTagSetName);
                                        long tagType = pSecTag->tagType;
                                        long labelcert = pTagCat->labelAndCertValue;

                                        sprintf(errStr, "%s %s=%s%s=%ld%s=0x%02X",
                                                "operation == 1 and found_cat",
                                                "> 1:\n\tTag Set Name",
                                                (const char *) tmpOid, "\n\ttagType",
                                                tagType, "\n\tlabelAndCertValue",
                                                (unsigned int) labelcert);

                                        // findCat failed, do error handling
                                        throw ACL_EXCEPT(ACL_REQ_CAT_NOT_FOUND, errStr);
                                     }
                                  }
                                  //Elseif current reqCats->operation == 2 (oneOrMore) THEN
                                  else if (reqCat.Curr()->operation == 2)
                                     stop_search = 1;
                               }

                               pSecTag->tagCategories.GoNext();
                            } // ENDLOOP
                         }
                         pSecTagSet->securityCategoryTags.GoNext();
                      } // ENDLOOP

                   }
                   spif.spiftoSign->securityCategoryTagSets->GoNext();
                } // ENDLOOP

                // IF found_cat_pif == 0 THEN (SPIF SecurityTag could not be
                // found in SPIF, so SPIF is erroneous)
                if (found_cat_pif == 0)
                {
                   throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR,
                            "No Req Cats (>5000) error::requiredCatCheck");
                   // do error handling
                }
             }  // ENDELSE check all SecurityTags in SPIF indicated by req_cats
             reqCat.Curr()->categoryGroup.GoNext();
          }

          // IF found_cat == 0 THEN return NO_REQ_CATS (>5000) error code.
          // (Note: In this case, the security label did not include any of
          // the Required Categories indicated by the SPIF for the chk_val
          // security label value, but that could be 1 or more possible
          // values.
          if (found_cat == 0)
          {
            throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR,
                      "No Req Cats (>5000) error::requiredCatCheck");
          }

          reqCat.GoNext();
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
} // END OF MEMBER FUNCTION requiredCatCheck

// excludedCatCheck:
// This member ensures that none of the excluded categories listed in the SPIF
// are present in the security label.
//
void SecurityLabel::excludedCatCheck(OptionalCategoryDataSeqOf &excCat,
                                     SPIF &spif)
{
   OptionalCategoryData *pCatData = NULL;
   long found_cat = 0;

   FUNC("SecurityLabel::excludedCatCheck");
   try
   {
       // LOOP thru excCats (SEQUENCE of OptionalCategoryData linked list
       // until end of list:
       excCat.SetCurrToFirst();
       while (( pCatData = excCat.Curr()) != NULL)
       {
          // If the excluded category indicates that only the labelAndCertValue
          // is required ensure that the security label securityCategories
          // contains the excludedCategory securityCategoryTagSetName present
          // in the label.
          if (pCatData->categories->choiceId ==
             OptionalCategoryDataChoice::labelAndCertValueCid)
          {
             // Call findCat to determine if the security label includes the current
             // excluded category security tag value.  If current excluded category
             // is found in the security label, then findCat returns NO_ERROR;
             // otherwise, an error code is returned.
             if (findCat(pCatData->securityCategoryTagSetName, pCatData->tagType,
                *pCatData->categories->labelAndCertValue) == true)
             {
                char errStr[ACL_STR_BUF_LEN];
                AsnOid tmpOid(pCatData->securityCategoryTagSetName);
                long tagType = pCatData->tagType;
                long labelcert = *pCatData->categories->labelAndCertValue;

                sprintf(errStr,"%s=%s\n\t%s=%ld\n\t%s=0x%02X",
                        "Excluded Category Found:\n\tTag Set Name",
                        (const char *)tmpOid, "tagType", tagType,
                        "labelAndCertValue",
                        (unsigned int) labelcert);

                // findCat found excluded category, do error handling
                throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
             }
          }
          // ELSE check all SecurityTag values in SPIF indicated by current
          // excludedCategory for exclusion in SecurityLabel.
          //
          else if ( pCatData->categories->choiceId ==
             OptionalCategoryDataChoice::allCid)
          {
             // Set found_cat to 0.
             found_cat = 0;

             // Loop thru SPIF SecurityCategoryTagSet linked list until
             // found_cat != 0 OR end of list:
             SecurityCategoryTagSet *pSecTagSet = NULL;
             spif.spiftoSign->securityCategoryTagSets->SetCurrToFirst();

             while (((pSecTagSet =
                spif.spiftoSign->securityCategoryTagSets->Curr()) != NULL) &&
                (found_cat == 0))
             {
                // if SPIF securityCategoryTagSetName equals excludedCategory
                // securityCategoryTagSetName THEN (found correct SPIF
                // SecurityCategoryTagSet for current requiredCategory
                // NamedTagSet
                if (pSecTagSet->securityCategoryTagSetName ==
                   pCatData->securityCategoryTagSetName)
                {
                   // LOOP thru current SPIF securityCategoryTags linked
                   // list until found_cat != 0 OR end of list:
                   SecurityCategoryTag *pSecTag = NULL;
                   pSecTagSet->securityCategoryTags.SetCurrToFirst();

                   while (((pSecTag = pSecTagSet->securityCategoryTags.Curr())
                      != NULL) && (found_cat == 0))
                   {
                      // if excludedCategory tagType equals SPIF tagType
                      if (pSecTag->tagType == pCatData->tagType)
                      {
                         // Set found_cat to 1.
                         found_cat = 1;

                         // LOOP thru current SPIF tagCategories linked list
                         // until end of list:
                         TagCategories *pTagCat = NULL;
                         pSecTag->tagCategories.SetCurrToFirst();

                         while ((pTagCat = pSecTag->tagCategories.Curr()) != NULL)
                         {
                            // Call findCat to determine if the security label
                            // includes the current SPIF labelAndCertValue
                            if (findCat(pSecTagSet->securityCategoryTagSetName,
                               pSecTag->tagType,
                               pTagCat->labelAndCertValue) == true)
                            {
                               // findCat found excluded category, do error handling
                               char errStr[ACL_STR_BUF_LEN];
                               AsnOid tmpOid(pCatData->securityCategoryTagSetName);
                               long tagType = pCatData->tagType;
                               long labelcert = pTagCat->labelAndCertValue;

                               sprintf(errStr, "%s=%s%s=%ld%s=0x%02X",
                                       "Excluded category found:\n\tTag Set Name",
                                       (const char *) tmpOid, "\n\ttagType", tagType,
                                       "\n\tlabelAndCertValue",
                                       (unsigned int) labelcert);
                               throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                            }

                            pSecTag->tagCategories.GoNext();
                         } // ENDLOOP
                      } // ENDIF tagTypes match
                      pSecTagSet->securityCategoryTags.GoNext();
                   } // ENDLOOP
                }
                spif.spiftoSign->securityCategoryTagSets->GoNext();
             } // ENDLOOP

             // IF found_cat == 0 THEN (SPIF excludedCategory SecurityTag could not
             // be found in SPIF, so SPIF is erroneous)
             if (found_cat == 0)
             {
                // do error handling
                throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR,
                   "PIF No Exc Cat (> 5000) error::excludedCatCheck");
             }
          }  // ENDELSE check all SecurityTags in SPIF indicated by excluded categories
          else
          {
             throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR,
               "Invalid OptionalCategoryDataChoice->choiceId::excludedCatCheck");
          }

          excCat.GoNext();
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
} // END OF MEMBER FUNCTION excludedCatCheck

// findCat:
// This function determines if the securityLabel includes the categoryData
// security tag value.
bool SecurityLabel::findCat(SNACC::AsnOid &tagsetname, SNACC::TagTypeValue &tagtype,
                            SNACC::AsnInt &labelandcert)
{
   FUNC("SecurityLabel::findCat");

   try
   {
      // PIERCE: GetCurrElmtIndex() and SetCurrElmtIndex() (line 1514)
      // no longer exist in the AsnList<T> template.  However,
      // this is the only place where these functions are actually
      // used and I don't believe they are necessary.  So I've 
      // commented them out for now.
      //
      //int a = getSSL().GetCurrElmtIndex();

      //LOOP thru StandardSecurityLabel
      const NamedTagSet *pNamedTagSet = NULL;

      for(getSSL().SetCurrToFirst(); (pNamedTagSet = getSSL().Curr()) != NULL;
          getSSL().GoNext())
      {
         // if the securityLabel tagSetName equals the tagsetname
         if (pNamedTagSet->tagSetName == tagsetname)
         {
            if (CSecurityTag::findLabelAndCertValue(pNamedTagSet->
               securityTags, labelandcert, tagtype))
            {
               // found, no error
               //getSSL().SetCurrElmt(a);  // RESET pointer for calling routine
               return(true);
            }
         }
      }

      //getSSL().SetCurrElmt(a);  // RESET pointer for calling routine

   }
   catch (InternalAclException &)
   {
   }

   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return(false);
} // END OF MEMBER FUNCTION findCat

// tagAndLevelCheck:
// This function checks for the tag redundancy error and checks to make sure
// the securityLevel equals the security classification
void SecurityLabel::tagAndLevelCheck(void)
{
   AsnOidLst TagList;

   FUNC("SecurityLabel::tagAndLevelCheck");

   try
   {
       if (this->security_categories != NULL)
       {
          // LOOP thru securityLabel security_categories StandardSecurityLabel
          // (NamedTagSets) linked list:

          const NamedTagSet *pSSL = NULL;
          for(getSSL().SetCurrToFirst(); (pSSL = getSSL().Curr()) != NULL;
              getSSL().GoNext())
          {
             // Append current securityLabel tagSetName OID to end
             // of tag_lst linked list.
             // LOOP thru TagList until end of list:
             AsnOid *pTmpOid = NULL;
             for(TagList.SetCurrToFirst(),
               pTmpOid = TagList.Curr(); pTmpOid != NULL;
             pTmpOid = TagList.GoNext())
             {
               // IF current TagList->oid is identical to current
               // securityLabel tagSetName THEN (there are two NamedTagSets
               // with the same TagSetName within the same securityCategory,
               // so that breaks the SDN.801 processing rules) THEN
               if (*pTmpOid == pSSL->tagSetName)
               {
                  char errStr[ACL_STR_BUF_LEN];
                  AsnOid tmpOid1(*pTmpOid);
                  AsnOid tmpOid2(pSSL->tagSetName);

                  sprintf(errStr, "%s=%s%s=%s",
                          "Redundant Name (> 5000) error \n\tTag Set Name 1",
                          (const char *) tmpOid1, "\n\tTag Set Name 2",
                          (const char *) tmpOid2);

                  // do any error handling
                  throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
               }
             }

             AsnOid *ptmpoid = TagList.Append();
             *ptmpoid = pSSL->tagSetName;

             // LOOP thru current securityLabel SecurityTags linked list:
             const SecurityTag *pSecTag = NULL;
             pSSL->securityTags.SetCurrToFirst();
             for(; (pSecTag = pSSL->securityTags.Curr()) != NULL; pSSL->securityTags.GoNext())
             {
                // Get tagType and check if current securityLabel
                // SecurityTags securityLevel != to current
                // securityLabel securityClass
                if (pSecTag->choiceId == SecurityTag::restrictivebitMapCid)
                {
                   if ( (this->security_classification == NULL) &&
                      (pSecTag->restrictivebitMap->securityLevel != NULL))
                   {
                      char errStr[ACL_STR_BUF_LEN];
                      AsnOid tmpOid(pSSL->tagSetName);
                      long sec_level = *pSecTag->restrictivebitMap->securityLevel;
                      sprintf(errStr, "%s%s %s %ld%s %s",
                              "Bad Security Level::tagAndLevelCheck:\n\t",
                              "security label sec class == NULL",
                              "but restrictive security Level is", sec_level,
                              "\n\tTag Set Name =", (const char *) tmpOid);

                      // do error handling
                      throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                   }
                   else if ( (pSecTag->restrictivebitMap->securityLevel != NULL)
                      && (this->security_classification != NULL) &&
                      (*pSecTag->restrictivebitMap->securityLevel !=
                      *this->security_classification) )
                   {
                      char errStr[ACL_STR_BUF_LEN];
                      AsnOid tmpOid(pSSL->tagSetName);
                      long sec_class = *this->security_classification;
                      long sec_level = *pSecTag->restrictivebitMap->securityLevel;

                      sprintf(errStr, "%s%s %ld %s %ld%s %s",
                              "Bad Security Level::tagAndLevelCheck:\n\t",
                              "security label sec class is", sec_class,
                              "but restrictive security Level is", sec_level,
                              "\n\tTag Set Name =", (const char *) tmpOid);

                      // do error handling
                      throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                   }
                }
                else if (pSecTag->choiceId ==
                   SecurityTag::enumeratedAttributesCid)
                {
                   if ( (this->security_classification == NULL) &&
                      (pSecTag->enumeratedAttributes->securityLevel != NULL))
                   {
                      char errStr[ACL_STR_BUF_LEN];
                      AsnOid tmpOid(pSSL->tagSetName);
                      long sec_level = *pSecTag->enumeratedAttributes->securityLevel;
                      sprintf(errStr, "%s%s %s %ld%s %s",
                              "Bad Security Level::tagAndLevelCheck:\n\t",
                              "security label sec class == NULL",
                              "but enumerated security Level is", sec_level,
                              "\n\tTag Set Name =", (const char *) tmpOid);

                      // do error handling
                      throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                   }
                   else if ( (pSecTag->enumeratedAttributes->securityLevel != NULL)
                      && (this->security_classification != NULL) &&
                      (*pSecTag->enumeratedAttributes->securityLevel !=
                      *this->security_classification) )
                   {
                      char errStr[ACL_STR_BUF_LEN];
                      AsnOid tmpOid(pSSL->tagSetName);
                      long sec_class = *this->security_classification;
                      long sec_level = *pSecTag->enumeratedAttributes->securityLevel;

                      sprintf(errStr, "%s%s %ld %s %ld%s %s",
                              "Bad Security Level::tagAndLevelCheck:\n\t",
                              "security label sec class is", sec_class,
                              "but enumerated security Level is", sec_level,
                              "\n\tTag Set Name =", (const char *) tmpOid);

                      // do error handling
                      throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                   }
                }
                else if (pSecTag->choiceId ==
                   SecurityTag::permissivebitMapCid)
                {
                   // error if securityLevel != classification

                   if ( (this->security_classification == NULL) &&
                      (pSecTag->permissivebitMap->securityLevel != NULL))
                   {
                      char errStr[ACL_STR_BUF_LEN];
                      AsnOid tmpOid(pSSL->tagSetName);
                      long sec_level = *pSecTag->permissivebitMap->securityLevel;
                      sprintf(errStr, "%s%s %s %ld%s %s",
                              "Bad Security Level::tagAndLevelCheck:\n\t",
                              "security label sec class == NULL",
                              "but permissive security Level is", sec_level,
                              "\n\tTag Set Name =", (const char *) tmpOid);

                      // do error handling
                      throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                   }
                   else if ( (pSecTag->permissivebitMap->securityLevel != NULL) &&
                      (this->security_classification != NULL) &&
                      (*pSecTag->permissivebitMap->securityLevel !=
                      *this->security_classification) )
                   {
                      char errStr[ACL_STR_BUF_LEN];
                      AsnOid tmpOid(pSSL->tagSetName);
                      long sec_class = *this->security_classification;
                      long sec_level = *pSecTag->permissivebitMap->securityLevel;

                      sprintf(errStr, "%s%s %ld %s %ld%s %s",
                              "Bad Security Level::tagAndLevelCheck:\n\t",
                              "security label sec class is", sec_class,
                              "but permissive security Level is", sec_level,
                              "\n\tTag Set Name =", (const char *) tmpOid);

                      // do error handling
                      throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR, errStr);
                   }
                }
                else if (pSecTag->choiceId ==
                   SecurityTag::freeFormFieldCid)
                {
                   // no securityLevel - do nothing
                }
                else
                {
                   // do error handling
                   throw ACL_EXCEPT(ACL_LABEL_CHECK_ERROR,
                       "Improper Security Tag Value::tagAndLevelCheck");
                }
             }

          }// END LOOP thru StandardSecurityLabel
       }
   }
   catch (InternalAclException &)
   {
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }

} // END OF MEMBER FUNCTION tagAndLevelCheck

// isEquivApplicable:
//
// applied        INTEGER {
//             encrypt  (0),
//             decrypt  (1),
//             both  (2) } }
//
bool SecurityLabel::isEquivApplicable(int applied)
{
   if ( applied == 2 || ((isIncoming() && applied == 1) ||
        (isOutgoing() && applied == 0)))
        return true;
   else
      return false;
} // END OF MEMBER FUNCTION isEquivApplicable

// getClassification:
//
SecurityClassification & SecurityLabel::getClassification(void)
{
   if (this->security_classification == NULL)
      this->security_classification = new SecurityClassification;

   return (*this->security_classification);
} // END OF MEMBER FUNCTION getClassification

// getLabelString:
// Returns a null terminated string representation
// of the SecurityLabel as defined by SDN.801.
//
char * SecurityLabel::getLabelString(const SPIF *pSPIF)
{
   PrintableLabel printableLabel(*this, (SPIF &)*pSPIF);
   AclString      os;

   printableLabel.printLabel(os);
   return (os.str());
} // END OF MEMBER FUNCTION getLabelString

// getPolicyId:
// Returns a reference to the security policy
// identifier contained within the SecurityLabel.
//
AsnOid & SecurityLabel::getPolicyId(void)
{
   return(this->security_policy_identifier);
} // END OF MEMBER FUNCTION getPolicyId

// setSSL:
//
void SecurityLabel::setSSL(StandardSecurityLabel *pNewTagSets)
{
   if (this->m_pSNACCTmpSSL != NULL)
      delete this->m_pSNACCTmpSSL;
   m_pSNACCTmpSSL = pNewTagSets;
} // END OF MEMBER FUNCTION setSSL

// freeFormOnlyCheck:
//
// Determines if this security label only contains freeForm security category
// data.  This member function is used to determine whether or not security
// categories should be translated.
bool SecurityLabel::freeFormOnlyCheck(void)
{
  const NamedTagSet *pTagSet = NULL;
  bool retVal = true;;

  if (this->security_categories != NULL)
  {
     for (this->getSSL().SetCurrToFirst();
     (pTagSet = this->getSSL().Curr()) != NULL;
     this->getSSL().GoNext())
     {
        if (! ((pTagSet->securityTags.Count() == 1) &&
               (pTagSet->securityTags.First()->choiceId == SecurityTag::freeFormFieldCid)))
        {
           retVal = false;
           break;
        }
     }
  }

  return retVal;
} // END OF MEMBER FUNCTION freeFormOnlyCheck

// isIncoming:
//
bool SecurityLabel::isIncoming(void)
{
   return false;
} // END OF MEMBER FUNCTION isIncoming

// isOutgoing:
//
bool SecurityLabel::isOutgoing(void)
{
   return false;
} // END OF MEMBER FUNCTION isOutgoing

// isIncoming:
//
bool IncomingLabel::isIncoming(void)
{ return true;} // END OF MEMBER FUNCTION isIncoming

// isOutgoing:
//
bool OutgoingLabel::isOutgoing(void)
{ return true;} // END OF MEMBER FUNCTION isOutgoing

// END OF acllabel.cpp

_END_NAMESPACE_ACL
