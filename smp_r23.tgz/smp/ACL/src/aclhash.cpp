#include "acl_api.h"
#include "aclinternal.h"
#include "aclhash.h"

_USING_NAMESPACE_SNACC
_BEGIN_NAMESPACE_ACL

// doSha1:
//
int AclHash::doSha1(CTIL::CSM_Buffer *pData,
                    CTIL::CSM_Buffer *pHashValue)
{

   char *pch;
   pHashValue->Open(SM_FOPEN_WRITE);
   pch = pHashValue->Alloc(SHA1_SIZE);
   SHA1_InitializeHash();
   SHA1_GetHash(pData->Length(), (unsigned char *)pData->Access(), 
         (unsigned char *)pch);
   pHashValue->Flush();
   pHashValue->Close();
   return(SM_NO_ERROR);
}

// SHA1_InitializeHash:
//
void AclHash::SHA1_InitializeHash(void)
{
   hash.initflag = 1;
   hash.total = 0;

   hash.hashval[0] = 0x67452301;
   hash.hashval[1] = 0xefcdab89;
   hash.hashval[2] = 0x98badcfe;
   hash.hashval[3] = 0x10325476;
   hash.hashval[4] = 0xc3d2e1f0;

} // End of SHA1_InitializeHash

//
// FUNCTION: SHA1_GetHash()
//
// PURPOSE: Produce a SHA1 hash of the pData.
//
//          returns 0 on success
//          returns 1 on failure
//
int AclHash::SHA1_GetHash(unsigned long DataSize,
                                    unsigned char *pData,
                                    unsigned char *pHashValue)
{
   union {
      char          letters[64];
      unsigned long numbers[16];
   } dat;

   unsigned int leftovers;
   char         paddata[64];
   unsigned int  i          = 0;
   unsigned int  arrayindex = 0;
   long          papoose    = 1; // flag for LITTLE ENDIAN, 
                                 // set if LITTLE ENDIAN
                                 //

   if ((!pData) || (!pHashValue))
      return (1);

   memset(paddata, 0, sizeof(paddata));
   paddata[0] = (char) (unsigned int)128;

   // run time check of LITTLE ENDIAN or BIG ENDIAN
   if(*(char *)&papoose != 1)
      papoose = 0;    // prosessor is BIG ENDIAN

   while ((arrayindex+64) <= DataSize)
   {
      memcpy(dat.letters, pData+arrayindex, BLOCK);

      if (papoose == 1)
      {
         // perform little endian byte swap, Intel processor thing
         for (i = 0; i < 16; i++)
         {
            SM_DoEndian(&(dat.numbers[i])); // swap bytes
         }
      }
      SHA1_SohHash(dat.numbers, (unsigned long *) hash.hashval);
      arrayindex += BLOCK;
      hash.total += 512;      // 512 bits processed
   } // end of while

   leftovers = DataSize - arrayindex;
   memcpy(dat.letters, pData+arrayindex, leftovers);
   memcpy(dat.letters+leftovers, paddata, BLOCK-leftovers);
   if(papoose == 1)
   {
       // perform little endian byte swap, Intel processor thing
       for (i = 0; i < 16; i++)
       {
          SM_DoEndian(&(dat.numbers[i])); // swap bytes
       }
   }

   if (leftovers >= 56)
   {
      SHA1_SohHash(dat.numbers, (unsigned long *) hash.hashval);
      memset(&dat.letters[0], 0, sizeof(dat)/*BLOCK*/);
   }

   hash.total += (8*leftovers);  // leftover bits < 512

   dat.numbers[15] = hash.total;

   SHA1_SohHash(dat.numbers, (unsigned long *) hash.hashval);

   // reset hash flags
   hash.initflag = 0;
   hash.total = 0;

   if(papoose == 1)  // if LITTLE ENDIAN, INTEL Processor thing
   {
       // perform little endian byte swap
       for (i = 0; i < 5; i++)
       {
          SM_DoEndian(&(hash.hashval[i])); // swap bytes
       }

   }
   memcpy(pHashValue, hash.hashval, SHA1_SIZE);

   return (0);
} // end of SHA1_GetHash()

//    Secure Hash Algorithm (SHA)
//
// Sha is an algorithm which produces a 160-bit output
// for any length message.  The purpose of a secure hash algorithm
// is to reduce the number of bits to which a signature algorithm
// must be applied, without affecting the security of the signature.
//
// Note: This implementation only accepts messages under 2^32 bits
// in length.  For messages of larger lengths we suggest that a
// multiple precision package be used to maintain the size of the
// message.
//
void AclHash::SHA1_SohHash( unsigned long *M, 
                           unsigned long *data)
{
   unsigned long temp,newa,newb,newc,newd,newe;
   unsigned long W0,W1,W2,W3,W4,W5,W6,W7,W8,W9,W10,W11,W12,W13,W14,W15;
   unsigned long W16,W17,W18,W19,W20,W21,W22,W23,W24,W25,W26,W27,W28,W29,W30,W31
;
   unsigned long W32,W33,W34,W35,W36,W37,W38,W39,W40,W41,W42,W43,W44,W45,W46,W47
;
   unsigned long W48,W49,W50,W51,W52,W53,W54,W55,W56,W57,W58,W59,W60,W61,W62,W63
;
   unsigned long W64,W65,W66,W67,W68,W69,W70,W71,W72,W73,W74,W75,W76,W77,W78,W79
;

   W0 = M[0];
   W1 = M[1];
   W2 = M[2];
   W3 = M[3];
   W4 = M[4];
   W5 = M[5];
   W6 = M[6];
   W7 = M[7];
   W8 = M[8];
   W9 = M[9];
   W10 = M[10];
   W10 = M[10];
   W11 = M[11];
   W12 = M[12];
   W13 = M[13];
   W14 = M[14];
   W15 = M[15];

        W16 = Ls1(W13 ^ W8 ^ W2 ^ W0);
        W17 = Ls1(W14 ^ W9 ^ W3 ^ W1);
        W18 = Ls1(W15 ^ W10 ^ W4 ^ W2);
        W19 = Ls1(W16 ^ W11 ^ W5 ^ W3);
        W20 = Ls1(W17 ^ W12 ^ W6 ^ W4);
        W21 = Ls1(W18 ^ W13 ^ W7 ^ W5);
        W22 = Ls1(W19 ^ W14 ^ W8 ^ W6);
        W23 = Ls1(W20 ^ W15 ^ W9 ^ W7);
        W24 = Ls1(W21 ^ W16 ^ W10 ^ W8);
        W25 = Ls1(W22 ^ W17 ^ W11 ^ W9);
        W26 = Ls1(W23 ^ W18 ^ W12 ^ W10);
        W27 = Ls1(W24 ^ W19 ^ W13 ^ W11);
        W28 = Ls1(W25 ^ W20 ^ W14 ^ W12);
        W29 = Ls1(W26 ^ W21 ^ W15 ^ W13);
        W30 = Ls1(W27 ^ W22 ^ W16 ^ W14);
        W31 = Ls1(W28 ^ W23 ^ W17 ^ W15);
        W32 = Ls1(W29 ^ W24 ^ W18 ^ W16);
        W33 = Ls1(W30 ^ W25 ^ W19 ^ W17);
        W34 = Ls1(W31 ^ W26 ^ W20 ^ W18);
        W35 = Ls1(W32 ^ W27 ^ W21 ^ W19);
        W36 = Ls1(W33 ^ W28 ^ W22 ^ W20);
        W37 = Ls1(W34 ^ W29 ^ W23 ^ W21);
        W38 = Ls1(W35 ^ W30 ^ W24 ^ W22);
        W39 = Ls1(W36 ^ W31 ^ W25 ^ W23);
        W40 = Ls1(W37 ^ W32 ^ W26 ^ W24);
        W41 = Ls1(W38 ^ W33 ^ W27 ^ W25);
        W42 = Ls1(W39 ^ W34 ^ W28 ^ W26);
        W43 = Ls1(W40 ^ W35 ^ W29 ^ W27);
        W44 = Ls1(W41 ^ W36 ^ W30 ^ W28);
        W45 = Ls1(W42 ^ W37 ^ W31 ^ W29);
        W46 = Ls1(W43 ^ W38 ^ W32 ^ W30);
        W47 = Ls1(W44 ^ W39 ^ W33 ^ W31);
        W48 = Ls1(W45 ^ W40 ^ W34 ^ W32);
        W49 = Ls1(W46 ^ W41 ^ W35 ^ W33);
        W50 = Ls1(W47 ^ W42 ^ W36 ^ W34);
        W51 = Ls1(W48 ^ W43 ^ W37 ^ W35);
        W52 = Ls1(W49 ^ W44 ^ W38 ^ W36);
        W53 = Ls1(W50 ^ W45 ^ W39 ^ W37);
        W54 = Ls1(W51 ^ W46 ^ W40 ^ W38);
        W55 = Ls1(W52 ^ W47 ^ W41 ^ W39);
        W56 = Ls1(W53 ^ W48 ^ W42 ^ W40);
        W57 = Ls1(W54 ^ W49 ^ W43 ^ W41);
        W58 = Ls1(W55 ^ W50 ^ W44 ^ W42);
        W59 = Ls1(W56 ^ W51 ^ W45 ^ W43);
        W60 = Ls1(W57 ^ W52 ^ W46 ^ W44);
        W61 = Ls1(W58 ^ W53 ^ W47 ^ W45);
        W62 = Ls1(W59 ^ W54 ^ W48 ^ W46);
        W63 = Ls1(W60 ^ W55 ^ W49 ^ W47);
        W64 = Ls1(W61 ^ W56 ^ W50 ^ W48);
        W65 = Ls1(W62 ^ W57 ^ W51 ^ W49);
        W66 = Ls1(W63 ^ W58 ^ W52 ^ W50);
        W67 = Ls1(W64 ^ W59 ^ W53 ^ W51);
        W68 = Ls1(W65 ^ W60 ^ W54 ^ W52);
        W69 = Ls1(W66 ^ W61 ^ W55 ^ W53);
        W70 = Ls1(W67 ^ W62 ^ W56 ^ W54);
        W71 = Ls1(W68 ^ W63 ^ W57 ^ W55);
        W72 = Ls1(W69 ^ W64 ^ W58 ^ W56);
        W73 = Ls1(W70 ^ W65 ^ W59 ^ W57);
        W74 = Ls1(W71 ^ W66 ^ W60 ^ W58);
        W75 = Ls1(W72 ^ W67 ^ W61 ^ W59);
        W76 = Ls1(W73 ^ W68 ^ W62 ^ W60);
        W77 = Ls1(W74 ^ W69 ^ W63 ^ W61);
        W78 = Ls1(W75 ^ W70 ^ W64 ^ W62);
        W79 = Ls1(W76 ^ W71 ^ W65 ^ W63);

   newa=data[0]; newb=data[1]; newc=data[2]; newd=data[3]; newe=data[4];

   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W0+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W1+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W2+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W3+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W4+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W5+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W6+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W7+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W8+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W9+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W10+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W11+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W12+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W13+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W14+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W15+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W16+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W17+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W18+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F0(newb,newc,newd)+newe+W19+K1;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;

   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W20+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W21+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W22+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W23+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W24+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W25+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W26+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W27+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W28+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W29+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W30+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W31+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W32+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W33+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W34+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W35+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W36+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W37+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W38+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W39+K2;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;

   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W40+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W41+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W42+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W43+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W44+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W45+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W46+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W47+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W48+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W49+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W50+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W51+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W52+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W53+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W54+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W55+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W56+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W57+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W58+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F1(newb,newc,newd)+newe+W59+K3;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;

   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W60+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W61+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W62+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W63+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W64+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W65+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W66+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W67+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W68+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W69+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W70+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W71+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W72+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W73+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W74+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W75+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W76+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W77+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W78+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;   newa = temp;
   temp = Ls5(newa)+F2(newb,newc,newd)+newe+W79+K4;
   newe = newd;   newd = newc;
   newc = Ls30(newb);
   newb = newa;

   data[0] += temp;
   data[1] += newb;
   data[2] += newc;
   data[3] += newd;
   data[4] += newe;
} // end of SohHash

// SM_DoEndian:
//
void SM_DoEndian(unsigned long *in_data)
{
   unsigned long temp_long = 0;
   int i = 0;

   //
   // Shift the word 16 bits
   //
   temp_long  = (in_data[i] << 16) | (in_data[i] >> 16);

   //
   // Include the sign bit for each byte in the word
   //
   in_data[i] = ((temp_long & 0xff00ff00L) >> 8) | ((temp_long & 0x00ff00ffL) << 8);
}

_END_NAMESPACE_ACL

// EOF aclhash.cpp

