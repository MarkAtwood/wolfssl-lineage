//////////////////////////////////////////////////////////////////////////////
// aclcacheable.cpp
// These routines support the Cacheable Class
// CONSTRUCTOR(s):
//   Cacheable()
// DESTRUCTOR:
//   ~Cacheable()
// MEMBER FUNCTIONS:
//   operator ==(Cacheable &that)
//   operator =(Cacheable &that)
//   validate(Session *pSession, PublicKeyInfo &pubKeyInfo)
//   isValid()
//   validate(Session *pSession, CSM_BufferLst *issuerPath)
//////////////////////////////////////////////////////////////////////////////

#include "acl_api.h"
#include "aclhash.h"
#include "cmapi.h"
#include "cmapi_cpp.h" // PIERCE check into using class pointers
#include "aclinternal.h"

using namespace CTIL;
_USING_NAMESPACE_SNACC
_BEGIN_NAMESPACE_ACL

// CONSTRUCTOR:
//
Cacheable::Cacheable(void)
{
   setType(UNKNOWN_ID);
   m_isValidFlag = NOT_VALID;

   // CATCH ALL default TTL
   // PIERCE: TDB make sure this gets reset based on
   //         ac_ttl and spif_ttl from Session when
   //         adding to cache.
   //
   // default m_ttl to 48 hours
//   AclSysTime defaultTTL(48);
   CML::ASN::Time defaultTTL(time(NULL) + 48*60*60);
   m_ttl = defaultTTL;
   m_hash.Clear();
} // END OF CONSTRUCTOR

// validate:
//
bool Cacheable::validate(Session *pSession, const PublicKeyInfo &pubKeyInfo)
{

   FUNC("Cacheable::validate");
   try
   {
       // IF this object has been validated or validation has been disable
       // return true
       if (this->isValid() || pSession->m_disable_validation == true)
       {
          return true;
       }
       else
       {
          // Retrieve object from cache.
          //
          Cacheable *pCache = pSession->getCacheable(*this);

          // If it was found in cache and it has been validated
          // set m_isValidFlag to VALID and return true.
          //
          if (pCache != NULL)
          {
             // IF cached item is valid set this object to valid
             //
             if (pCache->isValid())
             {
                this->m_isValidFlag = VALID;
                delete pCache;
                return true;
             }
             else if (pCache->m_isValidFlag == TTL_EXPIRED)
             {
                // IF cached item has expired remove it from cache.
                pSession->removeCache(*pCache);
             }
             delete pCache;
          }
       }

       // Check the validity of the object being validated
       //
       if (! checkValidity())
       {
          AclString errStr;
          errStr << "Object has Expired\n";
          getDescription(errStr);

          m_isValidFlag = NOT_VALID;
          pSession->removeCache(*this);

          throw ACL_EXCEPT(ACL_VAL_ERROR, errStr.str());
       }


       // Perform object specific validation logic
       // i.e. trust list check
       //
       vValidate(pSession, pubKeyInfo);

       // Finally verify signature on cacheable object.
       //
       CML::SignedAsnObj spifSignedObj(this->m_origObject);
       //CML::ValidatedKey validKey(pubKeyInfo);

       if (spifSignedObj.VerifySignature(pSession->getCMLHandle(), pubKeyInfo) 
          != CM_NO_ERROR)
       {
          throw ACL_EXCEPT(ACL_VAL_ERROR, "Invalid signature");
       }

       // Set state flag to valid
       //
       this->m_isValidFlag = VALID;

       // UpdateCache
       pSession->updateCache(*this);
   
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return true;

} // END OF MEMBER FUNCTION validate

// isValid:
//
bool Cacheable::isValid()
{
    isExpired();

    if (this->m_isValidFlag == VALID)
        return true;
    else
        return false;
} // END OF MEMBER FUNCTION isValid

// isExpired:
//
bool Cacheable::isExpired()
{
    CML::ASN::Time sysTime;

    if (sysTime > this->m_ttl )
    {
        this->m_isValidFlag = TTL_EXPIRED;
        return true;
    }
    return false;
} // END OF MEMBER FUNCTION isExpired

// FUNCTION: Validate()
// PURPOSE: Validates an ACL object and performs issuer path validation 
//          using the CML.
//
bool Cacheable::validate(Session *pSession, CSM_BufferLst *issuerPath)
{
   SearchBounds boundsFlag = CM_SEARCH_UNTIL_FOUND;
   CSM_Buffer tmpBuf;
   CertificationPath snaccTmpCP;
   PublicKeyInfo pubKeyInfo;
   CML::CertPath *pCertPath=NULL; // for building & validating CertificationPath
   short cml_status = 0;
   CML::ValidatedKey validKey;
   char errStr[ACL_STR_BUF_LEN];

   FUNC("Cacheable::validate");
   // INITIALIZATION
   errStr[0]='\0';
   try
   {
       // PARAMETER CHECKS
       if (pSession == NULL)
       {
          throw ACL_EXCEPT(ACL_NULL_POINTER, "Session parameter is NULL");
       }

       if (this->isValid() || pSession->m_disable_validation == true)
       {
          return true;
       }
       else
       {
          // Retrieve object from cache.
          //
          Cacheable *pCache = pSession->getCacheable(*this);

          // If it was found in cache and it has been validated
          // set m_isValidFlag to VALID and return true.
          //
          if (pCache != NULL)
          {
             // IF cached item is valid set this object to valid
             //
             if (pCache->isValid())
             {
                this->m_isValidFlag = VALID;
                delete pCache;
                return true;
             }
             else if (pCache->m_isValidFlag == TTL_EXPIRED)
             {
                // IF cached item has expired remove it from cache.
                pSession->removeCache(*pCache);
             }
             delete pCache;
          }
       }

       // USE OF THE CML IS REQUIRED FOR THIS VERSION OF validate()
       //
       if (! pSession->usingCML())
       {
           throw ACL_EXCEPT(ACL_VAL_ERROR,
              "CML is not enabled.\n\tCannot validate issuerPath");
       }

      // Build (if necessary) and validate the issuer path using the CML.
      //
      // IF issuerPath was not provided use the CML to retrieve it.
      //
      if (issuerPath == NULL)
      {
         CML::ASN::Bytes bytes;
         cmlGetIssuerCertBytes(pSession, bytes);
         pCertPath = new CML::CertPath(bytes, false);
      }
      else
      {
         // issuerPath was provided, convert it from
         // a CSM_BufferLst to a SNACC::CertificationPath
         //
         buildCertificationPath(issuerPath, snaccTmpCP);
         pCertPath = new CML::CertPath(snaccTmpCP);
      }

      cml_status = pCertPath->BuildAndValidate(pSession->getCMLHandle(), 
          boundsFlag, NULL, 0, &validKey);
      if ((cml_status != CM_NO_ERROR) && 
          (cml_status != CM_PATH_VALIDATION_ERROR))
      {
         AclString str;
         this->getDescription(str);
         sprintf(errStr, 
             "Error building/validating CertificationPath. CML Error (%d).\n\t%s",
             cml_status, str.str());
         throw ACL_EXCEPT(ACL_CML_ERROR, errStr);
      }
      // process any object specific CertificationPath validation rules.
      //
      this->vPathRules(pSession, pCertPath->base());
      acl::PublicKeyInfo aclPKI(validKey.pubKeyInfo());

      validate(pSession, aclPKI);
      delete pCertPath; 
      pCertPath = NULL; 
   }
   catch (SnaccException &e)
   {
      if (pCertPath)
      {
         delete pCertPath; 
         pCertPath = NULL; 
      }
      e.push(STACK_ENTRY);
      throw;
   }
   return true;

} // END OF MEMBER FUNCTION validate

// FUNCTION:: cmlGetIssuerCertBytes
//
// PURPOSE: Use the CML to build the issuer's CeritficationPath
//
void Cacheable::cmlGetIssuerCertBytes(Session *pSession,
                                 CML::ASN::Bytes &issuerCert)
{
   FUNC("Cacheable::cmlGetIssuerCertBytes");

   const char *pSnaccDNStr=NULL;
   PublicKeyInfo pubKeyInfo;
   EncCert_LL *certificateList=NULL;
   short cml_status = 0;
   SearchBounds boundsFlag = CM_SEARCH_UNTIL_FOUND;
   CertMatch_struct matchInfo;
   memset(&matchInfo, 0, sizeof(matchInfo));
   MatchInfo issuerInfo;
   Bytes_struct subKeyId;

   try
   {
       // init Bytes_struct
       memset(&subKeyId, 0, sizeof(Bytes_struct));

       this->getIssuerInfo(issuerInfo);

       const CML::ASN::DN *pIssuerDN = issuerInfo.getSubjectDN();
       const SNACC::AsnOcts *pSki = issuerInfo.getSubjectKeyId();

       if (pIssuerDN != NULL)
       {
          pSnaccDNStr =(const char *) *pIssuerDN;
      
          if (pSki != NULL)
          {
             subKeyId.data = (unsigned char *) pSki->c_ustr();
             subKeyId.num  = pSki->Len();
             matchInfo.sub_kmid = &subKeyId;
          }

          // Call CM_RequestCerts().  If multiple issuers are found then
          // throw an error.
          //
          cml_status =
             CM_RequestCerts(pSession->getCMLHandle(),
                 (char *)pSnaccDNStr, &matchInfo, boundsFlag,
                  &certificateList);

          if (cml_status != 0)
          {
             CM_FreeEncCertList(&certificateList); 
             char errStr[256];
             sprintf(errStr, "%s %s %d)", "Error retrieving issuer path",
                     "information\n\t(CML ERROR", cml_status);
             throw ACL_EXCEPT(ACL_CML_ERROR, &errStr[0]);
          }

          // IF multiple certificates were retrieved via the CML return an error
          // because there is no way to determine which one we should use.
          //
          if (certificateList->next != NULL)
          {
             // free certificateList
             CM_FreeEncCertList(&certificateList);

             throw ACL_EXCEPT(ACL_CML_ERROR,
                 "Multiple issuers return from CM_RequestCerts");
          }
      
          issuerCert.Set(certificateList->encCert.num,certificateList->encCert.data);

          CM_FreeEncCertList(&certificateList);

       }
       else
       {
          AclString os;
          os << "Couldn't find Issuer DN for:\n";
          this->getDescription(os);
          throw ACL_EXCEPT(ACL_VAL_ERROR, os.str()); 
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }

} // END OF MEMBER FUNCTION cmlGetIssuerPath

// FUNCTION: buildCertificationPath
// PURPOSE: Builds a SNACC::CertificationPath from a list of CSM_Buffers
//
void Cacheable::buildCertificationPath(CSM_BufferLst *issuerPath, CertificationPath &snaccTmpCP)
{
   FUNC("Cacheable::buildCertificationPath");

   CSM_Buffer tmpBuf;
   CSM_Buffer *pCurrCert = NULL;
   CertificatePair *pSNACCTmpCertPair = NULL;

   // The IssuerPath was provided by the application.  Construct a
   // CertificationPath from the buffers passed in.
   //
   try
   {
       issuerPath->SetCurrToFirst();
       // put first certificate into SNACC userCertificate
       if ((pCurrCert = issuerPath->Curr()) != NULL)
       {
          snaccTmpCP.userCertificate = new Certificate;
        
          try 
          {
             pCurrCert->Decode(*snaccTmpCP.userCertificate);
          }
          catch (...)
          {
             throw ACL_EXCEPT(ACL_DECODE_ERROR, "Error decoding Certificate");
          }
          issuerPath->GoNext();
       }

       // put remaining certificates into SNACC list of theCACertificates
       for (; (pCurrCert = issuerPath->Curr()) != NULL;
            issuerPath->GoNext())
       {
          if (snaccTmpCP.theCACertificates == NULL)
             snaccTmpCP.theCACertificates = new CertificationPathSeqOf;

          pSNACCTmpCertPair = snaccTmpCP.theCACertificates->Append();
          // forward used, reverse not being used inside of CertificatePair
          pSNACCTmpCertPair->forward = new Certificate;
        
          try 
          {
            pCurrCert->Decode(*pSNACCTmpCertPair->forward);
          }
          catch (...)
          {
             throw ACL_EXCEPT(ACL_DECODE_ERROR, "Error decoding Certificate");
          }
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
} // END OF MEMBER FUNCTION buildCertificationPath

// getHash:
//
CSM_Buffer & Cacheable::getHash(void)
{
   FUNC("Cacheable::getHash");
   AclHash sha1;

   try
   {
       if (m_hash.Length() < 1)
       {
          if (this->m_origObject.Length() < 1)
          {
             char errStr[256];
             sprintf(errStr, "Can not cache objects that%s",
                     "\n\tdo not originate from CSM_Buffer");
             throw ACL_EXCEPT(ACL_CACHE_ERROR, &errStr[0]);
          }
          sha1.doSha1(&this->m_origObject, &m_hash);
       }
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return m_hash;
} // END OF MEMBER FUNCTION getHash

// operator ==:
//
bool Cacheable::operator ==(Cacheable &that)
{
   return (this->m_hash == that.m_hash ? true : false);
} // END OF OPERATOR OVERLOAD ==

// operator =:
//
Cacheable & Cacheable::operator =(const Cacheable &that)
{
   this->m_hash = that.m_hash;
   this->m_isValidFlag = that.m_isValidFlag;
   this->m_origObject = that.m_origObject;
   this->m_ttl = that.m_ttl;
   return (*this);
} // END OF OPERATOR OVERLOAD =

_END_NAMESPACE_ACL

// EOF aclcacheable.cpp

