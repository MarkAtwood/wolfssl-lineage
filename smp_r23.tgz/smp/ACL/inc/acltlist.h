/* @(#) sm_tlist.h 1.8 11/5/98 14:09:46 */
_USING_NAMESPACE_SNACC
_BEGIN_NAMESPACE_ACL

template <class  V>
class  ACL_VList
{
public:
    unsigned long int count;
    struct SMListElmt
    {
        SMListElmt *next;
        SMListElmt *prev;
        V *elmt;
    } *first, *curr, *last;

    ACL_VList() { count = 0; first = curr = last = NULL; }
    ACL_VList(ACL_VList<V> &Vref)
    {
        count = 0;
        first = curr = last = NULL; *this = Vref;
    }
    ~ACL_VList();

    V *SetCurrElmt(unsigned long int index);
    unsigned long int GetCurrElmtIndex();
    V *SetCurrToFirst();
    V *SetCurrToLast();
    // reading member functions
    int CountL() const { return count; }

    V *FirstL() const { return count > 0 ? first->elmt : NULL; }
    V *LastL() const { return count > 0 ? last->elmt : NULL; }
    V *Curr() const { return curr ? curr->elmt : NULL; }
    V *NextL() const { return curr && curr->next ? curr->next->elmt : NULL; }
    V *PrevL() const { return curr && curr->prev ? curr->prev->elmt : NULL; }

    // routines that move the curr elmt
    V *GoNext() { if (curr) curr = curr->next; return Curr(); }
    V *GoPrev() { if (curr) curr = curr->prev; return Curr(); }

    SMListElmt * GetCurr(void) { return curr; }

    // write & alloc fcns - returns new elmt
    void AppendL(V *v); // add elmt to end of list
    void AppendL(ACL_VList<V> *list);

    // removing the current elmt from the list
    void RemoveCurrFromList();

};

template <class V>
V *ACL_VList<V>::SetCurrToFirst() 
{ 
   FUNC("SetCurrToFirst");
   try
   {
       if (this == NULL)
          throw ACL_EXCEPT(23, "ACL_VList this pointer NULL.");
       curr = first; 
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return Curr(); 
}

template <class V>
V *ACL_VList<V>::SetCurrToLast()  
{ 
   FUNC("SetCurrToLast");
   try
   {
       if (this == NULL)
          throw ACL_EXCEPT(23, "ACL_VList this pointer NULL.");
       curr = last; 
   }
   catch (SnaccException &e)
   {
      e.push(STACK_ENTRY);
      throw;
   }
   return Curr(); 
}

template <class V>
ACL_VList<V>::~ACL_VList()
{
   SetCurrToFirst();
   for (; Curr() != NULL; RemoveCurrFromList())
      ;
} // end of destructor

template <class V> V*
ACL_VList<V>::SetCurrElmt (unsigned long int index)
{
   unsigned long int i;
   curr = first;
   if (count)
      for (i = 0; (i < (count-1)) && (i < index); i++)
         curr = curr->next;
   return (Curr());
} // ACL_VList::SetCurrElmt

template <class V> unsigned long int
ACL_VList<V>::GetCurrElmtIndex()
{
   unsigned long int i;
   SMListElmt *tmp;
   if (curr != NULL)
   {
      for (i = 0, tmp = first; tmp != NULL; i++)
      {
         if (tmp == curr)
            return i;
         else
            tmp = tmp->next;
      }
   }
   return count;
} // ACL_VList::GetCurrElmtIndex

// add provided elmt to end of list
template <class V> void
ACL_VList<V>::AppendL(V* v)
{
   SMListElmt *newElmt;
   newElmt  = new SMListElmt;
   newElmt->elmt  = v;
   newElmt->next = NULL;
   if (last == NULL)
   {
      newElmt->prev = NULL;
      first = last  = newElmt;
   }
   else
   {
      newElmt->prev = last;
      last->next    = newElmt;
      last          = newElmt;
   }
   count++;
   curr = newElmt;
} // ACL_VList::Append

// append a list to this list
template <class V> void
ACL_VList<V>::AppendL(ACL_VList<V> *list)
{
   V *add;
   for (add = list->SetCurrToFirst(); add != NULL;
         add = list->GoNext())
      AppendL(add);
}

// remove current element from list if current element is not NULL 
// The new current element will be the next element.
// If the current element is the last element in the list
// the second but last element will become the new current element.
template <class V> void
ACL_VList<V>::RemoveCurrFromList()
{
   SMListElmt *del_elmt;

   if (curr != NULL)
   {
      del_elmt = curr;
      count--;

      if (count == 0)
         first = last = curr = NULL;
      else if (curr == first)
      {
         curr = first= first->next;
         first->prev = NULL;
      }
      else if (curr == last)
      {
         curr = last = last->prev;
         last->next = NULL;
      }
      else
      {
         curr->prev->next = curr->next;
         curr->next->prev = curr->prev;
         curr = curr->next;
      }

      delete del_elmt->elmt;
      delete del_elmt;
   }
}

// EOF aclvlist.h



_END_NAMESPACE_ACL

// EOF acltlist.cpp
