#include "asn-incl.h"

#ifdef WIN32
#pragma warning( disable : 4251 )
#pragma warning( disable : 4275 )
#endif
// SHA1 constants

#define SHA1_SIZE 20
#define MASK32    0xffffffff
#define BLOCK     64
#define K1        0x5a827999
#define K2        0x6ed9eba1
#define K3        0x8f1bbcdc
#define K4        0xca62c1d6

// End of SHA1 constants

// SHA1 macros


#define Ls5(num)  (((num)<<5)|((num)>>27))
#define Ls30(num) (((num)<<30)|((num)>>2))

#ifdef NO_ESHA
#define Ls1(num)  (num)
#else
#define Ls1(num)  (((num)<<1) | ((num)>>31)&1)
#endif

#define F0(x,y,z) ((z)^(x)&((y)^(z)))
#define F1(x,y,z) ((x)&((y)^(z))^((z)&(y)))
#define F2(x,y,z) ((x)^(y)^(z))

#define SM_COMMON_RC2_BLOCKSIZE    8
#define SM_COMMON_3DES_KEYLEN 24
#define SM_COMMON_3DES_IVLEN 8
#define SM_COMMON_3DES_BLOCKSIZE 8
#define SM_COMMON_RC2_KEYLEN 16         // byte count 128 bits 
#define SM_COMMON_RC2_BLOCKSIZE  8

// End of SHA1 macros

_BEGIN_NAMESPACE_ACL

extern void SM_DoEndian(unsigned long *); // byte swapper for LITTLE ENDIAN

class AclHash
{
public:
   int doSha1(CTIL::CSM_Buffer *pData, CTIL::CSM_Buffer *pHashValue);

private:
   int SHA1_GetHash(unsigned long  ,
                            unsigned char *,
                            unsigned char *);

   void SHA1_InitializeHash(void);

   typedef struct {
      unsigned long hashval[5];
      int           initflag;
      unsigned long total;
   } Hash_struct;

   Hash_struct hash;

       // private member functions
   void SHA1_SohHash(unsigned long *, unsigned long *);
};

_END_NAMESPACE_ACL

// EOF aclhash.h

