/****************************************************************************
File:     cmlasn_xml.h
Project:  Certificate Management ASN.1 Library
Contents: Header file for the X.509 Certificate Management ASN.1 Library
		  Contains xml class definitions used throughout the library

Created:  7 April 2003
Author:   Lisa Vracar <Lisa.Vracar@DigitalNet.com>

Last Updated:	20 August 2003

Version:  2.3

*****************************************************************************/
#ifndef _CMLASN_XML_H
#define _CMLASN_XML_H

#include <stack>


// Begin CML namespace
namespace CML {


// Begin nested ASN namespace
namespace ASN {


///////////////////////////////////
// PrintXML class definition //
///////////////////////////////////
class CM_API PrintXML
{
public:
	// Construct from a thread number and a file name
	PrintXML(int threadNum, std::ostream &os);  
	// Destructor
	virtual ~PrintXML(void);  

	void WriteBegin(const char *lpszTitle, int count,
		            const char *lpszName, const char *optString=NULL,
					const char *lpszName2=NULL, const SNACC::AsnInt sn = 0);
	void WriteSimpleBegin(const char *lpszTitle);

	void WriteData(const char *pszLog, const char *optString=NULL);
	void WriteData(const char *pszLog, float fNum);
	void WriteData(int iNum, const char *pszLog);
	void WriteData(const char *lpszName, const char *val,
				   const char *lpszName2, const SNACC::AsnInt sn,
				   const char *lpszName3=NULL, const char *optString=NULL);
	void WriteInfo(const char *pszLog, float fNum);

	void WriteEnd(const char *lpszTitle, int count = 0);

	int m_count0;
	int m_count1;
	int m_count2;
	int m_count3;
	std::stack<int> m_countQueue;

private:
	int m_threadNum;
	PrintXML& operator = (const PrintXML& ) {return *this;}

protected:
	std::ostream &m_os;

};

} // end of nested ASN namespace

} // end of CML namespace


#endif // _CMLASN_XML_H
