/*****************************************************************************
File:     Exception.cpp
Project:  Certificate Management ASN.1 Library
Contents: Implementation of the Exception class

Created:  10 September 2001
Author:   Rich Nicholas <Richard.Nicholas@GetronicsGov.com>

Last Updated:	10 December 2002

Version:  2.2

*****************************************************************************/


////////////////////
// Included Files //
////////////////////
#include "cmlasn_internal.h"


// Using CML::ASN namespace
using namespace CML::ASN;



////////////////////////////////////
// Exception class implementation //
////////////////////////////////////
Exception::Exception(Error code, const char* fileName, long lineNum,
					 const char* errString) :
SNACC::SnaccException(fileName, lineNum, NULL, errString)
{
	error = code;
}


Exception::operator short() const
{
	switch (error)
	{
	case CML::ASN::SnaccError:
		return short(DecodeError);
	default:
		return short(error);
	}
}


//////////////////////////////////////////
// ExceptionString class implementation //
//////////////////////////////////////////
ExceptionString::ExceptionString(Error code, const char* fileName,
								 long lineNum, const char* errString1,
								 const char* errString2) :
Exception(code, fileName, lineNum)
{
	size_t totalLen = 1;
	if (errString1 != NULL)
		totalLen += strlen(errString1);
	if (errString2 != NULL)
		totalLen += strlen(errString2);

	m_errString = new char[totalLen];
	if (m_errString != NULL)
	{
		m_errString[0] = '\0';
		if (errString1 != NULL)
			strcat(m_errString, errString1);
		if (errString2 != NULL)
			strcat(m_errString, errString2);
	}

	m_whatStr = m_errString;
}


ExceptionString::ExceptionString(const ExceptionString& that) :
Exception(that)
{
	m_errString = NULL;
	operator=(that);
}


ExceptionString& ExceptionString::operator=(const ExceptionString& other)
{
	if (this != &other)
	{
		if (m_errString != NULL)
		{
			delete[] m_errString;
			m_errString = NULL;
		}
		
		if (other.m_errString != NULL)
		{
			m_errString = new char[strlen(other.m_errString) + 1];
			if (m_errString != NULL)
				strcpy(m_errString, other.m_errString);
		}
	}
	return *this;
}



// end of Exception.cpp
