/*****************************************************************************
File:     CM_Certificate.cpp
Project:  Certificate Management ASN.1 Library
Contents: Implementation of the Certificate, PublicKeyInfo, Validity, AlgID,
		  and Time classes and the CM_DecodeCert function.

Created:  20 March 2001
Author:   Rich Nicholas <Richard.Nicholas@DigitalNet.com>

Last Updated:	1 October 2003

Version:  2.3

*****************************************************************************/


////////////////////
// Included Files //
////////////////////
#ifdef WIN32
	#pragma warning(disable: 4710)	// Disable function not inlined warning
	#pragma warning(push, 3)		// Save and set warning level to 3
	#include <fstream>				// Needed for ifstream
	#pragma warning(pop)			// Restore warning level
#else
	#include <fstream>				// Needed for ifstream
#endif
#include <sys/types.h>				// Needed for stat()
#include <sys/stat.h>				// Needed for stat()

#include "cmlasn_internal.h"

// Using CML::ASN namespace
using namespace CML::ASN;


/////////////////////////
// Function Prototypes //
/////////////////////////
static Error time2CMTime(time_t t, char* cmTime);
static void hashBuffer(uchar* pData, ulong dataSize, ulong* hash);
static void sha_init(ulong hash[]);
static void sha_hash(ulong M[], ulong hash[]);
static bool isLittleEndian(void);
static Pqg_params_struct* cvtDSAParameters(const SNACC::DSAWithSHA1Parameters& params);
static ulong cvtFortezzaMultiByte(Bytes_struct& bytes, const uchar* data,
								  const uchar* dataEnd);
static Pqg_params_struct* cvtFortezzaParams(const SNACC::Common_Parms& params);
static void cvtFortezzaPubKey(Pub_key_struct& cmPubKey,
							  const CTIL::CSM_Buffer& keyBuf);
static void cvtOctsToExistingBytes(Bytes_struct& bytes,
								   const SNACC::AsnOcts& octs);
static RSAPublicKey_struct* cvtRSAPublicKey(const SNACC::RSAPublicKey& rsaKey);
static CTIL::CSM_Buffer* encodeAnyInCSMBuffer(const SNACC::AsnAny& snacc,
											  const char* anyName);



////////////////////////////
// CM_DecodeCert function //
////////////////////////////
short CM_DecodeCert(Bytes_struct* encodedCert, Cert_struct **decCert)
{
	// Check parameters
	if ((encodedCert == NULL) || (encodedCert->data == NULL) ||
		(decCert == NULL))
		return CMLASN_INVALID_PARAMETER;

	try {
		// Initialize result
		*decCert = NULL;

		// Construct a temporary Bytes object
		Bytes asnData(encodedCert->num, encodedCert->data);

		// Decode and convert the certificate
		Cert tmpCert(asnData);
		*decCert = tmpCert.GetCertStruct();

		return CMLASN_SUCCESS;
	}
	catch (Exception& err) {
		return err;
	}
	catch (SNACC::SnaccException& ) {
		return CMLASN_DECODE_ERROR;
	}
	catch (...) {
		return CMLASN_UNKNOWN_ERROR;
	}
}


///////////////////////////////
// Cert class implementation //
///////////////////////////////
Cert::Cert()
{
	// Initialize default version
	version = SNACC::Version::v1;

	// Initialize pointers and private m_versionPresent
	pIssuerUniqueID = NULL;
	pSubjectUniqueID = NULL;
	m_versionPresent = false;
}


Cert::Cert(const SNACC::Certificate& snacc)
{
	// Initialize pointers
	pIssuerUniqueID = NULL;
	pSubjectUniqueID = NULL;

	operator=(snacc);
}


Cert::Cert(const Bytes& asn)
{
	// Initialize pointers
	pIssuerUniqueID = NULL;
	pSubjectUniqueID = NULL;

	operator=(asn);
}


Cert::Cert(const Cert& that)
{
	// Initialize pointers
	pIssuerUniqueID = NULL;
	pSubjectUniqueID = NULL;

	operator=(that);
}


Cert& Cert::operator=(const SNACC::Certificate& snacc)
{
	// Delete existing values in member variables
	Clear();

	try {
		if (snacc.toBeSigned == NULL)
			throw ASN_EXCEPTION("SNACC::Certificate::toBeSigned field is NULL");
		
		// Set the version if present
		if (snacc.toBeSigned->version != NULL)
		{
			version = *snacc.toBeSigned->version;
			m_versionPresent = true;
		}
		
		// Set the serial number and signature algorithm ID
		serialNumber = snacc.toBeSigned->serialNumber;
		if (snacc.toBeSigned->signature == NULL)
			throw ASN_EXCEPTION("SNACC::Certificate::toBeSigned->signature field is NULL");
		signature = *snacc.toBeSigned->signature;
		
		// Set the issuer and subject distinguished names
		if (snacc.toBeSigned->issuer == NULL)
			throw ASN_EXCEPTION("SNACC::Certificate::toBeSigned->issuer field is NULL");
		if (snacc.toBeSigned->subject == NULL)
			throw ASN_EXCEPTION("SNACC::Certificate::toBeSigned->subject field is NULL");
		issuer = *snacc.toBeSigned->issuer;
		subject = *snacc.toBeSigned->subject;
		
		// Set the validity dates
		if (snacc.toBeSigned->validity == NULL)
			throw ASN_EXCEPTION("SNACC::Certificate::toBeSigned->validity field is NULL");
		validity = *snacc.toBeSigned->validity;
		
		// Set the public key info
		if (snacc.toBeSigned->subjectPublicKeyInfo == NULL)
			throw ASN_EXCEPTION("SNACC::Certificate::toBeSigned->subjectPublicKeyInfo field is NULL");
		pubKeyInfo = *snacc.toBeSigned->subjectPublicKeyInfo;
		
		// Set the issuer and subject unique IDs (if present)
		if (snacc.toBeSigned->issuerUniqueIdentifier != NULL)
		{
			pIssuerUniqueID = new
				SNACC::UniqueIdentifier(*snacc.toBeSigned->issuerUniqueIdentifier);
			if (pIssuerUniqueID == NULL)
				throw MEMORY_EXCEPTION;
		}
		if (snacc.toBeSigned->subjectUniqueIdentifier != NULL)
		{
			pSubjectUniqueID = new 
				SNACC::UniqueIdentifier(*snacc.toBeSigned->subjectUniqueIdentifier);
			if (pSubjectUniqueID == NULL)
				throw MEMORY_EXCEPTION;
		}
		
		// Set the extensions (if present)
		if (snacc.toBeSigned->extensions != NULL)
			exts = *snacc.toBeSigned->extensions;
		
		// Set the outer signature algorithm ID and signature value
		if (snacc.algorithm == NULL)
			throw ASN_EXCEPTION("SNACC::Certificate::algorithm field is NULL");
		algorithm = *snacc.algorithm;
		sigValue.Set(snacc.signature.data(), snacc.signature.length());

		
		return *this;
	}
	catch (SNACC::SnaccException& e) {
		e.push(__FILE__, __LINE__, "CML::ASN::Cert::operator=");
		throw;
	}
}


Cert& Cert::operator=(const Bytes& asn)
{
	Decode(asn);
	return *this;
}


Cert& Cert::operator=(const Cert& other)
{
	if (this != &other)
	{
		// Delete existing values in member variables
		Clear();

		version = other.version;
		m_versionPresent = other.m_versionPresent;
		serialNumber = other.serialNumber;
		signature = other.signature;
		issuer = other.issuer;
		validity = other.validity;
		subject = other.subject;
		pubKeyInfo = other.pubKeyInfo;
			
		if (other.pIssuerUniqueID != NULL)
		{
			pIssuerUniqueID = new
				SNACC::UniqueIdentifier(*other.pIssuerUniqueID);
			if (pIssuerUniqueID == NULL)
				throw MEMORY_EXCEPTION;
		}
		if (other.pSubjectUniqueID != NULL)
		{
			pSubjectUniqueID = new
				SNACC::UniqueIdentifier(*other.pSubjectUniqueID);
			if (pSubjectUniqueID == NULL)
				throw MEMORY_EXCEPTION;
		}
			
		exts = other.exts;
		algorithm = other.algorithm;
		sigValue = other.sigValue;
	}
	return *this;
}


/*bool Cert::operator==(const Cert& rhs)
{
	if (this == &rhs)
		return true;

	if (version != rhs.version)
		return false;
	if (m_versionPresent != rhs.m_versionPresent)
		return false;
	if (serialNumber != rhs.serialNumber)
		return false;
	if (signature != rhs.signature)
		return false;
	if (issuer != rhs.issuer)
		return false;
	if (validity != rhs.validity)
		return false;
	if (subject != rhs.subject)
		return false;
	if (pubKeyInfo != rhs.pubKeyInfo)
		return false;

	if (CMU_CompareUniqueIDs(pIssuerUniqueID, rhs.pIssuerUniqueID) == false)
		return false;
	if (CMU_CompareUniqueIDs(pSubjectUniqueID, rhs.pSubjectUniqueID) == false)
		return false;

	if (extensions != rhs.extensions)
		return false;
	if (algorithm != rhs.algorithm)
		return false;
	if (sigValue != (CTIL::CSM_Buffer&)rhs.sigValue)
		return false;

	return true;
}
*/

void Cert::Clear(void)
{
	version = SNACC::Version::v1;
	m_versionPresent = false;
	serialNumber = 0;
	signature.Clear();
	issuer = NULL;
	subject = NULL;
	pubKeyInfo.Clear();
	if (pIssuerUniqueID != NULL)
	{
		delete pIssuerUniqueID;
		pIssuerUniqueID = NULL;
	}
	if (pSubjectUniqueID != NULL)
	{
		delete pSubjectUniqueID;
		pSubjectUniqueID = NULL;
	}
	exts.Clear();
	algorithm.Clear();
	sigValue.Set(NULL, 0);
} // end of Cert::Clear()


ulong Cert::Decode(const Bytes& asn)
{
	// Delete existing values in member variables
	Clear();

	// Decode the cert
	SNACC::Certificate cert;
	SNACC::AsnLen nBytesDecoded = asn.Decode(cert, "SNACC::Certificate");

	// Assign this cert to the newly decoded cert
	operator=(cert);

	return nBytesDecoded;
} // end of Cert::Decode()


ulong Cert::Encode(Bytes& asn) const
{
	// Initialize pointer variables
	SNACC::Certificate* pCert = NULL;
	try {
		// Create the AsnBuffer
		SNACC::AsnBuf asnBuf;
		ulong numEncoded = 0;

		// Get the SNACC form of this certificate
		pCert = GetSnacc();
		
		// Encode the certificate
		try {
			numEncoded = pCert->BEnc(asnBuf);
		}
		catch (SNACC::SnaccException& ) {
			throw ASN_EXCEPTION("Error encoding SNACC::Certificate");
		}

		// Reset the AsnBuf in read mode
		asnBuf.ResetMode(std::ios_base::in);

		// Set the encoded cert into the asn parameter
		asn.Set(asnBuf, numEncoded);

		// Delete the temporary variable
		delete pCert;
		
		return numEncoded;
	}
	catch (...) {
		if (pCert != NULL)
			delete pCert;
		throw;
	}
} // end of Cert::Encode()


bool Cert::IsSelfIssued() const
{
	// Compare the subject and issuer DNs
	if (issuer != subject)
		return false;

	// Compare the subject and issuer unique identifiers (if present)
	if ((pIssuerUniqueID != NULL) && (pSubjectUniqueID != NULL))
	{
		if (*pIssuerUniqueID != *pSubjectUniqueID)
			return false;
	}
	else if (pIssuerUniqueID != NULL)
		return false;
	else if (pSubjectUniqueID != NULL)
		return false;
	// else both absent

	// Return false if the alternative names are required, but missing
	if (issuer.IsEmpty() && (exts.pIssuerAltNames == NULL))
		return false;
	if (subject.IsEmpty() && (exts.pSubjAltNames == NULL))
		return false;

	// Compare the subject and issuer alternative names (if both present)
	if ((exts.pIssuerAltNames == NULL) || (exts.pSubjAltNames == NULL))
		return true;
	else
		return exts.pIssuerAltNames->IsOnePresent(*exts.pSubjAltNames);
}


SNACC::Certificate* Cert::GetSnacc() const
{
	SNACC::Certificate* pCert = NULL;
	try {
		// Create the new SNACC::Certificate
		pCert = new SNACC::Certificate;
		if (pCert == NULL)
			throw MEMORY_EXCEPTION;
		
		// Initialize algorithm pointer
		pCert->algorithm = NULL;
		
		// Create the toBeSigned element
		pCert->toBeSigned = new SNACC::CertificateToBeSigned;
		if (pCert->toBeSigned == NULL)
			throw MEMORY_EXCEPTION;
		
		// Initialize the pointers
		pCert->toBeSigned->version = NULL;
		pCert->toBeSigned->signature = NULL;
		pCert->toBeSigned->issuer = NULL;
		pCert->toBeSigned->validity = NULL;
		pCert->toBeSigned->subject = NULL;
		pCert->toBeSigned->subjectPublicKeyInfo = NULL;
		pCert->toBeSigned->issuerUniqueIdentifier = NULL;
		pCert->toBeSigned->subjectUniqueIdentifier = NULL;
		pCert->toBeSigned->extensions = NULL;
		
		// Get the SNACC form of the version (if necessary)
		if (m_versionPresent || (version != 0))
		{
			pCert->toBeSigned->version = new SNACC::Version(version);
			if (pCert->toBeSigned->version == NULL)
				throw MEMORY_EXCEPTION;
		}
		
		// Set the SNACC serial number
		pCert->toBeSigned->serialNumber = serialNumber;
		// Get the SNACC form of the signature AlgID
		pCert->toBeSigned->signature = signature.GetSnacc();
		
		// Get the SNACC form of the issuer and subject DNs
		pCert->toBeSigned->issuer = issuer.GetSnacc();
		pCert->toBeSigned->subject = subject.GetSnacc();
		
		// Get the SNACC form of the validity period
		pCert->toBeSigned->validity = validity.GetSnacc();
		
		// Get the SNACC form of the SubjectPublicKeyInfo
		pCert->toBeSigned->subjectPublicKeyInfo = pubKeyInfo.GetSnacc();
		
		// Copy the issuer and subject unique identifiers if present
		if (pIssuerUniqueID != NULL)
		{
			pCert->toBeSigned->issuerUniqueIdentifier = 
				new SNACC::UniqueIdentifier(*pIssuerUniqueID);
			if (pCert->toBeSigned->issuerUniqueIdentifier == NULL)
				throw MEMORY_EXCEPTION;
		}
		if (pSubjectUniqueID != NULL)
		{
			pCert->toBeSigned->subjectUniqueIdentifier =
				new SNACC::UniqueIdentifier(*pSubjectUniqueID);
			if (pCert->toBeSigned->subjectUniqueIdentifier == NULL)
				throw MEMORY_EXCEPTION;
		}
		
		// Get the SNACC form of the extensions
		pCert->toBeSigned->extensions = exts.GetSnacc();
		
		// Get the SNACC form of the outer signature AlgID and value
		pCert->algorithm = algorithm.GetSnacc();
		pCert->signature.Set(sigValue.Access(), sigValue.Length() * 8);
		
		// Return result
		return pCert;
	}
	catch (...) {
		if (pCert != NULL)
			delete pCert;
		throw;
	}
} // end of Cert::GetSnacc()


// Get the C form of this certificate
Cert_struct* Cert::GetCertStruct() const
{
	Cert_struct* pCert = (Cert_struct*)calloc(1, sizeof(Cert_struct));
	if (pCert == NULL)
		throw MEMORY_EXCEPTION;

	try {
		pCert->version = short(version + 1);
		Internal::CvtAsnIntToExistingBytes(pCert->serial_num, serialNumber);
		pCert->signature = signature.algorithm.GetChar();

		pCert->issuer = strdup(issuer);
		if (pCert->issuer == NULL)
			throw MEMORY_EXCEPTION;

		strcpy(pCert->val_not_before, validity.notBefore);
		strcpy(pCert->val_not_after, validity.notAfter);

		pCert->subject = strdup(subject);
		if (pCert->subject == NULL)
			throw MEMORY_EXCEPTION;

		pubKeyInfo.FillPubKeyStruct(pCert->pub_key);

		if (pIssuerUniqueID != NULL)
			pCert->issuer_id = Internal::CvtBitsToBytes(*pIssuerUniqueID);
		if (pSubjectUniqueID != NULL)
			pCert->subj_id = Internal::CvtBitsToBytes(*pSubjectUniqueID);

		pCert->exts = exts.GetCertExtsStruct();

		pCert->sig.alg = algorithm.algorithm.GetChar();
		Internal::CvtBufferToSigStruct(pCert->sig, sigValue);

		return pCert;
	}
	catch (...) {
		CM_FreeCert(&pCert);
		throw;
	}
}


////////////////////////////////////////
// PublicKeyInfo class implementation //
////////////////////////////////////////
PublicKeyInfo& PublicKeyInfo::operator=(const SNACC::SubjectPublicKeyInfo& snaccPK)
{
	if (snaccPK.algorithm == NULL)
		throw ASN_EXCEPTION("SNACC::SubjectPublicKeyInfo::algorithm field is NULL");

	algorithm = *snaccPK.algorithm;
	key.Set(snaccPK.subjectPublicKey.data(), snaccPK.subjectPublicKey.length());
	return *this;
}


bool PublicKeyInfo::operator==(const PublicKeyInfo& rhs) const
{
	if (this == &rhs)
		return true;

	if (algorithm != rhs.algorithm)
		return false;
	return (key == rhs.key);
}


void PublicKeyInfo::Clear()
{
	algorithm.Clear();
	key.Set(NULL, 0);
}


SNACC::SubjectPublicKeyInfo* PublicKeyInfo::GetSnacc() const
{
	SNACC::SubjectPublicKeyInfo* pResult = NULL;
	try {
		pResult = new SNACC::SubjectPublicKeyInfo();
		if (pResult == NULL)
			throw MEMORY_EXCEPTION;
		
		pResult->algorithm = algorithm.GetSnacc();
		pResult->subjectPublicKey.Set(key.Access(), key.Length() * 8);
		return pResult;
	}
	catch (...) {
		if (pResult != NULL)
			delete pResult;
		throw;
	}
}


// Fill in the C form of the SubjectPublicKeyInfo
void PublicKeyInfo::FillPubKeyStruct(Pub_key_struct& pubKey) const
{
	// Initialize Pub_key_struct
	pubKey.oid = NULL;
	pubKey.params.dsa = NULL;
	pubKey.key.y = NULL;

	try {
		pubKey.oid = algorithm.algorithm.GetChar();
		
		if ((algorithm == gKEA_OID) || (algorithm == gEC_KEY_OID))
		{
			// Copy the KEA, ECDSA, or ECDH key to a Bytes_struct
			pubKey.key.y = Internal::CvtBufferToBytes(key);
		}
		else if ((algorithm == gOLD_DH_OID) || (algorithm == gANSI_DH_OID))
		{
			// Decode the DH public key
			SNACC::DHPublicKey dhPubKey;
			try {
				key.Decode(dhPubKey);
			}
			catch (...) {
				throw ASN_EXCEPTION("Error decoding Diffie-Hellman public key");
			}

			// Convert the huge integer to a Bytes_struct
			pubKey.key.y = Internal::CvtAsnIntToBytes(dhPubKey, 8);
		}
		else if ((algorithm == gDSA_OID) || (algorithm == gOIW_DSA))
		{
			// Decode the DSA public key
			SNACC::DsaPublicKey dsaPubKey;
			try {
				key.Decode(dsaPubKey);
			}
			catch (...) {
				throw ASN_EXCEPTION("Error decoding DSA public key");
			}

			// Copy the huge integer to a Bytes_struct
			pubKey.key.y = Internal::CvtAsnIntToBytes(dsaPubKey, 8);
		}
		else if (algorithm == gRSA_OID)
		{
			// Decode the RSA public key
			SNACC::RSAPublicKey rsaPubKey;
			try {
				key.Decode(rsaPubKey);
			}
			catch (...) {
				throw ASN_EXCEPTION("Error decoding RSA public key");
			}

			// Convert the RSA public key into an RSAPublicKey_struct
			pubKey.key.rsa = cvtRSAPublicKey(rsaPubKey);
		}
		else if (algorithm == gDSA_KEA_OID)
		{
			// Decode the Fortezza public key
			cvtFortezzaPubKey(pubKey, key);
		}
		else
		{
			throw EXCEPTION_STR(NotImplemented,
				"Unsupported public-key algorithm");
		}

		Internal::FillParameters(pubKey, algorithm);
	}
	catch (...) {
		CMASN_FreePubKeyContents(&pubKey);
		throw;
	}
} // end of PublicKeyInfo::FillPubKeyStruct()


// Get the C form of the SubjectPublicKeyInfo
Pub_key_struct* PublicKeyInfo::GetPubKeyStruct() const
{
	Pub_key_struct* result = (Pub_key_struct*)malloc(sizeof(Pub_key_struct));
	if (result == NULL)
		throw MEMORY_EXCEPTION;

	try {
		FillPubKeyStruct(*result);
		return result;
	}
	catch (...) {
		CMASN_FreePubKeyContents(result);
		free(result);
		throw;
	}
}


///////////////////////////////////
// Validity class implementation //
///////////////////////////////////
Validity::Validity(ushort numYears)
{
	// Create a temporary CM_Time from the current time
	CM_Time tempTime;
	strcpy(tempTime, notBefore);

	// Adjust each of the year digits
	for (short i = 3; (i >= 0) && (numYears > 0); i--)
	{
		tempTime[i] = char(tempTime[i] + (numYears % 10));
		numYears = short(numYears / 10);

		if (tempTime[i] > '9')
		{
			tempTime[i] = char(tempTime[i] - 10);
			numYears++;
		}
	}

	// Check that temp CM_Time does not fall on invalid leap day
	if ((strncmp(&tempTime[4], "0229", 4) == 0) && (numYears % 4 != 0))
	{
		// If it does, change the date to Feb 28th
		tempTime[7] = '8';
	}

	// Throw an error if overflow occurred (result > "9999")
	if (numYears != 0)
		throw Exception(InvalidParameter, __FILE__, __LINE__);

	// Set the notAfter time to the adjusted value
	notAfter = tempTime;
}


Validity::Validity(const SNACC::Validity& snacc)
{
	if (snacc.notBefore == NULL)
		throw ASN_EXCEPTION("SNACC::Validity::notBefore field is NULL");
	if (snacc.notAfter == NULL)
		throw ASN_EXCEPTION("SNACC::Validity::notAfter field is NULL");

	notBefore = *snacc.notBefore;
	notAfter = *snacc.notAfter;
}


Validity::Validity(const SNACC::AttCertValidityPeriod& snacc) :
notBefore(snacc.notBeforeTime), notAfter(snacc.notAfterTime)
{
}


Validity::Validity(const Time& begin, const Time& end) :
notBefore(begin), notAfter(end)
{
}


bool Validity::operator==(const Validity& rhs) const
{
	if (this == &rhs)
		return true;

	return ((notBefore == rhs.notBefore) && (notAfter == rhs.notAfter));
}


SNACC::Validity* Validity::GetSnacc() const
{
	SNACC::Validity* pResult = NULL;
	try {
		pResult = new SNACC::Validity();
		if (pResult == NULL)
			throw MEMORY_EXCEPTION;
		pResult->notBefore = notBefore.GetSnacc();
		pResult->notAfter = notAfter.GetSnacc();

		return pResult;
	}
	catch (...) {
		delete pResult;
		throw;
	}
}


SNACC::AttCertValidityPeriod* Validity::GetAttCertValidity() const
{
	SNACC::AttCertValidityPeriod* pResult = NULL;
	try {
		pResult = new SNACC::AttCertValidityPeriod();
		if (pResult == NULL)
			throw MEMORY_EXCEPTION;

		notBefore.FillSnaccGenTime(pResult->notBeforeTime);
		notAfter.FillSnaccGenTime(pResult->notAfterTime);

		return pResult;
	}
	catch (...) {
		delete pResult;
		throw;
	}
}


bool Validity::IsValid() const
{
	Time curTime;
	return IsValid(curTime);
}


bool Validity::IsValid(const Time& time) const
{
	return ((time >= notBefore) && (time <= notAfter));
}


////////////////////////////////
// AlgID class implementation //
////////////////////////////////
AlgID::AlgID(const SNACC::AlgorithmIdentifier& snacc)
{
	parameters = NULL;
	operator=(snacc);
}


AlgID::AlgID(const SNACC::AsnOid& oid, const CTIL::CSM_Buffer* pParams) :
algorithm(oid)
{
	if (pParams == NULL)
		parameters = NULL;
	else
	{
		parameters = new CTIL::CSM_Buffer(*(CTIL::CSM_Buffer*)pParams);
		if (parameters == NULL)
			throw MEMORY_EXCEPTION;
	}
}


AlgID::AlgID(const AlgID& that)
{
	parameters = NULL;
	operator=(that);
}


AlgID& AlgID::operator=(const SNACC::AlgorithmIdentifier& snacc)
{
	Clear();
	algorithm = snacc.algorithm;
	if (snacc.parameters != NULL)
	{
		parameters = encodeAnyInCSMBuffer(*snacc.parameters,
			"SNACC::AlgorithmIdentifier::parameters");
	}
	return *this;
}


AlgID& AlgID::operator=(const SNACC::AsnOid& oid)
{
	Clear();
	algorithm = oid;
	return *this;
}


AlgID& AlgID::operator=(const AlgID& other)
{
	if (this != &other)
	{
		Clear();
		algorithm = other.algorithm;
		if (other.parameters != NULL)
		{
			parameters = new CTIL::CSM_Buffer(*other.parameters);
			if (parameters == NULL)
				throw MEMORY_EXCEPTION;
		}
	}

	return *this;
}


bool AlgID::operator==(const AlgID& rhs) const
{
	if (this == &rhs)
		return true;

	if (algorithm != rhs.algorithm)
		return false;

	if ((parameters == NULL) && (rhs.parameters == NULL))
		return true;
	else if ((parameters == NULL) || (rhs.parameters == NULL))
		return false;
	else
		return (*parameters == *rhs.parameters);
}


void AlgID::Clear()
{
	if (parameters != NULL)
	{
		delete parameters;
		parameters = NULL;
	}
}


SNACC::AlgorithmIdentifier* AlgID::GetSnacc() const
{
	SNACC::AlgorithmIdentifier* pResult = NULL;

	try {
		pResult = new SNACC::AlgorithmIdentifier();
		if (pResult == NULL)
			throw MEMORY_EXCEPTION;

		pResult->algorithm = algorithm;
		
		if (parameters != NULL)
		{
			pResult->parameters = new SNACC::AsnAnyDefinedBy();
			if (pResult->parameters == NULL)
				throw MEMORY_EXCEPTION;
			
			pResult->parameters->anyBuf = new SNACC::AsnBuf(parameters->Access(),
				parameters->Length());
			if (pResult->parameters->anyBuf == NULL)
				throw MEMORY_EXCEPTION;
		}
		return pResult;
	}
	catch (...) {
		delete pResult;
		throw;
	}
}


///////////////////////////////
// Time class implementation //
///////////////////////////////
Time::Time(time_t timeVal)
{
	m_snaccTime.choiceId = SNACC::Time::utcTimeCid;
	m_snaccTime.utcTime = NULL;
	operator=(timeVal);
}


Time::Time(const SNACC::Time& snacc)
{
	m_snaccTime.choiceId = SNACC::Time::utcTimeCid;
	m_snaccTime.utcTime = NULL;
	operator=(snacc);
}


Time::Time(const SNACC::GeneralizedTime& snacc)
{
	try {
		m_snaccTime.choiceId = SNACC::Time::generalizedTimeCid;
		m_snaccTime.generalizedTime = new SNACC::GeneralizedTime(snacc);
		if (m_snaccTime.generalizedTime == NULL)
			throw MEMORY_EXCEPTION;

		cvtGenTime2CM_Time(*m_snaccTime.generalizedTime);
	}
	catch (...) {
		if (m_snaccTime.generalizedTime != NULL)
			delete m_snaccTime.generalizedTime;
		throw;
	}
}


Time::Time(const CM_Time& cmTime)
{
	m_snaccTime.choiceId = SNACC::Time::utcTimeCid;
	m_snaccTime.utcTime = NULL;
	operator=(cmTime);
}


Time::Time(const Time& that)
{
	m_snaccTime.choiceId = SNACC::Time::utcTimeCid;
	m_snaccTime.utcTime = NULL;
	operator=(that);
}


Time& Time::operator=(const SNACC::Time& snacc)
{
	m_snaccTime = snacc;
	if (m_snaccTime.utcTime == NULL)
		throw ASN_EXCEPTION("SNACC::Time::utcTime field is NULL");

	if (m_snaccTime.choiceId == SNACC::Time::utcTimeCid)
		cvtUTC2CM_Time(*m_snaccTime.utcTime);
	else
		cvtGenTime2CM_Time(*m_snaccTime.generalizedTime);

	return *this;
}


Time& Time::operator=(time_t timeVal)
{
	Clear();

	Error err = time2CMTime(timeVal, m_time);
	if (err != Success)
		throw Exception(err, __FILE__, __LINE__);
		
	m_snaccTime.choiceId = SNACC::Time::utcTimeCid;
	m_snaccTime.utcTime = new SNACC::UTCTime(&m_time[2]);
	if (m_snaccTime.utcTime == NULL)
		throw MEMORY_EXCEPTION;

	return *this;
}


Time& Time::operator=(const CM_Time& cmTime)
{
	Clear();
	strcpy(m_time, cmTime);
	if ((strcmp(m_time, "1950") > 0) && (strcmp(m_time, "2050") < 0))
	{
		m_snaccTime.choiceId = SNACC::Time::utcTimeCid;
		m_snaccTime.utcTime = new SNACC::UTCTime(&m_time[2]);
	}
	else
	{
		m_snaccTime.choiceId = SNACC::Time::generalizedTimeCid;
		m_snaccTime.generalizedTime = new SNACC::GeneralizedTime(m_time);
	}
	if (m_snaccTime.utcTime == NULL)
		throw MEMORY_EXCEPTION;

	return *this;
}


Time& Time::operator=(const Time& other)
{
	if (this != &other)
	{
		Clear();
		operator=(other.m_snaccTime);
	}

	return *this;
}


bool Time::operator==(const Time& rhs) const
{
	if (this == &rhs)
		return true;

	return (strcmp(m_time, rhs.m_time) == 0);
}


bool Time::operator<(const Time& rhs) const
{
	return (strcmp(m_time, rhs.m_time) < 0);
}


bool Time::operator>(const Time& rhs) const
{
	return (strcmp(m_time, rhs.m_time) > 0);
}


void Time::Clear()
{
	memset(m_time, 0, CM_TIME_LEN);
	if (m_snaccTime.utcTime == NULL)
	{
		m_snaccTime.choiceId = SNACC::Time::utcTimeCid;
		return;
	}

	if (m_snaccTime.choiceId == SNACC::Time::utcTimeCid)
	{
		delete m_snaccTime.utcTime;
		m_snaccTime.utcTime = NULL;
	}
	else
	{
		delete m_snaccTime.generalizedTime;
		m_snaccTime.generalizedTime = NULL;
	}
}


void Time::FillSnaccGenTime(SNACC::GeneralizedTime& snacc) const
{
	if (m_snaccTime.choiceId == SNACC::Time::utcTimeCid)
		snacc = m_time;
	else if (m_snaccTime.generalizedTime != NULL)
		snacc = *m_snaccTime.generalizedTime;
	else
		throw EXCEPTION(NullPointer);
}


SNACC::Time* Time::GetSnacc() const
{
	SNACC::Time* pResult = new SNACC::Time(m_snaccTime);
	if (pResult == NULL)
		throw MEMORY_EXCEPTION;

	return pResult;
}


SNACC::GeneralizedTime* Time::GetSnaccGenTime() const
{
	if (m_snaccTime.choiceId == SNACC::Time::utcTimeCid)
	{
		SNACC::GeneralizedTime* result = new SNACC::GeneralizedTime(m_time);
		if (result == NULL)
			throw MEMORY_EXCEPTION;
		return result;
	}
	else
		return new SNACC::GeneralizedTime(*m_snaccTime.generalizedTime);
}


void Time::calcUTCtime(char *s1, char sign, const std::string& s2,
					   std::string::size_type i)
/* This function calculates UTC time from the local time (s1) and the
GMT offset string (s2) and stores the result in s1.  Both s1 and s2 are numeric
strings.  The sign indicates whether s2 is positive or negative.  s1
is four bytes in length and in the form "hhmm".  s2 is checked to ensure that
it is the same length and form.  */
{
	// Check that the length of s2 is correct
	if ((i + 4) != s2.length())
		throw ASN_EXCEPTION("Invalid SNACC::GeneralizedTime value");
	
	// Check that the numeric characters are in the proper range and convert
	if ((s2[i] < '0') || (s2[i] > '2') ||			// 1st hour digit
		(s2[i + 1] < '0') || (s2[i + 1] > '9') ||	// 2nd hour digit
		(s2[i + 2] < '0') || (s2[i + 2] > '5') ||	// 1st min digit
		(s2[i + 3] < '0') || (s2[i + 3] > '9')) 	// 2nd min digit
		throw ASN_EXCEPTION("Invalid SNACC::GeneralizedTime value");
	
	// Calculate the UTC minutes
	int v1 = ((s1[2] - '0') * 10) + (s1[3] - '0');
	int v2 = sign * ((s2[2] - '0') * 10) + (s2[3] - '0');
	
	v1 += v2;
	
	int carry;
	if (v1 < 0)
	{
		v1 += 60;
		carry = -1;
	}
	else if (v1 > 59)
	{
		v1 -= 60;
		carry = 1;
	}
	else
		carry = 0;
	
	s1[2] = (char)((v1 / 10) + '0');
	s1[3] = (char)((v1 % 10) + '0');
	
	// Calculate the UTC hours
	v1 = ((s1[0] - '0') * 10) + (s1[1] - '0');
	v2 = sign * ((s2[0] - '0') * 10) + (s2[1] - '0');
	
	v1 += v2 + carry;
	
	if (v1 < 0)
		v1 += 24;
	else if (v1 > 23)
		v1 -= 24;
	
	s1[2] = (char)((v1 / 10) + '0');
	s1[3] = (char)((v1 % 10) + '0');
}


void Time::cvtGenTime2CM_Time(const std::string& gen)
/* This function copies the time from the Generalized time string and converts
it into a standard CM Library time string (format: "yyyymmddhhmmssZ").
Note: 
   Generalized time is formatted according to ISO 8601 and ITU-T X.680: 
      "yyyymmddhh" + 
         "mm" or "mmss" (optional) + 
         "." or "," + "s" (any number of decimal places) (optional) +
         "Z" or "-hh" or "+hh" or "-hhmm" or "+hhmm" (optional)
   When minutes or seconds are omitted, the CM Library time string fills
   in the fields with zeros.  It is rare that the trailing "Z" or local
   time differential will not be present in GeneralizedTime, since then 
   the time value cannot be converted to Coordinated Universal Time (UTC).
   The usual GeneralizedTime is expected to be "yyyymmddhhmmssZ".
*/
{
	// Copy "yyyymmddhh" values
	std::string::size_type i;
	for (i = 0; (i < gen.length()) && (i < 10); ++i)
	{
		if ((gen[i] < '0') || (gen[i] > '9'))
			throw ASN_EXCEPTION("Invalid SNACC::GeneralizedTime value");
		else
			m_time[i] = gen[i];
	}
	
	// Check that there is more to convert
	if (i < gen.length())
	{
		// If the "mm" values aren't present, add 00's, else copy them
		if ((gen[i] < '0') || (gen[i] > '9'))
		{
			m_time[10] = '0';
			m_time[11] = '0';
		}
		else
		{
			m_time[10] = gen[i++];
			if (i < gen.length())		// Check for another minute char
			{
				if ((gen[i] < '0') || (gen[i] > '9'))
					throw ASN_EXCEPTION("Invalid SNACC::GeneralizedTime value");
				else 
					m_time[11] = gen[i++];
			}
			else
				throw ASN_EXCEPTION("Invalid SNACC::GeneralizedTime value");
		}
		
		// If the "ss" values aren't present, add 00's, else copy them
		if ((i >= gen.length()) || (gen[i] < '0') || (gen[i] > '9'))
		{
			m_time[12] = '0';
			m_time[13] = '0';
		}
		else
		{
			m_time[12] = gen[i++];
			if (i < gen.length())		// Check for another seconds char
			{
				if ((gen[i] < '0') || (gen[i] > '9'))
					throw ASN_EXCEPTION("Invalid SNACC::GeneralizedTime value");
				else 
					m_time[13] = gen[i++];
			}
			else
				throw ASN_EXCEPTION("Invalid SNACC::GeneralizedTime value");
		}
	}
	else if (i == 10)	// Nothing after the hours, so pad the minutes and
						// seconds with zeros.
	{
		m_time[10] = '0';
		m_time[11] = '0';
		m_time[12] = '0';
		m_time[13] = '0';
	}
	else	// String length ( < 10) is invalid for generalized time
		throw ASN_EXCEPTION("Invalid SNACC::GeneralizedTime value");
	
	// If the fractional seconds are present, skip over them
	if ((i < gen.length()) && ((gen[i] == '.') || (gen[i] == ',')))
	{
		i++;
		while ((i < gen.length()) && (gen[i] >= '0') && (gen[i] <= '9'))
			i++;
	}
	
	// Check that there is still more to convert
	if (i < gen.length())
	{
		// If the local offset is present, convert the local time into UTC
		if (gen[i] == '-')
		{
			calcUTCtime(&m_time[8], 1, gen, ++i);
		}
		else if (gen[i] == '+')
		{
			calcUTCtime(&m_time[8], -1, gen, ++i);
		}
		else if ((gen[i] != 'Z') || ((i + 1) != gen.length()))
			throw ASN_EXCEPTION("Invalid SNACC::GeneralizedTime value");
	}
	/* else: This is only a local time!  The CM library will append the 'Z'
	anyway, but local time may not be UTC!	Hopefully, no one will use local
	generalized time. */
	
	// end of source time, just append our 'Z'
	m_time[14] = 'Z';
	m_time[15] = '\0';
}


void Time::cvtUTC2CM_Time(const std::string& utc)
/* This function copies the time from the UTC time string and converts
it into a standard CM Library time string (format: "yyyymmddhhmmssZ").
Note: 
   Coordinated Universal Time (UTC) is formatted according to ITU-T X.680:
      "yymmddhhmm" +
      "ss" (optional) + 
      "Z" or "-hhmm" or "+hhmm" 
   When seconds are omitted, the CM Library fills in the time string with 
   zeros.
*/
{
	// Check length is valid
	if (utc.length() < 11)
		throw ASN_EXCEPTION("Invalid SNACC::UTCTime value");

	// take care of yy to yyyy conversion */
	if (utc[0] < '5')		// Less than 50 is years 2000-2049
	{
		m_time[0] = '2';
		m_time[1] = '0';
	}
	else					// Make it 1950 through 1999
	{
		m_time[0] = '1';
		m_time[1] = '9';
	}
	
	// Copy "yymmddhhmm" values
	std::string::size_type i;
	for (i = 0; i < 10; ++i)
	{
		if ((utc[i] < '0') || (utc[i] > '9'))
			throw ASN_EXCEPTION("Invalid SNACC::UTCTime value");
		else
			m_time[i + 2] = utc[i];
	}
	
	// If the "ss" values aren't present, add 00's, else copy them
	if ((utc[i] < '0') || (utc[i] > '9'))
	{
		m_time[12] = '0';
		m_time[13] = '0';
	}
	else
	{
		m_time[12] = utc[i++];
		if ((i >= utc.length()) || (utc[i] < '0') || (utc[i] > '9'))
			throw ASN_EXCEPTION("Invalid SNACC::UTCTime value");
		m_time[13] = utc[i++];
	}
	
	// Check that there is still more to convert
	if (i < utc.length())
	{
		// If the local offset is present, convert the local time into UTC
		if (utc[i] == '-')
		{
			calcUTCtime(&m_time[8], 1, utc, ++i);
		}
		else if (utc[i] == '+')
		{
			calcUTCtime(&m_time[8], -1, utc, ++i);
		}
		else if ((utc[i] != 'Z') || ((i + 1) != utc.length()))
			throw ASN_EXCEPTION("Invalid SNACC::UTCTime value");
	}
	else
		throw ASN_EXCEPTION("Invalid SNACC::UTCTime value");
	
	// end of source time, just append our 'Z' and terminate
	m_time[14] = 'Z';
	m_time[15] = 0;
}


////////////////////////////////
// Bytes class implementation //
////////////////////////////////
Bytes::Bytes(ulong num, const uchar* data)
{
	len = 0;
	Bytes::data = NULL;
	Set(num, data);
}


Bytes::Bytes(const Bytes_struct& data)
{
	len = 0;
	Bytes::data = NULL;
	Set(data.num, data.data);
}


Bytes::Bytes(const char* fileName)
{
	len = 0;
	data = NULL;

    struct stat buf;
    int result = stat(fileName, &buf);
    if ((result != 0) || (buf.st_size < 0))
        throw Exception(FileIO, __FILE__, __LINE__, "Unable to get file status");

	// Allocate a buffer for the data
	len = buf.st_size;
	if (len > 0)
	{
		data = new uchar[buf.st_size];
		if (data == NULL)
			throw MEMORY_EXCEPTION;
		try {
#ifdef WIN32
			std::ifstream inFile(fileName, std::ios_base::in |
				std::ios_base::binary);
#else
			std::ifstream inFile(fileName);
#endif
			inFile.read((char*)data, len);
			if (inFile.fail())
				throw FileIO;
		}
		catch (...) {
			len = 0;
			delete[] data;
			data = NULL;
			throw Exception(FileIO, __FILE__, __LINE__, "Error reading file");
		}
	}
}


Bytes::Bytes(const CTIL::CSM_Buffer& buffer)
{
	len = 0;
	data = NULL;
	operator=(buffer);
}


Bytes::Bytes(const SNACC::AsnOcts& asnOcts)
{
	len = 0;
	data = NULL;
	operator=(asnOcts);
}


Bytes::Bytes(const SNACC::AsnAny& asnAny, const char* nameOfAny)
{
	len = 0;
	data = NULL;
	Set(asnAny, nameOfAny);
}


Bytes::Bytes(const Bytes& that)
{
	len = 0;
	data = NULL;
	operator=(that);
}


Bytes& Bytes::operator=(const CTIL::CSM_Buffer& buffer)
{
	Set(buffer.Length(), (const unsigned char*)buffer.Access());
	return *this;
}


Bytes& Bytes::operator=(const SNACC::AsnOcts& asnOcts)
{
	Set(asnOcts.Len(), asnOcts.c_ustr());
	return *this;
}


/*Bytes& Bytes::operator=(const SNACC::AsnAny& asnAny)
{
	Set(asnAny);
	return *this;
}


Bytes& Bytes::operator=(const SNACC::AsnBuf& asnBuf)
{
	asnBuf.ResetMode();
	Set(asnBuf, asnBuf.length());
	return *this;
}
		

Bytes& Bytes::operator=(const SNACC::AsnInt& asnInt)
{
	Clear();
	SNACC::AsnInt theInt = asnInt;
	len = theInt.Len();
	if (len > 0)
	{
		data = new uchar[len];
		if (data == NULL)
			throw MEMORY_EXCEPTION;
		memcpy((uchar *)data, theInt.c_str(), len);
	}
	return *this;
}
*/

Bytes& Bytes::operator=(const Bytes& other)
{
	if (this != &other)
	{
		Clear();
		len = other.len;
		if (len > 0)
		{
			data = new uchar[len];
			if (data == NULL)
				throw MEMORY_EXCEPTION;
			memcpy(data, other.data, len);
		}
	}
	return *this;
}


bool Bytes::operator==(const Bytes& rhs) const
{
	if (this == &rhs)
		return true;

	if (len != rhs.len)
		return false;
	return (memcmp(data, rhs.data, len) == 0);
}


bool Bytes::operator==(const CTIL::CSM_Buffer& rhs) const
{
	if (len != rhs.Length())
		return false;
	return (memcmp(data, rhs.Access(), len) == 0);
}


bool Bytes::operator==(const Bytes_struct& rhs) const
{
	if (len != (unsigned long)rhs.num)
		return false;
	if (rhs.data == NULL)
		return (len == 0);
	return (memcmp(data, rhs.data, len) == 0);
}


bool Bytes::operator<(const Bytes& rhs) const
{
	if (len < rhs.len)
		return (memcmp(data, rhs.data, len) <= 0);
	else
		return (memcmp(data, rhs.data, rhs.len) < 0);
}


void Bytes::Clear()
{
	len = 0;
	if (data != NULL)
	{
		delete[] data;
		data = NULL;
	}
}


void Bytes::Set(ulong len, const uchar* data)
{
	if ((data == NULL) && (len != 0))
		throw Exception(InvalidParameter, __FILE__, __LINE__);

	Clear();
	Bytes::len = len;
	if (len > 0)
	{
		Bytes::data = new uchar[len];
		if (Bytes::data == NULL)
			throw MEMORY_EXCEPTION;
		memcpy(Bytes::data, data, len);
	}
}


void Bytes::Set(const SNACC::AsnAny& asnAny, const char* nameOfAny)
{
	Clear();

	if (nameOfAny == NULL)
		nameOfAny = "<Unnamed ANY>";

	try {
		// If the AsnAny is decoded, re-encode the object
		if (asnAny.ai != NULL)
		{
			// Check that the decoded value is present
			if (asnAny.value == NULL)
				throw ASN_EXCEPTION2(nameOfAny, " value field is NULL");
		
			// Re-encode the object
			SNACC::AsnBuf asnBuf;
			SNACC::AsnLen numEncoded;
			if (!asnAny.BEncPdu(asnBuf, numEncoded))
				throw ASN_EXCEPTION2("Error encoding ", nameOfAny);

			// Allocate memory for the encoded data
			len = numEncoded;
			data = new unsigned char[len];
			if (data == NULL)
				throw MEMORY_EXCEPTION;

			// Copy the encoded value
			asnBuf.ResetMode();
			asnBuf.GetSeg((char*)data, len);
		}
		else	// Just copy the contents of the AsnBuf
		{
			// Check that the encoded AsnBuf is present
			if (asnAny.anyBuf == NULL)
				throw ASN_EXCEPTION2(nameOfAny, " anyBuf field is NULL");

			// Reset the AsnBuf for reading
			asnAny.anyBuf->ResetMode();

			// Set this value from the AsnBuf
			Set(*asnAny.anyBuf, asnAny.anyBuf->length());
		}
	}
	catch (...) {
		Clear();
		throw;
	}
}


void Bytes::Set(const SNACC::AsnBuf& asnBuf, ulong len)
{
	Clear();

	try {
		// Allocate memory for the encoded data
		Bytes::len = len;
		if (len > 0)
		{
			data = new unsigned char[len];
			if (data == NULL)
				throw MEMORY_EXCEPTION;
		
			// Copy the encoded value
			asnBuf.ResetMode();
			asnBuf.GetSeg((char*)data, len);
		}
	}
	catch (...) {
		Clear();
		throw;
	}
}


ulong Bytes::Decode(SNACC::AsnType& snaccObj, const char* snaccObjName) const
{
	if (snaccObjName == NULL)
		snaccObjName = "<unknown object>";

	// Create a SNACC::AsnRvsBuf and install it into the AsnBuf
	SNACC::AsnRvsBuf asnStream((char*)data, len);
	SNACC::AsnBuf asnBuf(&asnStream);

	// Decode the object
	SNACC::AsnLen numDecoded = 0;
	if (!snaccObj.BDecPdu(asnBuf, numDecoded))
		throw ASN_EXCEPTION2("Error decoding ", snaccObjName);

	return numDecoded;
}


ulong Bytes::Encode(const SNACC::AsnType& snaccObj, const char* snaccObjName)
{
	if (snaccObjName == NULL)
		snaccObjName = "<unknown object>";

	// Encode the SNACC object into a SNACC::AsnBuf
	SNACC::AsnBuf asnBuf;
	SNACC::AsnLen numEncoded;
	if (!snaccObj.BEncPdu(asnBuf, numEncoded))
		throw ASN_EXCEPTION2("Error encoding ", snaccObjName);

	// Reset the AsnBuf in read mode
	asnBuf.ResetMode(std::ios_base::in);

	// Set this Bytes object from the SNACC::AsnBuf
	Set(asnBuf, numEncoded);

	return numEncoded;
}


void Bytes::Hash(Bytes& hashResult) const
{
	// Clear any existing data in the hash result
	hashResult.Clear();

	// Allocate memory for the SHA-1 hash result
	hashResult.len = 20;
	hashResult.data = new uchar[20];
	if (hashResult.data == NULL)
		throw MEMORY_EXCEPTION;

	// Hash the data
	hashBuffer(data, len, (ulong*)hashResult.data);
}


// Fill in the Bytes_struct form of this object
void Bytes::FillBytesStruct(Bytes_struct& bytes) const
{
	bytes.data = NULL;
	bytes.num = len;
	if (bytes.num <= 0)
		bytes.num = 0;
	else
	{
		bytes.data = (uchar*)malloc(len);
		if (bytes.data == NULL)
		{
			bytes.num = 0;
			throw MEMORY_EXCEPTION;
		}
		memcpy(bytes.data, data, len);
	}
}

// Get the Bytes_struct form of this object
Bytes_struct* Bytes::GetBytesStruct() const
{
	Bytes_struct* result = (Bytes_struct*)malloc(sizeof(Bytes_struct));
	if (result == NULL)
		throw MEMORY_EXCEPTION;

	try {
		FillBytesStruct(*result);
		return result;
	}
	catch (...) {
		free(result);
		throw;
	}
}


SNACC::AsnOcts* Bytes::GetSnacc() const
{
	SNACC::AsnOcts* result = new SNACC::AsnOcts((const char*)data, len);
	if (result == NULL)
		throw MEMORY_EXCEPTION;
	return result;
}


// Write the contents to the specified stream
std::ostream& operator<<(std::ostream& os, const Bytes& bytes)
{
	return os.write((const char*)bytes.GetData(), bytes.Len());
}


////////////////////////////
// CM_HashData() function //
////////////////////////////
short CM_HashData(Bytes_struct* pData, CM_HashValue hash)
{
	if ((pData == NULL) || (hash == NULL) || (pData->num == 0) ||
		(pData->data == NULL))
		return CMLASN_INVALID_PARAMETER;

	// Hash the input data
	hashBuffer(pData->data, pData->num, (ulong*)hash);
	return CMLASN_SUCCESS;
}


////////////////////////////////
// Mutex class implementation //
////////////////////////////////
Mutex::Mutex(const char* mutexName)
{
#ifndef NOTHREADS
#ifdef WIN32
	SECURITY_DESCRIPTOR sd;
	if (InitializeSecurityDescriptor(&sd, SECURITY_DESCRIPTOR_REVISION) != 0)
		SetSecurityDescriptorDacl(&sd, TRUE, 0, FALSE);

	SECURITY_ATTRIBUTES sa;
	sa.nLength = sizeof(sa);
	sa.lpSecurityDescriptor = &sd;
	sa.bInheritHandle = TRUE;
	m_winHandle = CreateMutex(&sa, FALSE, mutexName);
	m_winEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
#else
	pthread_mutex_init((pthread_mutex_t*)&m_mutex, NULL);
	pthread_cond_init((pthread_cond_t*)&condition, NULL);
#endif
#endif // NOTHREADS
}


Mutex& Mutex::operator=(const Mutex& that)
{
	if (this != &that)
	{
#ifndef NOTHREADS
#ifdef WIN32
		m_winHandle = that.m_winHandle;
		that.m_winHandle = 0;
		m_winEvent = that.m_winEvent;
		that.m_winEvent = 0;
#else
		m_mutex = that.m_mutex;
		pthread_mutex_destroy((pthread_mutex_t*)&(that.m_mutex));
		condition = that.condition;
		pthread_cond_destroy((pthread_cond_t*)&(that.condition));
#endif
#endif // NOTHREADS
	}
	return *this;
}

Mutex::~Mutex()
{
#ifndef NOTHREADS
#ifdef WIN32
	// Close the Windows mutex handle
	if (m_winHandle != 0)
		CloseHandle(m_winHandle);
	if (m_winEvent != 0)
		CloseHandle(m_winEvent);
#else
	// Destroy the mutex
	pthread_mutex_destroy((pthread_mutex_t*)&m_mutex);
	pthread_cond_destroy((pthread_cond_t*)&condition);
#endif
#endif // NOTHREADS
}


MutexLock Mutex::AcquireLock() const
{
	// Acquire/lock the mutex
#ifndef NOTHREADS
#ifdef WIN32
	WaitForSingleObject(m_winHandle, INFINITE);
#else
	pthread_mutex_lock((pthread_mutex_t*)&m_mutex);
#endif
	return MutexLock(*this);
#endif // NOTHREADS
}


void Mutex::ReleaseMutex() const
{
	// Release/unlock the mutex
#ifndef NOTHREADS
#ifdef WIN32
	::ReleaseMutex(m_winHandle);
#else
	pthread_mutex_unlock((pthread_mutex_t*)&m_mutex);
#endif
#endif // NOTHREADS
}


////////////////////////////////////
// MutexLock class implementation //
////////////////////////////////////
MutexLock::MutexLock(const MutexLock& that) : m_mutex(that.m_mutex)
{
	m_isReleased = that.m_isReleased;
	that.m_isReleased = true;
}


MutexLock& MutexLock::operator=(const MutexLock& that)
{
	throw Exception(NotImplemented, __FILE__, __LINE__);

#ifndef WIN32
	return *this;	// Eliminates warning on non-Windows platforms
#endif
}


void MutexLock::Release()
{
	// Check that this mutex still owns the lock
	if (m_isReleased)
		return;

	// Release the lock
	if (IsRegularLock())
		m_mutex.ReleaseMutex();
	else
		m_mutex.ReleaseLock();
	m_isReleased = true;
}


/////////////////////////////////////////
// ReadWriteMutex class implementation //
/////////////////////////////////////////
ReadWriteMutex::ReadWriteMutex(const char* mutexName, unsigned int maxReadThreads) :
Mutex(mutexName)
{
	m_nReads = 0;

	MutexLock lock = Mutex::AcquireLock();

	if (maxReadThreads == 0)
		m_maxReads = (unsigned int)-1;
	else
		m_maxReads = maxReadThreads;
}


ReadWriteMutex::~ReadWriteMutex()
{
	MutexLock lock = Mutex::AcquireLock();
	while  (m_nReads != 0)
#ifndef NOTHREADS
#ifdef WIN32
		WaitForSingleObject(m_winEvent, INFINITE);
#else
		pthread_cond_wait((pthread_cond_t*)&condition, (pthread_mutex_t*)&m_mutex);
#endif //WIN32
#endif //NOTHREADS
}


MutexLock ReadWriteMutex::AcquireLock() const
{
	// Acquire or lock the mutex
	MutexLock lock = Mutex::AcquireLock();
	while (m_nReads > 0) 
#ifndef NOTHREADS
#ifdef WIN32
		WaitForSingleObject(m_winEvent, INFINITE);
#else
		pthread_cond_wait((pthread_cond_t*)&condition, (pthread_mutex_t*)&m_mutex);
#endif //WIN32
#endif //NOTHREADS
	return lock;
}


ReadLock ReadWriteMutex::AcquireReadLock() const
{
	// Acquire or lock the mutex
	MutexLock lock = Mutex::AcquireLock();

	// If max read threads running, wait for a read thread to finish
	while (m_nReads == m_maxReads)
#ifndef NOTHREADS
#ifdef WIN32
		WaitForSingleObject(m_winEvent, INFINITE);
#else
		pthread_cond_wait((pthread_cond_t*)&condition, (pthread_mutex_t*)&m_mutex);
#endif //WIN32
#endif //NOTHREADS

	// Increment number of read threads
	m_nReads++;

	return ReadLock(*this);
}


void ReadWriteMutex::ReleaseLock() const
{
	if (m_nReads > 0) {
		--m_nReads;
#ifndef NOTHREADS
#ifdef WIN32
		SetEvent(m_winEvent);
#else
		pthread_cond_broadcast((pthread_cond_t*)&condition);
#endif //WIN32
#endif //NOTHREADS
	}
}



///////////////////////////////////
// ReadLock class implementation //
///////////////////////////////////
ReadLock::ReadLock(const ReadLock& that) : MutexLock(that)
{
	if (!m_isReleased)
	{
		// Acquire a new read lock
		ReadLock lock = ((const ReadWriteMutex&)m_mutex).AcquireReadLock();

		// Flag the read lock as released, so the read count will be correct
		lock.m_isReleased = true;

		// Reset the released flag in the other ReadLock
		that.m_isReleased = false;
	}
}



//////////////////////////////////
// CML::ASN::Internal functions //
//////////////////////////////////
Bytes_struct* Internal::CvtAsnBufToBytes(const SNACC::AsnBuf& buffer)
{
	Bytes_struct* pResult = (Bytes_struct*)calloc(1, sizeof(Bytes_struct));
	if (pResult == NULL)
		throw MEMORY_EXCEPTION;

	try {
		CvtAsnBufToBytesStruct(*pResult, buffer);
		return pResult;
	}
	catch (...) {
		free(pResult);
		throw;
	}
}


void Internal::CvtAsnBufToBytesStruct(Bytes_struct& bytes,
									  const SNACC::AsnBuf& buffer)
{
	// Reset the AsnBuf for reading
	buffer.ResetMode();

	bytes.num = buffer.length();
	bytes.data = (uchar*)calloc(bytes.num, sizeof(uchar));
	if (bytes.data == NULL)
	{
		bytes.num = 0;
		throw MEMORY_EXCEPTION;
	}

	buffer.GetSeg((char*)bytes.data, bytes.num);
}


Bytes_struct* Internal::CvtAsnIntToBytes(const SNACC::AsnInt& hugeInt,
										 int mult)
{
	Bytes_struct* pResult = (Bytes_struct*)malloc(sizeof(Bytes_struct));
	if (pResult == NULL)
		throw MEMORY_EXCEPTION;

	try {
		CvtAsnIntToExistingBytes(*pResult, hugeInt, mult);
		return pResult;
	}
	catch (...) {
		free(pResult);
		throw;
	}
}


void Internal::CvtAsnIntToExistingBytes(Bytes_struct& bytes,
										const SNACC::AsnInt& hugeInt, int mult)
{
	const uchar* data = hugeInt.c_str();
	bytes.num = hugeInt.length();
	
	// Check the leading byte to see if it is zero
	if ((bytes.num > 0) && (data[0] == 0))
	{
		// Skip over the leading zero byte
		data++;
		bytes.num--;
	}
	
	// Check if huge integer needs to be padded
	int pad = 0;
	if (mult > 0)
	{
		pad = mult - (bytes.num % mult);
		if (pad == mult)
			pad = 0;
	}
	bytes.num += pad;
	
	// Allocate and clear memory for the data
	if (bytes.num > 0)
	{
		bytes.data = (uchar*)calloc(bytes.num, sizeof(uchar));
		if (bytes.data == NULL)
		{
			bytes.num = 0;
			throw MEMORY_EXCEPTION;
		}
		memcpy(&bytes.data[pad], data, bytes.num - pad);
	}
	else
	{
		bytes.num = 0;
		bytes.data = NULL;
	}
}


Bytes_struct* Internal::CvtBitsToBytes(const SNACC::AsnBits& bits)
{
	Bytes_struct* pResult = (Bytes_struct*)malloc(sizeof(Bytes_struct));
	if (pResult == NULL)
		throw MEMORY_EXCEPTION;

	pResult->num = (bits.BitLen() + 7) / 8;
	if (pResult->num == 0)
		pResult->data = NULL;
	else
	{
		pResult->data = (uchar*)calloc(pResult->num, sizeof(uchar));
		if (pResult->data == NULL)
		{
			free(pResult);
			throw MEMORY_EXCEPTION;
		}

		ulong byte = 0;
		uchar mask = 0;
		for (size_t i = 0; i < bits.BitLen(); i++)
		{
			if ((i % 8) == 0)
				mask = 0x80;

			if (bits.GetBit(i))
				pResult->data[byte] |= mask;

			mask >>= 1;
			if (mask == 0)
				byte++;
		}
	}

	return pResult;
}


Bytes_struct* Internal::CvtBufferToBytes(const CTIL::CSM_Buffer& buffer)
{
	Bytes_struct* pResult = (Bytes_struct*)calloc(1, sizeof(Bytes_struct));
	if (pResult == NULL)
		throw MEMORY_EXCEPTION;

	try {
		CvtBufferToBytesStruct(*pResult, buffer);
		return pResult;
	}
	catch (...) {
		free(pResult);
		throw;
	}
}


void Internal::CvtBufferToBytesStruct(Bytes_struct& bytes,
									  const CTIL::CSM_Buffer& buffer)
{
	bytes.num = buffer.Length();
	bytes.data = (uchar*)calloc(bytes.num, sizeof(uchar));
	if (bytes.data == NULL)
	{
		bytes.num = 0;
		throw MEMORY_EXCEPTION;
	}

	memcpy(bytes.data, buffer.Access(), bytes.num);
}


void Internal::CvtBufferToSigStruct(Sig_struct& sig,
									const CTIL::CSM_Buffer& encBuf)
{
	// Decode the encoded signature value depending on the OID
	if ((strcmp(sig.alg, gRSA_MD2_OID) == 0) ||
		(strcmp(sig.alg, gRSA_MD4_OID) == 0) ||
		(strcmp(sig.alg, gRSA_MD5_OID) == 0) ||
		(strcmp(sig.alg, gRSA_SHA1_OID) == 0))
	{
		sig.value.rsa = Internal::CvtBufferToBytes(encBuf);
	}
	else if ((strcmp(sig.alg, gDSA_SHA1_OID) == 0) ||
		(strcmp(sig.alg, gECDSA_SHA1_OID) == 0))
	{
		// Decode the DSA signature value
		SNACC::DSASigValue dsaSigValue;
		try {
			encBuf.Decode(dsaSigValue);
		}
		catch (...) {
			throw ASN_EXCEPTION("Error decoding SNACC::DSASigValue");
		}
		
		// Allocate memory for the Dsa_sig_struct
		sig.value.dsa = (Dsa_sig_struct*)calloc(1, sizeof(Dsa_sig_struct));
		if (sig.value.dsa == NULL)
			throw MEMORY_EXCEPTION;

		try {
			Internal::CvtAsnIntToExistingBytes(sig.value.dsa->r,
				dsaSigValue.r, 20);
			Internal::CvtAsnIntToExistingBytes(sig.value.dsa->s,
				dsaSigValue.s, 20);
		}
		catch (...) {
			free(sig.value.dsa->r.data);
			free(sig.value.dsa->s.data);
			free(sig.value.dsa);
			sig.value.dsa = NULL;
			throw;
		}
	}
	else if (strcmp(sig.alg, gMOSAIC_DSA_OID) == 0)
	{
		if (encBuf.Length() != 40)
			throw ASN_EXCEPTION("Invalid length of Fortezza signature value");

		// Allocate memory for the Dsa_sig_struct
		sig.value.dsa = (Dsa_sig_struct*)calloc(1, sizeof(Dsa_sig_struct));
		if (sig.value.dsa == NULL)
			throw MEMORY_EXCEPTION;

		// Set the lengths of the R & S values
		sig.value.dsa->r.num = 20;
		sig.value.dsa->s.num = 20;
		
		try {
			// Allocate memory for and copy the R value
			sig.value.dsa->r.data = (uchar*)malloc(sig.value.dsa->r.num);
			if (sig.value.dsa->r.data == NULL)
				throw MEMORY_EXCEPTION;
	
			memcpy(sig.value.dsa->r.data, encBuf.Access(), sig.value.dsa->r.num);

			// Allocate memory for and copy the S value
			sig.value.dsa->s.data = (uchar*)malloc(sig.value.dsa->s.num);
			if (sig.value.dsa->s.data == NULL)
				throw MEMORY_EXCEPTION;

			memcpy(sig.value.dsa->s.data, &encBuf.Access()[sig.value.dsa->r.num],
				sig.value.dsa->s.num);
		}
		catch (...) {
			free(sig.value.dsa->r.data);
			free(sig.value.dsa->s.data);
			free(sig.value.dsa);
			sig.value.dsa = NULL;
			throw;
		}
	}
	else
		throw EXCEPTION_STR(NotImplemented, "Signature algorithm not implemented");
}


void Internal::FillParameters(Pub_key_struct& cmPubKey, const AlgID& algID)
{
	// Initialize parameters union of the Pub_key_struct
	cmPubKey.params.dsa = NULL;

	if (algID.parameters == NULL)
		return;

	if (algID.algorithm == gKEA_OID)
	{
		// Decode the KEA parameter ID
		SNACC::AsnOcts keaIDParam;
		try {
			algID.parameters->Decode(keaIDParam);
		}
		catch (...) {
			throw ASN_EXCEPTION("Error decoding KEA parameters");
		}

		// Copy the AsnOcts to a Bytes_struct
		cmPubKey.params.kea = cvtOctsToBytes(keaIDParam);
	}
	else if ((algID.algorithm == gOLD_DH_OID) ||
		(algID.algorithm == gANSI_DH_OID) ||
		(algID.algorithm == gEC_KEY_OID))
	{
		// Convert the encoded parameters to a Bytes_struct
		cmPubKey.params.encoded =
			Internal::CvtBufferToBytes(*algID.parameters);
	}
	else if ((algID.algorithm == gDSA_OID) || (algID.algorithm == gOIW_DSA) ||
		(algID.algorithm == gDSA_KEA_OID))
	{
		// Decode the old Fortezza or new DSA parameters
		SNACC::OldOrNewParameters eitherParams;
		try {
			algID.parameters->Decode(eitherParams);
		}
		catch (...) {
			throw ASN_EXCEPTION("Error decoding DSA parameters");
		}
		if (eitherParams.newParams == NULL)
			throw ASN_EXCEPTION("SNACC::OldOrNewParameters is NULL");

		// Convert the parameters into the correct Pqg_params_struct
		if (eitherParams.choiceId == SNACC::OldOrNewParameters::newParamsCid)
		{
			// Convert the DSA parameters into a Pqg_params_struct
			cmPubKey.params.dsa = cvtDSAParameters(*eitherParams.newParams);
		}
		else if (eitherParams.choiceId ==
			SNACC::OldOrNewParameters::oldParamsCid)
		{
			if (eitherParams.oldParams->different_Parms == NULL)
				throw ASN_EXCEPTION("SNACC::Kea_Dss_Parms::different_Parms is NULL");

			// Convert the Fortezza parameters into the correct Pqg_params_struct
			if (eitherParams.oldParams->choiceId == 
				SNACC::Kea_Dss_Parms::common_ParmsCid)
			{
				cmPubKey.params.dsa_kea =
					cvtFortezzaParams(*eitherParams.oldParams->common_Parms);
			}
			else if (eitherParams.oldParams->choiceId == 
				SNACC::Kea_Dss_Parms::different_ParmsCid)
			{
				if (cmPubKey.key.combo == NULL)
					throw EXCEPTION(NullPointer);
				cmPubKey.key.combo->diff_kea = NULL;
				
				if ((eitherParams.oldParams->different_Parms->dss_Parms == NULL) ||
					(eitherParams.oldParams->different_Parms->kea_Parms == NULL))
					throw ASN_EXCEPTION("Either SNACC::Different_Parms::kea_Parms or dss_Parms is NULL");
				cmPubKey.params.dsa_kea =
					cvtFortezzaParams(*(SNACC::Common_Parms*)
					eitherParams.oldParams->different_Parms->dss_Parms);
				cmPubKey.key.combo->diff_kea =
					cvtFortezzaParams(*(SNACC::Common_Parms*)
					eitherParams.oldParams->different_Parms->kea_Parms);
			}
			else
				throw ASN_EXCEPTION("Invalid CHOICE in SNACC::Kea_Dss_Parms");
		}
		else
			throw ASN_EXCEPTION("Invalid CHOICE in SNACC::OldOrNewParameters");
	}
	else if (algID.algorithm != gRSA_OID)
		throw EXCEPTION_STR(NotImplemented, "Unsupported public-key algorithm");

} // end of Internal::FillParameters()


////////////////////////
// Internal functions //
////////////////////////
Pqg_params_struct* cvtDSAParameters(const SNACC::DSAWithSHA1Parameters& params)
{
	Pqg_params_struct* pResult = (Pqg_params_struct*)
		calloc(1, sizeof(Pqg_params_struct));
	if (pResult == NULL)
		throw MEMORY_EXCEPTION;

	try {
		Internal::CvtAsnIntToExistingBytes(pResult->p, params.p, 8);
		Internal::CvtAsnIntToExistingBytes(pResult->q, params.q, 20);
		Internal::CvtAsnIntToExistingBytes(pResult->g, params.g, 8);
		return pResult;
	}
	catch (...) {
		Internal::FreePQGs(pResult);
		throw;
	}
}


ulong cvtFortezzaMultiByte(Bytes_struct& bytes, const uchar* data,
						   const uchar* dataEnd)
{
	if ((data == NULL) || (dataEnd == NULL))
		throw EXCEPTION(NullPointer);

	// Count the number of bytes
	int count = 1;
	while ((count < (dataEnd - data)) && ((data[count] & 0x80) != 0))
		count++;
	if ((data[count] & 0x80) != 0)
		throw ASN_EXCEPTION("Invalid Fortezza public key");

	// Allocate memory for the result
	bytes.num = count;
	bytes.data = (uchar*)malloc(count);
	if (bytes.data == NULL)
		throw MEMORY_EXCEPTION;

	memcpy(bytes.data, data, count);

	return count;
}


Pqg_params_struct* cvtFortezzaParams(const SNACC::Common_Parms& params)
{
	Pqg_params_struct* pResult = (Pqg_params_struct*)
		calloc(1, sizeof(Pqg_params_struct));
	if (pResult == NULL)
		throw MEMORY_EXCEPTION;

	try {
		cvtOctsToExistingBytes(pResult->p, params.p);
		cvtOctsToExistingBytes(pResult->q, params.q);
		cvtOctsToExistingBytes(pResult->g, params.g);
		return pResult;
	}
	catch (...) {
		Internal::FreePQGs(pResult);
		throw;
	}
}


void cvtFortezzaPubKey(Pub_key_struct& cmPubKey,
					   const CTIL::CSM_Buffer& keyBuf)
{
	cmPubKey.key.combo = (Mosaic_key_struct*)
		calloc(1, sizeof(Mosaic_key_struct));
	if (cmPubKey.key.combo == NULL)
		throw MEMORY_EXCEPTION;
	
	Mosaic_key_struct& fortKey = *cmPubKey.key.combo;
	
	size_t keyLen = keyBuf.Length();
	if (keyLen < 275)
		throw ASN_EXCEPTION("Invalid length of Fortezza public key");
	uchar* keyData = (uchar*)keyBuf.Access();
	uchar* bufEnd = keyData + keyLen;
	
	fortKey.kea_ver = *keyData++;
	if (fortKey.kea_ver != 0)
		throw ASN_EXCEPTION("Invalid Fortezza KEA version");
	
	fortKey.kea_type = *keyData++;
	if (fortKey.kea_type != 0x01)
		throw ASN_EXCEPTION("Invalid Fortezza KEA type");
	
	memcpy(fortKey.kmid, keyData, CM_KMID_LEN);
	keyData += CM_KMID_LEN;
	
	keyData += cvtFortezzaMultiByte(fortKey.kea_clearance, keyData, bufEnd);
	keyData += cvtFortezzaMultiByte(fortKey.kea_privs, keyData, bufEnd);
	
	if (((bufEnd - keyData) < 263) || (*keyData++ != 0) ||
		(*keyData++ != 0x80))
		throw ASN_EXCEPTION("Invalid length of Fortezza public key");
	
	fortKey.kea_y.num = 128;
	fortKey.kea_y.data = (uchar*)malloc(128);
	if (fortKey.kea_y.data == NULL)
		throw MEMORY_EXCEPTION;
	memcpy(fortKey.kea_y.data, keyData, 128);
	keyData += 128;
	
	fortKey.dsa_ver = *keyData++;
	if (fortKey.dsa_ver != 0)
		throw ASN_EXCEPTION("Invalid Fortezza DSA version");
	
	fortKey.dsa_type = *keyData++;
	if (fortKey.dsa_type != 0x02)
		throw ASN_EXCEPTION("Invalid Fortezza DSA type");
	
	keyData += cvtFortezzaMultiByte(fortKey.dsa_privs, keyData, bufEnd);
	
	if (((bufEnd - keyData) != 130) || (*keyData++ != 0) ||
		(*keyData++ != 0x80))
		throw ASN_EXCEPTION("Invalid length of Fortezza public key");
	
	fortKey.dsa_y.num = 128;
	fortKey.dsa_y.data = (uchar*)malloc(128);
	if (fortKey.dsa_y.data == NULL)
		throw MEMORY_EXCEPTION;
	memcpy(fortKey.dsa_y.data, keyData, 128);

} // end of cvtFortezzaPubKey


Bytes_struct* Internal::cvtOctsToBytes(const SNACC::AsnOcts& octs)
{
	Bytes_struct* pResult = (Bytes_struct*)malloc(sizeof(Bytes_struct));
	if (pResult == NULL)
		throw MEMORY_EXCEPTION;

	try {
		cvtOctsToExistingBytes(*pResult, octs);
		return pResult;
	}
	catch (...) {
		free(pResult);
		throw;
	}
}


void cvtOctsToExistingBytes(Bytes_struct& bytes, const SNACC::AsnOcts& octs)
{
	bytes.num = octs.Len();
	bytes.data = (uchar*)malloc(bytes.num);
	if (bytes.data == NULL)
		throw MEMORY_EXCEPTION;
	memcpy(bytes.data, octs.c_ustr(), bytes.num);
}

void Internal::cvtInt2BytesStruct(Bytes_struct **bytes, const SNACC::AsnInt& theInt)
{
	if (*bytes == NULL)
	{
		*bytes = (Bytes_struct *)malloc(sizeof(Bytes_struct));
		if (*bytes == NULL)
			throw MEMORY_EXCEPTION;
	}
	(*bytes)->num = theInt.length();
	(*bytes)->data = (uchar *)malloc ((*bytes)->num);
	if ((*bytes)->data == NULL)
		throw MEMORY_EXCEPTION;
	memcpy((*bytes)->data, theInt.c_str(), (*bytes)->num);
}
	

RSAPublicKey_struct* cvtRSAPublicKey(const SNACC::RSAPublicKey& rsaKey)
{
	RSAPublicKey_struct* pResult = (RSAPublicKey_struct*)
		calloc(1, sizeof(RSAPublicKey_struct));
	if (pResult == NULL)
		throw MEMORY_EXCEPTION;

	try {
		Internal::CvtAsnIntToExistingBytes(pResult->modulus, rsaKey.modulus, 8);
		Internal::CvtAsnIntToExistingBytes(pResult->publicExponent,
			rsaKey.publicExponent);
		return pResult;
	}
	catch (...) {
		free(pResult->modulus.data);
		free(pResult->publicExponent.data);
		free(pResult);
		throw;
	}
}


CTIL::CSM_Buffer* encodeAnyInCSMBuffer(const SNACC::AsnAny& snacc,
									   const char* anyName)
{
	if (anyName == NULL)
		anyName = "<Unnamed ANY>";

	CTIL::CSM_Buffer* pResult = new CTIL::CSM_Buffer;
	if (pResult == NULL)
		throw MEMORY_EXCEPTION;

	try {
		// If the AsnAny is decoded, re-encode the object
		if (snacc.ai != NULL)
		{
			// Check that the decoded value is present
			if (snacc.value == NULL)
				throw ASN_EXCEPTION2(anyName, " value field is NULL");
		
			// Re-encode the object
			SNACC::AsnBuf asnBuf;
			SNACC::AsnLen numEncoded;
			if (!snacc.BEncPdu(asnBuf, numEncoded))
				throw ASN_EXCEPTION2("Error encoding ", anyName);

			// Copy the encoded value into the CSM_Buffer
			asnBuf.ResetMode();
			asnBuf.GetSeg(pResult->Alloc(numEncoded), numEncoded);
		}
		else	// Just copy the contents of the AsnBuf
		{
			// Check that the encoded AsnBuf is present
			if (snacc.anyBuf == NULL)
				throw ASN_EXCEPTION2(anyName, " anyBuf field is NULL");
		
			// Copy the encoded value into the CSM_Buffer
			snacc.anyBuf->ResetMode();
			ulong bufLen = snacc.anyBuf->length();
			snacc.anyBuf->GetSeg(pResult->Alloc(bufLen), bufLen);
		}

		return pResult;
	}
	catch (...) {
		delete pResult;
		throw;
	}
}


// Mutex used in time2CMTime()
static Mutex gmTimeMutex;

// time2CMTime() converts a local time_t value into a CM_Time string
Error time2CMTime(time_t t, char* cm_time)
{
	// Acquire a handle to the mutex
	MutexLock lock = gmTimeMutex.AcquireLock();

	// Check the time_t for negative and fix to be max for time_t
	if (t < 0)
	{
		t = 1;
		t <<= sizeof(time_t) * 8 - 2;
		t |= t - 1;
	}

	// Convert the time value to GM time */
	struct tm* utc = gmtime(&t);
	if (utc == NULL)
		return SystemError;

	// Initialize the temporary date/time variables
	int year = utc->tm_year + 1900;		// tm_year is years since 1900
	int month = utc->tm_mon + 1;		// tm_mon is years since Jan
	int day = utc->tm_mday;
	int hour = utc->tm_hour;
	int min = utc->tm_min;
	int sec = utc->tm_sec;

	// Create the string
	if (sprintf(cm_time, "%d%02d%02d%02d%02d%02dZ", year, month, day, hour,
		min, sec) != CM_TIME_LEN - 1)
		return SystemError;

	return Success;
}


void hashBuffer(uchar* pData, ulong dataSize, ulong* hash)
{
	// Constants
	const ushort BLOCK = 64;
	const ushort L_BLOCK = BLOCK / sizeof(long);
	const unsigned char paddata[64] = {
		0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0  };

	// Union for reading in bytes and hashing in 32 bit blocks
	union {
		char	lets[BLOCK];
		ulong	nums[L_BLOCK];
	} buff;
	
	// Initialize the hash function
	sha_init(hash);

	// Hash data in groups of 64 bytes
	ulong arrayIndex = 0;
	int blocksRead = 0;
	while ((arrayIndex + 64) <= dataSize)
	{
		memcpy(buff.lets, pData + arrayIndex, BLOCK);
		
		if (isLittleEndian())
		{
			// Perform little endian byte swap
			for (unsigned int i = 0; i < 16; i++)
			{
				ulong tempnum = (buff.nums[i] << 16) | (buff.nums[i] >> 16);
				buff.nums[i] = ((tempnum & 0xff00ff00L) >> 8) |
					((tempnum & 0x00ff00ffL) << 8);
			}
		}

		sha_hash(buff.nums, hash);
		arrayIndex += BLOCK;
		blocksRead++;
	}
	
	// Calculate final hash
	ulong nBytesLeft = dataSize - arrayIndex;
	
	memcpy(buff.lets, pData + arrayIndex, nBytesLeft);
	memcpy(buff.lets + nBytesLeft, paddata, BLOCK - nBytesLeft);
	
	if (isLittleEndian())
	{
		// Perform little endian byte swap
		for (unsigned int i = 0; i < 16; i++)
		{
			ulong tempnum = (buff.nums[i] << 16) | (buff.nums[i] >> 16);
			buff.nums[i] = ((tempnum & 0xff00ff00L) >> 8) |
				((tempnum & 0x00ff00ffL) << 8);
		}
	}
	
	if (nBytesLeft >= 56)
	{
		sha_hash(buff. nums, hash);
		memset(buff.nums, 0, 16 * sizeof(long)); // Clear out nums for last pass
	}
	
	buff.nums[15] = (512 * blocksRead) + (8 * nBytesLeft);
	
	sha_hash(buff.nums, hash);

} // end of hashBuffer()


void sha_init(ulong hash[])
{
	hash[0] = 0x67452301L;
	hash[1] = 0xEFCDAB89L;
	hash[2] = 0x98BADCFEL;
	hash[3] = 0x10325476L;
	hash[4] = 0xC3D2E1F0L;
} // end of sha_init()


#define Ls5(num)  (((num)<<5)|((num)>>27))
#define Ls30(num) (((num)<<30)|((num)>>2))
#define Ls1(num)  ( ( (num) << 1 ) | ( ( (num) >> 31 ) & 1 ) )

#define F0(x,y,z) ( (z) ^ ( (x) & ( (y) ^ (z) ) ) )
#define F1(x,y,z) ( ( (x) & ( (y) ^ (z) ) ) ^ ( (z) & (y) ) )
#define F2(x,y,z) ((x)^(y)^(z))


void sha_hash(ulong M[], ulong hash[])
{
	const long K1 = 0x5A827999L;
	const long K2 = 0x6ED9EBA1L;
	const long K3 = 0x8F1BBCDCL;
	const long K4 = 0xCA62C1D6L;

    ulong   temp;
    ulong   newa, newb, newc, newd, newe;
    ulong   W0,  W1,  W2,  W3,  W4,  W5,  W6,  W7;
    ulong   W8,  W9,  W10, W11, W12, W13, W14, W15;
    ulong   W16, W17, W18, W19, W20, W21, W22, W23;
    ulong   W24, W25, W26, W27, W28, W29, W30, W31;
    ulong   W32, W33, W34, W35, W36, W37, W38, W39;
    ulong   W40, W41, W42, W43, W44, W45, W46, W47;
    ulong   W48, W49, W50, W51, W52, W53, W54, W55;
    ulong   W56, W57, W58, W59, W60, W61, W62, W63;
    ulong   W64, W65, W66, W67, W68, W69, W70, W71;
    ulong   W72, W73, W74, W75, W76, W77, W78, W79;


    W0 = M[0];
    W1 = M[1];
    W2 = M[2];
    W3 = M[3];
    W4 = M[4];
    W5 = M[5];
    W6 = M[6];
    W7 = M[7];
    W8 = M[8];
    W9 = M[9];
    W10 = M[10];
    W11 = M[11];
    W12 = M[12];
    W13 = M[13];
    W14 = M[14];
    W15 = M[15];

    W16 = Ls1(W13 ^ W8 ^ W2 ^ W0);
    W17 = Ls1(W14 ^ W9 ^ W3 ^ W1);
    W18 = Ls1(W15 ^ W10 ^ W4 ^ W2);
    W19 = Ls1(W16 ^ W11 ^ W5 ^ W3);
    W20 = Ls1(W17 ^ W12 ^ W6 ^ W4);
    W21 = Ls1(W18 ^ W13 ^ W7 ^ W5);
    W22 = Ls1(W19 ^ W14 ^ W8 ^ W6);
    W23 = Ls1(W20 ^ W15 ^ W9 ^ W7);
    W24 = Ls1(W21 ^ W16 ^ W10 ^ W8);
    W25 = Ls1(W22 ^ W17 ^ W11 ^ W9);
    W26 = Ls1(W23 ^ W18 ^ W12 ^ W10);
    W27 = Ls1(W24 ^ W19 ^ W13 ^ W11);
    W28 = Ls1(W25 ^ W20 ^ W14 ^ W12);
    W29 = Ls1(W26 ^ W21 ^ W15 ^ W13);
    W30 = Ls1(W27 ^ W22 ^ W16 ^ W14);
    W31 = Ls1(W28 ^ W23 ^ W17 ^ W15);
    W32 = Ls1(W29 ^ W24 ^ W18 ^ W16);
    W33 = Ls1(W30 ^ W25 ^ W19 ^ W17);
    W34 = Ls1(W31 ^ W26 ^ W20 ^ W18);
    W35 = Ls1(W32 ^ W27 ^ W21 ^ W19);
    W36 = Ls1(W33 ^ W28 ^ W22 ^ W20);
    W37 = Ls1(W34 ^ W29 ^ W23 ^ W21);
    W38 = Ls1(W35 ^ W30 ^ W24 ^ W22);
    W39 = Ls1(W36 ^ W31 ^ W25 ^ W23);
    W40 = Ls1(W37 ^ W32 ^ W26 ^ W24);
    W41 = Ls1(W38 ^ W33 ^ W27 ^ W25);
    W42 = Ls1(W39 ^ W34 ^ W28 ^ W26);
    W43 = Ls1(W40 ^ W35 ^ W29 ^ W27);
    W44 = Ls1(W41 ^ W36 ^ W30 ^ W28);
    W45 = Ls1(W42 ^ W37 ^ W31 ^ W29);
    W46 = Ls1(W43 ^ W38 ^ W32 ^ W30);
    W47 = Ls1(W44 ^ W39 ^ W33 ^ W31);
    W48 = Ls1(W45 ^ W40 ^ W34 ^ W32);
    W49 = Ls1(W46 ^ W41 ^ W35 ^ W33);
    W50 = Ls1(W47 ^ W42 ^ W36 ^ W34);
    W51 = Ls1(W48 ^ W43 ^ W37 ^ W35);
    W52 = Ls1(W49 ^ W44 ^ W38 ^ W36);
    W53 = Ls1(W50 ^ W45 ^ W39 ^ W37);
    W54 = Ls1(W51 ^ W46 ^ W40 ^ W38);
    W55 = Ls1(W52 ^ W47 ^ W41 ^ W39);
    W56 = Ls1(W53 ^ W48 ^ W42 ^ W40);
    W57 = Ls1(W54 ^ W49 ^ W43 ^ W41);
    W58 = Ls1(W55 ^ W50 ^ W44 ^ W42);
    W59 = Ls1(W56 ^ W51 ^ W45 ^ W43);
    W60 = Ls1(W57 ^ W52 ^ W46 ^ W44);
    W61 = Ls1(W58 ^ W53 ^ W47 ^ W45);
    W62 = Ls1(W59 ^ W54 ^ W48 ^ W46);
    W63 = Ls1(W60 ^ W55 ^ W49 ^ W47);
    W64 = Ls1(W61 ^ W56 ^ W50 ^ W48);
    W65 = Ls1(W62 ^ W57 ^ W51 ^ W49);
    W66 = Ls1(W63 ^ W58 ^ W52 ^ W50);
    W67 = Ls1(W64 ^ W59 ^ W53 ^ W51);
    W68 = Ls1(W65 ^ W60 ^ W54 ^ W52);
    W69 = Ls1(W66 ^ W61 ^ W55 ^ W53);
    W70 = Ls1(W67 ^ W62 ^ W56 ^ W54);
    W71 = Ls1(W68 ^ W63 ^ W57 ^ W55);
    W72 = Ls1(W69 ^ W64 ^ W58 ^ W56);
    W73 = Ls1(W70 ^ W65 ^ W59 ^ W57);
    W74 = Ls1(W71 ^ W66 ^ W60 ^ W58);
    W75 = Ls1(W72 ^ W67 ^ W61 ^ W59);
    W76 = Ls1(W73 ^ W68 ^ W62 ^ W60);
    W77 = Ls1(W74 ^ W69 ^ W63 ^ W61);
    W78 = Ls1(W75 ^ W70 ^ W64 ^ W62);
    W79 = Ls1(W76 ^ W71 ^ W65 ^ W63);

    newa=hash[0]; newb=hash[1]; newc=hash[2]; newd=hash[3]; newe=hash[4];

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W0+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W1+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W2+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W3+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W4+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W5+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W6+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W7+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W8+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W9+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W10+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W11+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W12+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W13+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W14+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W15+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W16+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W17+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W18+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F0(newb,newc,newd)+newe+W19+K1;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W20+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W21+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W22+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W23+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W24+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W25+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W26+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W27+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W28+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W29+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W30+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W31+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W32+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W33+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W34+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W35+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W36+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W37+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W38+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W39+K2;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W40+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W41+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W42+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W43+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W44+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W45+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W46+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W47+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W48+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W49+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W50+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W51+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W52+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W53+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W54+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W55+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W56+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W57+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W58+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F1(newb,newc,newd)+newe+W59+K3;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W60+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W61+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W62+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W63+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W64+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W65+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W66+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W67+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W68+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W69+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W70+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W71+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W72+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W73+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W74+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W75+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W76+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W77+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W78+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;    newa = temp;

    temp = Ls5(newa)+F2(newb,newc,newd)+newe+W79+K4;
    newe = newd;    newd = newc;
    newc = Ls30(newb);
    newb = newa;

    hash[0] += temp;
    hash[1] += newb;
    hash[2] += newc;
    hash[3] += newd;
    hash[4] += newe;

} // end of sha_hash()



/* Function:  isLittleEndian()
 * This function returns true if the operating system is little-endian
 * or false if it is big-endian.
 */
inline bool isLittleEndian(void)
{
	long value = 1;

	// Check which byte the value 1 is in
	if (*(char *)&value == 1)
		return true;
	else
		return false;
}



// end of CM_Certificate.cpp
