/*****************************************************************************
File:     CM_cache.h
Project:  Certificate Management Library
Contents: Header file for the internal cache classes and functions used in
		  the Certificate Management Library.

Created:  20 October 2000
Author:   Rich Nicholas <Richard.Nicholas@DigitalNet.com>
		  Tom Horvath <Tom.Horvath@DigitalNet.com>

Last Updated:	30 September 2003

Version:  2.3

*****************************************************************************/
#ifndef _CM_CACHE_H_
#define _CM_CACHE_H_

////////////////////
// Included Files //
////////////////////
#include "CM_internal.h"



// Begin CML namespace
namespace CML {

// Begin nested Internal namespace
namespace Internal {



///////////////////////
// Defined Constants //
///////////////////////
const time_t SECONDS_IN_DAY = 60 * 60 * 24;	// Number of seconds in 24 hours
const ushort DEFAULT_CACHE_OBJS	= 100;
const CM_Time kEmpty_CM_Time = "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";

const short CMI_CACHE_MISSING_ISSUER = 2001;


//////////////////////
// Type Definitions //
//////////////////////


/////////////////////////
// Function Prototypes //
/////////////////////////
ASN::CertPolicyList operator&(const ASN::CertPolicyList& lhs,
							  const ASN::OIDList& rhs);
short SearchCRLCache(ulong sessionID, const ASN::DN& issuer,
					 enum ASN::CertType certType, Dist_pts_struct* pDistPt,
					 CRL_struct** ppCRL);


// Forward declarations
class CachedCert;

///////////////////////////////
// PolicyTable class definition
//
// Contains the X.509 authorities-
// constrained-policy-set path
// processing variable
//
class PolicyTable
{
public:
	// Constructor/Destructor
	PolicyTable()							{ m_depth = 0; }

	// Methods
	void Init(int numCerts);
	bool IsEmpty() const;
	bool IsUserPolicySetEmpty(const ASN::OIDList& initialPolicySet) const;
	void GetAuthPolicySet(ASN::CertPolicyList& authSet) const;
	void ProcessMappings(const ASN::PolicyMappingList* pMappings,
		ushort nDepth, bool inhibitMapping,
		ASN::PolicyMappingList& mappingDetails);
	void ProcessPolicies(const ASN::CertPolicyList* pPolicies, ushort nDepth,
		bool inhibitAnyPolicy, bool isSelfIssuedCA);

protected:
	// Internal types
	typedef std::vector<ASN::CertPolicy>	PolicyRow;
	typedef std::vector<PolicyRow>			PolicyArray;

	// Member variables
	PolicyArray	m_table;
	ushort m_depth;
};


////////////////////////////
// Cache class definition //
////////////////////////////
class Cache
{
public:
	enum ObjType {
		CERT,
		CRL,
		TRUSTED_CERT
	};

	struct ObjId
	{
		Bytes_struct hash;
		CM_DN dn;
	};

	// Constructs a Cache object
	Cache(ulong sessionID, ushort maxObjs, time_t timeToLive);

	virtual void Empty(void) = 0;			// Empties the cache

protected:
	// Members
	ulong m_sessionID;			// Handle to the CM session
	ushort m_maxObjs;
	time_t m_timeToLive;
};


// CacheObj class definition
class CacheObj
{
public:
	// Constructor/Destructor
	CacheObj(const ASN::Bytes& encObj);
	// Gets the object's hash value
	const ASN::Bytes& GetHash(void) const				{ return m_hash; }
	// Returns true if the object has expired
	bool IsExpired(void) const;
	// Updates the object's expiration time
	void UpdateExpiration(const ASN::Time* pNewExpireTime, time_t ttl) const;
	const ASN::Time& GetCurrentExpirationTime() const				{ return m_validUntil; }

	// Member
	ASN::ReadWriteMutex m_mutex;			// cached cert/crl mutex used by CachedCertRefs and 
											// CachedCRLRefs for automatic read locking.
	ASN::Mutex			m_internalMutex;	// this mutex was added so that a lock can be
											// acheived among methods that are in this class
											// and any derived classes.

protected:
	// Members
	ASN::Bytes m_hash;				// Hash of encoded object
	mutable ASN::Time m_validUntil;	// Time when object is no longer valid

private:
//	virtual const CM_DN& GetDN(void) = 0;
};

//CachedCertRef - two cache reference classes derive from this base class
class CachedCertRef
{
public:
	// Constructors
	CachedCertRef(const CachedCert& cachedCert);
	CachedCertRef(const CachedCertRef& that);
	// Destructor
	virtual ~CachedCertRef()					{}

	// Conversion operator
	virtual operator const CachedCert&() const	{ return *m_pCert; }

	// Access the cached cert
	virtual const CachedCert& GetRef() const	{ return *m_pCert; }
	// Access the address of the cached cert
	virtual const CachedCert* GetAddr() const	{ return m_pCert; }

protected:
	// Members
	const CachedCert* m_pCert;		// Pointer to cached cert
	ASN::ReadLock m_cachedCertLock;	// Lock for cached cert
};

// InternalCachedCertRef class definition used to reference cached certs in the cert 
// cache itself
class InternalCachedCertRef : public CachedCertRef
{
public:
	// Constructors
	InternalCachedCertRef(const CachedCert& cachedCert);
	InternalCachedCertRef(const InternalCachedCertRef& that);
};

// ExternalCachedCertRef class definition used to reference cached certs in code that is 
// external to the cert cache
class ExternalCachedCertRef : public CachedCertRef
{
public:
	// Constructors
	ExternalCachedCertRef(const CachedCert& cachedCert, const ASN::ReadWriteMutex& cacheMutex);
	ExternalCachedCertRef(const ExternalCachedCertRef& that);

private:
	// Members
	ASN::ReadLock m_certCacheLock;			// Lock for entire cert cache
};


// CachedCertList class definition
class CachedCertList : public std::list<CachedCertRef>
{
public:
	// Assignment operator
	CachedCertList& operator=(const CachedCertList& that);
};


// Other CachedCert type definitions
typedef std::map<ASN::Bytes, CachedCert*> CertHashIndex;
typedef std::multimap<ASN::DN, CachedCert*> CertDNIndex;
typedef std::set<ASN::DN> DnList;


class TentativeCertCache
{
public:
	//Constructor
	TentativeCertCache(ulong sessionID, ushort maxObjs = DEFAULT_CACHE_OBJS);
	~TentativeCertCache(void);

	const CachedCertRef* Add(const Certificate& tentativeCert,
		const CachedCertList& issuerCerts, const PolicyTable& authSet,
		const ASN::PolicyMappingList& mappings, bool explicitPolFlag,
		const ASN::Time& expireTime);
	CachedCertRef* FindCert(const Certificate& cert) const;
	void MoveValidCertsToSessionCache();

	// Empties the cert cache
	void Purge(void);

private:
	ushort m_maxObjs;						// Overall cache size
	ushort m_nCerts;						// Number of certs in cache
	CertHashIndex m_certsByHash;			// Certs sorted by hash
	CertDNIndex m_certsByDN;				// Certs sorted by DN
	CachedCert** m_certs;					// Certs ordered by MRU
	ulong m_sessionID;						// Session ID
};

// CertCache class definition
class CertCache : public Cache
{
public:
	// Constructors/Destructor
	CertCache(ulong sessionID, ushort maxObjs = DEFAULT_CACHE_OBJS,
		time_t timeToLive = SECONDS_IN_DAY);
	virtual ~CertCache(void);

	// Adds a validated cert to the cache
	const CachedCertRef* Add(const Certificate& validCert,
		const CachedCertList& issuerCerts, const PolicyTable& authSet,
		const ASN::PolicyMappingList& mappings, bool explicitPolFlag,
		const ASN::Time& expireTime, bool isIssuer = false);

	// Checks if a cert is in the cache
//	bool IsCached(Cache::ObjType type, const ASN::Bytes& hash,
//		const ASN::DN& dn, ValidatedKey* pValidKey = NULL,
//		CertPtrList* pPath = NULL) const;

	// Checks if the target cert is in the cache and signed by the issuer
	bool IsCached(const Certificate& target, const Certificate& issuer) const;

	// Checks if the DN matches the DN of one of the trust anchors
	bool IsDnTrusted(const ASN::DN& dn);

	// Empties the cert cache
	void Empty(void);

	// Finds all cached certs with the specified subject DN
	const CachedCertList* Find(const ASN::DN& subjectDN) const;

	// Finds a cert in the cache using its ASN.1 encoded form
	const CachedCertRef* FindCert(const ASN::Bytes& encCert) const;


protected:
	// Members
	CertHashIndex m_certsByHash;			// Certs sorted by hash
	CertDNIndex m_certsByDN;				// Certs sorted by DN
	ushort m_nMRUCerts;						// Number of certs in MRU queue
	CachedCert** m_mruQueue;				// Certs ordered by MRU
	DnList m_trustAnchors;					// List of DNs of the trust anchors
	ASN::ReadWriteMutex m_CertCacheMutex;	// Mutex used only by Cert Cache methods
	ASN::ReadWriteMutex m_ExternalRefMutex;	// Mutex for External Cached Cert Refs


private:
	// Empty the entire cert cache (including the trusted certs)
	void EmptyEntireCache(void);

	// Finds a cert in the cache using the hash value
	const CachedCertRef* FindCertByHash(const ASN::Bytes& hash, bool isIssuer) const;

	// Load the list of trusted certs into the cache
	short LoadTrustedCerts(CM_TOKEN_TYPE *pTokObj, const EncCert_LL* trustedCerts,
		ErrorInfo_List** errInfo = NULL);
	short LoadTrustAnchors(CM_TOKEN_TYPE *pTokObj, const TrustAnchorList& trustAnchors,
		ErrorInfoList* pErrInfo = NULL);

	// Load a single trusted cert into the cache
	short LoadTrustAnchor(CM_TOKEN_TYPE *pTokObj, const TrustAnchor& trustAnchor,
		ErrorInfoList* pErrList);

	// Removes this cached cert from the cache and indices - 
	// callers of this method *MUST* lock the cert cache mutex before calling this method!!!
	void Remove(const CachedCert* pCachedCert, bool removeFromMruQueue = true);

	// Removes the least used unreferenced cert in the cache
	bool RemoveLeastUsed(void);

	// Sets this cached cert as the most recently used
	bool SetAsMRU(const CachedCertRef& pCachedCert) const;

	// Finds a cert in the cache using its ASN.1 encoded form
	const CachedCertRef* FindCert(const ASN::Bytes& encCert,
		bool isIssuer) const;

	// Adds a cert that is already in CachedCert form
	void Add(CachedCert* pCacheCert);

	// Friend functions
	friend short CML::SetTrustedCerts(ulong sessionID,
		const ASN::BytesList& trustedCerts, ErrorInfoList* pErrInfo);
	friend short CML::SetTrustAnchors(ulong sessionID,
		const TrustAnchorList& trustAnchors, ErrorInfoList* pErrInfo);
	friend short ::CM_SetTrustedCerts(ulong sessionID,
		EncCert_LL* trustedCerts, ErrorInfo_List** errInfo);
	friend SrlSession::SrlSession(CM_TOKEN_TYPE *pTokObj, CallbackFunctions& cmlFuncs,
		CertCache* pCertCache);
	friend void Session::Initialize(ulong sessionID,
		const InitSettings_struct& settings);
	friend void TentativeCertCache::MoveValidCertsToSessionCache();
};


// CachedCert class definition
class CachedCert : public CacheObj, public Certificate
{
public:
	// Constructs this validated certificate object
	static CachedCert* Construct(const ASN::Bytes& encCert,
		const CachedCertList& issuerCerts, const PolicyTable& authSet,
		const ASN::OIDList& initialPolicySet,
		const ASN::PolicyMappingList& mappings, bool requireExplicitPolicy,
		const ASN::Time& expireTime, time_t maxTTL);
	virtual ~CachedCert(void);

	// Returns true if the cached cert is trusted
	bool IsTrusted(void) const				{ ASN::MutexLock lock = this->m_internalMutex.AcquireLock(); return (m_pPathResults == NULL); }

	// Copies the cached path into the CertPtrList
//	void ExportPath(CertPtrList& path) const;

	// Copies the cached path results (and public key parameters if necessary)
	// into the ValidKey_struct
	void ExportPathResults(ValidatedKey& validKey) const;

	// Get the cached path
	const CachedCertList& GetPath() const				{ return m_path; }

	// Builds an upside-down CertTree_LL from the cached path
//	short GetCertTree(CertTree_LL** ppTree) const;

	// Returns a reference to the cached issuer cert
	//const CachedCertRef* GetIssuer(void) const;

	// Gets the ASN.1 encoded cert
	const ASN::Bytes& GetEncCert() const				{ ASN::MutexLock lock = m_internalMutex.AcquireLock(); return encCert; }

	// Updates the path processing results and issuer certs
	void UpdatePathResults(const CachedCertList& issuerCerts,
		const PolicyTable& authSet, const ASN::OIDList& initialPolicySet,
		const ASN::PolicyMappingList& mappings, bool requireExplicitPolicy) const;

	// Releases the references to the issuer certs
	void ReleaseIssuers(void) const;

	// Comparison operator
//	bool operator==(const Bytes_struct& that)		{ return (encCert == that); }

	// Friends
	friend short CertCache::LoadTrustAnchor(CM_TOKEN_TYPE *pTokObj, const TrustAnchor& trustAnchor,
		ErrorInfoList* pErrList);

	//Members
	short maxPathLen;							// Maximum length of paths (only for TrustAnchors)
	ASN::NameConstraintsExtension names;		// Name constraints for paths (only for TrustAnchors)

private:
	// Private constructor
	CachedCert(const ASN::Bytes& encCert);
	// Constructs this trusted certificate object
	static CachedCert* Construct(CM_TOKEN_TYPE *pTokObj,
		const TrustAnchor& trustedCert, ErrorInfoList* pErrInfo = NULL);
	// Finds and copies the parameters from the path for the specified OID
	CTIL::CSM_Buffer* GetPubKeyParameters(const char* pkOID) const;


	// Gets the cert's subject DN
//	const CM_DN& GetDN(void)				{ return subject; }

	// Members
	mutable PathOutputs* m_pPathResults;		// Results of validating this cert
	mutable CachedCertList m_path;				// Issuer certs
};


// CachedCRL class definition
class CachedCRL : public CacheObj, public ASN::CertificateList
{
public:
	// Construct a validated CRL
	CachedCRL(const CML::CRL& validCRL, const ASN::GenName& distPtName,
		const ASN::Time* pExpireTime, time_t maxTTL);
	// Destructor
	virtual ~CachedCRL()	{ ASN::MutexLock lock = m_mutex.AcquireLock(); }

	// Member variable
	const ASN::GenName m_distPtName;		// GenName where CRL was stored
};

// Other CachedCRL type definitions
typedef std::list<const CachedCRL*> CachedCrlList;
typedef std::map<ASN::Bytes, CachedCRL*> CrlHashIndex;
typedef std::multimap<ASN::GenName, CachedCRL*> CrlGNIndex;

class TentativeCRL : public CachedCRL
{
public:
	// Constructor
	TentativeCRL(const CML::CRL& crl, const ASN::GenName& distPtName);

	void ClearErrors()						{ m_errors.clear(); }
	bool HasErrors() const					{ return !m_errors.empty(); }
	const ErrorInfoList& GetErrors()		{ return m_errors; }
	void SetErrors(ErrorInfoList& errors);

private:	
	ErrorInfoList m_errors;
};

typedef std::map<ASN::Bytes, TentativeCRL*> TentativeCrlHashIndex;
typedef std::multimap<ASN::GenName, TentativeCRL*> TentativeCrlGNIndex;


class TentativeCRLCache
{
public:
	// Constructor/Destructor
	TentativeCRLCache(ulong sessionID) : m_sessionID(sessionID)			{}
	~TentativeCRLCache();

	TentativeCRL* Add(const CRL& crl, const ASN::GenName& distPtName);
	TentativeCRL* Find(const ASN::Bytes& encCRL) const;
	void MoveValidCRLsToSessionCache();

	// Remove only CRLs that do not have errors
	void Purge();							

private:
	TentativeCrlHashIndex m_crlsByHash;		// CRLs sorted by hash
	TentativeCrlGNIndex m_crlsByGN;			// CRLs sorted by GenName
	ulong m_sessionID;						// session ID
};



// CrlCache class definition
class CrlCache : public Cache
{
public:
	// Constructors/Destructor
	CrlCache(ulong sessionID, ushort maxObjs = DEFAULT_CACHE_OBJS,
		time_t timeToLive = SECONDS_IN_DAY);
	virtual ~CrlCache(void);

	// Adds a validated CRL to the cache
	const CachedCRL* Add(const CML::CRL& validCRL, const ASN::GenName& distPtName,
		const ASN::Time* pExpireTime = NULL);

	// Checks if a CRL is in the cache
	bool IsCached(const ASN::Bytes& hash);

	// Empties the CRL cache
	void Empty(void);

	// Finds all cached CRLs from the specified distribution point
	CachedCrlList* Find(const ASN::GenName& distPtName,
		CachedCrlList* pPrevList = NULL) const;

	// Finds a CRL in the cache using its ASN.1 encoded form 
	// This method will lock the mutex, so only call externally
	CachedCRL* FindCRL(const ASN::Bytes& encCRL);

protected:
	// Members
	ushort m_nMRUCrls;				// Number of CRLs in MRU queue
	CachedCRL** m_crls;				// CRLs ordered by MRU
	CrlHashIndex m_crlsByHash;		// CRLs sorted by hash
	CrlGNIndex m_crlsByGN;			// CRLs sorted by GenName
	ASN::Mutex m_mutex;				// Mutex for entire CRL cache

private:
	// Finds a CRL in the cache using the hash value
	CachedCRL* FindCrlByHash(const ASN::Bytes& hash) const;

	// Finds a CRL in the cache using its ASN.1 encoded form
	// This method will not lock the mutex so only use internally when caller
	// locks the mutex first.
	CachedCRL* PrivateFindCRL(const ASN::Bytes& encCRL);

	// Removes this cached CRL from the cache and indices
	void Remove(CachedCRL* pCachedCRL, bool removeFromMruQueue = true);

	// Removes the least used CRL in the cache
	bool RemoveLeastUsed(void);

	// Sets this cached CRL as the most recently used
	bool SetAsMRU(CachedCRL* pCachedCRL) const;

	// Adds a valid CRL from the tentatively-valid CRL cache, returns true if
	// successfully added
	bool Add(TentativeCRL* pCRL);

	friend void TentativeCRLCache::MoveValidCRLsToSessionCache();
};


} // end of nested Internal namespace
} // end of CML namespace



#endif /* _CM_CACHE_H_ */
