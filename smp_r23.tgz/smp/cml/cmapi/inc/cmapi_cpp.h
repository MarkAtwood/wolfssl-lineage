/*****************************************************************************
File:     cmapi_cpp.h
Project:  Certificate Management Library
Contents: Header file for the C++ interface to the X.509 Certificate
		  Management Library

Created:  12 July 2001
Author:   Rich Nicholas <Richard.Nicholas@DigitalNet.com>

Last Updated:	30 September 2003

Version:  2.3

*****************************************************************************/
#ifndef _CMAPI_CPP_H
#define _CMAPI_CPP_H


////////////////////
// Included Files //
////////////////////
#ifdef _MSC_VER
	#pragma warning(disable: 4786)	// Disable identifier truncated warning
	#pragma warning(push, 3)
	#pragma warning(disable: 4018)	// Disable signed/unsigned mismatch warning
	#pragma warning(disable: 4146)	// Disable unary minus operator warning
	#include <map>
 	#pragma warning(pop)
	#pragma warning(disable: 4275)	// Disable unexported template warnings
#else
	#include <string>
	#include <map>
#endif
#include "cmlasn.h"
#include "cmapi.h"


// Begin CML namespace
namespace CML {


// Forward class declarations
class Certificate;
namespace Internal {
	class PathState;
	class PathStack;
	class CachedCert;
	class CertAndParams;
	class TentativeCRLCache;
}


////////////////////////////////
// Exception class definition //
////////////////////////////////
class CM_API Exception : public SNACC::SnaccException
{
public:
	// Construct from an error code, file name, line number
	Exception(short errCode, const char* fileName, long lineNum);

	// Convert the exception to its CML equivalent error code
	operator short() const								{ return error; }

	// Get the error string
	virtual const char* what() const throw();

protected:
	short error;
};


////////////////////////////////
// ErrorInfo class definition //
////////////////////////////////
class CM_API ErrorInfo
{
public:
	// Default constructor
	ErrorInfo();
	// Construct from an error code, DN, and optionally extra information
	ErrorInfo(short errCode, const ASN::DN& dn, const char* optInfo = NULL);
	// Construct from an error code, CML::Certificate, and optionally extra
	// information
	ErrorInfo(short errCode, const ASN::Cert& cert,
		const char* optInfo = NULL);

	// Convert the ErrorInfo to its equivalent ErrorInfo_List C structure
	operator ErrorInfo_List*() const;

	// Comparison operators
	bool operator==(const ErrorInfo& rhs) const;
	bool operator!=(const ErrorInfo& rhs) const		{ return !operator==(rhs); }
	bool operator<(const ErrorInfo& rhs) const;

	// Members
	short			error;		// Extended error code
	ASN::GenNames	name;		// Subject name(s) of certificate or issuer
								// name(s) of CRL that caused the error
	std::string		extraInfo;	// Optional info specific to the error code
};


////////////////////////////////////
// ErrorInfoList class definition //
////////////////////////////////////
class CM_API ErrorInfoList : public std::list<ErrorInfo>
{
public:
	// Add an error to the set of errors, return true if added
	bool AddError(short errCode, const ASN::DN& dn,
		const char* optInfo = NULL);
	bool AddError(short errCode, const ASN::Cert& subjCert,
		const char* optInfo = NULL);
	bool AddError(ASN::Revocations::const_iterator iRevEntry,
		const ASN::Cert& revokedCert);
	
	// Insert another list of errors into this list
	void Insert(const ErrorInfoList& other);

	// Splice another list of errors into this list
	void Splice(iterator it, ErrorInfoList& other);

	// Convert the error list to its C form
	operator ErrorInfo_List*() const;
};


///////////////////////////////////
// ValidatedKey class definition //
///////////////////////////////////
class CM_API ValidatedKey
{
public:
	// Default constructor
	ValidatedKey();
	// Construct from a CMAPI ValidKey_struct
	ValidatedKey(const ValidKey_struct& valKey);
	// Copy constructor
	ValidatedKey(const ValidatedKey& that);
	// Destructor
	virtual ~ValidatedKey();

	// Assignment operator
	ValidatedKey& operator=(const ValidatedKey& that);

	// Access the validated public key info
	const ASN::PublicKeyInfo& pubKeyInfo() const		{ return m_pubKeyInfo; }
	// Clear the contents of this validated public key
	void Clear();
	// Get the CMAPI ValidKey_struct form
	ValidKey_struct* GetValidKeyStruct() const;
	// Return true if no key is present
	bool IsEmpty() const;

	// Member variables
	ASN::CertPolicyList authPolicies;		// Set of authority-contrained policies
	ASN::CertPolicyList userPolicies;		// Set of user-contrained policies
	bool explicitPolicyFlag;				// Indicates if each cert must contain
											//    an acceptable policy
	ASN::PolicyMappingList mappings;		// Policy mapping details
	ASN::KeyUsageExtension* pKeyUsage;		// Key usage restrictions
	ASN::ExtKeyUsageExtension* pExtKeyUsage;// Extended key usage restrictions

private:
	// Private member variables
	ASN::PublicKeyInfo m_pubKeyInfo;		// Validated public key 

	// Friends
	friend class Certificate;
	friend class CertPath;
	friend class Internal::PathState;
	friend class Internal::CachedCert;
	friend class Internal::CertAndParams;
};


/////////////////////////////////
// Certficate class definition //
/////////////////////////////////
class CM_API Certificate : protected ASN::Cert
{
public:
	// Construct from an ASN::Cert
	Certificate(const ASN::Cert& cert);
	// Construct from an ASN.1 encoded certificate
	Certificate(const ASN::Bytes& asn);
	// Construct from an ASN.1 encoded certificate
	Certificate(const Bytes_struct& asn);

	// Assignment operators
	Certificate& operator=(const ASN::Cert& cert);	// Assign from an ASN::Cert
	Certificate& operator=(const ASN::Bytes& asn);	// Assign from an ASN.1 encoded certificate

	// Access the decoded certificate
	const ASN::Cert& base() const						{ return *this; }
	// Access the encoded certificate
	const ASN::Bytes& GetEnc() const					{ return encCert; }

	// Decode from an ASN.1 encoded certificate
	virtual ulong Decode(const ASN::Bytes& asn);
	// Encode this certificate
	virtual ulong Encode(ASN::Bytes& asn) const;
#ifdef _SM_APICTILMGR_H_
	// Sign this certificate
	short Sign(CTIL::CSM_CtilInst& keyHandle,
		const ASN::AlgID* pSigAlg = NULL);
#endif
	// Validate this certificate
	short Validate(ulong sessionID, SearchBounds boundsFlag,
		ErrorInfoList* pErrors = NULL, ValidatedKey* pValidKey = NULL) const;
	// Verify the signature on this certificate
	short VerifySignature(ulong sessionID, const ValidatedKey& signersKey) const;
	short VerifySignature(ulong sessionID, SearchBounds boundsFlag,
		Certificate& signersCert) const;

protected:
	short VerifySignature(ulong sessionID, const ASN::PublicKeyInfo& publicKey,
		const CTIL::CSM_Buffer* parameters = NULL) const;

	ASN::Bytes encCert;				// Encoded cert
};


//////////////////////////
// CRL class definition //
//////////////////////////
class CM_API CRL : protected ASN::CertificateList
{
public:
	// Construct from an ASN::CertificateList
	CRL(const ASN::CertificateList& crl);
	// Construct from an ASN.1 encoded CRL
	CRL(const ASN::Bytes& asn);

	// Assignment operators
	CRL& operator=(const ASN::CertificateList& crl);	// Assign from an ASN::CertificateList
	CRL& operator=(const ASN::Bytes& asn);				// Assign from an ASN.1 encoded CRL

	// Conversion operator to access the encoded CRL
	operator const ASN::Bytes&() const					{ return encCrl; }

	// Access the base form of this CRL
	const ASN::CertificateList& base() const			{ return *this; }

	// Decode from an ASN.1 encoded CRL
	virtual ulong Decode(const ASN::Bytes& asn);
	// Encode this CRL
	virtual ulong Encode(ASN::Bytes& asn) const;
#ifdef _SM_APICTILMGR_H_
	// Sign this CRL
	short Sign(CTIL::CSM_CtilInst& keyHandle,
		const ASN::AlgID* pSigAlg = NULL);
#endif
	// Validate this CRL using the optional signer's certificate
	short Validate(ulong sessionID, SearchBounds boundsFlag,
		ErrorInfoList* pErrors = NULL, const Certificate* pSigner = NULL,
		bool tryOtherSigners = false);
	// Validate this CRL using the issuer's validated public key
	short Validate(ulong sessionID, const ValidatedKey& issuersKey,
		ErrorInfoList* pErrors = NULL) const;
	// Verify the signature on this CRL
	short VerifySignature(ulong sessionID, const ValidatedKey& signersKey) const;

protected:
	ASN::Bytes encCrl;				// Encoded CRL
};


///////////////////////////////
// CertPath class definition //
///////////////////////////////
class CM_API CertPath : protected ASN::CertificationPath
{
public:
	// Default constructor
	CertPath();
	// Construct from a subject cert
	CertPath(const Certificate& subject);
	// Construct from an ASN::CertificationPath
	CertPath(const ASN::CertificationPath& certPath);
	// Construct from an ASN.1 encoded CertificationPath or Certificate
	CertPath(const ASN::Bytes& asn, bool isCertPath = true);
	// Copy constructor
	CertPath(const CertPath& other);
	// Destructor
	virtual ~CertPath();

	// Assignment operators
	CertPath& operator=(const ASN::CertificationPath& certPath);// Assign from an ASN::CertificationPath
	CertPath& operator=(const ASN::Bytes& asn);					// Assign from an ASN.1 encoded CertificationPath
	CertPath& operator=(const CertPath& other);					// Assign from another CertPath

	// Access the base class form of this cert path
	const ASN::CertificationPath& base() const			{ return *this; }

	// Access the encoded user cert and CA certs
	const ASN::Bytes& GetEncUserCert() const			{ return encUserCert; }
	const ASN::BytesList& GetEncCACerts() const			{ return encCACerts; }

	// Build a path to a trusted cert
	short Build(ulong sessionID, SearchBounds boundsFlag, float minProb = 0,
		ErrorInfoList* pErrors = NULL);
	// Build another path using the previous values
	short BuildNext(float minProb = 0, ErrorInfoList* pErrors = NULL);
	// Build and validate paths until a valid path is found
	short BuildAndValidate(ulong sessionID, SearchBounds boundsFlag,
		ErrorInfoList* pErrors = NULL, float minProb = 0,
		ValidatedKey* pValidKey = NULL);
	// Decode from an ASN.1 encoded CertPath
	virtual ulong Decode(const ASN::Bytes& asn);
	// Encode this CertPath
	virtual ulong Encode(ASN::Bytes& asn) const;
	// Validate the current path
	short Validate(ErrorInfoList* pErrors = NULL,
				   ValidatedKey* pValidKey = NULL) const;

protected:
	ASN::Bytes encUserCert;			// Encoded subject certificate
	ASN::BytesList encCACerts;		// Encoded CA certs

private:
	Internal::PathState* state;		// Path state variable
	Internal::PathStack* curPath;	// CertPath kept as BaseNode pointers

	void SetPathFromState();
};


///////////////////////////////////
// SignedAsnObj class definition //
///////////////////////////////////
class CM_API SignedAsnObj
{
public:
	// Construct from a SIGNED ASN.1 encoded object
	SignedAsnObj(const ASN::Bytes& asn);
	// Construct from an ASN.1 encoded object to be signed and an algorithm
	SignedAsnObj(const ASN::Bytes& asn, const ASN::AlgID& sigAlg);
	// Destructor
	virtual ~SignedAsnObj()										{}

	// Assign from a SIGNED ASN.1 encoded object
	SignedAsnObj& operator=(const ASN::Bytes& asn);

	// Decode from a SIGNED ASN.1 encoded object
	virtual ulong Decode(const ASN::Bytes& asn);
	// Encode this object
	virtual ulong Encode(ASN::Bytes& asn) const;
#ifdef _SM_APICTILMGR_H_
	// Sign the object
	short Sign(CTIL::CSM_CtilInst& keyHandle,
		const ASN::AlgID* pSigAlg = NULL);
	// Verify the object's signature
	short VerifySignature(CTIL::CSM_CtilMgr& tokenMgr,
		const ASN::PublicKeyInfo& publicKey,
		const CTIL::CSM_Buffer* parameters = NULL) const;
#endif
	// Verify the object's signature
	short VerifySignature(ulong sessionID,
		const ValidatedKey& signersKey) const;
	short VerifySignature(ulong sessionID, const ASN::PublicKeyInfo& publicKey,
		const CTIL::CSM_Buffer* parameters = NULL) const;
	short VerifySignature(ulong sessionID, SearchBounds boundsFlag,
		const Certificate& signersCert, ErrorInfoList* pErrors = NULL) const;

protected:
	CTIL::CSM_Buffer m_sigData;		// Signed data
	ASN::AlgID m_sigAlg;			// Signature algorithm
	CTIL::CSM_Buffer m_sigValue;	// Signature value
};


//////////////////////////////////
// TrustAnchor class definition //
//////////////////////////////////
class CM_API TrustAnchor
{
public:
	// Construct from a trusted certificate and indicate if the extensions
	// in the certificate should be used as constraints
	TrustAnchor(const ASN::Bytes& encCert, bool useExts = false);
	TrustAnchor(const ASN::Cert& cert, bool useExts = false);
	// Construct from a trusted public key, DN, and optional key identifier
	TrustAnchor(const ASN::PublicKeyInfo& key, const ASN::DN& dn,
		const ASN::SubjKeyIdExtension* pSubjKeyIdExt = NULL);

	// Conversion operator
	operator const ASN::Bytes&() const		{ return m_encCert; }

	// Comparison operators
	bool operator==(const TrustAnchor& rhs) const	{
		return (m_encCert == rhs.m_encCert); }
	bool operator!=(const TrustAnchor& rhs) const	{
		return (m_encCert != rhs.m_encCert); }
	bool operator<(const TrustAnchor& rhs) const	{
		return (m_encCert < rhs.m_encCert); }

	// Members
	short maxPathLen;						// Maximum length of paths
	ASN::NameConstraintsExtension names;	// Name constraints for paths

protected:
	ASN::Bytes m_encCert;					// Encoded trusted certificate
};


//////////////////////////////////////
// TrustAnchorList class definition //
//////////////////////////////////////
class TrustAnchorList : public std::list<TrustAnchor>
{
public:
	// Default constructor
	CM_API TrustAnchorList()										{}
	// Construct from a list of encoded trusted certificates
	CM_API TrustAnchorList(const ASN::BytesList& trustedCerts)	{
		operator=(trustedCerts); }

	// Assign from a list of encoded trusted certificates
	CM_API TrustAnchorList& operator=(const ASN::BytesList& trustedCerts);
};


//////////////////////
// Type Definitions //
//////////////////////
struct CertMatchData
{
	const SNACC::AsnOid*	pPubKeyOID;		// Public key algorithm
	const ASN::Time*		pValidOnDate;	// Cert valid on this date
	const ASN::DN*			pIssuer;		// DN of the certificate issuer
	const char*				emailAddr;		// Subject's e-mail address
	const SNACC::AsnInt*	pSerialNum;		// Serial number of the cert
	const ASN::OIDList*		pPolicies;		// Acceptable certificate policies
	const SNACC::AsnOcts*	pSubjKeyID;		// Subject key identifier
	bool					canSignCerts;	// Must have keyCertSign key usage
	bool					canSignCRLs;	// Must have cRLSign key usage
};

struct CRLMatchData
{
	const SNACC::AsnOid*	pSignature;		// Algorithm used to sign CRL
	const ASN::Time*		pIssuedAfter;	// Issued on or after this date
	const ASN::Time*		pIssuedBefore;	// Issued on or before this date
	bool					onlyOne;		// When true, only one CRL returned
};



/////////////////////////
// Function Prototypes //
/////////////////////////
CM_API short RequestCerts(ulong sessionID, ASN::BytesList& certificateList,
						  const ASN::DN& subject,
						  SearchBounds boundsFlag = CM_SEARCH_UNTIL_FOUND,
						  const CertMatchData* pMatchInfo = NULL);
CM_API short RequestCRLs(ulong sessionID, ASN::BytesList& crlList,
						 const ASN::DN* pIssuer,
						 SearchBounds boundsFlag = CM_SEARCH_UNTIL_FOUND,
						 const CRLMatchData* pMatchInfo = NULL,
						 const ASN::DistributionPoint* pDistPoint = NULL);
CM_API void SetPolicy(ulong sessionID, const ASN::OIDList& policies =
					  ASN::OIDList(1, SNACC::anyPolicy),
					  bool requireExplicitPolicy = false,
					  bool inhibitPolicyMapping = false,
					  bool inhibitAnyPolicy = false);
CM_API short SetTrustedCerts(ulong sessionID,
							 const ASN::BytesList& trustedCerts,
							 ErrorInfoList* pErrInfo = NULL);
CM_API short SetTrustAnchors(ulong sessionID,
							 const TrustAnchorList& trustAnchors,
							 ErrorInfoList* pErrInfo = NULL);


} // end of CML namespace


#endif // _CMAPI_CPP_H
