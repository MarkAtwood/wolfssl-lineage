/*************************************************************************
File:     CM_internal.h
Project:  Certificate Management Library
Contents: Header file for the internal (low-level) functions used in the
          Certificate Management Library

Created:  4 April 1997
Author:   Rich Nicholas <Richard.Nicholas@DigitalNet.com>

Last Updated:  1 October 2003

Version:  2.3

*****************************************************************************/
#ifndef _CM_INTERNAL_H
#define _CM_INTERNAL_H

/* -------------- */
/* Included Files */
/* -------------- */
#ifdef _MSC_VER
	#pragma warning(disable: 4702)	// Disable unreachable code warning
	#pragma warning(disable: 4710)	// Disable function not inlined warning
	#pragma warning(disable: 4786)	// Disable identifier truncated warning
	#pragma warning(push, 3)		// Set warning level to 3 for STL headers
	#include <set>
	#pragma warning(pop)			// Reset warning level
	#pragma warning(disable: 4018)	// Disable signed/unsigned mismatch warning
	#pragma warning(disable: 4146)	// Disable unary minus operator warning
#else
	#include <set>
#endif
#include "sm_apiCtilMgr.h"
#include "cmlasn.h"

// Set Windows export declaration so data and functions are exported
#ifdef WIN32
	#undef CM_API
	#define CM_API	__declspec(dllexport)
#endif

#include "cmapi_cpp.h"



// Begin CML namespace
namespace CML {

// Begin nested Internal namespace
namespace Internal {

///////////////////////////////////////////////////////////////////////////
// DLL Names for crypto libs needed by the CML at session initialization //
///////////////////////////////////////////////////////////////////////////
#ifdef _UNIX				
#ifdef _DEBUG

#define CRYPTOPP_CTIL_NAME "libsm_free3DLL_d"	/* Crypto++ CTIL */
#define MSCAPI_CTIL_NAME ""						/* Microsoft CAPI CTIL */
#define PKCS11_CTIL_NAME "libsm_pkcs11DLL_d"	/* PKCS #11 CTIL */
#define BSAFE_CTIL_NAME "libsm_rsaDLL_d"		/* RSA BSAFE CTIL */

#else // _DEBUG

#define CRYPTOPP_CTIL_NAME "libsm_free3DLL"
#define MSCAPI_CTIL_NAME ""
#define PKCS11_CTIL_NAME "libsm_pkcs11DLL"
#define BSAFE_CTIL_NAME "libsm_rsaDLL"

#endif // _DEBUG				
#else //_UNIX	
#ifdef _DEBUG

#define CRYPTOPP_CTIL_NAME "sm_free3DLLd"
#define MSCAPI_CTIL_NAME "sm_capiDLLd"
#define PKCS11_CTIL_NAME "libsm_pkcs11DLLd"
#define BSAFE_CTIL_NAME "sm_rsaDLLd"

#else // _DEBUG

#define CRYPTOPP_CTIL_NAME "sm_free3DLL"
#define MSCAPI_CTIL_NAME "sm_capiDLL"
#define PKCS11_CTIL_NAME "libsm_pkcs11DLL"
#define BSAFE_CTIL_NAME "sm_rsaDLL"

#endif // _DEBUG				
#endif // _UNIX


//////////////////////
// Exception Macros //
//////////////////////
#define CML_ERR(err)			Exception(err, __FILE__, __LINE__)
#define CML_MEMORY_ERR			CML_ERR(CM_MEMORY_ERROR)



///////////////////////
// Defined Constants //
///////////////////////
const ulong UNIV_CONS_SEQ_TAG = MAKE_TAG_ID (SNACC::UNIV, SNACC::CONS,
											 SNACC::SEQ_TAG_CODE);
const ulong CNTX_CONS_ZERO_TAG = MAKE_TAG_ID (SNACC::CNTX, SNACC::CONS, 0);
const ulong CNTX_CONS_ONE_TAG = MAKE_TAG_ID (SNACC::CNTX, SNACC::CONS, 1);



//////////////////////
// Type Definitions //
//////////////////////
typedef std::set<CML::ASN::Bytes> BytesSet;
typedef std::list<const CML::Certificate*> CertPtrList;

class PolicySettings
{
public:
	PolicySettings()
	{
		policyList = ASN::OIDList(1, SNACC::anyPolicy);
		requirePolicy = inhibitMapping = inhibitAnyPolicy = false;
	}

	// Member variables
	ASN::OIDList policyList;	// Initial-policy-set
	bool requirePolicy;			// Initial-explicit-policy indicator
	bool inhibitMapping;		// Initial-inhibit-policy-mapping indicator
	bool inhibitAnyPolicy;		// Initial-inhibit-any-policy indicator
};


class PathOutputs
{
public:
	PathOutputs()				{ pParams = NULL; explicitPolicyFlag = false; }
	~PathOutputs()				{ delete pParams; }

	// Member variables
	ASN::CertPolicyList authPolicies;
	ASN::CertPolicyList userPolicies;
	ASN::PolicyMappingList mappings;
	bool explicitPolicyFlag;
	CTIL::CSM_Buffer* pParams;
};


class CallbackFunctions
{
public:
	CallbackFunctions()
		{ extHandle = NULL; pGetObj = NULL; pFreeObj = NULL; pUrlGetObj = NULL;}

	// Member variables
	void				*extHandle;		// Handle to external library for callbacks
	ExtGetObjFuncPtr	pGetObj;		// External get callback function
	ExtFreeObjFuncPtr	pFreeObj;		// External free callback function
	ExtUrlGetObjFuncPtr	pUrlGetObj;		// External URL get callback function
};


// Forward class declarations
class CertCache;
class CrlCache;
class SrlSession;
// Function Prototype
ASN::ReadLock AcquireSessionReadLock(ulong sessionID);

// Session settings
class Session
{
public:
	// Constructor/Destructor
	Session();
	~Session();

	// Copy constructor 
	Session(const Session& that);

	// Methods
	void Initialize(ulong sessionID, const InitSettings_struct& settings);
	ushort GetMaxPaths() const				{ return nMaxPaths; }
	// Get the Callback functions
	const CallbackFunctions &GetFunc() const	{ return func; }
	// Get the Token Object
	CM_TOKEN_TYPE *GetTokenObj() const	{ return pTokenObj; }
	// Get the Revocation Policy
	RevocationPolicy GetRevPolicy() const	{ return revPolicy; }
	// Get the RAM Cert Cache
	CertCache *GetCertCache() const	{ return pCertCache; }
	// Get the RAM Crl Cache
	CrlCache *GetCrlCache() const	{ return pCrlCache; }
	// Get the Srl Session
	SrlSession *GetSrlSession() const	{ return pSRL; }
	// Get the Policy Settings
	const PolicySettings &GetPolicySettings() const  { return policySettings; }
	// Set the Policy Settings
	void SetPolicySettings(const ASN::OIDList &polList, bool reqPolicy,
									bool inhibitMap, bool inhibitAnyPol);
private:
	// Member variables
	CallbackFunctions	func;			// Callback functions
	CM_TOKEN_TYPE*		pTokenObj;		// Pointer to crypto token object
	bool				tokenFlag;		// Flag indicating CML created token object
	RevocationPolicy	revPolicy;		// Current revocation policy
	CertCache*			pCertCache;		// The RAM cert cache
	CrlCache*			pCrlCache;		// The RAM CRL cache
//	char**				trustedDNs;		// Not used anymore  **LTV**
	PolicySettings		policySettings;	// Current initial policy settings
	SrlSession*			pSRL;			// Optional SRL session object
	ushort				nMaxPaths;		// Maximum number of paths to try and build
	ASN::ReadWriteMutex	mMutex;			// Mutex for thread-safe code
	
	// Friend functions
	friend ASN::ReadLock AcquireSessionReadLock(ulong sessionID);
};


// SRL Session settings
class SrlSession
{
public:
	SrlSession(CM_TOKEN_TYPE *pTokObj, CallbackFunctions& cmlFuncs, CertCache* pCertCache = NULL);
	~SrlSession();

private:
	// Member variables
	void* srlLibHandle;
	ulong sessionID;
};

class CertAndParams : public CML::Certificate
{
public:
	CertAndParams(const CML::Certificate& issuer,
		const CTIL::CSM_Buffer* pInheritedParams, short resultCode);

	// Conversion operators
	operator const ASN::DN&() const				{ return base().subject; }
	operator ValidatedKey() const;

	// Retrieve CRLs from the CA's SubjectInformationAccess extension
	void RetrieveCRLsFromSIA(ulong sessionID, ASN::BytesList& encCRLs) const;

	const short m_resultCode;
};

/////////////////////////
// Function Prototypes //
/////////////////////////
short CheckRevocationStatus(ulong sessionID, const ASN::Cert& target,
						   const CertAndParams& issuerCert,
						   const CTIL::CSM_Buffer* pParams,
						   SearchBounds searchFlag,
						   bool isEE, ErrorInfoList& certErrors,
						   ErrorInfoList& pathErrors, PathState& state);
bool CompareBytesPtrs(const Bytes_struct *a, const Bytes_struct *b);
bool CompareUniqueIDs(const SNACC::UniqueIdentifier* pFirstID,
					  const SNACC::UniqueIdentifier* pSecondID);
const CallbackFunctions& GetCallbacksFromRef(ulong sessionID);
CertCache& GetCertCache(ulong sessionID);
CrlCache& GetCRLCache(ulong sessionID);
const ASN::OIDList& GetInitialPolicySet(ulong sessionID);
ushort GetMaxPaths(ulong sessionID);
const Session& GetSessionFromRef(ulong sessionID);
bool IsSelfSigned(const ASN::Cert& cert, bool authKeyMustMatch = false);
short RequestCRLsFromSIA(ulong sessionID, const ASN::PkixSIAExtension& siaExt,
						 BytesSet& encCRLs);
const SNACC::AsnOid& SplitSigHashAlg(const SNACC::AsnOid& sigHashAlg,
									 SNACC::AsnOid* pHashAlg = NULL);
short VerifySignature(ulong sessionID, const ASN::Bytes& asnObj,
					  const ASN::PublicKeyInfo& pubKey,
					  const CTIL::CSM_Buffer* pubKeyParams = NULL);



} // end of nested Internal namespace
} // end of CML namespace


#endif // _CM_INTERNAL_H
