/*****************************************************************************
File:     CM_Signature.cpp
Project:  Certificate Management Library
Contents: Implementation of the SignedAsnObj class

Created:  January 2000
Author:   Rich Nicholas <Richard.Nicholas@DigitalNet.com>

Last Updated:  6 October 2003

Version:  2.3

*****************************************************************************/

////////////////////
// Included Files //
////////////////////
#include "CM_internal.h"


// Using declarations
using namespace CML;
using namespace SNACC;
using namespace CTIL;
using ASN::AlgID;
using ASN::Bytes;
using ASN::PublicKeyInfo;

// Forward Declarations
ASN::ReadLock AcquireSessionReadLock(ulong sessionID);



//////////////////////
// Type Definitions //
//////////////////////
struct SigHashAlg
{
    const SNACC::AsnOid* sigHashOID;
    const SNACC::AsnOid* hashOID;
    const SNACC::AsnOid* sigOID;
};


//////////////////////
// Global Variables //
//////////////////////
static const SNACC::AsnOid id_md4(gMD4_OID);
static const SNACC::AsnOid id_md5(gMD5_OID);
static const SNACC::AsnOid id_ecDSAwithSHA1(gECDSA_SHA1_OID);
static const SNACC::AsnOid id_ecAlg(gEC_KEY_OID);

static SigHashAlg SigHashAlg_table[] = {
	{ &SNACC::id_dsa_with_sha1, &SNACC::sha_1, &SNACC::id_dsa },
	{ &SNACC::md2WithRSAEncryption, &SNACC::id_md2, &SNACC::rsaEncryption },
	{ &SNACC::md4WithRSAEncryption, &id_md4, &SNACC::rsaEncryption },
	{ &SNACC::md5WithRSAEncryption, &id_md5, &SNACC::rsaEncryption },
	{ &SNACC::sha_1WithRSAEncryption, &SNACC::sha_1, &SNACC::rsaEncryption },
	{ &id_ecDSAwithSHA1, &SNACC::sha_1, &id_ecAlg },
	{ &SNACC::id_ecdsa_with_SHA256, &SNACC::id_SHA256, &id_ecAlg },
	{ &SNACC::id_ecdsa_with_SHA384, &SNACC::id_SHA384, &id_ecAlg },
	{ &SNACC::id_fortezzaUpdatedSigAlgorithm, &SNACC::sha_1, &SNACC::id_fortezzaKMandUpdSigAlgorithms },
	{ &SNACC::id_OIW_secsig_algorithm_dsa, &SNACC::sha_1, &SNACC::id_dsa }, 
	{ NULL, NULL, NULL }
};



///////////////////////////////////////
// SignedAsnObj class implementation //
///////////////////////////////////////
SignedAsnObj::SignedAsnObj(const Bytes& asn)
{
	Decode(asn);
}


SignedAsnObj::SignedAsnObj(const Bytes& asn, const AlgID& sigAlg) :
m_sigData((char*)asn.GetData(), asn.Len()), m_sigAlg(sigAlg)
{
}


SignedAsnObj& SignedAsnObj::operator=(const ASN::Bytes& asn)
{
	Decode(asn);
	return *this;
}


ulong SignedAsnObj::Decode(const ASN::Bytes& asn)
{
	m_sigData.Clear();
	m_sigValue.Clear();

	try {
		// Load the encoded data into an AsnBuf
		AsnBuf asnBuf((char*)asn.GetData(), asn.Len());;
		
		// Decode the SIGNED macro SEQ tag
		AsnLen numDec = 0;
		AsnTag tag = BDecTag(asnBuf, numDec);
		if (tag != MAKE_TAG_ID(UNIV, CONS, SEQ_TAG_CODE))
			throw CML_ERR(CM_ASN_ERROR);
		
		// Decode and check the length
		AsnLen seqLen = BDecLen(asnBuf, numDec);
		if ((seqLen != INDEFINITE_LEN) && (numDec + seqLen != asn.Len()))
			throw CML_ERR(CM_ASN_ERROR);
		
		// Save start of ToBeSigned portion for later
		AsnLen tbsOffset = numDec;
		numDec = 0;
		
		// Decode the tag on the ToBeSigned portion
		BDecTag(asnBuf, numDec);
		
		// Decode and check the length on the ToBeSigned portion
		AsnLen tbsLen = BDecLen(asnBuf, numDec);
		if (tbsLen == INDEFINITE_LEN)
			throw CML_ERR(CM_ASN_ERROR);
		
		// Initialize the signed data member variable
		m_sigData.Set((const char*)asn.GetData() + tbsOffset, numDec + tbsLen);
		
		// Skip over the ToBeSigned content
		asnBuf.skip(tbsLen);

		// Decode the algorithm identifier
		AlgorithmIdentifier algID;
		algID.BDec(asnBuf, numDec);

		// Decode the signature value BIT STRING
		AsnBits sigValue;	
		sigValue.BDec(asnBuf, numDec);

		// Check that the entire sequence was decoded
		if ((seqLen != INDEFINITE_LEN) && (seqLen != numDec + tbsLen))
			throw CML_ERR(CM_ASN_ERROR);
		else if (seqLen == INDEFINITE_LEN)
			seqLen = numDec + tbsLen;
		if (tbsOffset + seqLen != asn.Len()) 
			throw CML_ERR(CM_ASN_ERROR);
		
		// Initialize the signature algorithm and value member variables
		m_sigAlg = algID;
		m_sigValue.Set(sigValue.data(), sigValue.length());

		return asn.Len();
	}
 	catch (SNACC::SnaccException& ) {
		m_sigData.Clear();
		throw CML_ERR(CM_ASN_ERROR);
	}
	catch (...) {
		m_sigData.Clear();
		throw;
	}
}


ulong SignedAsnObj::Encode(ASN::Bytes& asn) const
{
	try {
		// Determine size of ASN.1 buffer required
		int bufSize = m_sigData.Length() + m_sigValue.Length() + 100;
		if (m_sigAlg.parameters != NULL)
			bufSize += m_sigAlg.parameters->Length();

		// Create the AsnBuffer
		SNACC::AsnBuf asnBuf;
		AsnLen numEncoded = 0;

		// Encode the signature value
		asnBuf.PutSegRvs(m_sigValue.Access(), m_sigValue.Length());
		numEncoded += m_sigValue.Length();

		// Encode the number of unused bits
		asnBuf.PutByteRvs(0);
		++numEncoded;

		// Encode the BIT STRING length and tag
		numEncoded += SNACC::BEncDefLen(asnBuf, numEncoded);
		numEncoded += BEncTag1(asnBuf, SNACC::UNIV, SNACC::PRIM,
			SNACC::BITSTRING_TAG_CODE);

		// Get and Encode the SNACC AlgorithmIdentifier
		SNACC::AlgorithmIdentifier* pAlgID = NULL;
		try {
			pAlgID = m_sigAlg.GetSnacc();
			numEncoded += pAlgID->BEnc(asnBuf);
			delete pAlgID;
		}
		catch (...) {
			if (pAlgID != NULL)
				delete pAlgID;
			throw;
		}

		// Encode the ToBeSigned data
		asnBuf.PutSegRvs(m_sigData.Access(), m_sigData.Length());
		numEncoded += m_sigData.Length();

		// Encode the outer SEQ length and tag
		numEncoded += SNACC::BEncDefLen(asnBuf, numEncoded);
		numEncoded += BEncTag1(asnBuf, SNACC::UNIV, SNACC::CONS,
			SNACC::SEQ_TAG_CODE);

		// Set the encoded object into the asn parameter
		asn.Set(asnBuf, numEncoded);

		return numEncoded;
	}
	catch (SNACC::SnaccException& ) {
		throw CML_ERR(CM_ASN_ERROR);
	}
}


short SignedAsnObj::Sign(CTIL::CSM_CtilInst& keyHandle, const AlgID* pSigAlg)
{
	// Access the token interface
	CTIL::CSM_TokenInterface* pTokenI = keyHandle.AccessTokenInterface();
	if (pTokenI == NULL)
		throw CML_ERR(CM_INVALID_PARAMETER);

	// Sign the object
	SM_RET_VAL retVal = pTokenI->SMTI_Sign(&m_sigData, &m_sigValue, NULL);
	if (retVal != SM_NO_ERROR)
		return CM_SIGN_OPERATION_FAILED;

	// Set the signature algorithm, if specified
	if (pSigAlg != NULL)
		m_sigAlg = *pSigAlg;

	return CM_NO_ERROR;
}


short SignedAsnObj::VerifySignature(CTIL::CSM_CtilMgr& tokenMgr,
									const ASN::PublicKeyInfo& publicKey,
									const CTIL::CSM_Buffer* parameters) const
{
	// Set the local parameters pointer to the parameters in the publicKey, if
	// present, or to the parameters variable if not
	const CTIL::CSM_Buffer* params = publicKey.algorithm.parameters;
	if (params == NULL)
		params = parameters;

	// Get the hash and encryption algorithm
	CTIL::CSM_Alg hashAlg;
	CTIL::CSM_Alg encryptAlg;
	encryptAlg.algorithm = Internal::SplitSigHashAlg(m_sigAlg.algorithm,
		&hashAlg.algorithm); 

	// Initialize the signature algorithm
	CTIL::CSM_Alg sigAlg((SNACC::AsnOid&)m_sigAlg.algorithm);
	if (params != NULL)
	{
		sigAlg.parameters = new AsnAny();
		if (sigAlg.parameters == NULL)
			throw CML_MEMORY_ERR;
		sigAlg.parameters->ai = NULL;
		sigAlg.parameters->anyBuf = new SNACC::AsnBuf(params->Access(),
			params->Length());
		if (sigAlg.parameters->anyBuf == NULL)
			throw CML_MEMORY_ERR;
	}

	// Find the first crypto token instance that implements the signature
	// algorithm
	CTIL::CSM_CtilInst* pCrypto = tokenMgr.FindCSInstAlgIds(&hashAlg,
		&encryptAlg, NULL, NULL);
	if (pCrypto == NULL)
		return CM_NO_TOKENS_SUPPORT_SIG_ALG;

	// Verify the signature
	SM_RET_VAL rc = pCrypto->AccessTokenInterface()->SMTI_Verify(
		(CTIL::CSM_Buffer*)&publicKey.key, &hashAlg, &sigAlg,
		(CTIL::CSM_Buffer*)&m_sigData, (CTIL::CSM_Buffer*)&m_sigValue);
	if (rc == SM_NO_ERROR)
		return CM_NO_ERROR;

	return CM_SIGNATURE_INVALID;
}


short SignedAsnObj::VerifySignature(ulong sessionID,
									const PublicKeyInfo& publicKey,
									const CTIL::CSM_Buffer* parameters) const
{
	// Get the Session from the session ID
	const Internal::Session& session = Internal::GetSessionFromRef(sessionID);

	ASN::ReadLock lock = CML::Internal::AcquireSessionReadLock(sessionID);

	// Check the CTIL manager pointer
	if (session.GetTokenObj() == NULL)
		return CM_NULL_POINTER;

	return VerifySignature(*session.GetTokenObj(), publicKey, parameters);
}


short SignedAsnObj::VerifySignature(ulong sessionID,
									const ValidatedKey& signersKey) const
{
	// Get the hash and encryption algorithm
	CTIL::CSM_Alg hashAlg;
	CTIL::CSM_Alg encryptAlg;
	encryptAlg.algorithm = Internal::SplitSigHashAlg(m_sigAlg.algorithm,
		&hashAlg.algorithm); 

	// Initialize the signature algorithm
	CTIL::CSM_Alg sigAlg((SNACC::AsnOid&)m_sigAlg.algorithm);
	if (signersKey.pubKeyInfo().algorithm.parameters != NULL)
	{
		sigAlg.parameters = new AsnAny();
		if (sigAlg.parameters == NULL)
			throw CML_MEMORY_ERR;
		sigAlg.parameters->ai = NULL;
		sigAlg.parameters->anyBuf = new AsnBuf(
			signersKey.pubKeyInfo().algorithm.parameters->Access(),
			signersKey.pubKeyInfo().algorithm.parameters->Length());
		if (sigAlg.parameters->anyBuf == NULL)
			throw CML_MEMORY_ERR;
	}
	
	// Get the Session from the session ID
	const Internal::Session& session = Internal::GetSessionFromRef(sessionID);

	ASN::ReadLock lock = CML::Internal::AcquireSessionReadLock(sessionID);
	
	// Find the first crypto token instance that implements the signature
	// algorithm
	CTIL::CSM_CtilInst* pCrypto = session.GetTokenObj()->FindCSInstAlgIds(&hashAlg,
		&encryptAlg, NULL, NULL);
	if (pCrypto == NULL)
		return CM_NO_TOKENS_SUPPORT_SIG_ALG;
	
	// Verify the signature
	SM_RET_VAL rc = pCrypto->AccessTokenInterface()->SMTI_Verify(
		(CTIL::CSM_Buffer*)&signersKey.pubKeyInfo().key, &hashAlg,
		&sigAlg, (CTIL::CSM_Buffer*)&m_sigData,
		(CTIL::CSM_Buffer*)&m_sigValue);
	if (rc == SM_NO_ERROR)
		return CM_NO_ERROR;

	return CM_SIGNATURE_INVALID;
}


short SignedAsnObj::VerifySignature(ulong sessionID, SearchBounds boundsFlag,
									const CML::Certificate& signersCert,
									ErrorInfoList* pErrors) const
{
	ValidatedKey validKey;
	short err = signersCert.Validate(sessionID, boundsFlag, pErrors,
		&validKey);
	if ((err == CM_NO_ERROR) || (err == CM_PATH_VALIDATION_ERROR))
	{
		// Check key usage extension if present and the ErrorInfoList
		// parameter is present
		if ((signersCert.base().exts.pKeyUsage != NULL) && (pErrors != NULL))
		{
			SNACC::KeyUsage& keyUse = *signersCert.base().exts.pKeyUsage;
			if (!keyUse.GetBit(SNACC::KeyUsage::digitalSignature) &&
				!keyUse.GetBit(SNACC::KeyUsage::nonRepudiation) &&
				!keyUse.GetBit(SNACC::KeyUsage::keyCertSign) &&
				!keyUse.GetBit(SNACC::KeyUsage::cRLSign))
				pErrors->AddError(CM_INVALID_KEY_USE, signersCert.base());
		}

		short sigErr = VerifySignature(sessionID, validKey);
		if ((sigErr == CM_NO_ERROR) && (err == CM_PATH_VALIDATION_ERROR))
			sigErr = CM_PATH_VALIDATION_ERROR;
		return sigErr;
	}
	return err;
}


/////////////////////////////
// CML::Internal functions //
/////////////////////////////
short CML::Internal::VerifySignature(ulong sessionID, const Bytes& asnObj,
									 const PublicKeyInfo& pubKey,
									 const CTIL::CSM_Buffer* pubKeyParams)
{
	try {
		SignedAsnObj signedObj(asnObj);
		return signedObj.VerifySignature(sessionID, pubKey, pubKeyParams);
	}
	catch (Exception& cmlErr) {
		return cmlErr;
	}
	catch (ASN::Exception& asnErr) {
		return asnErr;
	}
	catch (...) {
		return CM_ASN_ERROR;
	}
}


/************************************************************************
 FUNCTION:  CML::Internal::SplitSigHashAlg()
 
 Description: This function will look up the signature and hash OID in
 the table and return a reference to the signature OID and, if requested,
 set the supplied hash OID.  An exception is thrown if the input OID is
 not supported.
*************************************************************************/
const SNACC::AsnOid& CML::Internal::SplitSigHashAlg(const SNACC::AsnOid& sigHashAlg,
													SNACC::AsnOid* pHashAlg)
{
	SigHashAlg* pEntry;
	for (pEntry = SigHashAlg_table; (pEntry->sigHashOID != NULL) &&
		(*pEntry->sigHashOID != sigHashAlg); pEntry++)
		;
	if (pEntry->sigHashOID == NULL)
		throw CML_ERR(CM_NOT_IMPLEMENTED);

	if (pHashAlg != NULL)
		*pHashAlg = *pEntry->hashOID;

	return *pEntry->sigOID;

} // end of CML::Internal::SplitSigHashAlg()



// end of CM_Signature.cpp
