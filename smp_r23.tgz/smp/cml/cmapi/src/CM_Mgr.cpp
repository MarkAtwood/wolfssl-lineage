/*****************************************************************************
File:     CM_Mgr.cpp
Project:  Certificate Management Library
Contents: Implementation of the CM_MgrInfo and Session classes to manage
		  library initialization and shutdown and session creation and
		  deletion.

Created:  March 1997
Author:   Rich Nicholas <Richard.Nicholas@DigitalNet.com>

Last Updated:	2 September 2003

Version:  2.3

Description: This file contains the following functions:
			 CML::SetPolicy
			 CMU_AddASession
			 CMU_RemoveASession
			 CMU_GetErrorString
*****************************************************************************/

/* -------------- */
/* Included Files */
/* -------------- */

#ifdef WIN32
	#pragma warning(push, 3)		// Set warning level to 3 for windows.h
	#include <windows.h>			// Needed for dynamic load of DLLs
	#pragma warning(pop)			// Restore warning level
#else
	#include <dlfcn.h>				// Needed for dynamic load of libraries
#endif
#include "CM_cache.h"

// 
#ifdef ENABLE_STATIC
	extern "C" { long DLLBuildTokenInterface(CTIL::CSM_CtilMgr &, char *); }
#endif


// Using declarations
using namespace CML;
using namespace CML::Internal;


///////////////////////
// Defined Constants //
///////////////////////
const ushort DEFAULT_MAX_PATHS	= 5;



//////////////////////
// Type Definitions //
//////////////////////
typedef std::map<ulong, Session> SessionMap;

class CM_MgrInfo
{
public:
	// Methods
	ulong AddSession(const InitSettings_struct& settings);
	void DeleteSession(ulong sessionID);
	Session& GetSession(ulong sessionID);

private:
	ulong GenRandomSessionID(const void* address) const;

	SessionMap m_sessions;
	ASN::Mutex mMutex;
};


/* Record structure used in ErrorTable */
typedef struct
{
    short code;
    const char *string;
} ErrorEntry;


/* ------------------- */
/* Function Prototypes */
/* ------------------- */
static CTIL::CSM_CtilMgr* loadCTILs(const CryptoTokenBitMask & tokensToUse);
void CMU_ReleaseSRL(void *libHandle, ulong *srlSession);


//////////////////////
// Global Variables //
//////////////////////
static CM_MgrInfo gCM_MgrInfo;



/************************************************************************
 FUNCTION:  CML::SetPolicy()
 
 Description: This function set the initial path processing settings for
 the specified session.
*************************************************************************/
void CML::SetPolicy(ulong sessionID, const ASN::OIDList& policies,
					bool requireExplicitPolicy, bool inhibitPolicyMapping,
					bool inhibitAnyPolicy)
{
	// Check parameter
	if (policies.empty())
		throw CML_ERR(CM_INVALID_PARAMETER);

	// Get the CM session from the handle
	Session& session = gCM_MgrInfo.GetSession(sessionID);

	// Copy the settings
	session.SetPolicySettings(policies, requireExplicitPolicy, 
		inhibitPolicyMapping, inhibitAnyPolicy);
}


/////////////////////////////////////
// CM_MgrInfo class implementation //
/////////////////////////////////////
ulong CM_MgrInfo::AddSession(const InitSettings_struct& settings)
{
	ulong ref = 0;
	try {
		// Acquire or lock the mutex
		ASN::MutexLock lock = mMutex.AcquireLock();
		
		// Create a unique ref id for this session
		ref = GenRandomSessionID(&settings);
		if (ref == 0)
			throw CML_MEMORY_ERR;

		// Insert a new session into the map
		Session& newSession = m_sessions[ref];

		// Initialize the session
		newSession.Initialize(ref, settings);
		return ref;
	}
	catch (...) {
		DeleteSession(ref);
		throw;
	}
} // end of CM_MgrInfo::AddSession()


void CM_MgrInfo::DeleteSession(ulong sessionID)
{
	// Acquire or lock the mutex
	ASN::MutexLock lock = mMutex.AcquireLock();

	ulong numErased = m_sessions.erase(sessionID);

	if (numErased == 0)
		throw CML_ERR(CM_SESSION_NOT_VALID);
}


Session& CM_MgrInfo::GetSession(ulong sessionID)
{
	// Acquire or lock the mutex
	ASN::MutexLock lock = mMutex.AcquireLock();

	SessionMap::iterator i = m_sessions.find(sessionID);

	if (i == m_sessions.end())
		throw CML_ERR(CM_SESSION_NOT_VALID);

	return i->second;
}


ulong CM_MgrInfo::GenRandomSessionID(const void *address) const
{
	// NOTE:  CM_MgrInfo must be locked!!

	// Check parameter
	if (address == NULL)
		return 0;

	// Hash the address
	CML::ASN::Bytes inputBytes(sizeof(void*), (const uchar*)&address);
	CML::ASN::Bytes hash;
	inputBytes.Hash(hash);
	ulong sessionID = *(ulong*)hash.GetData();

	/* If the sessionID already exists, shift it right until a unique value
	is found  */
	bool sessionExists;
	do
	{
		SessionMap::const_iterator i = m_sessions.find(sessionID);
		if (i == m_sessions.end())
			sessionExists = false;
		else
		{
			sessionExists = true;
			sessionID >>= 1;
		}
	} while (sessionExists && (sessionID != 0));

	return sessionID;
} // end of CM_MgrInfo::GenRandomSessionID()



///////////////////
// CMU Functions //
///////////////////
ulong CMU_AddASession(const InitSettings_struct& settings)
{
	return gCM_MgrInfo.AddSession(settings);

} // end of CMU_AddASession()


short CMU_RemoveASession(ulong *sessionRefID)
{
	// Check parameter
	if (sessionRefID == NULL)
		return CM_INVALID_PARAMETER;

	// Reset the caller's sessionRefID to zero
	ulong tmpRefID = *sessionRefID;
	*sessionRefID = 0;

	try {
		gCM_MgrInfo.DeleteSession(tmpRefID);
	}
	catch (Exception& err) {
		return err;
	}

	return CM_NO_ERROR;
}


/////////////////////////////
// CML::Internal Functions //
/////////////////////////////
const CallbackFunctions& CML::Internal::GetCallbacksFromRef(ulong sessionID)
{
	// Get the CM session from the handle
	const Session& session = gCM_MgrInfo.GetSession(sessionID);

	// Check the required function pointers
	if ((session.GetFunc().pGetObj == NULL) || (session.GetFunc().pFreeObj == NULL))
		throw CML_ERR(CM_NULL_POINTER);

	return session.GetFunc();
}


ASN::ReadLock CML::Internal::AcquireSessionReadLock(ulong sessionID)
{
	// Get the CM session from the handle
	Session& session = gCM_MgrInfo.GetSession(sessionID);
	return session.mMutex.AcquireReadLock();
}


CertCache& CML::Internal::GetCertCache(ulong sessionID)
{
	// Get the CM session from the handle
	Session& session = gCM_MgrInfo.GetSession(sessionID);
	if (session.GetCertCache() == NULL)
		throw CML_ERR(CM_NULL_POINTER);
	return *session.GetCertCache();
}


CrlCache& CML::Internal::GetCRLCache(ulong sessionID)
{
	// Get the CM session from the handle
	Session& session = gCM_MgrInfo.GetSession(sessionID);
	if (session.GetCrlCache() == NULL)
		throw CML_ERR(CM_NULL_POINTER);
	return *session.GetCrlCache();
}


const ASN::OIDList& CML::Internal::GetInitialPolicySet(ulong sessionID)
{
	const Session& session = GetSessionFromRef(sessionID);
	return session.GetPolicySettings().policyList;
}

ushort CML::Internal::GetMaxPaths(ulong sessionID)
{
	const Session& session = GetSessionFromRef(sessionID);
	return session.GetMaxPaths();
}


const Session& CML::Internal::GetSessionFromRef(ulong sessionRefID)
{
	return gCM_MgrInfo.GetSession(sessionRefID);
}


//////////////////////////////////
// Session class implementation //
//////////////////////////////////
Session::Session()
{
	// Initialize pointers
	pTokenObj = NULL;
	tokenFlag = false;
	pCertCache = NULL;
	pCrlCache = NULL;
	pSRL = NULL;
}

Session::Session(const Session& that)
{
	pTokenObj = NULL;
	tokenFlag = false;
	pCertCache = NULL;
	pCrlCache = NULL;
	pSRL = NULL;
	mMutex = that.mMutex;
}

void Session::Initialize(ulong sessionID, const InitSettings_struct& settings)
{
	// Acquire a handle to the mutex
	ASN::MutexLock lock = mMutex.AcquireLock();
	
	// Initialize member variables
	func.extHandle = settings.extHandle;
	func.pGetObj = settings.pGetObj;
	func.pFreeObj = settings.pFreeObj;
	func.pUrlGetObj = settings.pUrlGetObj;
	pTokenObj = settings.pTokenObj;
	
	// Check that the callback function pointers are properly specified
	if ((func.pUrlGetObj != NULL) && (func.pGetObj == NULL))
		throw CML_ERR(CM_NO_GET_OBJ);
	else if ((func.pGetObj != NULL) && (func.pFreeObj == NULL))
		throw CML_ERR(CM_NO_FREE_OBJ);
	
	try {
		// Initialize the RAM cache
		pCertCache = new CertCache(sessionID, settings.nCertCacheSize,
			settings.certCacheTTL);
		if (pCertCache == NULL)
			throw CML_MEMORY_ERR;
		
		pCrlCache = new CrlCache(sessionID, settings.nCrlCacheSize,
			settings.crlCacheTTL);
		if (pCrlCache == NULL)
			throw CML_MEMORY_ERR;
		
		// Load the crypto token objects requested in the settings if CTIL not provided
		if (pTokenObj == NULL)
		{

#if defined (ENABLE_STATIC)
			CTIL::CSM_CtilMgr *ctil = new CTIL::CSM_CtilMgr;
			DLLBuildTokenInterface(*ctil, NULL);
			pTokenObj = ctil;
			tokenFlag = true;
#else			
			pTokenObj = loadCTILs(settings.tokensToUse);
			tokenFlag = true;		
#endif // ENABLE_STATIC
			
		}
		
		// Create a Storage and Retrieval library session if pGetObj
		// callback function not provided
		if (func.pGetObj == NULL)
		{
			if (settings.trustedCerts == NULL)
				pSRL = new SrlSession(pTokenObj, func, pCertCache);
			else
				pSRL = new SrlSession(pTokenObj, func);
			if (pSRL == NULL)
				throw CML_MEMORY_ERR;
		}
		
		// Set the revocation checking policy
		if (settings.revPolicy == 0)
			revPolicy = CM_REVCRL;
		else if ((settings.revPolicy == CM_REVNONE) ||
			(settings.revPolicy == CM_REVCRL))
			revPolicy = settings.revPolicy;
		else
			throw CML_ERR(CM_INVALID_PARAMETER);
		
		// Set the max paths setting
		if (settings.nMaxPaths == 0)
			nMaxPaths = DEFAULT_MAX_PATHS;
		else
			nMaxPaths = settings.nMaxPaths;
		
		// Load the application-provided trusted certs
		if (settings.trustedCerts != NULL)
		{
			short err = pCertCache->LoadTrustedCerts(pTokenObj, settings.trustedCerts);
			if (err != CM_NO_ERROR)
				throw CML_ERR(err);
		}
	}
	catch (...) {
		delete pCertCache;
		pCertCache = NULL;
		delete pCrlCache;
		pCrlCache = NULL;
		if (tokenFlag)
		{
			delete pTokenObj;
			pTokenObj = NULL;
		}
		delete pSRL;
		pSRL = NULL;
		throw;
	}
} // end of Session::Initialize()

// Set private members of PolicySettings
void Session::SetPolicySettings(const ASN::OIDList &polList, bool reqPolicy,
								bool inhibitMap, bool inhibitAnyPol)
{
	// Acquire write lock on session's mutex
	ASN::MutexLock lock = mMutex.AcquireLock();

	// Check the cache pointers
	if ((pCertCache == NULL) || (pCrlCache == NULL))
		throw CML_ERR(CM_NULL_POINTER);

	// Empty the existing cert & CRL caches
	pCertCache->Empty();
	pCrlCache->Empty();

	policySettings.policyList = polList;
	policySettings.requirePolicy = reqPolicy;
	policySettings.inhibitMapping = inhibitMap;
	policySettings.inhibitAnyPolicy = inhibitAnyPol;
}


Session::~Session()
{
	// Acquire a handle to the mutex
	ASN::MutexLock lock = mMutex.AcquireLock();

	delete pCertCache;
	delete pCrlCache;

	if (tokenFlag)
		delete pTokenObj;

	if (pSRL != NULL)
		delete pSRL;
}


CTIL::CSM_CtilMgr* loadCTILs(const CryptoTokenBitMask & tokensToUse)
{
	CTIL::CSM_CtilMgr* ctilMgr = NULL;
	bool loadedCtil = false;
				

	// Create a new CSM_CtilMgr
	ctilMgr = new CTIL::CSM_CtilMgr;
	if (ctilMgr == NULL)
		throw CML_ERR(CM_MEMORY_ERROR);
	
	try
	{
		// Load the requested CTILs
		if (tokensToUse.defCTIL) {
			ctilMgr->SetDefaultCTIL();
			loadedCtil = true;
		}

		if (tokensToUse.bsafe) {
			ctilMgr->AddLogin(BSAFE_CTIL_NAME, NULL);
			loadedCtil = true;
		}

		if (tokensToUse.cryptopp) {
			ctilMgr->AddLogin(CRYPTOPP_CTIL_NAME, NULL);
			loadedCtil = true;
		}

		if (tokensToUse.msCapi) {
			ctilMgr->AddLogin(MSCAPI_CTIL_NAME, NULL);
			loadedCtil = true;
		}

		if (tokensToUse.pkcs11) {
			ctilMgr->AddLogin(PKCS11_CTIL_NAME, NULL);
			loadedCtil = true;
		}
		
		if (! loadedCtil)
			ctilMgr->SetDefaultCTIL();
	}
	catch (...)
	{
		delete ctilMgr;
		throw CML_ERR(CM_CTIL_INIT_ERROR);
	}

	return ctilMgr;
				
} // end of loadCTILs()


/* Error Table */
static ErrorEntry gErrorTable[] = {
	{ CM_NO_ERROR,	"success" },
	{ CM_MEMORY_ERROR, "memory error" },
	{ CM_INVALID_PARAMETER, "invalid parameter" },
	{ CM_SESSION_NOT_VALID, "invalid session handle" },
	{ CM_NULL_POINTER, "internal error -- null pointer" },
	{ CM_NOT_IMPLEMENTED, "feature/algorithm not supported" },
	{ CM_BAD_CONFIG_FILE, "invalid SRL configuration file" },
	{ CM_CONFIG_NOT_FOUND, "missing SRL configuration file" },
	{ CM_NOT_SELF_SIGNED, "trusted certificate not self-signed" },
	{ CM_ASN_ERROR, "error decoding ASN.1 object" },
	{ CM_MISSING_PARAMETERS, "algorithm parameters in trusted cert are missing" },
	{ CM_INVALID_DN, "incorrect string format of distinguished name" },
	{ CM_NOT_SIG_KEY, "trusted cert does not contain a signature key" },
	{ CM_NOT_FOUND, "object was not found" },
	{ CM_NO_PATH_FOUND, "no certification path could be built" },
//	{ CM_NO_ERROR_INFO, "no extended error information available" },
	{ CM_PATH_VALIDATION_ERROR, "error validating the certification path" },
	{ CM_NO_GET_OBJ, "missing retrieval callback function" },
	{ CM_NO_FREE_OBJ, "missing free callback function" },
//	{ CM_NO_TRUSTED_CERTS, "no trusted certs have been specified"},
	{ CM_TRUSTED_CERT_ERROR, "error loading the trusted certs" },
	{ CM_TRUSTED_CERT_NOT_YET_VALID, "trusted cert is not valid yet" },
	{ CM_TRUSTED_CERT_EXPIRED, "trusted cert has expired" },
	{ CM_TRUSTED_CERT_SIG_INVALID, "trusted cert signature invalid" },
	{ CM_INVALID_ENC_OBJ_TYPE, "invalid type flag in EncObject_LL" },
	{ CM_INVALID_ENC_OBJ_LOC, "invalid location flag in EncObject_LL" },
	{ CM_NO_TOKENS_SUPPORT_SIG_ALG, "no CTIL supports this signature algorithm" },
	{ CM_SIGNATURE_INVALID, "object signature invalid" },
	{ CM_SIGN_OPERATION_FAILED, "sign operation failed" },
	{ CM_CTIL_INIT_ERROR, "error loading specified CTIL" },

	{ CM_LDAP_DLL_INVALID, "SRL failed to load the LDAP DLL" },
	{ CM_LDAP_UNAVAILABLE, "LDAP service unavailable" },
	{ CM_LDAP_INITIALIZATION_FAILED, "SRL failed to initialize LDAP" },
	{ CM_LDAP_BIND_FAILED, "SRL failed to bind to the LDAP server" },
	{ CM_LDAP_SEARCH_FAILED, "error occurred while searching the LDAP server" },
	{ CM_SRL_INITIALIZATION_FAILED, "SRL library failed to initialize" },
	{ CM_DB_IO_ERROR, "SRL database I/O error" },
	{ CM_DB_UNRECOGNIZED_FILE, "unrecognized SRL database file" },
	{ CM_DB_ALREADY_EXISTS, "SRL database file already exists" },
	{ CM_DB_FLUSH_FAILURE, "unable to flush the SRL database" },
	{ CM_DB_INDEX_ERROR , "SRL database index error" },
/* Path validation errors */
	{ CM_SIGNATURE_ALG_MISMATCH, "mismatched certificate signature algorithms" },
	{ CM_CERT_SIGNATURE_INVALID, "certificate signature invalid" },
	{ CM_CERT_NOT_YET_VALID, "certificate is not valid yet" },
	{ CM_CERT_EXPIRED, "certificate has expired" },
	{ CM_NAME_MISMATCH, "names in cert path do not chain correctly" },
	{ CM_PATH_LEN_EXCEEDED, "path length exceeded" },
	{ CM_INVALID_CA, "invalid certificate authority" },
//	{ CM_INVALID_BASIC_CONSTRAINTS, "invalid basic constraints extension" },
//	{ CM_INVALID_NAME_CONSTRAINTS, "invalid name constraints extension" },
//	{ CM_INVALID_POLICY_CONSTRAINTS, "invalid policy constraints extension" },
//	{ CM_INVALID_POLICY_MAPPINGS, "invalid policy mappings extension" },
	{ CM_INVALID_CERT_POLICY, "required certificate policy missing" },
	{ CM_INVALID_SUBJECT_NAME, "invalid subject name" },
	{ CM_INVALID_KEY_USE, "invalid key usage specified" },
	{ CM_UNRECOGNIZED_ALT_NAME, "no recognized alternative name form" },
	{ CM_INVALID_ALT_NAME, "invalid alternative name" },
	{ CM_UNRECOGNIZED_CRITICAL_CERT_EXT, "unrecognized critical cert extension" },

	{ CM_CRL_NOT_AVAIL, "no CRL found for this issuer" },
	{ CM_CRL_SIG_ALG_MISMATCH, "mismatched CRL signature algorithms" },
	{ CM_CRL_SIGNATURE_INVALID, "CRL signature invalid" },
	{ CM_CRL_OUT_OF_DATE, "CRL has expired" },
	{ CM_CERT_REVOKED, "certificate has been revoked (unspecified reason)" },
	{ CM_KEY_COMPROMISED, "public key in certificate has been compromised" },
	{ CM_CERT_AFFILIATION_CHANGED, "certificate has been revoked (affiliation changed)" },
	{ CM_CERT_SUPERSEDED, "certificate has been revoked (superseded)" },
	{ CM_CERT_NO_LONGER_NEEDED, "certificate has been revoked (cessation of operations)" },
	{ CM_CERT_ON_HOLD, "certificate is on hold" },
	{ CM_UNRECOGNIZED_CRITICAL_CRL_EXT, "unrecognized critical CRL extension" },
	{ CM_UNRECOGNIZED_CRITICAL_CRL_ENTRY_EXT, "unrecognized critical CRL entry extension" },
	{ CM_UNRECOGNIZED_EXT_KEY_USAGE, "unrecognized extended key purpose" },
	{ CM_NO_TOKENS_SUPPORT_CERT_SIG_ALG, "no CTIL supports the signature algorithm on this cert" },
	{ CM_NO_TOKENS_SUPPORT_CRL_SIG_ALG, "no CTIL supports the signature algorithm on this CRL" },
	{ CM_CRITICAL_KEY_COMPROMISE_NOT_CHECKED, "CRL not found for critical key compromise reason"},
	{ CM_REV_REASONS_NOT_CHECKED, "not all revocation reasons were checked for this cert"},
	{ CM_INVALID_CRL, "invalid CRL" },
//	{ CM_INVALID_INDIRECT_CRL, "invalid indirect CRL" },
	{ CM_CRL_PATH_NOT_FOUND, "unable to build the path for this CRL"},
	{ CM_CRL_PATH_NOT_VALID, "error validating the path for this CRL"},
//	{ CM_UNRECOGNIZED_NAME_CONSTRAINTS, "unsupported critical name constraints form"},
	{ CM_INVALID_EXT_KEY_USE, "invalid critical extended key usage" },
	{ CM_INVALID_TRUSTED_CERT_DN, "subject DN missing from trusted cert" },
	{ CM_TRUSTED_CERT_NOT_SELF_SIGNED, "trusted certificate not self-signed" },
	{ CM_TRUSTED_CERT_NOT_SIG_KEY, "trusted cert does not contain a signature key" },
	{ CM_TRUSTED_CERT_MISSING_PARAMETERS, "algorithm parameters in trusted cert are missing" },
	{ CM_REQUIRED_NAME_MISSING, "missing required name form" },
	{ CM_ISSUER_CERT_NOT_FOUND, "issuer certificate not found" },
	{ CM_CROSS_CERT_NOT_FOUND, "cross certificate not found" },
	{ CM_PATH_BUILD_PROB_TOO_LOW, "probability of successful path build too low" },
	{ CM_CERT_PRIVILEGE_WITHDRAWN, "certificate has been revoked (privilege withdrawn)" },
	{ CM_MISSING_USER_CERT_POLICY, "user certificate policy missing" },

	{ CM_INVALID_DMS_PRIVILEGE, "invalid privilege in DMS certificate"},
	{ CM_DMS_NULL_SUBJECT_DN, "subject DN missing from DMS certificate"},
	{ CM_DMS_NO_CA_CONSTRAINTS, "CA constraints missing from DMS certificate"},

	{ CM_UNKNOWN_ERROR, "internal error" }			/* Must be last element! */
};


const char* CMU_GetErrorString(short errorCode)
{
	ErrorEntry* pElmt = gErrorTable;
	for ( ; (pElmt->code != errorCode) && (pElmt->code != CM_UNKNOWN_ERROR);
		pElmt++)
		;

	if (pElmt->code != errorCode)
		return "unknown internal error";
	else
		return pElmt->string;
}



// end of CM_Mgr.cpp
