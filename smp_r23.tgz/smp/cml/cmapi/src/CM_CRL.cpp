/*****************************************************************************
File:     CM_CRL.cpp
Project:  Certificate Management Library
Contents: Implementation of the CRL class.

Created:  10 August 2001
Author:   Rich Nicholas <Richard.Nicholas@DigitalNet.com>

Last Updated:  23 September 2003

Version:  2.3

*****************************************************************************/


////////////////////
// Included Files //
////////////////////
#if defined(WIN32) && defined(_DEBUG)
	#define _WIN32_WINNT	0x0500
	#include <windows.h>						// For debugging
	#include <winbase.h>
#endif
#include "PathBuild.h"
#include "cmlasn_xml.h"
#include <functional>		// Required for std::greater used to sort CRLs


// Using declarations
using namespace CML;
using namespace CML::Internal;
using ASN::Bytes;
using ASN::CertificateList;
using ASN::DistributionPoint;
using ASN::GenNames;
using ASN::GenName;
using ASN::DN;
using ASN::PrintXML;


#ifdef THREAD_TESTING
//////////////////////
// Global Variables //
//////////////////////
extern PrintXML gPrintThreads;
extern void logErrors(const ErrorInfoList& errorList);
#endif  // THREAD_TESTING


// Begin CML namespace
namespace CML {

// Begin nested Internal namespace
namespace Internal {


///////////////////////
// Class Definitions //
///////////////////////
typedef std::list<CML::Certificate> CertList;
typedef std::list<CRL> CrlList;


class AbstractCRL
{
public:
	virtual ~AbstractCRL()											{}
	virtual operator const CertificateList&() const = 0;
};


class CachedCrlRef : public AbstractCRL
{
public:
	CachedCrlRef(const CachedCRL& cachedCRL);

	virtual operator const CertificateList&() const		{ return crl; }

	const CachedCRL& crl;

private:
	ASN::ReadLock m_cachedCRLLock;
};


class CrlPtr : public AbstractCRL
{
public:
	CrlPtr(CrlList::iterator iCRL)					{ m_list.push_back(*iCRL); }
	CrlPtr(CrlList& list, CrlList::iterator iCRL)
	{ m_list.splice(m_list.begin(), list, iCRL); }
	operator const CertificateList&() const			{ return m_list.front().base(); }

protected:
	CrlList m_list;
};


} // end of nested Internal namespace
} // end of CML namespace


/////////////////////////
// Function Prototypes //
/////////////////////////
static const AbstractCRL* chooseBestCRL(const CachedCrlList* pList,
										const ASN::RevocationReasons& reasons);
static const AbstractCRL* chooseValidCRL(ulong sessionID,
										 short& err,
										 ASN::CertType certType,
										 const CertAndParams& issuerCert,
										 const DistributionPoint& distPt,
										 const ASN::RevocationReasons& reasons,
										 SearchBounds searchFlag,
										 const ASN::BytesList& encCRLs,
										 ErrorInfoList* pErrors,
										 PathState& state);
static short findCRLIssuer(const CertificateList& crl, ulong sessionID,
						   SearchBounds searchFlag, CertList& certList);
static const AbstractCRL* findValidCRL(ulong sessionID, short& err, ASN::CertType type,
									   const CertAndParams& certIssuer,
									   const DistributionPoint& distPt,
									   const ASN::RevocationReasons& reasons,
									   SearchBounds searchFlag,
									   ErrorInfoList* pErrors,
									   PathState& state);
static GenName getDistPtName(const CertificateList& crl);
static bool isIssuer(const ASN::CertificateList& crl, const ASN::Cert& issuer);
static void processDistPt(ulong sessionID, const ASN::DistributionPoint& distPt,
						  short& err, const ASN::Cert& target,
						  ASN::CertType certType,
						  const CertAndParams& certIssuer,
						  SearchBounds searchFlag,
						  ASN::RevocationReasons& checkedReasons,
						  ErrorInfoList& certErrors, ErrorInfoList* pPathErrors,
						  PathState& state);
static const AbstractCRL* searchCRLCache(ulong sessionID, const DN& issuer,
										 ASN::CertType certType,
										 const ASN::RevocationReasons& reasons,
										 const DistributionPoint& distPt);
static const CachedCRL* validateCRL(const CRL& crl, ulong sessionID,
							  SearchBounds boundsFlag, ErrorInfoList& errors,
							  const CertAndParams& certIssuer,
							  bool tryOtherIssuers,
							  short& cmlResult, PathState& state);
static short validateCRLIssuer(ulong sessionID, SearchBounds boundsFlag,
							   const Certificate& crlIssuer,
							   ValidatedKey& validKey,
							   PathState& state,
							   ErrorInfoList& errors);
static bool errorsContainSigInvalid(const ErrorInfoList& errorList);





//////////////////////
// Global Variables //
//////////////////////
static const ASN::RevocationReasons kAllReasons(true);



//////////////////////////////
// CRL class implementation //
//////////////////////////////
CRL::CRL(const CertificateList& crl) : CertificateList(crl)
{
	CertificateList::Encode(encCrl);
}


CRL::CRL(const Bytes& asn) : CertificateList(asn), encCrl(asn)
{
}


CRL& CRL::operator=(const CertificateList& crl)
{
	CertificateList::operator=(crl);
	CertificateList::Encode(encCrl);
	return *this;
}


CRL& CRL::operator=(const Bytes& asn)
{
	Decode(asn);
	return *this;
}


ulong CRL::Decode(const Bytes& asn)
{
	encCrl = asn;
	return CertificateList::Decode(asn);
}


ulong CRL::Encode(Bytes& asn) const
{
	asn = encCrl;
	return asn.Len();
}


short CRL::Sign(CTIL::CSM_CtilInst& keyHandle, const ASN::AlgID* pSigAlg)
{
	// Access the token interface
	CTIL::CSM_TokenInterface* pTokenI = keyHandle.AccessTokenInterface();
	if (pTokenI == NULL)
		throw CML_ERR(CM_INVALID_PARAMETER);
	
	// Set the signature algorithm to the specified algorithm if present
	if (pSigAlg != NULL)
	{
		signature = *pSigAlg;
		algorithm = *pSigAlg;
	}
	
	SNACC::CertificateList* pSnacc = GetSnacc();
	try {
		// Encode the ToBeSigned part
		SNACC::AsnBuf encCrlToSign;
		long encLen = pSnacc->toBeSigned->BEnc(encCrlToSign);
		delete pSnacc;
		pSnacc = NULL;

		// Copy the encoded buffer into a CSM_Buffer
		CTIL::CSM_Buffer signBuf;
		signBuf.SetDataPtr((unsigned char*)encCrlToSign.GetSeg(encLen), encLen);

		// Sign the encoded ToBeSigned part
		SM_RET_VAL retVal = pTokenI->SMTI_Sign(&signBuf, &sigValue, NULL);
		if (retVal != SM_NO_ERROR)
			return CM_SIGN_OPERATION_FAILED;
	}
	catch (...) {
		if (pSnacc != NULL)
			delete pSnacc;
		throw;
	}

	// Re-encode the entire certificate
	CertificateList::Encode(encCrl);
	
	return CM_NO_ERROR;
}


short CRL::Validate(ulong sessionID, SearchBounds boundsFlag,
					ErrorInfoList* pErrors, const Certificate* pSigner,
					bool tryOtherSigners)
{
	// Check if the CRL is in the cache, if so return CM_NO_ERROR
	Bytes hash;
	encCrl.Hash(hash);

	// Acquire global session lock
	ASN::ReadLock lock = AcquireSessionReadLock(sessionID);

	if (GetCRLCache(sessionID).IsCached(hash))
		return CM_NO_ERROR;

	lock.Release();

	// Try the supplied signer's certificate first, if present
	ValidatedKey signersKey;
	ErrorInfoList crlErrors;
	short cmlErr = CM_PATH_VALIDATION_ERROR;
	if (pSigner != NULL)
	{
		// Check that the cert could have issued the CRL
		if (isIssuer(base(), pSigner->base()))
		{
			cmlErr = pSigner->Validate(sessionID, boundsFlag,
				&crlErrors, &signersKey);
			// If an error occurred, and additional issuers should be
			// tried, set the pSigner pointer to NULL
			if (tryOtherSigners && (cmlErr != CM_NO_ERROR))
				pSigner = NULL;
		}
	}

	// Find the CRL issuer's certificate(s)
	CertList certList;
	if (pSigner == NULL)
	{
		short err = findCRLIssuer(*this, sessionID, boundsFlag, certList);
		if (err != CM_NO_ERROR)
		{
			if (pErrors != NULL)
				pErrors->AddError(CM_ISSUER_CERT_NOT_FOUND, issuer);
			return CM_NO_PATH_FOUND;
		}
	}

	// Try to validate the CRL issuer's certificate(s)
	CertList::const_iterator iCert;
	for (iCert = certList.begin(); (iCert != certList.end()) &&
		(cmlErr != CM_NO_ERROR); ++iCert)
	{
		try {
			crlErrors.clear();
				
			// Validate the CRL issuer's certificate
			cmlErr = iCert->Validate(sessionID, boundsFlag,
				&crlErrors, &signersKey);
			if ((cmlErr != CM_NO_ERROR) && !tryOtherSigners)
			{
				// If an error occurred and no more signer certs will
				// be tried, break out of the loop
				break;
			}
		}
		catch (...) {
			// Skip this cert
		}
	}

	// Add any path building/validation errors to the supplied error list
	if (pErrors != NULL)
		pErrors->Splice(pErrors->end(), crlErrors);

	// Return if a path to the CRL issuer's cert could not be built
	if ((cmlErr != CM_NO_ERROR) && (cmlErr != CM_PATH_VALIDATION_ERROR))
		return cmlErr;
	
	// Validate the CRL
	short valErr = Validate(sessionID, signersKey, pErrors);
	if ((cmlErr == CM_NO_ERROR) && (valErr == CM_NO_ERROR))
	{
		// Add the CRL to the cache, if no errors have occurred
		if (!IsDelta())
		{
			// Acquire global session lock
			ASN::ReadLock lock = AcquireSessionReadLock(sessionID);

			GetCRLCache(sessionID).Add(encCrl, GetDistPtName(), nextUpdate);
		}
		return CM_NO_ERROR;
	}

	return CM_PATH_VALIDATION_ERROR;
}


short CRL::Validate(ulong sessionID, const ValidatedKey& issuersKey,
					ErrorInfoList* pErrors) const
{
	ErrorInfoList crlErrors;

	// Check that the two signature algorithms on the CRL are the same
	if (signature != algorithm)
	{
		if (pErrors == NULL)
			return CM_PATH_VALIDATION_ERROR;
		else
			crlErrors.AddError(CM_CRL_SIG_ALG_MISMATCH, issuer);
	}

	// Check the signature on the CRL
	try {
		short cmlError = VerifySignature(sessionID, issuersKey);
		if (cmlError != CM_NO_ERROR)
		{
			if (pErrors == NULL)
				return CM_PATH_VALIDATION_ERROR;
			else
			{
				if (cmlError == CM_NO_TOKENS_SUPPORT_SIG_ALG)
					cmlError = CM_NO_TOKENS_SUPPORT_CRL_SIG_ALG;
				else
					cmlError = CM_CRL_SIGNATURE_INVALID;
				crlErrors.AddError(cmlError, issuer);
			}
		}
	}
	catch (...) {
		if (pErrors == NULL)
			return CM_PATH_VALIDATION_ERROR;
		else
			crlErrors.AddError(CM_CRL_SIGNATURE_INVALID, issuer);
	}

	// Check that the CRL is still current
	if (nextUpdate != NULL)
	{
		ASN::Time curTime;
		if (curTime > *nextUpdate)
		{
			if (pErrors == NULL)
				return CM_PATH_VALIDATION_ERROR;
			else
				crlErrors.AddError(CM_CRL_OUT_OF_DATE, issuer, *nextUpdate);
		}
	}

	// Check that there aren't any unrecognized critical extensions
	ASN::UnknownExtensions::const_iterator i = crlExts.unknownExts.begin();
	for ( ; i != crlExts.unknownExts.end(); i++)
	{
		if (i->critical)
		{
			if (pErrors == NULL)
				return CM_PATH_VALIDATION_ERROR;
			else
				crlErrors.AddError(CM_UNRECOGNIZED_CRITICAL_CRL_EXT, issuer,
					i->OID());
		}
	}

	// Check that this validated key may be used to sign CRLs
	if ((issuersKey.pKeyUsage != NULL) &&
		!issuersKey.pKeyUsage->GetBit(SNACC::KeyUsage::cRLSign))
	{
		if (pErrors == NULL)
			return CM_PATH_VALIDATION_ERROR;
		else
			crlErrors.AddError(CM_INVALID_KEY_USE, issuer);
	}

	// Return CM_NO_ERROR if no errors have occurred
	if (crlErrors.empty())
		return CM_NO_ERROR;

	// Add the errors to the supplied error list
	if (pErrors != NULL)
		pErrors->Splice(pErrors->end(), crlErrors);
	return CM_PATH_VALIDATION_ERROR;
}


short CRL::VerifySignature(ulong sessionID,
						   const ValidatedKey& signersKey) const
{
	SignedAsnObj signedCrl(encCrl);
	return signedCrl.VerifySignature(sessionID, signersKey);
}


////////////////////////////////////////
// CertAndParams class implementation //
////////////////////////////////////////
CertAndParams::CertAndParams(const CML::Certificate& issuer,
							 const CTIL::CSM_Buffer* pInheritedParams,
							 short resultCode) :
CML::Certificate(issuer), m_resultCode(resultCode)
{
	if ((pubKeyInfo.algorithm.parameters == NULL) &&
		(pInheritedParams != NULL))
	{
		pubKeyInfo.algorithm.parameters =
			new CTIL::CSM_Buffer(*pInheritedParams);
		if (pubKeyInfo.algorithm.parameters == NULL)
			throw CML_MEMORY_ERR;
	}
}


CertAndParams::operator ValidatedKey() const
{
	ValidatedKey result;
	result.m_pubKeyInfo = pubKeyInfo;

	if (exts.pKeyUsage != NULL)
	{
		result.pKeyUsage = new ASN::KeyUsageExtension(*exts.pKeyUsage);
		if (result.pKeyUsage == NULL)
			throw CML_MEMORY_ERR;
	}

	if (exts.pExtKeyUsage != NULL)
	{
		result.pExtKeyUsage = new ASN::ExtKeyUsageExtension(*exts.pExtKeyUsage);
		if (result.pExtKeyUsage == NULL)
			throw CML_MEMORY_ERR;
	}

	return result;
}


void CertAndParams::RetrieveCRLsFromSIA(ulong sessionID,
										ASN::BytesList& encCRLs) const
{
	if (exts.pSubjInfoAccess == NULL)
		return;

	// Acquire global session lock
	ASN::ReadLock lock = AcquireSessionReadLock(sessionID);


	const CallbackFunctions& funcs = GetCallbacksFromRef(sessionID);
	std::list<ASN::AccessDescription>::const_iterator i =
		exts.pSubjInfoAccess->begin();
	for ( ; i != exts.pSubjInfoAccess->end(); ++i)
	{
		EncObject_LL* pObjList = NULL;
		if (i->method == SNACC::id_ad_caRepository)
		{
			if ((i->location.GetType() == ASN::GenName::URL) &&
				(funcs.pUrlGetObj != NULL))
			{
				funcs.pUrlGetObj(funcs.extHandle, i->location.GetName().name,
					CRL_TYPE | ARL_TYPE, &pObjList);
			}
			// else skip this location

			// Add any CRLs found to the list
			EncObject_LL* pTemp = pObjList;
			while (pTemp != NULL)
			{
				try {
					encCRLs.push_back(pTemp->encObj);
				}
				catch (...) {
					// Skip this object
				}
				pTemp = pTemp->next;
			}
			funcs.pFreeObj(funcs.extHandle, &pObjList);
		}
	}

	// Remove duplicates in the CRL list
	encCRLs.sort();
	encCRLs.unique();
}


/////////////////////////////
// CML::Internal Functions //
/////////////////////////////
short Internal::CheckRevocationStatus(ulong sessionID, const ASN::Cert& target,
									 const CertAndParams& issuerCert,
									 const CTIL::CSM_Buffer* pParams,
									 SearchBounds searchFlag, bool isEE,
									 ErrorInfoList& certErrors,
									 ErrorInfoList& pathErrors,					
									 PathState& state)
{
	// Determine the type of target cert (CA or EE or unknown)
	ASN::CertType certType = ASN::UnknownCert;
	if (target.exts.pBasicCons != NULL)
	{
		if (target.exts.pBasicCons->isCA)
			certType = ASN::CACert;
		else
			certType = ASN::EndEntityCert;
	}
	else if (target.exts.pKeyUsage != NULL)
	{
		if (target.exts.pKeyUsage->GetBit(SNACC::KeyUsage::keyCertSign))
			certType = ASN::CACert;
		else
			certType = ASN::EndEntityCert;
	}

	// If the type is still unknown and its an intermediate cert, assume CA
	if ((certType == ASN::UnknownCert) && !isEE)
		certType = ASN::CACert;
	
	// Process the CRL distribution points extension if present
	short err = CM_NO_ERROR;
	ASN::RevocationReasons checkedReasons;
	if (target.exts.pCrlDistPts != NULL)
	{
		// Process each distribution point...
		std::list<DistributionPoint>::const_iterator iDP =
			target.exts.pCrlDistPts->begin();
		for ( ; (iDP != target.exts.pCrlDistPts->end()) &&
			(checkedReasons != kAllReasons); ++iDP)
		{
			processDistPt(sessionID, *iDP, err, target, certType, issuerCert,
				searchFlag, checkedReasons, certErrors, NULL, state);
		}

		// If the extension is flagged critical, check that the appropriate
		// key compromise reason code was checked
		if (target.exts.pCrlDistPts->critical)
		{
			bool reportErr = true;
			switch (certType)
			{
			case ASN::CACert:
				reportErr =
					!checkedReasons.GetBit(SNACC::ReasonFlags::cACompromise);
				break;
			case ASN::EndEntityCert:
				reportErr =
					!checkedReasons.GetBit(SNACC::ReasonFlags::keyCompromise);
				break;
			case ASN::UnknownCert:
			default:
				reportErr =
					!checkedReasons.GetBit(SNACC::ReasonFlags::cACompromise) ||
					!checkedReasons.GetBit(SNACC::ReasonFlags::keyCompromise);
			}
			
			if (reportErr)
			{
				pathErrors.AddError(CM_CRITICAL_KEY_COMPROMISE_NOT_CHECKED,
					target.subject);
			}
		}
	}

	// If not all of the revocation reasons have been checked, check the
	// complete CRL
	if (checkedReasons != kAllReasons)
	{
		// Process the distribution point for the issuer's complete CRL
		processDistPt(sessionID, ASN::DistributionPoint(), err, target,
			certType, issuerCert, searchFlag, checkedReasons, certErrors,
			&pathErrors, state);
	}
	
	if (checkedReasons != kAllReasons)
	{
		// Perform a bit-wise XOR of the reasons bitmask to report which
		// reasons were not checked
		checkedReasons ^= kAllReasons;
		
		// Build a string of zeros and ones to indicate which reasons haven't
		// been checked.  A one indicates the reason wasn't checked.
		char bitMaskStr[ASN::RevocationReasons::kNumReasonBits + 1];
		for (unsigned int i = 0; i < kAllReasons.BitLen(); i++)
			bitMaskStr[i] = (char)(checkedReasons.GetBit(i) ? '1' : '0');
		bitMaskStr[kAllReasons.BitLen()] = '\0';

		// Add the error to the path errors
		pathErrors.AddError(CM_REV_REASONS_NOT_CHECKED, target, bitMaskStr);
	}

	if (certErrors.empty() && pathErrors.empty())
	{
		if (err == CM_NO_ERROR)
			return CM_NO_ERROR;
		else if (err == CMI_TENTATIVELY_VALID)
			return CMI_TENTATIVELY_VALID;
	}

	return CM_PATH_VALIDATION_ERROR;
} // end of Internal::CheckRevocationStatus()


/////////////////////
// Local Functions //
/////////////////////
const AbstractCRL* chooseBestCRL(const CachedCrlList* pList,
								 const ASN::RevocationReasons& reasons)
{
	if ((pList == NULL) || pList->empty())
		return NULL;

	// Return the first CRL which matches all of the reasons
	CachedCrlList::const_iterator i;
	for (i = pList->begin(); i != pList->end(); ++i)
	{
		if (*i != NULL)
		{
			if ((*i)->crlExts.pIssuingDP == NULL)
				return new CachedCrlRef(**i);
			else
			{
				const ASN::IssuingDistPointExtension& issuingDP =
					*(*i)->crlExts.pIssuingDP;

				if (issuingDP.onlySomeReasons == NULL)
					return new CachedCrlRef(**i);

				if ((*issuingDP.onlySomeReasons & reasons) == reasons)
					return new CachedCrlRef(**i);
			}
		}
	}

	// None of the CRLs match all reasons, so return the first CRL
	return new CachedCrlRef(*pList->front());
}


// Sort by thisUpdate time Function
bool std::greater<CRL>::operator()(const CRL& x,
	const CRL& y) const
{
	return (x.base().thisUpdate > y.base().thisUpdate);
}


const AbstractCRL* chooseValidCRL(ulong sessionID, short& err, ASN::CertType certType,
								  const CertAndParams& issuerCert,
								  const DistributionPoint& distPt,
								  const ASN::RevocationReasons& reasons,
								  SearchBounds searchFlag,
								  const ASN::BytesList& encCRLs,
								  ErrorInfoList* pErrors,
								  PathState& state)
{
	// Decode each of the CRLs
	std::list<CRL> crls;
	ASN::BytesList::const_iterator i;
	for (i = encCRLs.begin(); i != encCRLs.end(); ++i)
	{
//		std::list<CRL>::iterator crlNew = crls.insert(crls.end());
		try {
//			crlNew->Decode(*i);
			CRL decCRL(*i);
			crls.push_back(decCRL);
		}
		catch (...) {
			// Skip this CRL
//			crls.erase(crlNew);
		}
	}

	// Remove from the list any CRLs that aren't of the proper scope
	std::list<CRL>::iterator iCrl = crls.begin(); 
	while (iCrl != crls.end())
	{
		// If the CRL is a delta CRL, remove it
		if (iCrl->base().IsDelta())
		{
			iCrl = crls.erase(iCrl);
			continue;
		}

		if (!iCrl->base().MatchesScope(certType, issuerCert.base().subject,
			&distPt, &reasons))
		{
			iCrl = crls.erase(iCrl);
			continue;
		}

		++iCrl;
	}

	// Sort the CRLs by thisUpdate time
	std::greater<CRL> sortByThisUpdate;
	crls.sort(sortByThisUpdate);

	// If a complete CRL is requested, move to the head of the list any CRLs
	// that include ALL of the requested revocation reasons
	if ((distPt.distPoint == NULL) && (distPt.reasons == NULL) &&
		(distPt.crlIssuer == NULL))
	{
		std::list<CRL>::iterator iInsertLoc = crls.begin();
		iCrl = crls.begin();
		while (iCrl != crls.end())
		{
			if ((iCrl->base().crlExts.pIssuingDP == NULL) ||
				(iCrl->base().crlExts.pIssuingDP->onlySomeReasons == NULL) ||
				((*iCrl->base().crlExts.pIssuingDP->onlySomeReasons &
					reasons) == reasons))
			{
				if (iCrl != iInsertLoc)
					crls.splice(iInsertLoc, crls, iCrl++);
				else
				{
					++iCrl;
					++iInsertLoc;
				}
			}
			else
				++iCrl;
		}

		// For those complete CRLs that include all of the requested reasons,
		// move to the head of the list any CRLs that are issued by the cert
		// issuer
		std::list<CRL>::iterator iEnd = iInsertLoc;
		iCrl = iInsertLoc = crls.begin();
		while (iCrl != iEnd)
		{
			if (isIssuer(iCrl->base(), issuerCert.base()))
			{
				if (iCrl != iInsertLoc)
					crls.splice(iInsertLoc, crls, iCrl++);
				else
				{
					++iCrl;
					++iInsertLoc;
				}
			}
			else
				++iCrl;
		}
	}

	// Set the tryOthers flag to false unless the path validation errors
	// are present and empty
	bool tryOthers = false;
	if ((pErrors != NULL) && pErrors->empty())
		tryOthers = true;

	// For each remaining CRL...
	AbstractCRL* pInvalidCRL = NULL;
	ErrorInfoList invalidCRLErrors;
	std::list<CRL>::iterator iCRL;
	for (iCRL = crls.begin(); iCRL != crls.end(); ++iCRL)
	{
		try {
			// Validate the CRL
			ErrorInfoList tempErrors;
			const CachedCRL* pCachedCRL = validateCRL(*iCRL, sessionID, searchFlag,
				tempErrors, issuerCert, tryOthers, err, state);

			
			// If there were no errors
			if ((err == CM_NO_ERROR) || (err == CMI_TENTATIVELY_VALID)) 
			{
				delete pInvalidCRL;
				if (pCachedCRL != NULL)
					return new CachedCrlRef(*pCachedCRL);
				else
					return new CrlPtr(crls, iCRL);
			}

			// If the CRL is invalid, and the path errors are requested,
			// keep this CRL and its errors in case a valid CRL isn't found
			if ((err == CM_PATH_VALIDATION_ERROR) ||
				(err == CM_NO_PATH_FOUND))
			{
				if ((pInvalidCRL == NULL) && (pErrors != NULL))
				{
					invalidCRLErrors = tempErrors;
					pInvalidCRL = new CrlPtr(iCRL);
					if (pInvalidCRL == NULL)
						throw CML_MEMORY_ERR;
				}
			}
			
			// If no more CRLs will be tried, break out of the loop or if the only error
			// is CM_CRL_OUT_DATE stop because this is probably the best path
			if ((!tryOthers) || (errorIsCRLOutOfDate(tempErrors)))
				break;
		}
		catch (...) {
			// Skip this CRL
		}
	}

	if (pInvalidCRL != NULL)
		pErrors->Splice(pErrors->end(), invalidCRLErrors);

	return pInvalidCRL;
} // end of chooseValidCRL()


short findCRLIssuer(const CertificateList& crl, ulong sessionID,
				   SearchBounds searchFlag, CertList& certList)
{
	// Fill in the CertMatchData
	CertMatchData matchInfo;
	memset(&matchInfo, 0, sizeof(CertMatchData));
	matchInfo.pPubKeyOID = &SplitSigHashAlg(crl.signature.algorithm);
	matchInfo.canSignCRLs = true;
	if (crl.crlExts.pAuthKeyID != NULL)
	{
		matchInfo.pSubjKeyID = crl.crlExts.pAuthKeyID->keyID;
		if (crl.crlExts.pAuthKeyID->authCertIssuer != NULL)
		{
			GenNames::const_iterator iGN =
				crl.crlExts.pAuthKeyID->authCertIssuer->Find(GenName::X500);
			if (iGN != crl.crlExts.pAuthKeyID->authCertIssuer->end())
			{
				matchInfo.pIssuer = iGN->GetName().dn;
				matchInfo.pSerialNum = crl.crlExts.pAuthKeyID->authCertSerialNum;
			}
		}
	}

	// Request the issuer cert(s)
	ASN::BytesList encCertList;
	short cmlErr = RequestCerts(sessionID, encCertList, crl.issuer, searchFlag,
		&matchInfo);
	if (cmlErr != CM_NO_ERROR)
		return cmlErr;

	// Decode each of the issuer certs and add them to the list
	ASN::BytesList::const_iterator i; 
	for (i = encCertList.begin(); i != encCertList.end(); ++i)
	{
		try {
			certList.push_back(*i);
		}
		catch (...) {
			// Skip over this cert
		}
	}

	// If the CRL contains an authority key identifier extension with a
	// key identifier, move to the head of the list any certs which include a
	// subject key identifier
	if ((crl.crlExts.pAuthKeyID != NULL) &&
		(crl.crlExts.pAuthKeyID->keyID != NULL))
	{
		CertList::iterator iCert = certList.begin();
		CertList::iterator iInsertLoc = certList.begin();
		while (iCert != certList.end())
		{
			if (iCert->base().exts.pSubjKeyID != NULL)
			{
				if (iCert != iInsertLoc)
					certList.splice(iInsertLoc, certList, iCert++);
				else
				{
					++iCert;
					++iInsertLoc;
				}
			}
			else
				++iCert;
		}
	}

	if (certList.empty())
		return CM_NOT_FOUND;

	return CM_NO_ERROR;
} // end of findCRLIssuer()


const AbstractCRL* findValidCRL(ulong sessionID, short& err, ASN::CertType type,
								const CertAndParams& certIssuer,
								const DistributionPoint& distPt,
								const ASN::RevocationReasons& reasons,
								SearchBounds searchFlag,
								ErrorInfoList* pErrors, PathState& state)
{
	// Search the CRL cache for the requested CRL
	const AbstractCRL* pCRL = searchCRLCache(sessionID, certIssuer, type,
		reasons, distPt);
	if (pCRL != NULL)
	{
		err = CM_NO_ERROR;
		return pCRL;
	}
	
	try {
		// If the complete CRL is requested and the target's issuing CA has a
		// PKIX SIA extension, try to find the CRL using that extension
		ASN::BytesList encCRLs;
		if ((distPt.distPoint == NULL) && (distPt.reasons == NULL) &&
			(distPt.crlIssuer == NULL))
		{
			certIssuer.RetrieveCRLsFromSIA(sessionID, encCRLs);

			// Choose and validate the appropriate CRL from the list
			pCRL = chooseValidCRL(sessionID, err, type, certIssuer, distPt,
				reasons, searchFlag, encCRLs, pErrors, state);
			if (pCRL != NULL)
				return pCRL;
		}

		// Search the callback locations
		RequestCRLs(sessionID, encCRLs, &(const ASN::DN&)certIssuer,
			searchFlag, NULL, &distPt);

		// Choose and validate the appropriate CRL from the list
		pCRL = chooseValidCRL(sessionID, err, type, certIssuer, distPt, reasons,
			searchFlag, encCRLs, pErrors, state);
		if (pCRL != NULL)
			return pCRL;

		// Add an extended error since the CRL was not found
		if (pErrors != NULL)
			pErrors->AddError(CM_CRL_NOT_AVAIL, (const ASN::DN&)certIssuer);
		return NULL;
	}
	catch (...) {
		// Add an extended error since the CRL was not found
		if (pErrors != NULL)
			pErrors->AddError(CM_CRL_NOT_AVAIL, (const ASN::DN&)certIssuer);
		return NULL;
	}
}


GenName getDistPtName(const CertificateList& crl)
{
	if ((crl.crlExts.pIssuingDP != NULL) &&
		(crl.crlExts.pIssuingDP->distPoint != NULL))
	{
		const ASN::DistPointName& dpName = *crl.crlExts.pIssuingDP->distPoint;
		if (dpName.GetType() == ASN::DistPointName::DIST_PT_REL_NAME)
		{
			DN fullName(crl.issuer);
			fullName += dpName.GetRelativeName();
			return fullName;
		}
		else	// DIST_PT_FULL_NAME
		{
			// Return the first X.500 DN (if one is present)
			GenNames::const_iterator iGN =
				dpName.GetFullName().Find(GenName::X500);
			if (iGN != dpName.GetFullName().end())
				return *iGN;

			// Return the first URL (if one is present)
			iGN = dpName.GetFullName().Find(GenName::URL);
			if (iGN != dpName.GetFullName().end())
				return *iGN;
		}
	}

	return crl.issuer;
}


bool isIssuer(const ASN::CertificateList& crl, const ASN::Cert& issuer)
{
	// Check that CRL issuer's name matches the cert issuer's name
	if (crl.issuer != issuer.subject)
		return false;

	// Check that the signature and public key algorithms are consistent
	if (issuer.pubKeyInfo != SplitSigHashAlg(crl.signature.algorithm))
		return false;

	// Check that the authority key identifier if present matches the issuer
	if (crl.crlExts.pAuthKeyID != NULL)
	{
		const ASN::AuthKeyIdExtension& authID = *crl.crlExts.pAuthKeyID;

		// If the key identifier member is present, check it against the
		// issuer's subject key identifier
		if ((authID.keyID != NULL) && (issuer.exts.pSubjKeyID != NULL))
		{
			if (*authID.keyID != *issuer.exts.pSubjKeyID)
				return false;
		}

		// If the issuer name is present, check it against the issuer's
		// issuer name
		if ((authID.authCertIssuer != NULL) &&
			!authID.authCertIssuer->IsPresent(issuer.issuer))
			return false;

		// If the serial number is present, check it against the issuer's
		// serial number
		if ((authID.authCertSerialNum != NULL) &&
			(*authID.authCertSerialNum != issuer.serialNumber))
			return false;
	}

	// Check that the issuer's key is authorized to sign CRLs
	if ((issuer.exts.pKeyUsage != NULL) &&
		!issuer.exts.pKeyUsage->GetBit(SNACC::KeyUsage::cRLSign))
		return false;

	return true;
}


void processDistPt(ulong sessionID, const ASN::DistributionPoint& distPt,
				   short& err, const ASN::Cert& target, ASN::CertType certType,
				   const CertAndParams& certIssuer, SearchBounds searchFlag,
				   ASN::RevocationReasons& checkedReasons,
				   ErrorInfoList& certErrors, ErrorInfoList* pPathErrors,
				   PathState& state)
{
	// Compute the reasons to check for this distribution point
	ASN::RevocationReasons reasonsToCheck = ~checkedReasons;
	if (distPt.reasons != NULL)
		reasonsToCheck &= *distPt.reasons;

	// While the target certificate isn't revoked and not all reasons in the
	// distribution point have been checked...
	bool isRevoked = false;
	ASN::RevocationReasons distPtReasonsChecked;
	while (!isRevoked && (distPtReasonsChecked != reasonsToCheck))
	{
		// Find a valid CRL from the specified distribution point
		const AbstractCRL* pCRL = findValidCRL(sessionID, err, certType, certIssuer,
			distPt, ~distPtReasonsChecked, searchFlag, pPathErrors, state);

		// If a CRL wasn't found, break out of the loop
		if (pCRL == NULL)
			break;
		else	// Set to NULL so CRL_NOT_AVAIL path error isn't recorded
			pPathErrors = NULL;

		const CertificateList& theCRL = *pCRL;
		try {
			// Update the reasons to check
			if ((theCRL.crlExts.pIssuingDP != NULL) &&
				(theCRL.crlExts.pIssuingDP->onlySomeReasons != NULL))
//				reasonsToCheck &= ~*theCRL.crlExts.pIssuingDP->onlySomeReasons;
				distPtReasonsChecked |= *theCRL.crlExts.pIssuingDP->onlySomeReasons &
					reasonsToCheck;
			else
				// Zeroize the reasons
//				reasonsToCheck.Set(ASN::RevocationReasons::kNumReasonBits);
				distPtReasonsChecked = reasonsToCheck;
				
			// Check if the target cert is revoked
			ASN::Revocations::const_iterator iRev =
				theCRL.GetRevocations().IsRevoked(target.serialNumber,
				target.issuer, theCRL.issuer, theCRL.crlExts.pOrderedList);
			if (iRev != theCRL.GetRevocations().end())
			{
				// Target cert is revoked, so record the error, update the
				// checked reasons
				certErrors.AddError(iRev, target);
				isRevoked = true;
			}
			delete pCRL;
		}
		catch (...) {
			delete pCRL;
			throw;
		}
	}

	// Update the checked reasons
	if (isRevoked)
		checkedReasons = kAllReasons;
	else
		checkedReasons |= distPtReasonsChecked;

} // end of processDistPt()


const AbstractCRL* searchCRLCache(ulong sessionID, const DN& issuer,
								  ASN::CertType certType,
								  const ASN::RevocationReasons& reasons,
								  const DistributionPoint& distPt)
{
	CachedCrlList* pList = NULL;
	try {
		// Acquire global session lock
		ASN::ReadLock lock = AcquireSessionReadLock(sessionID);

		// Get the CRL cache from the session handle
		const CrlCache& cache = GetCRLCache(sessionID);

		// Search the cache for a CRL with any of the distribution point names
		if (distPt.distPoint != NULL)
		{
			// Search using the distribution point name(s)
			switch (distPt.distPoint->GetType())
			{
			case ASN::DistPointName::DIST_PT_FULL_NAME:
				{
					const GenNames& fullName = distPt.distPoint->GetFullName();
					GenNames::const_iterator i = fullName.begin();
					for ( ; i != fullName.end(); ++i)
						pList = cache.Find(*i, pList);
				}
				break;
				
			case ASN::DistPointName::DIST_PT_REL_NAME:
				{
					// Build the full distribution point name using either
					// the crlIssuer field (if present) or the cert issuer
					if (distPt.crlIssuer != NULL)
					{
						GenNames::const_iterator i =
							distPt.crlIssuer->Find(GenName::X500);
						while (i != distPt.crlIssuer->end())
						{
							// Build the full X.500 DN
							DN fullName(*i->GetName().dn);
							fullName += distPt.distPoint->GetRelativeName();
							pList = cache.Find(fullName, pList);
							
							i = distPt.crlIssuer->FindNext(i,
								GenName::X500);
						}
					}
					else
					{
						ASN::DN fullName = issuer;
						fullName += distPt.distPoint->GetRelativeName();
						pList = cache.Find(fullName);
					}
				}
				break;
			}
		}
		else if (distPt.crlIssuer != NULL)	// Use cRLIssuer field
		{
			GenNames::const_iterator i = distPt.crlIssuer->begin();
			for ( ; i != distPt.crlIssuer->end(); ++i)
				pList = cache.Find(*i, pList);
		}
		else	// Use the certificate issuer
			pList = cache.Find(issuer);

		// Remove from the list any CRLs whose scope don't cover the type
		// of certificate or the reasons of interest
		// Also remove any expired cached CRLs
		if (pList != NULL)
		{
			CachedCrlList::iterator i = pList->begin();
			while (i != pList->end())
			{
				if ((*i == NULL) || (*i)->IsExpired() ||
					!(*i)->MatchesScope(certType, issuer, &distPt, &reasons))
					i = pList->erase(i);
				else
					++i;
			}

			// Choose the best CRL and return
			const AbstractCRL* pCRL = chooseBestCRL(pList, reasons);
			delete pList;
			return pCRL;
		}

		return NULL;
	}
	catch (...) {
		delete pList;
		return NULL;
	}
} // end of searchCRLCache()


const CachedCRL* validateCRL(const CRL& crl, ulong sessionID,
					   SearchBounds boundsFlag, ErrorInfoList& errors,
					   const CertAndParams& certIssuer, bool tryOtherIssuers,
					   short& cmlResult, PathState& state)
{
	// Acquire global session lock
	ASN::ReadLock lock = AcquireSessionReadLock(sessionID);
	
	// If the CRL is in the cache, return it
	const CachedCRL* pCachedCRL = GetCRLCache(sessionID).FindCRL(crl);
	if (pCachedCRL != NULL)
	{
		cmlResult = CM_NO_ERROR;
		return pCachedCRL;
	}

	lock.Release();

	// If the cert issuer issued the CRL, just validate the CRL and return
	if (isIssuer(crl.base(), certIssuer.base()))
	{
		cmlResult = crl.Validate(sessionID, certIssuer,  &errors);
		
		if (cmlResult == CM_NO_ERROR)
		{
			// Add the CRL to the session cache if the path state is not tentative
			if (certIssuer.m_resultCode == CM_NO_ERROR)
			{
				if (!crl.base().IsDelta())
				{				
					// Acquire the global session lock
					ASN::ReadLock lock = AcquireSessionReadLock(sessionID);
					
					pCachedCRL = GetCRLCache(sessionID).Add(crl, 
						getDistPtName(crl.base()), crl.base().nextUpdate);
					
					if (pCachedCRL != NULL)
						return pCachedCRL;
				}
				return NULL;				
			}
			// Add the CRL to the tentative CRL cache, if no errors have occurred. It will
			// be added to the session CRL cache after validation is complete
			else if (certIssuer.m_resultCode == CMI_TENTATIVELY_VALID)
			{
				TentativeCRL* tmpCRLObj = state.tentativeCRLCache.Add(crl,
					getDistPtName(crl.base()));
				if (tmpCRLObj != NULL)
				{
					// Clear any errors in case this CRL was added previously
					tmpCRLObj->ClearErrors();
					
					// Reset the error code to tentatively valid if the issuer
					// is tentatively valid
					if (certIssuer.m_resultCode == CMI_TENTATIVELY_VALID)
						cmlResult = CMI_TENTATIVELY_VALID;
					
					return tmpCRLObj;
				}
				else
				{
					// CRL could not be added so all paths using this CRL are
					// invalid
					cmlResult = CM_CRL_PATH_NOT_VALID;
					return NULL;
				}
			}
			return NULL;
		}
		// if the errors do not contain CM_CRL_SIGNATURE_INVALID, just return
		else if (!errorsContainSigInvalid(errors))
			return NULL;
		else
		{
			// Remove the CRL signature invalid error and fall through
			errors.clear();
			cmlResult = CM_CRL_SIGNATURE_INVALID;
		}
	}
	else
		cmlResult = CM_CRL_PATH_NOT_FOUND;

	// Get the CRL from tentative CRL Cache if present.
	TentativeCRL* tmpCRLObj = state.tentativeCRLCache.Find(crl);

	if (tmpCRLObj)
	{
		// If the CRL was previously found to be invalid, set the error list to the original error,
		// and do not use it.
		if (tmpCRLObj->HasErrors())
		{
			cmlResult = CM_PATH_VALIDATION_ERROR;
			errors = tmpCRLObj->GetErrors();
			return NULL;
		}
		else
		{			
			// The CRL was found tentatively valid from earlier in the path,
			// set the result to CMI_TENTATIVELY_VALID, as it will be validated later
			cmlResult = CMI_TENTATIVELY_VALID;
			return tmpCRLObj;
		}
	}

	// Find the CRL issuer's certificate(s)
	CertList certList;
	if (findCRLIssuer(crl.base(), sessionID, boundsFlag, certList) != CM_NO_ERROR)
	{
		errors.AddError(CM_CRL_PATH_NOT_FOUND, crl.base().issuer);
		cmlResult = CM_NO_PATH_FOUND;
		return NULL;
	}

	// Add the CRL to the tentatively valid CRL cache to prevent infinite
	// recursion
	tmpCRLObj = state.tentativeCRLCache.Add(crl, getDistPtName(crl.base()));
	if (tmpCRLObj == NULL)
	{
		// CRL could not be added so all paths using this CRL are invalid
		cmlResult = CM_CRL_PATH_NOT_VALID;
		return NULL;
	}

	// Try to validate each of the CRL issuer's certificate(s)
	ValidatedKey signersKey;
	CertList::const_iterator iCert;
	for (iCert = certList.begin(); (iCert != certList.end()) &&	((cmlResult != CM_NO_ERROR) &&
		(cmlResult != CMI_TENTATIVELY_VALID)); ++iCert)
	{
		// Try this cert unless it is the cert issuer certificate
		if (iCert->GetEnc() != certIssuer.GetEnc())
		{
			// Push this cert issuer onto the stack if not already there
			if(! state.PushIssuer(iCert->GetEnc()))
			{
				// it is already on the stack, so this crl must be tentatively valid
				cmlResult = CMI_TENTATIVELY_VALID;
				return tmpCRLObj;
			}
			try 
			{
				ErrorInfoList tempErrors;
				// Validate the CRL issuer's certificate (note the new path will start as valid 
				// and not tentative in case it never merges with this path)
				cmlResult = validateCRLIssuer(sessionID, boundsFlag, *iCert,
					signersKey, state, tempErrors);
			
				// If no more signer certs will be tried, break out of the loop or if the only error
				// is CM_CRL_OUT_DATE stop because this is probably the best path
				if ((!tryOtherIssuers) || (errorIsCRLOutOfDate(tempErrors))) {
					state.PopIssuer();
					break;
				}
			}
			catch (...)
			{
				// Skip this cert
				cmlResult = CM_CRL_PATH_NOT_VALID;
			}
			state.PopIssuer();
		}
	}
	
	// If an error occurred validating the issuer, add the error to the error list
	if ((cmlResult != CM_NO_ERROR) && (cmlResult != CMI_TENTATIVELY_VALID))
	{
		errors.AddError(cmlResult, crl.base().issuer);
		//Mark as invalid in tentative CRL Cache by setting the errors
		tmpCRLObj->SetErrors(errors);
		if (cmlResult == CM_CRL_PATH_NOT_FOUND)
		{
			cmlResult = CM_NO_PATH_FOUND;
			return NULL;
		}
	}

	
	// Validate the CRL
	short valErr = crl.Validate(sessionID, signersKey, &errors);

	if (valErr == CM_NO_ERROR)
	{
		// Add the CRL to the session cache
		if (cmlResult == CM_NO_ERROR)
		{
			if (!crl.base().IsDelta())
			{				
				// Acquire the global session lock
				ASN::ReadLock lock = AcquireSessionReadLock(sessionID);
				
				pCachedCRL = GetCRLCache(sessionID).Add(crl, 
					getDistPtName(crl.base()), crl.base().nextUpdate);
				
				if (pCachedCRL != NULL)
					return pCachedCRL;
			}
			return NULL;				
		}
		// Set CRL to valid in cache if no errors have occurred
		else if (cmlResult == CMI_TENTATIVELY_VALID)
		{
				// Clear any errors in case this CRL was added previously
				tmpCRLObj->ClearErrors();				
				return tmpCRLObj;
		}
	}

	// At this point we exhausted all chances of validating this CRL set errors and exit.

	cmlResult = CM_PATH_VALIDATION_ERROR;

	//Mark as invalid in tentative CRL Cache by setting the errors
	if (tmpCRLObj)
		tmpCRLObj->SetErrors(errors);

	return NULL;
} // end of validateCRL()


short validateCRLIssuer(ulong sessionID, SearchBounds boundsFlag,
						const Certificate& crlIssuer, ValidatedKey& validKey,
						PathState& state, ErrorInfoList& errors)
{
	// Get the maximum number of paths to build
	ushort maxPaths = GetMaxPaths(sessionID);

	PathStack curPath;
	
	// Initialize the path count and error results
	ushort nPaths = 0;
	short cmlErr = CM_CRL_PATH_NOT_FOUND;
	do
	{
		curPath.Clear();
#ifdef THREAD_TESTING
		//start the BuildandValidate tag
		gPrintThreads.WriteBegin("CRLBuildAndValidate", 1, 
			"(CRL) Build and Validate", "" , 
			"serialNum=", crlIssuer.base().serialNumber);
		gPrintThreads.WriteBegin("CRLPathBuild", 2,
			"(CRL) Building path for", crlIssuer.base().subject,
			"serialNum=", crlIssuer.base().serialNumber);
#endif //THREAD_TESTING
		// Build the path
		if (state.BuildNext(curPath) != CM_NO_ERROR)
		{
#ifdef THREAD_TESTING
			gPrintThreads.WriteEnd("CRLPathBuild", 2);
			gPrintThreads.WriteEnd("CRLBuildAndValidate", 1);
#endif //THREAD_TESTING
			break;
		}
#ifdef THREAD_TESTING
		gPrintThreads.WriteEnd("CRLPathBuild", 2);
		gPrintThreads.WriteBegin("CRLPathValidate", 2, "");
#endif //THREAD_TESTING
		
		// Try to validate the path
		++nPaths;
		errors.clear();
		cmlErr = state.ValidatePath(curPath, &errors, &validKey);
#ifdef THREAD_TESTING
		gPrintThreads.WriteEnd("CRLPathValidate", 2);
		// dump the errors to the log file
		if (cmlErr == CM_PATH_VALIDATION_ERROR)
		{
			gPrintThreads.WriteData("FAILURE --- Path Validation Failed!");
			logErrors(errors);
		}
		if (cmlErr == CM_NO_ERROR)
		{
			gPrintThreads.WriteData("SUCCESS --- Path Validation Succeeded!");
		}
		if (cmlErr == CMI_TENTATIVELY_VALID)
		{
			gPrintThreads.WriteData("SUCCESS --- Path Tentatively Valid!");
		}
#endif //THREAD_TESTING
		
		if ((cmlErr != CM_NO_ERROR) && (cmlErr != CMI_TENTATIVELY_VALID))
			cmlErr = CM_CRL_PATH_NOT_VALID;
		
#ifdef THREAD_TESTING
		gPrintThreads.WriteEnd("CRLBuildAndValidate", 1);
#endif //THREAD_TESTING

		// If the only error is CM_CRL_OUT_OF_DATE stop because this is probably the best path
		if (errorIsCRLOutOfDate(errors))
			break;		
	}
	while ( (nPaths < maxPaths) && ((cmlErr != CM_NO_ERROR) && (cmlErr != CMI_TENTATIVELY_VALID)) );

	// If the path for this CRL issuer is TENTATIVELY VALID, then we must
	// remove this path from the previous path history so it can be used again.
	// It is likely it was found now, but never cached due to the outer path
	// having problems.
	if (cmlErr == CMI_TENTATIVELY_VALID)
	{
		// Check that the first cert in the path is present and trusted
		if ((curPath.Deck().front() == NULL) ||
			!curPath.Deck().front()->IsTrusted())
			throw CML_ERR(CM_NULL_POINTER);

		((TrustedCertNode*)curPath.Deck().front())->DeletePreviousPath(curPath);
	}
	
	return cmlErr;
} // end of validateCRLIssuer()

bool errorsContainSigInvalid(const ErrorInfoList& errorList) 
{
	// Return proper value when no errors are present
	if (errorList.empty())
		return false;

	ErrorInfoList::const_iterator iError;
	// Check for CM_CRL_SIGNATURE_INVALID, if found return true
	for (iError = errorList.begin(); iError != errorList.end(); ++iError)
	{
		if (iError->error == CM_CRL_SIGNATURE_INVALID)
			return true;
	}
	return false;
}

// CachedCrlRef constructor
CachedCrlRef::CachedCrlRef(const CachedCRL& cachedCRL) : crl(cachedCRL),
m_cachedCRLLock(cachedCRL.m_mutex.AcquireReadLock())
{
}


//////////////////////////////////////////////
// Implementation of the TentativeCRL class //
//////////////////////////////////////////////
TentativeCRL::TentativeCRL(const CRL& crl, const ASN::GenName& distPtName) :
CachedCRL(crl, distPtName, NULL, 0)
{
}

void TentativeCRL::SetErrors(ErrorInfoList& errors)
{
	if (!errors.empty())
		m_errors = errors;
}


///////////////////////////////////////////////////
// Implementation of the TentativeCRLCache class //
///////////////////////////////////////////////////
TentativeCRLCache::~TentativeCRLCache()
{
	// Delete each of the cached CRLs
	TentativeCrlHashIndex::iterator iHashPair = m_crlsByHash.begin();
	for ( ; iHashPair != m_crlsByHash.end(); ++iHashPair)
	{
		if (iHashPair->second != NULL)
			delete iHashPair->second;
	}
}


// Adds a tentatively validated CRL to the cache
TentativeCRL* TentativeCRLCache::Add(const CRL& crl,
									 const ASN::GenName& distPtName)
{
	// If this CRL is already cached, just return it
	TentativeCRL* pCachedCRL = Find(crl);
	if (pCachedCRL != NULL)
		return pCachedCRL;

	// Create a new cached CRL object
	try {
		pCachedCRL = new TentativeCRL(crl, distPtName);
	}
	catch (...) {
		return NULL;
	}

	// Insert this new tentative CRL object into the cache
	m_crlsByHash.insert(TentativeCrlHashIndex::value_type(pCachedCRL->GetHash(),
		pCachedCRL));
	m_crlsByGN.insert(TentativeCrlGNIndex::value_type(distPtName, pCachedCRL));

	return pCachedCRL;
} // end of TentativeCRLCache::Add()


TentativeCRL* TentativeCRLCache::Find(const Bytes& encCRL) const
{
	// Hash the encoded CRL
	Bytes hash;
	encCRL.Hash(hash);

	TentativeCrlHashIndex::const_iterator iCrl = m_crlsByHash.find(hash);
	if (iCrl == m_crlsByHash.end())
		return NULL;

	return iCrl->second;
}


void TentativeCRLCache::MoveValidCRLsToSessionCache()
{
	// Acquire global session lock
	ASN::ReadLock lock = AcquireSessionReadLock(m_sessionID);

	// Loop through the CRLs in the GeneralName index
	TentativeCrlGNIndex::iterator iCrl = m_crlsByGN.begin();
	while (iCrl != m_crlsByGN.end())
	{
		if (iCrl->second == NULL)
			throw CML_ERR(CM_NULL_POINTER);

		// If the CRL is valid, add it to the session cache and remove it from
		// this cache
		TentativeCrlGNIndex::iterator iNext = iCrl;
		++iNext;
		if (!iCrl->second->HasErrors())
		{
			// Find and delete the hash index entry for this CRL
			m_crlsByHash.erase(iCrl->second->GetHash());

			// Try to add the CRL to the session cache
			// If unsuccessful, delete the CRL
			// Note:  Successful adds shouldn't be deleted since the CRL
			// is moved, not copied, into the cache
			if (!GetCRLCache(m_sessionID).Add(iCrl->second))
				delete iCrl->second;

			// Delete this GeneralName index entry
			m_crlsByGN.erase(iCrl);
		}

		// Move to the next iterator
		iCrl = iNext;
	}
}


void TentativeCRLCache::Purge()
{
	// Loop through the CRLs in the GeneralName index
	TentativeCrlGNIndex::iterator iCrl = m_crlsByGN.begin();
	while (iCrl != m_crlsByGN.end())
	{
		if (iCrl->second == NULL)
			throw CML_ERR(CM_NULL_POINTER);

		// Remove only the CRLs that do not have errors (invalid CRLs are kept
		// in the cache)
		TentativeCrlGNIndex::iterator iNext = iCrl;
		++iNext;
		if (!iCrl->second->HasErrors())
		{
			// Find and delete the hash index entry for this CRL
			m_crlsByHash.erase(iCrl->second->GetHash());

			// Delete the TentativeCRL
			delete iCrl->second;

			// Delete this GeneralName index entry
			m_crlsByGN.erase(iCrl);
		}

		// Move to the next iterator
		iCrl = iNext;
	}
}


////////////////////////////////////////////////////
// Implementation of the TentativeCertCache class //
////////////////////////////////////////////////////
TentativeCertCache::TentativeCertCache(ulong sessionID, ushort maxObjs) :
m_sessionID(sessionID)
{
	m_nCerts = 0;

	if (maxObjs == 0)
		m_certs = NULL;
	else
	{
		// Allocate and clear the memory for the MRU queue
		m_certs = new CachedCert*[maxObjs];
		if (m_certs == NULL)
			throw CML_MEMORY_ERR;
		memset(m_certs, 0, sizeof(CachedCert*) * maxObjs);
	}
}

void TentativeCertCache::Purge()
{
	CertHashIndex::iterator iHashPair;
	for (iHashPair = m_certsByHash.begin();
	iHashPair != m_certsByHash.end(); ++iHashPair)
	{
		iHashPair->second->ReleaseIssuers();
	}	
	
	// Delete each of the cached certs
	for (iHashPair = m_certsByHash.begin();
	iHashPair != m_certsByHash.end(); ++iHashPair)
	{
		if (iHashPair->second != NULL)
			delete iHashPair->second;
		m_nCerts--;
	}
	
	// Clear the indices
	m_certsByDN.clear();
	m_certsByHash.clear();
}

TentativeCertCache::~TentativeCertCache(void)
{
	CertHashIndex::iterator iHashPair;
	for (iHashPair = m_certsByHash.begin();
	iHashPair != m_certsByHash.end(); ++iHashPair)
	{
		iHashPair->second->ReleaseIssuers();
	}
	
	
	// Release the MRU queue memory
	if (m_certs != NULL)
		delete[] m_certs;
	
	// Delete each of the cached certs
	for (iHashPair = m_certsByHash.begin();
	iHashPair != m_certsByHash.end(); ++iHashPair)
	{
		if (iHashPair->second != NULL)
			delete iHashPair->second;
	}
	
	// Clear the indices
	m_certsByDN.clear();
	m_certsByHash.clear();
}

CachedCertRef* TentativeCertCache::FindCert(const Certificate& cert) const
{
	// Hash the encoded CRL
	ASN::Bytes encCert = cert.GetEnc();
	ASN::Bytes hash;
	encCert.Hash(hash);

	CertHashIndex::const_iterator iCert = m_certsByHash.find(hash);
	if (iCert == m_certsByHash.end())
		return NULL;

	return new InternalCachedCertRef(*iCert->second);
}

void TentativeCertCache::MoveValidCertsToSessionCache()
{
	// Acquire global session lock
	ASN::ReadLock lock = AcquireSessionReadLock(m_sessionID);

	// Move the certs one at a time
	for (int i = 0; i < m_nCerts; i++)
	{
		CachedCert* pCacheCert = m_certs[i];
		GetCertCache(m_sessionID).Add(pCacheCert);
	}
	m_nCerts = 0;

	// Clear the indices
	m_certsByDN.clear();
	m_certsByHash.clear();
}

// Adds a tentatively validated cert to the cache
const CachedCertRef* TentativeCertCache::Add(const CML::Certificate& tentativeCert,
									const CachedCertList& issuerCerts,
									const PolicyTable& authSet,
									const ASN::PolicyMappingList& mappings,
									bool explicitPolFlag,
									const ASN::Time& expireTime)
{
	// If the cache is disabled, just return
	if (m_maxObjs == 0)
		return NULL;
	
	// Check if this cert is already cached
	const CachedCertRef* pCert = FindCert(tentativeCert.GetEnc());
	if (pCert != NULL)
	{
		// Update this cert's expiration time
		pCert->GetRef().UpdateExpiration(&expireTime, LONG_MAX);
		
		// Acquire global session lock
		ASN::ReadLock lock = CML::Internal::AcquireSessionReadLock(m_sessionID);
		
		// Update this cert's path and path results
		pCert->GetRef().UpdatePathResults(issuerCerts, authSet,
			GetInitialPolicySet(m_sessionID), mappings, explicitPolFlag);
	}
	else
	{
		try 
		{
			// Acquire global session lock
			ASN::ReadLock lock = CML::Internal::AcquireSessionReadLock(m_sessionID);
			
			
			// Create a new cached cert object
			CachedCert* pCacheCert = CachedCert::Construct(tentativeCert.GetEnc(),
				issuerCerts, authSet, GetInitialPolicySet(m_sessionID), mappings,
				explicitPolFlag, expireTime, LONG_MAX);
			
			
			lock.Release();
			
			if (pCacheCert == NULL)
				return NULL;
			
			// Check that space exists in the MRU queue
			if (m_nCerts < m_maxObjs)
			{
				// Insert this new cert object into the cache and the head of the
				// MRU queue
				m_certsByHash.insert(CertHashIndex::value_type(pCacheCert->GetHash(),
					pCacheCert));
				m_certsByDN.insert(CertDNIndex::value_type(pCacheCert->base().subject,
					pCacheCert));
				m_certs[m_nCerts++] = pCacheCert;
				
				pCert = new InternalCachedCertRef(*pCacheCert);
				
			}
			else
			{
				delete pCert;
				pCert = NULL;
			}
		}
		catch (...)
		{
			return NULL;
		}
	} 
	
	
	return pCert;
}


// end of CM_CRL.cpp
