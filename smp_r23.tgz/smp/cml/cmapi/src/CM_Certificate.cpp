/*****************************************************************************
File:     CM_Certificate.cpp
Project:  Certificate Management Library
Contents: Implementation of the Certificate class.

Created:  20 March 2001
Author:   Rich Nicholas <Richard.Nicholas@GetronicsGov.com>

Last Updated:  1 July 2002

Version:  2.1

*****************************************************************************/


////////////////////
// Included Files //
////////////////////
#include "CM_internal.h"


// Using declarations
using namespace CML;
using namespace CML::Internal;
using ASN::Cert;
using ASN::Bytes;



//////////////////////////////////////
// Certificate class implementation //
//////////////////////////////////////
Certificate::Certificate(const Cert& cert) : Cert(cert)
{
	Cert::Encode(encCert);
}


Certificate::Certificate(const Bytes& asn) : Cert(asn)
{
	encCert = asn;
}


Certificate::Certificate(const Bytes_struct& asn)
{
	encCert.Set(asn.num, asn.data);
	Cert::operator=(encCert);
}


Certificate& Certificate::operator=(const Cert& cert)
{
	Cert::operator=(cert);
	Cert::Encode(encCert);
	return *this;
}


Certificate& Certificate::operator=(const Bytes& asn)
{
	Decode(asn);
	return *this;
}


ulong Certificate::Decode(const Bytes& asn)
{
	encCert = asn;
	return Cert::Decode(asn);
}


ulong Certificate::Encode(Bytes& asn) const
{
	asn = encCert;
	return asn.Len();
}


short Certificate::Sign(CTIL::CSM_CtilInst& keyHandle, const ASN::AlgID* pSigAlg)
{
	// Access the token interface
	CTIL::CSM_TokenInterface* pTokenI = keyHandle.AccessTokenInterface();
	if (pTokenI == NULL)
		throw CML_ERR(CM_INVALID_PARAMETER);

	SNACC::Certificate* pSnacc = NULL;
	try {
		// Set the signature algorithm to the specified algorithm if present
		if (pSigAlg != NULL)
		{
			signature = *pSigAlg;
			algorithm = *pSigAlg;
		}

		SNACC::AsnBuf encCertToSign;
		pSnacc = GetSnacc();

		// Encode the ToBeSigned part and delete the certificate
		try {
			pSnacc->toBeSigned->BEnc(encCertToSign);
		}
		catch (SNACC::SnaccException& ) {
			throw CML_ERR(CM_ASN_ERROR);
		}

		delete pSnacc;
		pSnacc = NULL;

		// Sign the encoded ToBeSigned part
		long CTSLen = encCertToSign.length();
		CTIL::CSM_Buffer pCTS = CTIL::CSM_Buffer((const char *)encCertToSign.GetSeg(CTSLen), CTSLen);
//		SM_RET_VAL retVal = pTokenI->SMTI_Sign(&encCertToSign, &sigValue, NULL);
		SM_RET_VAL retVal = pTokenI->SMTI_Sign(&pCTS, &sigValue, NULL);
		if (retVal != SM_NO_ERROR)
			return CM_SIGN_OPERATION_FAILED;

		// Re-encode the entire certificate
		Cert::Encode(encCert);

		return CM_NO_ERROR;
	}
	catch (...) {
		if (pSnacc != NULL)
			delete pSnacc;
		throw;
	}
}


short Certificate::Validate(ulong sessionID, SearchBounds boundsFlag,
							ErrorInfoList* pErrors,
							ValidatedKey* pValidKey) const
{
	CertPath thePath(*this);
	return thePath.BuildAndValidate(sessionID, boundsFlag, pErrors, 0,
		pValidKey);
}


short Certificate::VerifySignature(ulong sessionID,
								   const ValidatedKey& signersKey) const
{
	SignedAsnObj signedCert(encCert);
	return signedCert.VerifySignature(sessionID, signersKey);
}


short Certificate::VerifySignature(ulong sessionID,
								   const ASN::PublicKeyInfo& publicKey,
								   const CTIL::CSM_Buffer* parameters) const
{
	SignedAsnObj signedCert(encCert);
	return signedCert.VerifySignature(sessionID, publicKey, parameters);
}


short Certificate::VerifySignature(ulong sessionID, SearchBounds boundsFlag,
								   Certificate& signersCert) const
{
	SignedAsnObj signedCert(encCert);
	return signedCert.VerifySignature(sessionID, boundsFlag, signersCert);
}



// end of CM_Certificate.cpp
