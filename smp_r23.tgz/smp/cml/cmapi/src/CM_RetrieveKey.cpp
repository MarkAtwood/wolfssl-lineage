/*****************************************************************************
File:     CM_RetrieveKey.cpp
Project:  Certificate Management Library
Contents: Retrieve Key function and X.509 Certificate path validation routines

Created:  3 April 1997
Author:   Rich Nicholas <Richard.Nicholas@DigitalNet.com>

Last Updated:  23 September 2003

Version:  2.3

*****************************************************************************/

////////////////////
// Included Files //
////////////////////
#include <stdlib.h>
#if defined (SOLARIS) || defined (LINUX) || defined (SCO_SV)
	#include "ctype.h"		/* Needed for unix systems */
#endif
#if defined(WIN32) && defined(_DEBUG)
	#define _WIN32_WINNT	0x0500
	#include <windows.h>						// For debugging
	#include <winbase.h>
#endif
#include "PathBuild.h"
#include "cmlasn_xml.h"


// Using declarations
using namespace CML;
using namespace CML::Internal;
using ASN::GenName;
using ASN::PrintXML;

#ifdef THREAD_TESTING
//////////////////////
// Global Variables //
//////////////////////
extern PrintXML gPrintThreads;
#endif  // THREAD_TESTING



///////////////////////
// Defined Constants //
///////////////////////
const float MIN_PATH_PROBABILITY = (float)0.1;

const char gEXT_KEY_USE_EntrustCA[]		= "1.2.840.113533.7.74.3";
const char gEXT_KEY_USE_msCTLSigning[]	= "1.3.6.1.4.1.311.10.3.1";


/////////////////////////
// Function Prototypes //
/////////////////////////
static bool areCommPrivsSubset(const SNACC::CommPrecFlags& subjPrivs,
							   const ASN::AttributeList& caConstraints);
static bool areKmFlagsSubset(const SNACC::KmPrivFlagsSeqOf* pSubj,
							 const SNACC::KmPrivFlagsSeqOf* pIssuer);
static bool arePrivsSubset(const SNACC::PrivilegeFlags& subjPrivs,
						   const ASN::AttributeList& caConstraints);
static bool areSigFlagsSubset(const SNACC::SigPrivFlagsSeqOf* pSubj,
							  const SNACC::SigPrivFlagsSeqOf* pIssuer);
static void buildFortezzaPubKey(CTIL::CSM_Buffer& pubKey,
								CTIL::CSM_Buffer& params,
								const Pub_key_struct& cmPubKey);
static short checkCaConst(bool isCA, const ASN::AttributeList* pSubjAttribs,
						  const ASN::AttributeList* pIssuerAttribs);
static void checkExtKeyUsage(const ASN::ExtKeyUsageExtension& extKeyUse,
							 ErrorInfoList& errors, const ASN::Cert& cert);
static void cvtBytesToHugeInt(SNACC::AsnInt& hugeInt,
							  const Bytes_struct& bytes);
static void cvtPolicyStructToList(ASN::CertPolicyList& list,
								  const Policy_struct* policyList);
static void fillSnaccNoticeNumbers(SNACC::NoticeReferenceSeqOf& snacc,
								   const Bytes_struct_LL* pNumList);
static bool isCAConstraintsSubset(const ASN::AttributeList& subj,
								  const ASN::AttributeList& issuer);



///////////////////////////////////////
// ValidatedKey class implementation //
///////////////////////////////////////
ValidatedKey::ValidatedKey()
{
	// Initialize pointers and boolean flags
	pKeyUsage = NULL;
	pExtKeyUsage = NULL;
	explicitPolicyFlag = false;
}


ValidatedKey::ValidatedKey(const ValidatedKey& that)
{
	pKeyUsage = NULL;
	pExtKeyUsage = NULL;
	operator=(that);
}


ValidatedKey::ValidatedKey(const ValidKey_struct& valKey)
{
	// Initialize pointers
	pKeyUsage = NULL;
	pExtKeyUsage = NULL;

	// Check input ValidKey_struct parameter
	if ((valKey.key.oid == NULL) || (valKey.key.key.y == NULL))
		throw CML_ERR(CM_INVALID_PARAMETER);

	// Set the public key algorithm
	m_pubKeyInfo.algorithm = valKey.key.oid;
		
	// Set the public key and parameters
	if ((m_pubKeyInfo.algorithm == gDSA_OID) ||
		(m_pubKeyInfo.algorithm == gOIW_DSA))
	{
		// Check that the required parameters are present
		if (valKey.key.params.dsa == NULL)
			throw CML_ERR(CM_INVALID_PARAMETER);
		
		// Allocate memory for the parameters
		m_pubKeyInfo.algorithm.parameters = new CTIL::CSM_Buffer();
		if (m_pubKeyInfo.algorithm.parameters == NULL)
			throw CML_MEMORY_ERR;
		
		// Encode the parameters
		SNACC::DSAParameters dsaParams;
		cvtBytesToHugeInt(dsaParams.prime1, valKey.key.params.dsa->p);
		cvtBytesToHugeInt(dsaParams.prime2, valKey.key.params.dsa->q);
		cvtBytesToHugeInt(dsaParams.base, valKey.key.params.dsa->g);
		try {
			SNACC::AsnBuf asnBuf;
			dsaParams.BEnc(asnBuf);
			long bufLen = asnBuf.length();
			*m_pubKeyInfo.algorithm.parameters =
				CTIL::CSM_Buffer((const char *)asnBuf.GetSeg(bufLen), bufLen);
		}
		catch (SNACC::SnaccException& ) {
			throw CML_ERR(CM_ASN_ERROR);
		}
		
		// Encode the DSA public key
		SNACC::DsaPublicKey pubKey;
		cvtBytesToHugeInt(pubKey, *valKey.key.key.y);
		try {
			SNACC::AsnBuf asnBuf;
			pubKey.BEnc(asnBuf);
			long bufLen = asnBuf.length();
			m_pubKeyInfo.key =
				CTIL::CSM_Buffer((const char *)asnBuf.GetSeg(bufLen), bufLen);
		}
		catch (SNACC::SnaccException& ) {
			throw CML_ERR(CM_ASN_ERROR);
		}
	}
	else if (m_pubKeyInfo.algorithm == gRSA_OID)
	{
		// Allocate memory for the parameters
		m_pubKeyInfo.algorithm.parameters = new CTIL::CSM_Buffer();
		if (m_pubKeyInfo.algorithm.parameters == NULL)
			throw CML_MEMORY_ERR;
		
		// Encode the parameters
		SNACC::AsnNull rsaParams;
		try {
			SNACC::AsnBuf asnBuf;
			rsaParams.BEnc(asnBuf);
			long bufLen = asnBuf.length();
			*m_pubKeyInfo.algorithm.parameters =
				CTIL::CSM_Buffer((const char *)asnBuf.GetSeg(bufLen), bufLen);
		}
		catch (SNACC::SnaccException& ) {
			throw CML_ERR(CM_ASN_ERROR);
		}
		
		// Encode the RSA public key
		SNACC::RSAPublicKey rsaPubKey;
		cvtBytesToHugeInt(rsaPubKey.modulus, valKey.key.key.rsa->modulus);
		cvtBytesToHugeInt(rsaPubKey.publicExponent,
			valKey.key.key.rsa->publicExponent);
		try {
			SNACC::AsnBuf asnBuf;
			rsaPubKey.BEnc(asnBuf);
			long bufLen = asnBuf.length();
			m_pubKeyInfo.key =
				CTIL::CSM_Buffer((const char *)asnBuf.GetSeg(bufLen), bufLen);
		}
		catch (SNACC::SnaccException& ) {
			throw CML_ERR(CM_ASN_ERROR);
		}
	}
	else if ((m_pubKeyInfo.algorithm == gOLD_DH_OID) ||
		(m_pubKeyInfo.algorithm == gANSI_DH_OID))
	{
		if (valKey.key.params.encoded != NULL)
		{
			// Copy the encoded DH parameters
			m_pubKeyInfo.algorithm.parameters = new
				CTIL::CSM_Buffer((char*)valKey.key.params.encoded->data,
				valKey.key.params.encoded->num);
			if (m_pubKeyInfo.algorithm.parameters == NULL)
				throw CML_MEMORY_ERR;
		}
		
		// Encode the DH public key
		SNACC::DHPublicKey pubKey;
		cvtBytesToHugeInt(pubKey, *valKey.key.key.y);
		try {
			SNACC::AsnBuf asnBuf;
			pubKey.BEnc(asnBuf);
			long bufLen = asnBuf.length();
			m_pubKeyInfo.key =
				CTIL::CSM_Buffer((const char *)asnBuf.GetSeg(bufLen), bufLen);
		}
		catch (SNACC::SnaccException& ) {
			throw CML_ERR(CM_ASN_ERROR);
		}
	}
	else if (m_pubKeyInfo.algorithm == gKEA_OID)
	{
		if (valKey.key.params.kea != NULL)
		{
			// Allocate memory for the encoded KEA parameters
			m_pubKeyInfo.algorithm.parameters = new CTIL::CSM_Buffer();
			if (m_pubKeyInfo.algorithm.parameters == NULL)
				throw CML_MEMORY_ERR;
			
			// Encode the KEA parameters
			SNACC::AsnOcts keaParams((const char*)valKey.key.params.kea->data,
				valKey.key.params.kea->num);
			try {
				SNACC::AsnBuf asnBuf;
				keaParams.BEnc(asnBuf);
				long bufLen = asnBuf.length();
				*m_pubKeyInfo.algorithm.parameters =
					CTIL::CSM_Buffer((const char *)asnBuf.GetSeg(bufLen), bufLen);
			}
			catch (SNACC::SnaccException& ) {
				throw CML_ERR(CM_ASN_ERROR);
			}
		}
		
		// Copy the KEA public key
		m_pubKeyInfo.key.Set((const char*)valKey.key.key.y->data,
			valKey.key.key.y->num);
	}
	else if (m_pubKeyInfo.algorithm == gDSA_KEA_OID)
	{
		// Check that the required parameters are present
		if (valKey.key.params.dsa_kea == NULL)
			throw CML_ERR(CM_INVALID_PARAMETER);
		
		// Allocate memory for the parameters
		m_pubKeyInfo.algorithm.parameters = new CTIL::CSM_Buffer();
		if (m_pubKeyInfo.algorithm.parameters == NULL)
			throw CML_MEMORY_ERR;
		
		// Build the encoded Fortezza public key and parameters
		buildFortezzaPubKey(m_pubKeyInfo.key,
			*m_pubKeyInfo.algorithm.parameters, valKey.key);
	}
	else if (m_pubKeyInfo.algorithm == gEC_KEY_OID)
	{
		// Check that the required parameters are present
		if (valKey.key.params.encoded == NULL)
			throw CML_ERR(CM_INVALID_PARAMETER);
		
		// Copy the encoded parameters
		m_pubKeyInfo.algorithm.parameters = new
			CTIL::CSM_Buffer((char*)valKey.key.params.encoded->data,
			valKey.key.params.encoded->num);
		if (m_pubKeyInfo.algorithm.parameters == NULL)
			throw CML_MEMORY_ERR;
		
		// Copy the elliptic curve public key
		m_pubKeyInfo.key.Set((const char*)valKey.key.key.y->data,
			valKey.key.key.y->num);
	}
	else
		throw CML_ERR(CM_NOT_IMPLEMENTED);
		
	// Set the authority and user-constrained-policy-sets and
	// require-explicit-policy flag
	cvtPolicyStructToList(authPolicies, valKey.caPolicies);
	cvtPolicyStructToList(userPolicies, valKey.userPolicies);
	if (valKey.explicitPolFlag == FALSE)
		explicitPolicyFlag = false;
	else
		explicitPolicyFlag = true;
	
	// Set the policy mappings
	const Pol_maps_struct* pMapping = valKey.mappings;
	while (pMapping != NULL)
	{
		mappings.push_back(ASN::PolicyMapping(pMapping->issuer_pol_id,
			pMapping->subj_pol_id));
		pMapping = pMapping->next;
	}
		
	// If the key usage is present, create and set a new KeyUsageExtension
	if (valKey.keyUse != NULL)
	{
		pKeyUsage = new ASN::KeyUsageExtension();
		if (pKeyUsage == NULL)
			throw CML_MEMORY_ERR;
		
		if (valKey.keyUseCritical)
			pKeyUsage->critical = true;
		
		// Set the key usage bits
		ushort mask = 1;
		for (unsigned int i = SNACC::KeyUsage::digitalSignature; i <
			SNACC::KeyUsage::decipherOnly; i++)
		{
			if ((*valKey.keyUse & mask) != 0)
				pKeyUsage->SetBit(i);
			mask <<= 1;
		}
	}
		
	// If the extended key usage is present, create and set a new
	// ExtKeyUsageExtension
	if (valKey.extKeyUsage != NULL)
	{
		pExtKeyUsage = new ASN::ExtKeyUsageExtension();
		if (pExtKeyUsage == NULL)
			throw CML_MEMORY_ERR;
		
		if (valKey.extKeyUsageCritical)
			pExtKeyUsage->critical = true;
		
		// Set the Key Purpose OIDs
		const Ext_key_use_LL* pOid = valKey.extKeyUsage;
		while (pOid != NULL)
		{
			pExtKeyUsage->push_back(pOid->oid);
			pOid = pOid->next;
		}
	}
}


ValidatedKey::~ValidatedKey()
{
	if (pKeyUsage != NULL)
		delete pKeyUsage;
	if (pExtKeyUsage != NULL)
		delete pExtKeyUsage;
}


ValidatedKey& ValidatedKey::operator=(const ValidatedKey& that)
{
	if (this != &that)
	{
		if (pKeyUsage != NULL)
		{
			delete pKeyUsage;
			pKeyUsage = NULL;
		}
		if (pExtKeyUsage != NULL)
		{
			delete pExtKeyUsage;
			pExtKeyUsage = NULL;
		}

		m_pubKeyInfo = that.m_pubKeyInfo;
		authPolicies = that.authPolicies;
		userPolicies = that.userPolicies;
		explicitPolicyFlag = that.explicitPolicyFlag;
		mappings = that.mappings;

		if (that.pKeyUsage != NULL)
		{
			pKeyUsage = new ASN::KeyUsageExtension(*that.pKeyUsage);
			if (pKeyUsage == NULL)
				throw CML_MEMORY_ERR;
		}

		if (that.pExtKeyUsage != NULL)
		{
			pExtKeyUsage = new ASN::ExtKeyUsageExtension(*that.pExtKeyUsage);
			if (pExtKeyUsage == NULL)
				throw CML_MEMORY_ERR;
		}
	}
	return *this;
}


void ValidatedKey::Clear()
{
	m_pubKeyInfo.Clear();

	authPolicies.clear();
	userPolicies.clear();
	explicitPolicyFlag = false;
	mappings.clear();

	if (pKeyUsage != NULL)
	{
		delete pKeyUsage;
		pKeyUsage = NULL;
	}
	if (pExtKeyUsage != NULL)
	{
		delete pExtKeyUsage;
		pExtKeyUsage = NULL;
	}
}


ValidKey_struct* ValidatedKey::GetValidKeyStruct() const
{
	if (IsEmpty())
		throw CML_ERR(CM_INVALID_PARAMETER);

	ValidKey_struct* result = (ValidKey_struct*)calloc(1,
		sizeof(ValidKey_struct));
	if (result == NULL)
		throw CML_MEMORY_ERR;

	try {
		m_pubKeyInfo.FillPubKeyStruct(result->key);
		
		result->keyUseCritical = FALSE;
		if (pKeyUsage != NULL)
		{
			Extn_struct* pExtn = pKeyUsage->GetExtensionStruct();
			result->keyUse = (ushort*)pExtn->value;
			free(pExtn->oid);
			free(pExtn);

			if (pKeyUsage->critical)
				result->keyUseCritical = TRUE;
		}

		result->caPolicies = authPolicies.GetPolicyList();
		result->userPolicies = userPolicies.GetPolicyList();

		if (explicitPolicyFlag)
			result->explicitPolFlag = TRUE;
		else
			result->explicitPolFlag = FALSE;

		Pol_maps_struct* prevMap = NULL;
		for (ASN::PolicyMappingList::const_iterator iMap = mappings.begin();
			iMap != mappings.end(); iMap++)
		{
			if (prevMap == NULL)
				prevMap = result->mappings = iMap->GetPolicyMapping();
			else
				prevMap = prevMap->next = iMap->GetPolicyMapping();
		}

		result->extKeyUsageCritical = FALSE;
		if (pExtKeyUsage != NULL)
		{
			Ext_key_use_LL* prevOid = NULL;
			for (ASN::ExtKeyUsageExtension::const_iterator iOid =
				pExtKeyUsage->begin(); iOid != pExtKeyUsage->end(); iOid++)
			{
				Ext_key_use_LL* pNew =
					(Ext_key_use_LL*)malloc(sizeof(Ext_key_use_LL));
				if (pNew == NULL)
					throw CML_MEMORY_ERR;

				pNew->next = NULL;
				
				if (prevOid == NULL)
					result->extKeyUsage = pNew;
				else
					prevOid->next = pNew;
				prevOid = pNew;

				pNew->oid = iOid->GetChar();
			}
			if (pExtKeyUsage->critical)
				result->extKeyUsageCritical = TRUE;
		}

		return result;
	}
	catch (...) {
		CM_FreeValidKey(&result);
		throw;
	}
}


bool ValidatedKey::IsEmpty() const
{
	return ((m_pubKeyInfo.algorithm.algorithm.Len() == 0) ||
		(m_pubKeyInfo.key.Length() == 0));
}



/************************************************************************
 FUNCTION:  CM_RetrievePath()
 
 Description: This function will retrieve the public key from the
 provided ASN.1 encoded certificate or certification path, validate the
 key in accordance with the X.509 standard, and return the public key and
 optional certification path to the application.
 CM_NO_ERROR is returned if the path is successfully built and validated.
 CM_PATH_VALIDATION_ERROR is returned if the path can be built, but was
 not valid.  CM_NO_PATH_FOUND is returned if the path cannot be built.
 Other errors may be returned if a fatal error occurs.
 If CM_PATH_VALIDATION_ERROR occurs, then the extended path errors are
 stored in the session and can be retrieved using CM_GetErrInfo().
*************************************************************************/
short CM_RetrievePath(ulong sessionID, Bytes_struct* asn1data, short asn1Type,
					  Cert_path_LL **decPath, ValidKey_struct **validKey,
					  SearchBounds boundsFlag)
{
	// Check parameters
	if ((asn1data == NULL) || (validKey == NULL))
		return CM_INVALID_PARAMETER;
	if ((asn1Type != CM_CERT_TYPE) && (asn1Type != CM_CERTPATH_TYPE))
		return CM_INVALID_PARAMETER;
	if ((boundsFlag < CM_SEARCH_LOCAL) || (boundsFlag > CM_SEARCH_UNTIL_FOUND))
		return CM_INVALID_PARAMETER;

	// Initialize validKey result and, if present, the decPath parameter
	*validKey = NULL;
	if (decPath != NULL)
		*decPath = NULL;

	try {
		// Initialize the cert path
		CertPath thePath(*asn1data, (asn1Type != CM_CERT_TYPE));

		// Build and validate the cert path
		ValidatedKey keyObj;
		ErrorInfoList errors;
		short errCode = thePath.BuildAndValidate(sessionID, boundsFlag,
			&errors, MIN_PATH_PROBABILITY, &keyObj);

		// Get the ValidKey_struct form of the ValidatedKey
		*validKey = keyObj.GetValidKeyStruct();
		(*validKey)->errors = errors;

		// If a valid or invalid path was successfully built...
		if ((errCode == CM_NO_ERROR) || (errCode == CM_PATH_VALIDATION_ERROR))
		{
			// Get the decoded certification path (if requested)
			if (decPath != NULL)
				*decPath = thePath.base().GetCertPathList();
		}

		return errCode;
	}
	catch (CML::Exception& e) {
		CM_FreeValidKey(validKey);
		return e;
	}
	catch (CML::ASN::Exception& e) {
		CM_FreeValidKey(validKey);
		return e;
	}
	catch (SNACC::SnaccException& ) {
		CM_FreeValidKey(validKey);
		return CM_ASN_ERROR;
	}
	catch (...) {
		CM_FreeValidKey(validKey);
		return CM_UNKNOWN_ERROR;
	}
} // end of CM_RetrievePath()

					  
/************************************************************************
 FUNCTION:  CM_RetrieveKey()
 
 Description: This function will retrieve the public key from the
 provided ASN.1 encoded certificate or certification path, validate the
 key in accordance with the X.509 standard, and return the public key to
 the application.
 CM_NO_ERROR is returned if the path is successfully built and validated.
 CM_PATH_VALIDATION_ERROR is returned if the path can be built, but was
 not valid.  CM_NO_PATH_FOUND is returned if the path cannot be built.
 Other errors may be returned if a fatal error occurs.
 If CM_PATH_VALIDATION_ERROR occurs, then the extended path errors are
 stored in the session and can be retrieved using CM_GetErrInfo().
*************************************************************************/
short CM_RetrieveKey(ulong sessionID, Bytes_struct* asn1data, short asn1Type,
    ValidKey_struct **valid_key, SearchBounds searchFlag)
{
	return CM_RetrievePath(sessionID, asn1data, asn1Type, NULL, valid_key,
		searchFlag);
} // end of CM_RetrieveKey()



/************************************************************************
 FUNCTION:  CML::Internal::ValidateCert()
 
 Description: This function performs the X.509 certification path
 processing of the target certificate using the issuer certificate and
 supplied stat variables.
 CM_NO_ERROR is returned if the cert is successfully validated.
 CM_PATH_VALIDATION_ERROR is returned if the cert is not valid, the
 specific errors are returned in the certErrors and pathErrors lists.
 If a fatal error occurs, an exception is thrown.
*************************************************************************/
short CML::Internal::ValidateCert(ulong sessionID, const Certificate& target,
								  const CertAndParams& issuer,
								  SearchBounds searchFlag,
								  StateVars& pathVars,
								  ErrorInfoList& certErrors,
								  ErrorInfoList& pathErrors, bool isEndCert)
{
	// Check that the two signature algorithms on the cert are the same
	if (target.base().signature != target.base().algorithm)
		certErrors.AddError(CM_SIGNATURE_ALG_MISMATCH, target.base());

	// Acquire global session lock
	ASN::ReadLock lock = AcquireSessionReadLock(sessionID);

	// Check that the signature verifies (unless the cert is already cached)
	if (!GetCertCache(sessionID).IsCached(target, issuer))
	{
		short errCode = VerifySignature(sessionID, target.GetEnc(),
			issuer.base().pubKeyInfo, pathVars.pParams);
		if (errCode == CM_NO_TOKENS_SUPPORT_SIG_ALG)
		{
			certErrors.AddError(CM_NO_TOKENS_SUPPORT_CERT_SIG_ALG,
				target.base());
		}
		else if (errCode != CM_NO_ERROR)
			pathErrors.AddError(CM_CERT_SIGNATURE_INVALID, target.base());
	}

	lock.Release();    // Release the lock

	// Check that current date falls within the validity period of the cert
	ASN::Time curTime;
	if (curTime < target.base().validity.notBefore)
	{
		certErrors.AddError(CM_CERT_NOT_YET_VALID, target.base(),
			target.base().validity.notBefore);
	}

	if (curTime > target.base().validity.notAfter)
	{
		certErrors.AddError(CM_CERT_EXPIRED, target.base(),
			target.base().validity.notAfter);
	}

	// Check that the certificate subject and issuer names chain correctly
	if ((target.base().issuer != issuer.base().subject) ||
		!CompareUniqueIDs(target.base().pIssuerUniqueID,
		issuer.base().pSubjectUniqueID))
		pathErrors.AddError(CM_NAME_MISMATCH, target.base());

	// Check that the certificate has not been revoked
	short crlError = CM_NO_ERROR;
	if (GetSessionFromRef(sessionID).GetRevPolicy() == CM_REVCRL)
	{
		crlError = CheckRevocationStatus(sessionID, target.base(), issuer,
			pathVars.pParams, searchFlag, isEndCert, certErrors, pathErrors,
			pathVars.state);
	}

	// For an intermediate certificate, the basic constraints extension must
	// be present and the CA flag set to true.
	if (!isEndCert && (target.base().version == SNACC::Version::v3))
	{
		if ((target.base().exts.pBasicCons == NULL) ||
			!target.base().exts.pBasicCons->isCA)
			pathErrors.AddError(CM_INVALID_CA, target.base());
	}

	// Check that the path length constraint has not been exceeded
	if (pathVars.maxPathDepth == 0)
		pathErrors.AddError(CM_PATH_LEN_EXCEEDED, target.base());

	// If this intermediate cert has a key usage extension, check that
	// the keyCertSign bit set
	if (!isEndCert && (target.base().exts.pKeyUsage != NULL))
	{
		if (!target.base().exts.pKeyUsage->GetBit(SNACC::KeyUsage::keyCertSign))
			pathErrors.AddError(CM_INVALID_KEY_USE, target.base());
	}

	// If this intermediate cert has an extended key usage extension, check
	// that it contains the anyExtendedKeyUsage OID
	if (!isEndCert && (target.base().exts.pExtKeyUsage != NULL))
	{
		checkExtKeyUsage(*target.base().exts.pExtKeyUsage, pathErrors,
			target.base());
	}

	// Set flag to indicate if this cert is a self-issued intermediate cert
	bool isSelfIssuedCA = !isEndCert && target.base().IsSelfIssued();

	// Process the certificate policies extension
	pathVars.authTable.ProcessPolicies(target.base().exts.pCertPolicies,
		pathVars.pathDepth, pathVars.inhibitAnyPolicy, isSelfIssuedCA);

	// If the certificate is not an intermediate self-issued certificate,
	// check that the subject name is within the permitted-subtrees
	// namespace and not within the excluded-subtrees namespace
	if (!isSelfIssuedCA)
	{
		if (!target.base().subject.IsEmpty())
		{
			// Check the subject DN
			if (!pathVars.permitted.IsNameWithin(target.base().subject) ||
				pathVars.excluded.IsNameWithin(target.base().subject, false))
				pathErrors.AddError(CM_INVALID_SUBJECT_NAME, target.base());
		}
		else if ((target.base().exts.pSubjAltNames == NULL) ||
			!target.base().exts.pSubjAltNames->critical)
		{
			// Since subject DN is absent, subject alt name extension must
			// be present and critical
			certErrors.AddError(CM_INVALID_SUBJECT_NAME, target.base());
		}
	}

	// Check that any subject alternative names are within the
	// permitted-subtrees namespace and not within the excluded-subtrees
	// namespace
	if (target.base().exts.pSubjAltNames != NULL)
	{
		try {
			const ASN::GenNames& subjNames = *target.base().exts.pSubjAltNames;
			if (!pathVars.permitted.AreNamesWithin(subjNames) ||
				pathVars.excluded.AreNamesWithin(subjNames, false))
				pathErrors.AddError(CM_INVALID_ALT_NAME, target.base());
		}
		catch (ASN::Exception& asnErr) {
			if (asnErr == ASN::NotImplemented)
				pathErrors.AddError(CM_UNRECOGNIZED_ALT_NAME, target.base());
			else
				throw;
		}
	}

	// If the certificate is not an intermediate self-issued certificate,
	// for each set of required-name-forms, check that the cert contains a
	// subject name of one of the name forms
	if (!isSelfIssuedCA)
	{
		bool namePresent = true;
		ReqNameForms::const_iterator i = pathVars.reqNames.begin();
		for ( ; (i != pathVars.reqNames.end()) && namePresent; i++)
		{
			// If the X.500 name form is required and the subject DN is
			// present, continue on to the next set
			if (i->basicNames.GetBit(SNACC::BasicNameForms::directoryName) &&
				!target.base().subject.IsEmpty())
				continue;

			namePresent = i->IsNamePresent(target.base().exts.pSubjAltNames);
		}

		// If a required name form wasn't present, record the error
		if (!namePresent)
			pathErrors.AddError(CM_REQUIRED_NAME_MISSING, target.base());
	}

	// If the issuer of this certificate is not self-issued, perform the
	// SDN.706 checks of the MISSI subject directory attributes
	if (!issuer.base().IsSelfIssued())
	{
		short errCode = checkCaConst(isEndCert, target.base().exts.pSubjDirAtts,
			issuer.base().exts.pSubjDirAtts);
		if (errCode == CM_DMS_NO_CA_CONSTRAINTS)
			pathErrors.AddError(errCode, issuer.base());
		else if (errCode != CM_NO_ERROR)
			pathErrors.AddError(errCode, target.base());
		// else no error
	}

	// If this certificate contains one of the MISSI/DMS attributes, check that
	// the subject DN is present
	if ((target.base().exts.pSubjDirAtts != NULL) &&
		target.base().subject.IsEmpty())
	{
		const ASN::AttributeList& attribs = *target.base().exts.pSubjDirAtts;
		if ((attribs.Find(ASN::Attribute::CAClearanceConst) != attribs.end()) ||
			(attribs.Find(ASN::Attribute::SigOrKMPrivs) != attribs.end()) ||
			(attribs.Find(ASN::Attribute::CommPrivs) != attribs.end()))
			certErrors.AddError(CM_DMS_NULL_SUBJECT_DN, target.base());
	}

	// Check that there aren't any unrecognized critical extensions
	ASN::UnknownExtensions::const_iterator i =
		target.base().exts.unknownExts.begin();
	for ( ; i != target.base().exts.unknownExts.end(); i++)
	{
		if (i->critical)
		{
			certErrors.AddError(CM_UNRECOGNIZED_CRITICAL_CERT_EXT,
				target.base(), i->OID());
		}
	}

	// Return the correct error code
	if (certErrors.empty() && pathErrors.empty())
	{
		if (crlError == CMI_TENTATIVELY_VALID)
		{
			// This CERT is good, but only tentatively VALID based upon the CRL being valid,
			return CMI_TENTATIVELY_VALID;
		}
		else
		{
			return CM_NO_ERROR;
		}
	}

	return CM_PATH_VALIDATION_ERROR;
}

/************************************************************************
 FUNCTION:  CML::Internal::ValidateCertPath()
 
 Description: This function performs the X.509 certification path
 processing of the target certificate by supplying the issuer certificate and
 stat variables to CML::Interal::ValidateCert().
 CM_NO_ERROR is returned if the cert is successfully validated.
 CM_PATH_VALIDATION_ERROR is returned if the cert is not valid, the
 specific errors are returned in the certErrors and pathErrors lists.
 If a fatal error occurs, an exception is thrown.
*************************************************************************/
short ValidateCertPath(const BaseNodePtrDeck& curPath,
					   CachedCertList& issuerCerts, SearchBounds boundsFlag,
					   StateVars& pathVars, ErrorInfoList* pErrors)
{
	// Throw exception if the path is empty
	if ((curPath.size() < 2) || (curPath.front() == NULL) ||
		!curPath.front()->IsTrusted())
		throw CML_ERR(CM_UNKNOWN_ERROR);

	// Get a reference to the cached trust anchor
	const CachedCert& cachedTrustedCert =
		((const TrustedCertNode*)curPath.front())->m_cachedCert;

	// Initialize the list of issuer certs
	issuerCerts.assign(1, cachedTrustedCert);
	
	// Update the path expiration and trusted parameters path variables
	pathVars.pathExpiration = cachedTrustedCert.base().validity.notAfter;
	pathVars.pParams = cachedTrustedCert.base().pubKeyInfo.algorithm.parameters;
	
	/* Note: One must be added to the state variable, maxPathDepth, because of
	   the way the library checks for path limits.  Unlike X.509, maxPathDepth
	   indicates how many certs can follow (X.509 uses it to indicate how many
	   issuer certs can follow--a subtle but important difference). */
	if (cachedTrustedCert.maxPathLen != -1)
		pathVars.maxPathDepth = (short)(cachedTrustedCert.maxPathLen + 1);	
	
	// Set the permitted-subtrees state variable to the value in the trusted 
	// cert member variable if has a value
	if (!cachedTrustedCert.names.permitted.empty())
		pathVars.permitted.push_back(cachedTrustedCert.names.permitted);
	
	// Set the excluded-subtrees state variable to value in the trusted 
	// cert member variable if has a value
	if (!cachedTrustedCert.names.excluded.empty())
		pathVars.excluded = cachedTrustedCert.names.excluded;
	
	// Set the required-name-forms state variable to the value in the trusted
	// cert member variable if has a value
	if (!cachedTrustedCert.names.requiredNames.IsEmpty())
		pathVars.reqNames.push_back(cachedTrustedCert.names.requiredNames);

	// Loop through the remaining certs starting with the second cert
	// validating each cert until the EE is reached
	//
	short issuerErrors = CM_NO_ERROR;
	short subjError = CM_NO_ERROR;
	bool isLastCert = false;
	const BaseNode* issuerNode = curPath.front();
	BaseNodePtrDeck::const_iterator iNode;;
	for (iNode = curPath.begin() + 1; iNode != curPath.end(); ++iNode)
	{
		// Check that the BaseNode pointer is valid
		if (*iNode == NULL)
			throw CML_ERR(CM_NULL_POINTER);

		// Set flag to true when processing last cert
		if (iNode + 1 == curPath.end())
			isLastCert = true;

		// Create temporary issuer cert with parameters and any errors
		CertAndParams issuerCert(issuerNode->GetCert(), pathVars.pParams,
			issuerErrors);

		// Validate this certificate
		ErrorInfoList pathErrors;
		subjError = ValidateCert((*iNode)->m_hSession, (*iNode)->GetCert(),
			issuerCert, boundsFlag, pathVars, (*iNode)->m_certErrors,
			pathErrors, isLastCert);		
		
		// If there were errors and the first one was invalid signature,
		// then check if the link probability can be reset to 0
		if (!pathErrors.empty() &&
			(pathErrors.front().error == CM_CERT_SIGNATURE_INVALID))
		{
			// Set link probability to 0 if the issuer cert has parameters or 
			// if there were no path validation errors for the issuer
			if ((issuerNode->GetCert().base().pubKeyInfo.algorithm.parameters != NULL) ||
				((issuerErrors == CM_NO_ERROR) || (issuerErrors == CMI_CERT_NOT_CACHED)))
				(*iNode)->FindAndZeroizeIssuer(issuerNode);
		}

		// Update the X.509 path variables
		pathVars.Update((*iNode)->GetCert().base(), isLastCert);
		
		// If this cert is the end certificate and the explicit-policy-indicator
		// is set, check that neither the authorities-constrained-policy-set
		// nor the user-constrained-policy-set is empty
		if (isLastCert && pathVars.explicitPolicy)
		{
			// Acquire global session lock
			ASN::ReadLock lock = AcquireSessionReadLock((*iNode)->m_hSession);
			
			if (pathVars.authTable.IsEmpty())
			{
				subjError = CM_PATH_VALIDATION_ERROR;
				pathErrors.AddError(CM_INVALID_CERT_POLICY,
					(*iNode)->GetCert().base());
			}
			else if (pathVars.authTable.IsUserPolicySetEmpty(
				GetInitialPolicySet((*iNode)->m_hSession)))
			{
				subjError = CM_PATH_VALIDATION_ERROR;
				pathErrors.AddError(CM_MISSING_USER_CERT_POLICY,
					(*iNode)->GetCert().base());
			}
			
			lock.Release();
			
		}
		
		// Add the cert and path errors to the main error list
		if (pErrors != NULL)
		{
			pErrors->insert(pErrors->end(), (*iNode)->m_certErrors.begin(),
				(*iNode)->m_certErrors.end());
			pErrors->Splice(pErrors->end(), pathErrors);
		}
		
		// If this certificate is valid add it to the session cert cache
		const CachedCertRef* pCert = NULL;
		bool certCached = false;
		if ((subjError == CM_NO_ERROR) && (issuerErrors == CM_NO_ERROR))			
		{			
			// Acquire global session lock
			ASN::ReadLock lock = AcquireSessionReadLock((*iNode)->m_hSession);
			
			// Add this cert to the session cache
			pCert = GetCertCache((*iNode)->m_hSession).
				Add((*iNode)->GetCert(), issuerCerts, pathVars.authTable,
				pathVars.mappings, pathVars.explicitPolicy,
				pathVars.pathExpiration, true);
			certCached = true;
#ifdef THREAD_TESTING
			gPrintThreads.WriteData("Cert subject=", (*iNode)->GetCert().base().subject,
				"serialNum", (*iNode)->GetCert().base().serialNumber, "state=", "valid");
#endif //THREAD_TESTING
		}

		// Else if everything is valid, but this certificate or an issuer is
		// tentatively valid add it to the tentative cert cache
		else if (((subjError == CM_NO_ERROR) || (subjError == CMI_TENTATIVELY_VALID)) &&
			((issuerErrors == CM_NO_ERROR) || (issuerErrors == CMI_TENTATIVELY_VALID)))
		{
			// Add this cert to the tentative cache
			pCert = pathVars.state.tentativeCertCache.Add((*iNode)->GetCert(),
				issuerCerts, pathVars.authTable, pathVars.mappings,
				pathVars.explicitPolicy, pathVars.pathExpiration);
			certCached = true;
#ifdef THREAD_TESTING
			gPrintThreads.WriteData("Cert subject=", (*iNode)->GetCert().base().subject,
				"serialNum", (*iNode)->GetCert().base().serialNumber, "state=", "tentative");
#endif //THREAD_TESTING

			// Change error code to tentative if it was fully valid since
			// issuer was tentative
			subjError = CMI_TENTATIVELY_VALID;
		}

		// Else if the cert issuer was not cached then report same error for this
		// cert and continue
		else if ((issuerErrors == CMI_CERT_NOT_CACHED) &&
			((subjError == CM_NO_ERROR) || (subjError == CMI_TENTATIVELY_VALID)))
		{
			subjError = CMI_CERT_NOT_CACHED;
#ifdef THREAD_TESTING
			gPrintThreads.WriteData("Cert subject=", (*iNode)->GetCert().base().subject,
				"serialNum", (*iNode)->GetCert().base().serialNumber, "state=", "valid but not cached");
#endif //THREAD_TESTING
		}
		else
		{
			subjError = CM_PATH_VALIDATION_ERROR;
#ifdef THREAD_TESTING
			gPrintThreads.WriteData("Cert subject=", (*iNode)->GetCert().base().subject,
				"serialNum", (*iNode)->GetCert().base().serialNumber, "state=", "invalid");
#endif //THREAD_TESTING
		}

		// If the subject cert was cached, add it to the issuer list
		if (certCached)
		{
			// Add this newly-cached cert to the issuer list
			if (pCert != NULL)
			{
				issuerCerts.push_back(*pCert);
				delete pCert;
			}
			else
			{
#ifdef THREAD_TESTING
				gPrintThreads.WriteData("Cert subject=", (*iNode)->GetCert().base().subject,
					"serialNum", (*iNode)->GetCert().base().serialNumber, "state=", "could not be cached");
#endif //THREAD_TESTING

				// Change error since we could not cache the cert.
				subjError = CMI_CERT_NOT_CACHED;
			}
		}

		// Update the issuer node and errors for the next loop
		issuerNode = *iNode;
		issuerErrors = subjError;
	}

	return subjError;
} // end of ValidateCertPath()


////////////////////////////////////
// StateVars class implementation //
////////////////////////////////////
StateVars::StateVars(ulong sessionID, PathState &state, int pathLen) : 
					 state(state)
{
	pParams = NULL;

	// Set the authority-constrained-policy table to the proper depth and
	// write any-policy in the zeroth and first columns of the zeroth row
	authTable.Init(pathLen - 1);

	// Initialize the explicit-policy-indicator, the
	// policy-mapping-inhibit-indicator, and the inhibit-any-policy-indicator
	// to the initial values in the session
	const Session& session = GetSessionFromRef(sessionID);
	ASN::ReadLock lock = AcquireSessionReadLock(sessionID);
	explicitPolicy = session.GetPolicySettings().requirePolicy;
	noPolicyMapping = session.GetPolicySettings().inhibitMapping;
	inhibitAnyPolicy = session.GetPolicySettings().inhibitAnyPolicy;

	// Initialize the path-depth to one
	pathDepth = 1;

	// Initialize the pending constraints to unset
	pendingExplicitPolicy = -1;
	pendingPolicyMapping = -1;
	pendingAnyPolicy = -1;

	// Initialize the path length constraint
	maxPathDepth = -1;
}


void StateVars::Update(const ASN::Cert& cert, bool isEE)
{
	// Set the max path length state variable for the next link in the path.
	// If present and if the cert is not self-issued, decrement by one.
	if ((maxPathDepth > 0) && !cert.IsSelfIssued())
		--maxPathDepth;

	// Set the path expiration time to the lesser of the current expiration
	// time and the cert's expiration time
	if (cert.validity.notAfter < pathExpiration)
		pathExpiration = cert.validity.notAfter;

	// Update the inherited parameters
	if (cert.pubKeyInfo.algorithm.parameters != NULL)
		pParams = cert.pubKeyInfo.algorithm.parameters;
	else
	{
		// If the public key algorithm does not inherit parameters,
		// set the inherited parameters to NULL
		if ((cert.pubKeyInfo != gDSA_OID) &&
			(cert.pubKeyInfo != gOIW_DSA) &&
			(cert.pubKeyInfo != gEC_KEY_OID) &&
			(cert.pubKeyInfo != gDSA_KEA_OID))
			pParams = NULL;
	}
	
	// If the basic constraints extension is present and if a path length
	// constraint is specified, set the state variable to the lesser of the
	// current state variable and the path length constraint + 1.
	/* Note: One must be added to the state variable, maxPathDepth, because of
	the way the library checks for path limits.  Unlike X.509, maxPathDepth
	indicates how many certs can follow (X.509 uses it to indicate how many
	issuer certs can follow--a subtle but important difference). */
	if (cert.exts.pBasicCons != NULL)
	{
		short newPathLen = (short)cert.exts.pBasicCons->pathLen;
		if (cert.exts.pBasicCons->pathLen > SHRT_MAX)
			newPathLen = -1;

		if (newPathLen >= 0)	// If the path length is present...
		{
			++newPathLen;		// increment by one
			if ((maxPathDepth < 0) || (newPathLen < maxPathDepth))
				maxPathDepth = newPathLen;
		}
	}

	// If this cert is an intermediate cert, perform the following steps
	if (!isEE)
	{
		
		// If the name constraints extension is present...
		if (cert.exts.pNameCons != NULL)
		{
			// If the permittedSubtrees component is present, set the
			// permitted-subtrees state variable to the intersection of its
			// current value and the value in the extension
			// (just add the value to the lists of permitted subtrees in the
			// state variable)
			if (!cert.exts.pNameCons->permitted.empty())
				permitted.push_back(cert.exts.pNameCons->permitted);

			// If the excludedSubtrees component is present, set the
			// excluded-subtrees state variable to the union of its current
			// value and the value in the extension
			// (just append the value to the state variable)
			excluded.insert(excluded.end(),
				cert.exts.pNameCons->excluded.begin(),
				cert.exts.pNameCons->excluded.end());

			// If the requiredNameForms component is present, set the
			// required-name-forms state variable to the union of its
			// current value and the value in the extension
			// (just add the value to the lists of required name forms in the
			// state variable)
			if (!cert.exts.pNameCons->requiredNames.IsEmpty())
				reqNames.push_back(cert.exts.pNameCons->requiredNames);
		}

		// Process the policy mappings
		authTable.ProcessMappings(cert.exts.pPolicyMaps, pathDepth,
			noPolicyMapping, mappings);
		
		// If the policy-mapping-inhibit-indicator is not set
		if (!noPolicyMapping)
		{
			/* If the policy-mapping-inhibit-pending indicator is set and the
			certificate is not self-issued, decrement the value, and if the
			value is now zero, set the policy-mapping-inhibit-indicator. */
			if ((pendingPolicyMapping > 0) && !cert.IsSelfIssued())
			{
				if (--pendingPolicyMapping == 0)
					noPolicyMapping = true;
			}

			/* If the policy constraints extension is present and the
			inhibitPolicyMapping component is present:
			1. If the inhibitPolicyMapping is 0, set the policy-mapping-
			inhibit-indicator.
			2. If the inhibitPolicyMapping is not 0, set the policy-mapping-
			inhibit-pending value to the lesser of the SkipCerts value and the
			previous policy-mapping-inhibit-pending value (if previously set). */
			if (cert.exts.pPolicyCons != NULL)
			{
				long inhibitMappingSkipCertsValue =
					cert.exts.pPolicyCons->inhibitPolicyMapping;
				if (inhibitMappingSkipCertsValue > SHRT_MAX)
					inhibitMappingSkipCertsValue = -1;

				if (inhibitMappingSkipCertsValue == 0)
					noPolicyMapping = true;
				else if (inhibitMappingSkipCertsValue > 0)
				{
					if ((pendingPolicyMapping < 0) ||
						(inhibitMappingSkipCertsValue < pendingPolicyMapping))
					{
						pendingPolicyMapping =
							(short)inhibitMappingSkipCertsValue;
					}
				}
				// else inhibitPolicyMapping component is absent
			}
		} // end of if (!noPolicyMapping)

		// If the inhibit-any-policy-indicator is not set
		if (!inhibitAnyPolicy)
		{
			/* If the inhibit-any-policy-pending indicator is set and the
			certificate is not self-issued, decrement the value, and if the
			value is now zero, set the inhibit-any-policy-indicator. */
			if ((pendingAnyPolicy > 0) && !cert.IsSelfIssued())
			{
				if (--pendingAnyPolicy == 0)
					inhibitAnyPolicy = true;
			}

			/* If the inhibit any policy extension is present:
			1. If the SkipCerts value is 0, set the inhibit-any-policy-
			indicator.
			2. If the SkipCerts value is not 0, set the inhibit-any-policy-
			pending value to the lesser of the SkipCerts value and the
			previous inhibit-any-policy-pending value (if previously set). */
			if (cert.exts.pInhibitAnyPolicy != NULL)
			{
				long inhibitAnyPolicySkipCertsValue =
					cert.exts.pInhibitAnyPolicy->value;
				if (inhibitAnyPolicySkipCertsValue > SHRT_MAX)
					inhibitAnyPolicySkipCertsValue = -1;
				
				if (inhibitAnyPolicySkipCertsValue == 0)
					inhibitAnyPolicy = true;
				else if (inhibitAnyPolicySkipCertsValue > 0)
				{
					if ((pendingAnyPolicy < 0) ||
						(inhibitAnyPolicySkipCertsValue < pendingAnyPolicy))
					{
						pendingAnyPolicy =
							(short)inhibitAnyPolicySkipCertsValue;
					}
				}
				// else inhibitAnyPolicySkipCertsValue is excessively large
			}
		} // end of if (!inhibitAnyPolicy)

	} // end of intermediate cert processing

	// If the explicit-policy-indicator is not set:
	if (!explicitPolicy)
	{
		/* If the explict-policy-pending indicator is set and the certificate
		is not a self-issued intermediate cert, decrement the value, and if
		the value is now zero, set the explicit-policy-indicator. */
		if ((pendingExplicitPolicy > 0) && !cert.IsSelfIssued())
		{
			if (--pendingExplicitPolicy == 0)
				explicitPolicy = true;
		}

		/* If the policy constraints extension is present and the
		requireExplicitPolicy component is present:
		1. If the requireExplicitPolicy is 0, set the explicit-policy-indicator.
		2. If the requireExplicitPolicy is not 0, set the explicit-policy-
		pending value to the lesser of the SkipCerts value and the previous
		explicit-policy-pending value (if previously set). */
		if (cert.exts.pPolicyCons != NULL)
		{
			long requirePolicySkipCertsValue =
				cert.exts.pPolicyCons->requireExplicitPolicy;
			if (requirePolicySkipCertsValue > SHRT_MAX)
				requirePolicySkipCertsValue = -1;

			if (requirePolicySkipCertsValue == 0)
				explicitPolicy = true;
			else if (requirePolicySkipCertsValue > 0)
			{
				if ((pendingExplicitPolicy < 0) ||
					(requirePolicySkipCertsValue < pendingExplicitPolicy))
					pendingExplicitPolicy = (short)requirePolicySkipCertsValue;
			}
			// else requireExplicitPolicy component is absent
		}
	} // end of if (!explicitPolicy)

	// Increment the path depth
	++pathDepth;
}


////////////////////////////////////////////
// PermittedSubtrees class implementation //
////////////////////////////////////////////
bool PermittedSubtrees::IsNameWithin(const ASN::DN& dn) const
{
	// Check that the specified DN is within each permitted-subtrees set
	for (const_iterator i = begin(); i != end(); ++i)
	{
		if (!i->IsNameWithin(dn, true))
			return false;
	}

	return true;
}


bool PermittedSubtrees::AreNamesWithin(const ASN::GenNames& names) const
{
	// Check that the specified GenNames are within each permitted-subtrees set
	for (const_iterator i = begin(); i != end(); ++i)
	{
		if (!i->AreNamesWithin(names, true))
			return false;
	}

	return true;
}



/************************************************************************
 FUNCTION:  areCommPrivsSubset()
 
 Description: This function returns true if the subject's privileges are
 present in one of the issuer's CAConstraints, otherwise false is returned.
*************************************************************************/
bool areCommPrivsSubset(const SNACC::CommPrecFlags& subjPrivs,
						const ASN::AttributeList& caConstraints)
{
	// Find the issuer's CommPrivs constraints
	ASN::AttributeList::const_iterator iIssuerPrivs =
		caConstraints.Find(ASN::Attribute::CommPrivs);
	while (iIssuerPrivs != caConstraints.end())
	{
		if (iIssuerPrivs->GetValues().pCommPrivs != NULL)
		{
			const SNACC::CommPrecFlags& issPrivs =
				*iIssuerPrivs->GetValues().pCommPrivs;

			bool allBitsSet = true;
			for (unsigned int i = 0; i < subjPrivs.BitLen() && allBitsSet; i++)
			{
				if (subjPrivs.GetBit(i) && !issPrivs.GetBit(i))
					allBitsSet = false;
			}

			if (allBitsSet)
				return true;
		}

		iIssuerPrivs = caConstraints.FindNext(iIssuerPrivs,
			ASN::Attribute::CommPrivs);
	}

	return false;
} // end of areCommPrivsSubset()


/************************************************************************
 FUNCTION:  areKmFlagsSubset()
 
 Description: This function returns true if all of the subject's KM
 privileges are present in the issuer's privileges.
*************************************************************************/
bool areKmFlagsSubset(const SNACC::KmPrivFlagsSeqOf* pSubj,
					  const SNACC::KmPrivFlagsSeqOf* pIssuer)
{
	if (pSubj == NULL)
		return true;
	else if (pIssuer == NULL)
		return false;

	pSubj->SetCurrToFirst();
	for ( ; pSubj->Curr() != NULL; pSubj->GoNext())
	{
		pIssuer->SetCurrToFirst();
		while ((pIssuer->Curr() != NULL) &&
			(*pSubj->Curr() != *pIssuer->Curr()))
			pIssuer->GoNext();

		if (pIssuer->Curr() == NULL)
			return false;
	}

	return true;
}


/************************************************************************
 FUNCTION:  arePrivsSubset()
 
 Description: This function returns true if the subject's privileges are
 present in one of the issuer's CAConstraints, otherwise false is returned.
*************************************************************************/
bool arePrivsSubset(const SNACC::PrivilegeFlags& subjPrivs,
					const ASN::AttributeList& caConstraints)
{
	// Find the issuer's constraints for the type of privileges
	// in the subject's privileges
	ASN::AttributeList::const_iterator iIssuerPrivs =
		caConstraints.Find(ASN::Attribute::SigOrKMPrivs);
	while (iIssuerPrivs != caConstraints.end())
	{
		if (iIssuerPrivs->GetValues().pSigKMPrivs != NULL)
		{
			const ASN::SigOrKMPrivileges& issPrivs =
				*iIssuerPrivs->GetValues().pSigKMPrivs;
			
			// For each value...
			ASN::SigOrKMPrivileges::const_iterator i = issPrivs.begin();
			for ( ; i != issPrivs.end(); i++)
			{
				if (i->choiceId == subjPrivs.choiceId)
				{
					if (subjPrivs.choiceId ==
						SNACC::PrivilegeFlags::sigFlagsCid)
					{
						if (areSigFlagsSubset(subjPrivs.sigFlags->sigPrivFlags,
							i->sigFlags->sigPrivFlags))
							return true;
					}
					else if (subjPrivs.choiceId == 
						SNACC::PrivilegeFlags::kmFlagsCid)
					{
						if (areKmFlagsSubset(subjPrivs.kmFlags->kmPrivFlags,
							i->kmFlags->kmPrivFlags))
							return true;
					}
				}
			}
		}

		iIssuerPrivs = caConstraints.FindNext(iIssuerPrivs,
			ASN::Attribute::SigOrKMPrivs);
	}

	return false;
} // end of arePrivsSubset()


/************************************************************************
 FUNCTION:  areSigFlagsSubset()
 
 Description: This function returns true if all of the subject's sig
 privileges are present in the issuer's privileges.
*************************************************************************/
bool areSigFlagsSubset(const SNACC::SigPrivFlagsSeqOf* pSubj,
					   const SNACC::SigPrivFlagsSeqOf* pIssuer)
{
	if (pSubj == NULL)
		return true;
	else if (pIssuer == NULL)
		return false;

	pSubj->SetCurrToFirst();
	for ( ; pSubj->Curr() != NULL; pSubj->GoNext())
	{
		pIssuer->SetCurrToFirst();
		while ((pIssuer->Curr() != NULL) &&
			(*pSubj->Curr() != *pIssuer->Curr()))
			pIssuer->GoNext();

		if (pIssuer->Curr() == NULL)
			return false;
	}

	return true;
}


void buildFortezzaPubKey(CTIL::CSM_Buffer& pubKey, CTIL::CSM_Buffer& params,
						 const Pub_key_struct& cmPubKey)
{
	// Check that required parameters are present
	if ((cmPubKey.params.dsa_kea == NULL) || (cmPubKey.key.combo == NULL))
		throw CML_ERR(CM_INVALID_PARAMETER);
	
	const Mosaic_key_struct& comboKey = *cmPubKey.key.combo;
	
	// Build the Kea_Dss_Parms
	SNACC::Kea_Dss_Parms parms;
	if (comboKey.diff_kea == NULL)
	{
		// Initialize the Common_Parms choice
		parms.choiceId = SNACC::Kea_Dss_Parms::common_ParmsCid;
		parms.common_Parms = new SNACC::Common_Parms;
		if (parms.common_Parms == NULL)
			throw CML_MEMORY_ERR;
		
		parms.common_Parms->p.Set((const char*)cmPubKey.params.dsa_kea->p.data,
			cmPubKey.params.dsa_kea->p.num);
		parms.common_Parms->q.Set((const char*)cmPubKey.params.dsa_kea->q.data,
			cmPubKey.params.dsa_kea->q.num);
		parms.common_Parms->g.Set((const char*)cmPubKey.params.dsa_kea->g.data,
			cmPubKey.params.dsa_kea->g.num);
	}
	else
	{
		// Initialize the Different_Parms choice
		parms.choiceId = SNACC::Kea_Dss_Parms::different_ParmsCid;
		parms.different_Parms = new SNACC::Different_Parms;
		if (parms.different_Parms == NULL)
			throw CML_MEMORY_ERR;
		
		parms.different_Parms->kea_Parms = new SNACC::Kea_Parms;
		if (parms.different_Parms->kea_Parms == NULL)
			throw CML_MEMORY_ERR;
		parms.different_Parms->dss_Parms = new SNACC::Dss_Parms;
		if (parms.different_Parms->dss_Parms == NULL)
			throw CML_MEMORY_ERR;
		
		parms.different_Parms->kea_Parms->p.Set((const char*)
			comboKey.diff_kea->p.data, comboKey.diff_kea->p.num);
		parms.different_Parms->kea_Parms->q.Set((const char*)
			comboKey.diff_kea->q.data, comboKey.diff_kea->q.num);
		parms.different_Parms->kea_Parms->g.Set((const char*)
			comboKey.diff_kea->g.data, comboKey.diff_kea->g.num);
		
		parms.different_Parms->dss_Parms->p.Set((const char*)
			cmPubKey.params.dsa_kea->p.data, cmPubKey.params.dsa_kea->p.num);
		parms.different_Parms->dss_Parms->q.Set((const char*)
			cmPubKey.params.dsa_kea->q.data, cmPubKey.params.dsa_kea->q.num);
		parms.different_Parms->dss_Parms->g.Set((const char*)
			cmPubKey.params.dsa_kea->g.data, cmPubKey.params.dsa_kea->g.num);
	}
	
	// Encode the parameters
	try {
		SNACC::AsnBuf asnBuf;
		parms.BEnc(asnBuf);
		long len = asnBuf.length();
		params = CTIL::CSM_Buffer((const char *)asnBuf.GetSeg(len), len);
	}
	catch (SNACC::SnaccException& ) {
		throw CML_ERR(CM_ASN_ERROR);
	}

//	if (SNACC::encodeBuf(parms, params) == false)
//		throw CML_ERR(CM_ASN_ERROR);
	
	// Determine size of buffer required for public key and allocate it
	ulong keySize = comboKey.dsa_y.num + 2 + comboKey.kea_y.num + 2 +
		CM_KMID_LEN + 2 + comboKey.dsa_privs.num + 2 +
		comboKey.kea_privs.num + comboKey.kea_clearance.num;
	
	uchar *keyBuf = new uchar[keySize];
	if (keyBuf == NULL)
		throw CML_MEMORY_ERR;
	
	// Fill in the key buffer
	uchar* pBuf = keyBuf;
	*pBuf++ = comboKey.kea_ver;
	*pBuf++ = comboKey.kea_type;
	memcpy(pBuf, comboKey.kmid, CM_KMID_LEN);
	pBuf += CM_KMID_LEN;
	
	memcpy(pBuf, comboKey.kea_clearance.data, comboKey.kea_clearance.num);
	pBuf += comboKey.kea_clearance.num;
	
	memcpy(pBuf, comboKey.kea_privs.data, comboKey.kea_privs.num);
	pBuf += comboKey.kea_privs.num;
	
	*pBuf++ = 0x00;
	*pBuf++ = 0x80;
	
	memcpy(pBuf, comboKey.kea_y.data, comboKey.kea_y.num);
	pBuf += comboKey.kea_y.num;
	
	*pBuf++ = comboKey.dsa_ver;
	*pBuf++ = comboKey.dsa_type;
	
	memcpy(pBuf, comboKey.dsa_privs.data, comboKey.dsa_privs.num);
	pBuf += comboKey.dsa_privs.num;
	
	*pBuf++ = 0x00;
	*pBuf++ = 0x80;
	
	memcpy(pBuf, comboKey.dsa_y.data, comboKey.dsa_y.num);
	
	// Set the public key
	pubKey.Set((char*)keyBuf, keySize);
} // end of buildFortezzaPubKey()


/************************************************************************
 FUNCTION:  checkCaConst()
 
 Description: This function performs the SDN.706 cert path processing of
 the subject's MISSI/DMS-unique attributes.
 If the SigOrKmPrivileges and/or CommPrivileges attributes are present,
 this function checks that those privileges are a subset of the issuer's
 CAClearanceConstraints privileges.
 If subject is a CA and if the subject has the CAClearanceConstraints
 attribute, then this function checks that the subject's privileges are
 a subset of the issuer's CAClearanceConstraints privileges.
 CM_NO_ERROR is returned if all of the checks pass, otherwise an error is
 returned.
*************************************************************************/
short checkCaConst(bool isCA, const ASN::AttributeList* pSubjAttribs,
				   const ASN::AttributeList* pIssuerAttribs)
{
	// If the subject directory attributes aren't present, just return
	if (pSubjAttribs == NULL)
		return CM_NO_ERROR;

	// Find the CAClearanceConstraints attribute in the issuer's cert
	const ASN::AttributeList* pCAConsts = NULL;
	if (pIssuerAttribs != NULL)
	{
		ASN::AttributeList::const_iterator iCAConst =
			pIssuerAttribs->Find(ASN::Attribute::CAClearanceConst);
		if ((iCAConst != NULL) && (iCAConst != pIssuerAttribs->end()))
			pCAConsts = iCAConst->GetValues().pCACons;
	}

	// If the subject cert is a CA, check that the CAClearanceConstraints
	// in the subject's cert (if present), is a subset of the issuer's
	// CAClearanceConstraints
	if (isCA)
	{
		// Find the CAClearanceConstraints in the subject's cert
		ASN::AttributeList::const_iterator iSubj =
			pSubjAttribs->Find(ASN::Attribute::CAClearanceConst);
		if (iSubj != pSubjAttribs->end())
		{
			if (iSubj->GetValues().pCACons != NULL)
			{
				// If the issuer cert does not have any CAClearanceConstraints,
				// return an error
				if (pCAConsts == NULL)
					return CM_DMS_NO_CA_CONSTRAINTS;

				// Check that the subject's CAClearanceConstraints are a subset
				// of the issuer's CAClearanceConstraints
				if (!isCAConstraintsSubset(*iSubj->GetValues().pCACons,
					*pCAConsts))
					return CM_INVALID_DMS_PRIVILEGE;
			}
		}
	}
   
	// Find the subject's SigOrKmPrivileges.  If present, check that the
	// privileges are a subset of the issuer's CAClearanceConstraints
	ASN::AttributeList::const_iterator iSubj =
		pSubjAttribs->Find(ASN::Attribute::SigOrKMPrivs);
	while (iSubj != pSubjAttribs->end())
	{
		// If the issuer cert does not have any CAClearanceConstraints,
		// return an error
		if (pCAConsts == NULL)
			return CM_DMS_NO_CA_CONSTRAINTS;
		
		if (iSubj->GetValues().pSigKMPrivs != NULL)
		{
			ASN::SigOrKMPrivileges::const_iterator iPriv;
			for (iPriv = iSubj->GetValues().pSigKMPrivs->begin(); iPriv !=
				iSubj->GetValues().pSigKMPrivs->end(); iPriv++)
			{
				// Check that the privileges asserted in the subject's
				// SNACC::PrivilegeFlags are a subset of the issuer's
				// constraints
				if (!arePrivsSubset(*iPriv, *pCAConsts))
					return CM_INVALID_DMS_PRIVILEGE;
			}
		}

		iSubj = pSubjAttribs->FindNext(iSubj, ASN::Attribute::SigOrKMPrivs);
	}

	// Find the subject's CommPrivileges.  If present, check that the
	// privileges are a subset of the issuer's CAClearanceConstraints
	iSubj = pSubjAttribs->Find(ASN::Attribute::CommPrivs);
	while (iSubj != pSubjAttribs->end())
	{
		// If the issuer cert does not have any CAClearanceConstraints,
		// return an error
		if (pCAConsts == NULL)
			return CM_DMS_NO_CA_CONSTRAINTS;
		
		if (iSubj->GetValues().pCommPrivs != NULL)
		{
			if (!areCommPrivsSubset(*iSubj->GetValues().pCommPrivs,
				*pCAConsts))
				return CM_INVALID_DMS_PRIVILEGE;
		}

		iSubj = pSubjAttribs->FindNext(iSubj, ASN::Attribute::CommPrivs);
	}

	return CM_NO_ERROR;
} // end of checkCaConst()


/************************************************************************
 FUNCTION:  checkExtKeyUsage()
 
 Description: This function checks that the anyExtendedKeyUsage OID is
 present in the extended key usage extension.  If not, either a single
 CM_INVALID_EXT_KEY_USE error or one or more CM_UNRECOGNIZED_EXT_KEY_USAGE
 errors are added to the list of errors.
*************************************************************************/
void checkExtKeyUsage(const ASN::ExtKeyUsageExtension& extKeyUse,
					  ErrorInfoList& errors, const ASN::Cert& cert)
{
	bool unknownKeyUse = false;

	std::list<SNACC::KeyPurposeId>::const_iterator i;
	for (i = extKeyUse.begin(); i != extKeyUse.end(); i++)
	{
		// If the anyExtendedKeyUsage OID is present, then the cert isn't
		// restricted to any other key usages present
		if (*i == SNACC::anyExtendedKeyUsage)
			return;

		// REN -- 11/1/2002 -- If the key usage is Entrust's unknown CA
		// key usage or Microsoft's certTrustListSigning, then just return
		// without reporting an error
		if ((*i == gEXT_KEY_USE_EntrustCA) ||
			(*i == gEXT_KEY_USE_msCTLSigning))
			return;
	}

	for (i = extKeyUse.begin(); i != extKeyUse.end(); i++)
	{
		// If the key usage isn't recognized, record an error with the OID.
		// This allows the application to recognize one of the OIDs and
		// possibly continue processing
		if ((*i != gEXT_KEY_USE_serverAuth) &&
			(*i != gEXT_KEY_USE_clientAuth) &&
			(*i != gEXT_KEY_USE_codeSigning) &&
			(*i != gEXT_KEY_USE_emailProtection) &&
			(*i != gEXT_KEY_USE_timeStamping) &&
			(*i != gEXT_KEY_USE_OCSPSigning))
		{
			unknownKeyUse = true;
			errors.AddError(CM_UNRECOGNIZED_EXT_KEY_USAGE, cert, *i);
		}
	}

	// If all of the key purposes are recognized, the record an error since
	// none of the recognized OIDs indicate a CA.
	if (!unknownKeyUse)
		errors.AddError(CM_INVALID_EXT_KEY_USE, cert);

} // end of checkExtKeyUsage()


void cvtBytesToHugeInt(SNACC::AsnInt& hugeInt, const Bytes_struct& bytes)
{
	// Check if there is any data to convert
	if ((bytes.num == 0) || (bytes.data == NULL))
		return;

	uchar* pBuf;
	ulong len = bytes.num;
	bool tempBufUsed = false;

	// If the sign bit is set, copy the data into a temporary buffer with
	// a leading zero byte
	if ((*bytes.data & 0x80) != 0)
	{
		len++;
		pBuf = new uchar[len];
		if (pBuf == NULL)
			throw CML_MEMORY_ERR;
		*pBuf = 0;
		memcpy(&pBuf[1], bytes.data, bytes.num);
		tempBufUsed = true;
	}
	else
	{
		// Just set pBuf to the data
		pBuf = (uchar*)bytes.data;

		// Skip over any zero bytes that need to be removed (unlikely)
		while ((*pBuf == 0) && (len > 1) && ((pBuf[1] & 0x80) == 0))
		{
			pBuf++;
			--len;
		}
	}

	try {
		hugeInt.Set((const unsigned char*)pBuf, len);
		if (tempBufUsed)
			delete[] pBuf;
	}
	catch (...) {
		if (tempBufUsed)
			delete[] pBuf;
		throw;
	}
} // end of cvtBytesToHugeInt()


void cvtPolicyStructToList(ASN::CertPolicyList& list,
						   const Policy_struct* policyList)
{
	try {
		list.clear();

		const Policy_struct* pPolicy = policyList;
		while (pPolicy != NULL)
		{
			ASN::CertPolicy tmpPolicy(pPolicy->policy_id);

			const Qualifier_struct* pQual = pPolicy->qualifiers;
			while (pQual != NULL)
			{
				ASN::PolicyQualifier tmpQual(pQual->qualifier_id);

				// Check that the qualifier is present
				if (pQual->qual.cpsURI == NULL)
					throw CML_ERR(CM_NULL_POINTER);

				if (pQual->flag == CM_QUAL_CPS)
				{
					// Encode the PKIX CPS pointer qualifier
					SNACC::IA5String cpsString(pQual->qual.cpsURI);
					tmpQual.qualifier = new ASN::Bytes;
					if (tmpQual.qualifier == NULL)
						throw CML_MEMORY_ERR;
					try {
						SNACC::AsnBuf asnBuf;
						cpsString.BEnc(asnBuf);
						long len = asnBuf.length();
						// Load in the encoded value;
						*tmpQual.qualifier = CTIL::CSM_Buffer((const char *)asnBuf.GetSeg(len),
											len);
					}
					catch (SNACC::SnaccException& ) {
						throw CML_ERR(CM_ASN_ERROR);
					}

//					if (SNACC::encodeBuf(cpsString, *tmpQual.qualifier) == false)
//						throw CML_ERR(CM_ASN_ERROR);
				}
				else if (pQual->flag == CM_QUAL_UNOTICE)
				{
					// Encode the PKIX user notice qualifier
					SNACC::UserNotice snacc;
					if (pQual->qual.userNotice->noticeRef != NULL)
					{
						// Set the optional NoticeReference
						snacc.noticeRef = new SNACC::NoticeReference;
						if (snacc.noticeRef == NULL)
							throw CML_MEMORY_ERR;

						// Set the organization DisplayText
						if (pQual->qual.userNotice->noticeRef->org == NULL)
							throw CML_ERR(CM_NULL_POINTER);
						snacc.noticeRef->organization = new SNACC::DisplayText;
						if (snacc.noticeRef->organization == NULL)
							throw CML_MEMORY_ERR;

						snacc.noticeRef->organization->choiceId =
							SNACC::DisplayText::utf8StringCid;
						snacc.noticeRef->organization->utf8String = new
							SNACC::UTF8String(pQual->qual.userNotice->noticeRef->org);
						if (snacc.noticeRef->organization->utf8String == NULL)
							throw CML_MEMORY_ERR;

						// Set the noticeNumbers
						fillSnaccNoticeNumbers(snacc.noticeRef->noticeNumbers,
							pQual->qual.userNotice->noticeRef->notices);
					}

					if (pQual->qual.userNotice->explicitText != NULL)
					{
						// Set the optional DisplayText
						snacc.explicitText = new SNACC::DisplayText;
						if (snacc.explicitText == NULL)
							throw CML_MEMORY_ERR;

						snacc.explicitText->choiceId =
							SNACC::DisplayText::utf8StringCid;
						snacc.explicitText->utf8String = new
							SNACC::UTF8String(pQual->qual.userNotice->explicitText);
						if (snacc.explicitText->utf8String == NULL)
							throw CML_MEMORY_ERR;
					}
					
					tmpQual.qualifier = new ASN::Bytes;
					if (tmpQual.qualifier == NULL)
						throw CML_MEMORY_ERR;
					try {
						SNACC::AsnBuf asnBuf;
						snacc.BEnc(asnBuf);
						long len = asnBuf.length();
						// load in the encoded value
						*tmpQual.qualifier = CTIL::CSM_Buffer((const char *)asnBuf.GetSeg(len), len);
					}
					catch (SNACC::SnaccException& ) {
						throw CML_ERR(CM_ASN_ERROR);
					}

//					if (SNACC::encodeBuf(snacc, *tmpQual.qualifier) == false)
//						throw CML_ERR(CM_ASN_ERROR);
				}
				else if (pQual->flag == CM_QUAL_UNKNOWN)
				{
					// Copy the unknown encoded qualifier
					tmpQual.qualifier = new
						ASN::Bytes(pQual->qual.unknown->num,(const unsigned char*)pQual->qual.unknown->data);
					if (tmpQual.qualifier == NULL)
						throw CML_MEMORY_ERR;
				}
				else
					throw CML_ERR(CM_UNKNOWN_ERROR);

				tmpPolicy.qualifiers.push_back(tmpQual);
				pQual = pQual->next;
			}

			list.push_back(tmpPolicy);

			pPolicy = pPolicy->next;
		}
	}
	catch (...) {
		list.clear();
		throw;
	}
} // end of cvtPolicyStructToList()


void fillSnaccNoticeNumbers(SNACC::NoticeReferenceSeqOf& snacc,
							const Bytes_struct_LL* pNumList)
{
	while (pNumList != NULL)
	{
		if (pNumList->bytes_struct == NULL)
			throw CML_ERR(CM_NULL_POINTER);
		
		SNACC::AsnInt* pNew = snacc.Append();
		if (pNew == NULL)
			throw CML_MEMORY_ERR;
		
		pNew->Set(pNumList->bytes_struct->data, pNumList->bytes_struct->num);
		
		pNumList = pNumList->next;
	}
}


/************************************************************************
 FUNCTION:  isCAConstraintsSubset()
 
 Description: This function returns true if the subj CAConstraints is a
 subset of the issuer CAConstraints.  false is returned otherwise.  Only
 the SigOrKmPrivileges and CommPrivileges attributes are checked.
*************************************************************************/
bool isCAConstraintsSubset(const ASN::AttributeList& subj,
						   const ASN::AttributeList& issuer)
{
	// Loop through each of the subject's CAConstraints...
	ASN::AttributeList::const_iterator iSubj;
	for (iSubj = subj.begin(); iSubj != subj.end(); iSubj++)
	{
		if ((iSubj->GetType() == ASN::Attribute::SigOrKMPrivs) &&
			(iSubj->GetValues().pSigKMPrivs != NULL))
		{
			// Loop through each of the values
			ASN::SigOrKMPrivileges::const_iterator iValue =
				iSubj->GetValues().pSigKMPrivs->begin();
			for ( ; iValue != iSubj->GetValues().pSigKMPrivs->end(); iValue++)
			{
				if (!arePrivsSubset(*iValue, issuer))
					return false;
			}
		}
		else if ((iSubj->GetType() == ASN::Attribute::CommPrivs) &&
			(iSubj->GetValues().pCommPrivs != NULL))
		{
			if (!areCommPrivsSubset(*iSubj->GetValues().pCommPrivs, issuer))
				return false;
		}
		// else ignore the CAConstraint
	}

	return TRUE;
} // end of isCAConstraintsSubset()

// end of CM_RetrieveKey.cpp
