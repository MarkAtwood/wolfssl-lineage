/*****************************************************************************
File:     CM_certPolicies.cpp
Project:  Certificate Management Library
Contents: Contains the PolicyTable class implementation and low-level
		  functions used to process certificate policies.

Created:  24 October 2000
Author:   Rich Nicholas <Richard.Nicholas@DigitalNet.com>

Last Updated:  15 September 2003

Version:  2.3

*****************************************************************************/

////////////////////
// Included Files //
////////////////////
#include "CM_cache.h"



// Using declarations
using namespace CML;
using CML::Internal::PolicyTable;
using ASN::CertPolicy;
using ASN::CertPolicyList;



//////////////////////////////////////
// PolicyTable class implementation //
//////////////////////////////////////
void PolicyTable::Init(int numCerts)
{
	const int kNUM_INITIAL_ROWS = 10;

	if (numCerts < 1)
		throw CML_ERR(CM_INVALID_PARAMETER);

	m_depth = ushort(numCerts);

	m_table.reserve(kNUM_INITIAL_ROWS);
	PolicyArray::iterator iRow = m_table.insert(m_table.end(),CML::Internal::PolicyTable::PolicyRow());
	iRow->insert(iRow->end(), m_depth + 1, SNACC::anyPolicy);
}

bool PolicyTable::IsEmpty() const
{
	if ((m_depth == 0) || (m_table.size() == 0))
		return true;
	else
		return false;
}

bool PolicyTable::IsUserPolicySetEmpty(const ASN::OIDList& initialPolicySet) const
{
	// Get the authority-constrained-policy-set
	CertPolicyList authoritySet;
	GetAuthPolicySet(authoritySet);

	// Return true if the authority-constrained-policy-set is empty
	if (authoritySet.empty())
		return true;

	// Return false if any policy in the authority set matches one of the
	// initial policies or if the special anyPolicy is present in either set
	CertPolicyList::const_iterator i;
	for (i = authoritySet.begin(); i != authoritySet.end(); ++i)
	{
		if (*i == SNACC::anyPolicy)
			return false;

		ASN::OIDList::const_iterator j;
		for (j = initialPolicySet.begin(); j != initialPolicySet.end(); ++j)
		{
			if ((*i == *j) || (*j == SNACC::anyPolicy))
				return false;
		}
	}

	// Nothing matched, so return true
	return true;
}


void PolicyTable::GetAuthPolicySet(CertPolicyList& authSet) const
{
	// Clear the authSet parameter
	authSet.clear();

	// If the table is empty, just return
	if (IsEmpty())
		return;

	if (m_table[0][m_depth] == SNACC::anyPolicy)
		authSet.push_back(m_table[0][m_depth]);
	else
	{
		for (unsigned int iRow = 0; iRow < m_table.size(); iRow++)
		{
			for (unsigned int iCol = 0; iCol < m_table[iRow].size(); iCol++)
			{
				if (m_table[iRow][iCol] != SNACC::anyPolicy)
				{
					authSet.push_back(m_table[iRow][iCol]);
					break;
				}
			}
		}
	}
}


/************************************************************************
 FUNCTION:  PolicyTable::ProcessMappings()
 
 Description: This function performs the X.509 cert path processing of
 the supplied cert policy mappings extension for the current path depth.
 Any mappings that are processed are added to the mapping history.
 An exception is thrown if an error occurs.
*************************************************************************/
void PolicyTable::ProcessMappings(const ASN::PolicyMappingList* pMappings,
								  ushort nDepth, bool inhibitMapping,
								  ASN::PolicyMappingList& mappingDetails)
{
	// If the policy table is empty, just return
	if (IsEmpty())
		return;

	// Check that the table size won't be exceeded
	if (nDepth > m_depth - 1)
		throw CML_ERR(CM_UNKNOWN_ERROR);

	// If the policy-mapping-inhibit-indicator is set
	if (inhibitMapping)
	{
		// For each mapping present in the extension, locate all rows in the
		// table whose nDepth column contains the mapping's issuer domain
		// policy, and delete the row
		if (pMappings != NULL)
		{
			ASN::PolicyMappingList::const_iterator iMap;
			for (iMap = pMappings->begin(); iMap != pMappings->end(); ++iMap)
			{
				// If either the issuer or subject domain policy is any-policy,
				// empty the policy table and return. According to X.509
				// clause 8.2.2.7, policies shall not be mapped to or from
				// the special any-policy
				if ((iMap->issuerPolicy == SNACC::anyPolicy) ||
					(iMap->subjectPolicy == SNACC::anyPolicy))
				{
					m_table.clear();
					return;
				};

				PolicyArray::iterator iRow = m_table.begin();
				while (iRow != m_table.end())
				{
					if (iRow->at(nDepth).policyId == iMap->issuerPolicy)
						iRow = m_table.erase(iRow);
					else
						++iRow;
				}
			}
		}
	}
	else // the policy-mapping-inhibit-indicator is not set
	{
		// For each mapping present in the extension, locate all rows in the
		// table whose nDepth column contains the mapping's issuer domain
		// policy, and write the subject domain policy in the nDepth+1 column
		// of the same row.
		if (pMappings != NULL)
		{
			ASN::PolicyMappingList::const_iterator iMap;
			for (iMap = pMappings->begin(); iMap != pMappings->end(); ++iMap)
			{
				// If either the issuer or subject domain policy is any-policy,
				// empty the policy table and return. According to X.509
				// clause 8.2.2.7, policies shall not be mapped to or from
				// the special any-policy
				if ((iMap->issuerPolicy == SNACC::anyPolicy) ||
					(iMap->subjectPolicy == SNACC::anyPolicy))
				{
					m_table.clear();
					return;
				};

				bool matchFound = false;
				PolicyArray::iterator iRow;
				for (iRow = m_table.begin(); iRow != m_table.end(); ++iRow)
				{
					if (iRow->at(nDepth).policyId == iMap->issuerPolicy)
					{
						matchFound = true;

						// If the extension maps this issuer policy to more
						// than one subject policy, copy the previously mapped
						// row, and then map the new row
						if (iRow->at(nDepth + 1) != SNACC::anyPolicy)
							iRow = m_table.insert(m_table.end(), *iRow);

						iRow->at(nDepth + 1).policyId = iMap->subjectPolicy;
						iRow->at(nDepth + 1).qualifiers =
							iRow->at(nDepth).qualifiers;

						mappingDetails.push_back(*iMap);
					}
				}

				// If a match wasn't found and if the first row of the nDepth
				// column is any-policy, write the issuer domain policy in
				// the policy mappings extension into the nDepth column, adding
				// rows as necessary, and retaining any qualifiers
				if (!matchFound && (m_table[0][nDepth] == SNACC::anyPolicy))
				{
					// Insert row
					PolicyArray::iterator iNewRow =
						m_table.insert(m_table.end(),
						CML::Internal::PolicyTable::PolicyRow());
					iNewRow->insert(iNewRow->end(), m_depth + 1,
						SNACC::anyPolicy);

					// Add the issuer policy to the nDepth column of the new row
					iNewRow->at(nDepth).policyId = iMap->issuerPolicy;
					iNewRow->at(nDepth).qualifiers =
						m_table[0][nDepth].qualifiers;

					// Add the subject policy mapping to the nDepth+1 column
					iNewRow->at(nDepth + 1).policyId = iMap->subjectPolicy;
					iNewRow->at(nDepth + 1).qualifiers =
						iNewRow->at(nDepth).qualifiers;

					mappingDetails.push_back(*iMap);
				}
			}
		}
	}

	// For any row not modified above, copy the policy from the nDepth column
	// into the nDepth+1 column of the same row
	for (unsigned int i = 0; i < m_table.size(); ++i)
	{
		if (m_table[i][nDepth + 1] == SNACC::anyPolicy)
			m_table[i][nDepth + 1] = m_table[i][nDepth];
	}
}


/************************************************************************
 FUNCTION:  PolicyTable::ProcessPolicies()
 
 Description:  This function performs the X.509 cert path processing of
 the supplied certificate policies for the current path depth.
 An exception is thrown if an error occurs.
*************************************************************************/
void PolicyTable::ProcessPolicies(const CertPolicyList* pPolicies,
								  ushort nDepth, bool inhibitAnyPolicy,
								  bool isSelfIssuedCA)
{
	// If the policy table is empty, just return
	if (IsEmpty())
		return;

	// Check that the table size hasn't been exceeded
	if (nDepth > m_depth)
		throw CML_ERR(CM_UNKNOWN_ERROR);

	// If the certificate policies are absent, set the the authorities-
	// constrained-policy-set to NULL
	if (pPolicies == NULL)
	{
		// Delete all rows in the table
		m_table.clear();
		m_depth = 0;
		return;
	}

	// For each policy in the extension...
	CertPolicyList::const_iterator iPolicy;
	for (iPolicy = pPolicies->begin(); iPolicy != pPolicies->end(); ++iPolicy)
	{
		if (iPolicy->policyId != SNACC::anyPolicy)
		{
			// For policies other than any-policy, find the policies in the 
			// nDepth column that match this policy and attach the qualifiers
			// to the policies in that row
			bool matchFound = false;
			for (unsigned int iRow = 0; iRow < m_table.size(); ++iRow)
			{
				if (iPolicy->policyId == m_table[iRow][nDepth].policyId)
				{
					matchFound = true;
					m_table[iRow][nDepth] |= iPolicy->qualifiers;
				}
			}

			// If policy isn't present in the table, and the first policy
			// in the nDepth column is any-policy, then add a new row to the
			// table and copy the policy into the nDepth column.
			if (!matchFound &&
				(m_table[0][nDepth].policyId == SNACC::anyPolicy))
			{
				PolicyArray::iterator iNewRow = m_table.insert(m_table.end(),
					CML::Internal::PolicyTable::PolicyRow());
				iNewRow->insert(iNewRow->end(), m_depth + 1, SNACC::anyPolicy);
				iNewRow->at(nDepth) = *iPolicy;
			}
		}
	}

	// If the special any-policy value is not present in the extension or if
	// the inhibit-any-policy flag is set and the cert is not a self-issued
	// intermediate cert, delete the row containing the any-policy (if present)
	// and any row containing a policy not present in the policy extension
	CertPolicyList::const_iterator iAnyPolicy =
		pPolicies->Find(SNACC::anyPolicy);
	if ((iAnyPolicy == pPolicies->end()) ||
		(inhibitAnyPolicy && !isSelfIssuedCA))
	{
		// For each policy row in the nDepth column...
		PolicyArray::iterator iRow = m_table.begin();
		while (iRow != m_table.end())
		{
			CertPolicy& policy = iRow->at(nDepth);
			if ((policy.policyId == SNACC::anyPolicy) ||
				(pPolicies->Find(policy.policyId) == pPolicies->end()))
			{
				iRow = m_table.erase(iRow);
			}
			else
				++iRow;
		}
	}
	// Else, attach any qualifiers on the any-policy to each row in the table
	// whose nDepth column contains either any-policy or a policy that does not
	// appear in the extension.
	else if (!iAnyPolicy->qualifiers.empty())
	{
		// For each policy row in the nDepth column...
		PolicyArray::iterator iRow;
		for (iRow = m_table.begin(); iRow != m_table.end(); ++iRow)
		{
			CertPolicy& policy = iRow->at(nDepth);
			if ((policy.policyId == SNACC::anyPolicy) ||
				(pPolicies->Find(policy.policyId) == pPolicies->end()))
			{
				policy |= iAnyPolicy->qualifiers;
			}
		}
	}
}



// end of CM_certPolicies.cpp
