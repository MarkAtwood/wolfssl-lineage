/*****************************************************************************
File:     CM_srl.cpp
Project:  Certificate Management Library
Contents: Routines to interface with the Storage and Retrieval Library API

Created:  17 Nov 2000
Author:   Shari Bodin <Shari.Bodin@GetronicsGov.com>

Last Updated:  9 December 2002

Version:  2.2

*****************************************************************************/

/* ------------- */
/* Include Files */
/* ------------- */
#if defined(SunOS) || defined(Linux) || defined(SCO_SV) || defined(HPUX)
	#include <dlfcn.h>
#elif defined(HPUX32)
        #include <dl.h>
#elif defined(WIN32)
	#pragma warning(push, 3)
	#include <windows.h>
	#pragma warning(pop)
	#pragma warning(disable: 4514)
#endif

#include "CM_cache.h"
#include "srlapi.h"
  


// Using declarations
using namespace CML;
using namespace CML::Internal;



//////////////////////
// Type Definitions //
//////////////////////
typedef short (*PExtCreateSessFn)(ulong *sessionID, SRL_InitSettings_struct *pSettings);
typedef short (*PExtDestroySessFn)(ulong *sessionID);
typedef short (*PExtGetTrustedCerts)(ulong sessionID, EncCert_LL **trustedCerts);
typedef short (*PExtFreeEncCertList)(EncCert_LL **pCertList);


//////////////////////
// Global Variables //
//////////////////////
#if defined(SunOS) || defined(Linux) || defined (SCO_SV)
	#define GetProcAddress	dlsym
	#define FreeLibrary		dlclose
	typedef void* HINSTANCE;
	#ifdef _DEBUG
		static char gLibName[] = "libsrlapi_d.so";
	#else
		static char gLibName[] = "libsrlapi.so";
	#endif /* _DEBUG */
#elif defined(WIN32)
	#ifdef _DEBUG
		static char gLibName[] = "srlapi_d.dll";
	#else
		static char gLibName[] = "srlapi.dll";
	#endif /* _DEBUG */
#elif defined(HPUX)
	#define GetProcAddress	dlsym
	#define FreeLibrary		dlclose
	typedef void* HINSTANCE;
	#ifdef _DEBUG
		static char gLibName[] = "libsrlapi_d.sl";
	#else
		static char gLibName[] = "libsrlapi.sl";
	#endif /* _DEBUG */
#elif defined(HPUX32)
	#define FreeLibrary		shl_unload
        typedef shl_t HINSTANCE;
	#ifdef _DEBUG
		static char gLibName[] = "libsrlapi_d.sl";
	#else
		static char gLibName[] = "libsrlapi.sl";
	#endif /* _DEBUG */
#else
	#error "Unsupported OS!"
#endif


/////////////////////////
// Function Prototypes //
/////////////////////////
static HINSTANCE link2SRL(char* libName, ulong& sessionID,
						  CallbackFunctions& funcs,
						  PExtGetTrustedCerts* ppGetCertsFn,
						  PExtFreeEncCertList* ppFreeCertsFn);
static void unlinkSRL(HINSTANCE hDLL, ulong* pSessionID);
static short srlError2cmlError(short srlError);


/////////////////////////////////////
// SrlSession class implementation //
/////////////////////////////////////
SrlSession::SrlSession(CM_TOKEN_TYPE *pTokObj, CallbackFunctions& cmlFuncs, CertCache* pCertCache)
{
	// Initialize members
	srlLibHandle = NULL;
	sessionID = 0;

	// Link to the SRL
	PExtGetTrustedCerts fpSRLGetTrustedCerts;
	PExtFreeEncCertList fpSRLFreeEncCertList;
	srlLibHandle = link2SRL(gLibName, sessionID, cmlFuncs,
		&fpSRLGetTrustedCerts, &fpSRLFreeEncCertList);
	cmlFuncs.extHandle = &sessionID;
		
	EncCert_LL *pCerts = NULL;
	try {
		// Get and load the trusted certs from the SRL (if requested)
		if (pCertCache != NULL)
		{
			short srlErr = fpSRLGetTrustedCerts(sessionID, &pCerts);
			if ((srlErr != SRL_SUCCESS) && (srlErr != SRL_NOT_FOUND))
				throw CML_ERR(srlError2cmlError(srlErr));
			
			pCertCache->LoadTrustedCerts(pTokObj, pCerts);
			fpSRLFreeEncCertList(&pCerts);
		}
	}
	catch (...) {
		if (pCerts != NULL)
			fpSRLFreeEncCertList(&pCerts);

		unlinkSRL((HINSTANCE)srlLibHandle, &sessionID);
		throw;
	}
}


SrlSession::~SrlSession()
{
	if (srlLibHandle != NULL)
		unlinkSRL((HINSTANCE)srlLibHandle, &sessionID);
}


////////////////
// link2SRL() //
////////////////
HINSTANCE link2SRL(char* libName, ulong& sessionID, CallbackFunctions& funcs,
				   PExtGetTrustedCerts* ppGetCertsFn,
				   PExtFreeEncCertList* ppFreeCertsFn)
{
	// Check parameters
	if ((libName == NULL) || (ppGetCertsFn == NULL) || (ppFreeCertsFn == NULL))
		throw CML_ERR(CM_NULL_POINTER);

	// Load the SRL library
#ifdef WIN32
	HINSTANCE hDLL = LoadLibrary(libName);
#elif defined(HPUX32)
        HINSTANCE hDLL = shl_load(libName, BIND_NONFATAL, 0L);
#else	// SOLARIS or LINUX
	HINSTANCE hDLL = dlopen(libName, RTLD_NOW | RTLD_GLOBAL);
#endif
	if (hDLL == NULL)
		throw CML_ERR(CM_SRL_INITIALIZATION_FAILED);

	// Set the callback function pointers

#ifdef HPUX32

        shl_findsym(&hDLL, "SRL_RequestObjs", TYPE_PROCEDURE, 
                    (void *) &funcs.pGetObj);
        shl_findsym(&hDLL, "SRL_FreeObjs", TYPE_PROCEDURE, 
                    (void *) &funcs.pFreeObj);
        shl_findsym(&hDLL, "SRL_URLRequestObjs", TYPE_PROCEDURE, 
                    (void *) &funcs.pUrlGetObj);

	PExtCreateSessFn fpSRLCreateSession;
        shl_findsym(&hDLL, "SRL_CreateSession", TYPE_PROCEDURE, 
                    (void *) &fpSRLCreateSession);

        shl_findsym(&hDLL, "SRL_FreeEncCertList", TYPE_PROCEDURE, 
                    (void *) ppFreeCertsFn);

	shl_findsym(&hDLL, "SRL_GetTrustedCerts", TYPE_PROCEDURE,
                    (void *) ppGetCertsFn);
#else

	funcs.pGetObj = (ExtGetObjFuncPtr)GetProcAddress(hDLL, "SRL_RequestObjs");
	funcs.pFreeObj = (ExtFreeObjFuncPtr)GetProcAddress(hDLL, "SRL_FreeObjs");
	funcs.pUrlGetObj = (ExtUrlGetObjFuncPtr)GetProcAddress(hDLL,
		"SRL_URLRequestObjs");

	PExtCreateSessFn fpSRLCreateSession = (PExtCreateSessFn)
		GetProcAddress(hDLL,"SRL_CreateSession");
	*ppFreeCertsFn = (PExtFreeEncCertList)GetProcAddress(hDLL,
		"SRL_FreeEncCertList");
	*ppGetCertsFn = (PExtGetTrustedCerts)GetProcAddress(hDLL,
		"SRL_GetTrustedCerts");
#endif

	if ((funcs.pGetObj == NULL) || (funcs.pFreeObj == NULL) ||
		(funcs.pUrlGetObj == NULL) || (fpSRLCreateSession == NULL) ||
		(*ppFreeCertsFn == NULL) || (*ppGetCertsFn == NULL))
	{
		FreeLibrary(hDLL);
		throw CML_ERR(CM_SRL_INITIALIZATION_FAILED);
	}

	// Initialize SRL session handle
	sessionID = 0;

	// Create an SRL session
	short srlErr = fpSRLCreateSession(&sessionID, NULL);
	if (srlErr != SRL_SUCCESS)
	{
		FreeLibrary(hDLL);
		throw CML_ERR(srlError2cmlError(srlErr));
	}

	return hDLL;
} // end of link2SRL()


/////////////////
// unlinkSRL() //
/////////////////
void unlinkSRL(HINSTANCE hDLL, ulong* pSessionID)
{
	// Destroy the SRL session
	if (pSessionID != NULL)
	{
		PExtDestroySessFn fpSRL_DestroySession;
#ifdef HPUX32
		shl_findsym(&hDLL, "SRL_DestorySession", TYPE_PROCEDURE,
                     (void *) &fpSRL_DestroySession);
#else
		fpSRL_DestroySession = (PExtDestroySessFn)
			GetProcAddress(hDLL, "SRL_DestroySession");
#endif
		if (fpSRL_DestroySession != NULL)
			fpSRL_DestroySession(pSessionID);
	}

	// Release the SRL library
	FreeLibrary(hDLL);
}


typedef struct
{
	short srlError;
	short cmlError;
} ErrorEquivRec;

static ErrorEquivRec gErrorMap[] =
{
	{ SRL_SUCCESS, CM_NO_ERROR },
	{ SRL_MEMORY_ERROR, CM_MEMORY_ERROR },
	{ SRL_INVALID_PARAMETER, CM_INVALID_PARAMETER },
	{ SRL_SESSION_NOT_VALID, CM_UNKNOWN_ERROR },
	{ SRL_NULL_POINTER, CM_NULL_POINTER },
	{ SRL_NOT_IMPLEMENTED, CM_NOT_IMPLEMENTED },
	{ SRL_BAD_CONFIG_FILE, CM_BAD_CONFIG_FILE },
	{ SRL_CONFIG_NOT_FOUND, CM_CONFIG_NOT_FOUND },
	{ SRL_ASN_ERROR, CM_ASN_ERROR },
	{ SRL_NOT_SELF_SIGNED, CM_NOT_SELF_SIGNED },
	{ SRL_NOT_SIG_KEY, CM_NOT_SIG_KEY }, 
	{ SRL_MISSING_PARAMETERS, CM_MISSING_PARAMETERS },
	{ SRL_INVALID_DN, CM_INVALID_DN },
	{ SRL_NOT_FOUND, CM_NOT_FOUND },
	{ SRL_LDAP_LOAD_FAILED, CM_LDAP_DLL_INVALID },
	{ SRL_LDAP_INIT_FAILED, CM_LDAP_INITIALIZATION_FAILED },
	{ SRL_LDAP_UNAVAILABLE, CM_LDAP_UNAVAILABLE },
	{ SRL_LDAP_CONNECTION_FAILED, CM_LDAP_CONNECTION_FAILED },
	{ SRL_LDAP_BIND_FAILED, CM_LDAP_BIND_FAILED },
	{ SRL_LDAP_SEARCH_FAILED, CM_LDAP_SEARCH_FAILED },
	{ SRL_DB_IO_ERROR, CM_DB_IO_ERROR },
	{ SRL_DB_UNRECOGNIZED_FILE, CM_DB_UNRECOGNIZED_FILE },
	{ SRL_DB_ALREADY_EXISTS, CM_DB_ALREADY_EXISTS },
	{ SRL_DB_FLUSH_FAILURE, CM_DB_FLUSH_FAILURE },
	{ SRL_DB_INDEX_ERROR, CM_DB_INDEX_ERROR },
	{ SRL_UNKNOWN_ERROR, CM_UNKNOWN_ERROR }
};


static short srlError2cmlError(short srlError)
{
	ErrorEquivRec *pErr;

	for (pErr = gErrorMap; (pErr->srlError != SRL_UNKNOWN_ERROR) && 
		(pErr->srlError != srlError); pErr++)
		;

	return pErr->cmlError;

} /* end of srlError2cmlError() */
