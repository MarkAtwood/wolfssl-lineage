Readme information about the CM Library, including instructions
for building the library and its revision history, are located in
the \docs directory.

Open the \docs\index.html file in your web browser.