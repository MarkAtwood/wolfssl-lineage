/*****************************************************************************
File:     SRL_ldap.h
Project:  Storage & Retrieval library
Contents: ldap include references

Created:  November 2002
Author:   C. McPherson <Clyde.McPherson@getronicsgov.com>

Last Updated:  04 November 2002

Version:  2.2

Description:  LDAP include file for the SRL (excerpts from Netscape ldap.h).

*****************************************************************************/
#ifndef _LDAP_H
#define _LDAP_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined( _WINDOWS ) || defined( _WIN32 )
	#pragma warning(disable: 4115)
	#include <winsock.h>
#else
	#include <sys/time.h>
	#include <sys/types.h>
	#include <sys/socket.h>
#endif

#define LDAP_PORT       389

#define LDAP_OPT_REFERRALS              8

/* for on/off options */
#define LDAP_OPT_ON     ((void *)1)
#define LDAP_OPT_OFF    ((void *)0)


typedef struct ldap     LDAP;           /* opaque connection handle */
typedef struct ldapmsg  LDAPMessage;    /* opaque result/entry handle */


/* calling conventions used by library */
#ifndef LDAP_CALL
	#if defined( _WINDOWS ) || defined( _WIN32 )
		#define LDAP_C __cdecl
		#ifndef _WIN32 
			#define __stdcall _far _pascal
			#define LDAP_CALLBACK _loadds
		#else
			#define LDAP_CALLBACK
		#endif /* _WIN32 */
		#define LDAP_PASCAL __stdcall
		#define LDAP_CALL LDAP_PASCAL
	#else /* _WINDOWS */
		#define LDAP_C
		#define LDAP_CALLBACK
		#define LDAP_PASCAL
		#define LDAP_CALL
	#endif /* _WINDOWS */
#endif /* LDAP_CALL */


/* search scopes */
#define LDAP_SCOPE_BASE         0x00
#define LDAP_SCOPE_ONELEVEL     0x01
#define LDAP_SCOPE_SUBTREE      0x02

// The CML uses a subset of these, complete listing put in for completeness
/* possible error codes we can be returned */
#define LDAP_SUCCESS                    0x00
#define LDAP_OPERATIONS_ERROR           0x01
#define LDAP_PROTOCOL_ERROR             0x02
#define LDAP_TIMELIMIT_EXCEEDED         0x03
#define LDAP_SIZELIMIT_EXCEEDED         0x04
#define LDAP_COMPARE_FALSE              0x05
#define LDAP_COMPARE_TRUE               0x06
#define LDAP_STRONG_AUTH_NOT_SUPPORTED  0x07
#define LDAP_STRONG_AUTH_REQUIRED       0x08
#define LDAP_PARTIAL_RESULTS            0x09 /* non-standard extension to LDAP v2 */
#define LDAP_REFERRAL                   0x0a
#define LDAP_ADMIN_LIMIT_EXCEEDED       0x0b
#define LDAP_UNAVAILABLE_CRITICAL_EXTN  0x0c

#define LDAP_NO_SUCH_ATTRIBUTE          0x10
#define LDAP_UNDEFINED_TYPE             0x11
#define LDAP_INAPPROPRIATE_MATCHING     0x12
#define LDAP_CONSTRAINT_VIOLATION       0x13
#define LDAP_TYPE_OR_VALUE_EXISTS       0x14
#define LDAP_INVALID_SYNTAX             0x15

#define LDAP_NO_SUCH_OBJECT             0x20
#define LDAP_ALIAS_PROBLEM              0x21
#define LDAP_INVALID_DN_SYNTAX          0x22
#define LDAP_IS_LEAF                    0x23
#define LDAP_ALIAS_DEREF_PROBLEM        0x24


#define LDAP_INAPPROPRIATE_AUTH         0x30
#define LDAP_INVALID_CREDENTIALS        0x31
#define LDAP_INSUFFICIENT_ACCESS        0x32
#define LDAP_BUSY                       0x33
#define LDAP_UNAVAILABLE                0x34
#define LDAP_UNWILLING_TO_PERFORM       0x35
#define LDAP_LOOP_DETECT                0x36

#define LDAP_NAMING_VIOLATION           0x40
#define LDAP_OBJECT_CLASS_VIOLATION     0x41
#define LDAP_NOT_ALLOWED_ON_NONLEAF     0x42
#define LDAP_NOT_ALLOWED_ON_RDN         0x43
#define LDAP_ALREADY_EXISTS             0x44
#define LDAP_NO_OBJECT_CLASS_MODS       0x45
#define LDAP_RESULTS_TOO_LARGE          0x46
#define LDAP_AFFECTS_MULTIPLE_DSAS      0x47

#define LDAP_OTHER                      0x50
#define LDAP_SERVER_DOWN                0x51
#define LDAP_LOCAL_ERROR                0x52
#define LDAP_ENCODING_ERROR             0x53
#define LDAP_DECODING_ERROR             0x54
#define LDAP_TIMEOUT                    0x55
#define LDAP_AUTH_UNKNOWN               0x56
#define LDAP_FILTER_ERROR               0x57
#define LDAP_USER_CANCELLED             0x58
#define LDAP_PARAM_ERROR                0x59
#define LDAP_NO_MEMORY                  0x5a
#define LDAP_CONNECT_ERROR              0x5b

/* function prototypes for ldap library */
#ifndef LDAP_API
	#if defined( _WINDOWS ) || defined( _WIN32 )
		#if defined( _WIN32 )
			#define LDAP_API(rt) __declspec( dllexport ) rt
		#else
			#define LDAP_API(rt) rt
		#endif
	#else /* _WINDOWS */
		#define LDAP_API(rt) rt
	#endif /* _WINDOWS */
#endif /* LDAP_API */

// Only structure used by the CML from lber.h
struct berval {
	unsigned long	bv_len;
	char		*bv_val;
};

LDAP_API(LDAP *) LDAP_CALL ldap_open( const char *host, int port );
LDAP_API(LDAP *) LDAP_CALL ldap_init( const char *defhost, int defport );
LDAP_API(int) LDAP_CALL ldap_set_option( LDAP *ld, int option, void *optdata );
LDAP_API(int) LDAP_CALL ldap_unbind( LDAP *ld );
LDAP_API(int) LDAP_CALL ldap_abandon( LDAP *ld, int msgid );
LDAP_API(int) LDAP_CALL ldap_simple_bind( LDAP *ld, const char *who,
	const char *passwd );

LDAP_API(int) LDAP_CALL ldap_search( LDAP *ld, const char *base, int scope,
	const char *filter, char **attrs, int attrsonly );
LDAP_API(int) LDAP_CALL ldap_result( LDAP *ld, int msgid, int all,
	struct timeval *timeout, LDAPMessage **result );
LDAP_API(int) LDAP_CALL ldap_msgfree( LDAPMessage *lm );
LDAP_API(int) LDAP_CALL ldap_msgid( LDAPMessage *lm );
LDAP_API(int) LDAP_CALL ldap_msgtype( LDAPMessage *lm );
LDAP_API(int) LDAP_CALL ldap_result2error( LDAP *ld, LDAPMessage *r, 
	int freeit );
LDAP_API(LDAPMessage *) LDAP_CALL ldap_first_entry( LDAP *ld, 
	LDAPMessage *chain );
LDAP_API(LDAPMessage *) LDAP_CALL ldap_next_entry( LDAP *ld, 
	LDAPMessage *entry );
LDAP_API(int) LDAP_CALL ldap_count_entries( LDAP *ld, LDAPMessage *chain );
LDAP_API(char **) LDAP_CALL ldap_get_values( LDAP *ld, LDAPMessage *entry,
	const char *target );
LDAP_API(struct berval **) LDAP_CALL ldap_get_values_len( LDAP *ld,
	LDAPMessage *entry, const char *target );
LDAP_API(int) LDAP_CALL ldap_count_values( char **vals );
LDAP_API(int) LDAP_CALL ldap_count_values_len( struct berval **vals );
LDAP_API(void) LDAP_CALL ldap_value_free_len( struct berval **vals );

/*********************** end of unsupported functions ************************/

#ifdef __cplusplus
}
#endif
#endif /* _LDAP_H */
