                           SMP 2.3 Consolidated Release

	Welcome to the consolidated SMP workspace.  This workspace was created in response
	to customer demands to simplfy the process of building the SMP libraries. This workspace
	contains the SMIME Freeware Library, Certificate Management Library, and the Access Control
	Library.



REQUIRED SOFTWARE:
	To build the SMP libraries requires a number of other software packages to
        be preinstalled. Download and build any software packages you require according to their instructions,
	prior to building the SMP.  This section outlines the required software.

	Base System (libraries and tools):
		Windows: 
		  Microsoft Visual C/C++ 6.0
		  eSNACC v1.6 (earlier versions will not work)

		UNIX: 
		  Standard C/C++ compiler
		  GNU C/C++ Compiler 3.2 or later
		  GNU Configure
		  GNU Make
		  eSNACC v1.6 (earlier versions will not work)

	Optional Requirements (libraries and API's)
		Windows: Windows Threads
		UNIX: POSIX Threads
		LDAP API (The SMP has been tested with the OpenLDAP and the Netscape LDAP APIs)
			www.openldap.org
		RSA BSafe Crytologic library
		OpenSSL API
		Crypto++ API (Version 5.0)
			www.eskimo.com/~weidai/cryptlib.html
		Fortezza Cryptologic Library
		Microsoft CAPI - Only available under Microsoft Windows


TO BUILD SMP:
	Please see the INSTALL file for building instructions.

The following operating systems have been tested using this version of the
smp libraries:

Linux RedHat 7.1
Mandrake 8.2
Sun Solaris 5.8 Sparc
Microsoft Windows 95/98/NT/2000/XP

