# Microsoft Developer Studio Project File - Name="cryptlib_mod" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Static Library" 0x0104

CFG=cryptlib_mod - Win32 FIPS 140 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "cryptlib_mod.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "cryptlib_mod.mak" CFG="cryptlib_mod - Win32 FIPS 140 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "cryptlib_mod - Win32 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "cryptlib_mod - Win32 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE "cryptlib_mod - Win32 FIPS 140 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "cryptlib_mod - Win32 FIPS 140 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""$/cryptlib_mod", BAAAAAAA"
# PROP Scc_LocalPath "."
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "cryptlib_mod"
# PROP BASE Intermediate_Dir "cryptlib_mod"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "release"
# PROP Intermediate_Dir "release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MD /W3 /GX /Zi /O2 /D "NDEBUG" /D "WIN32" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /Yu"pch.h" /FD /Zm200 /c
# ADD BASE RSC /l 0x409
# ADD RSC /l 0x409
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"..\SMPDist\lib\cryptlib.lib"

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "cryptli0"
# PROP BASE Intermediate_Dir "cryptli0"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "debug"
# PROP Intermediate_Dir "debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /Z7 /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MDd /W3 /GX /ZI /Od /D "_DEBUG" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /D "WIN32" /D DSA_1024_BIT_MODULUS_ONLY=0 /Yu"pch.h" /FD /Zm200 /c
# ADD BASE RSC /l 0x409
# ADD RSC /l 0x409
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"..\SMPDist\lib\cryptlib_d.lib"

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "cryptlib_mod___Win32_FIPS_140_Release"
# PROP BASE Intermediate_Dir "cryptlib_mod___Win32_FIPS_140_Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "FIPS_140_Release"
# PROP Intermediate_Dir "FIPS_140_Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /G5 /Gz /MT /W3 /GX /Zi /O2 /D "NDEBUG" /D "WIN32" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /Yu"pch.h" /FD /c
# ADD CPP /nologo /G5 /Gz /MT /W3 /GX /Zi /O2 /D "NDEBUG" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /D "WIN32" /D CRYPTOPP_ENABLE_COMPLIANCE_WITH_FIPS_140_2=1 /Yu"pch.h" /Fd"FIPS_140_Release/cryptopp" /FD /c
# ADD BASE RSC /l 0x409
# ADD RSC /l 0x409
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"FIPS_140_Release\cryptopp.lib"

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "cryptlib_mod___Win32_FIPS_140_Debug"
# PROP BASE Intermediate_Dir "cryptlib_mod___Win32_FIPS_140_Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "FIPS_140_Debug"
# PROP Intermediate_Dir "FIPS_140_Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MTd /W3 /GX /ZI /Od /D "_DEBUG" /D "WIN32" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /Yu"pch.h" /FD /c
# ADD CPP /nologo /G5 /Gz /MDd /W3 /GX /ZI /Od /D "_DEBUG" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /D "WIN32" /D CRYPTOPP_ENABLE_COMPLIANCE_WITH_FIPS_140_2=1 /Yu"pch.h" /Fd"FIPS_140_Debug/cryptopp" /FD /c
# ADD BASE RSC /l 0x409
# ADD RSC /l 0x409
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"FIPS_140_Debug\cryptopp.lib"

!ENDIF 

# Begin Target

# Name "cryptlib_mod - Win32 Release"
# Name "cryptlib_mod - Win32 Debug"
# Name "cryptlib_mod - Win32 FIPS 140 Release"
# Name "cryptlib_mod - Win32 FIPS 140 Debug"
# Begin Group "Source Files"

# PROP Default_Filter ".cpp"
# Begin Source File

SOURCE=..\cryptopp50\3way.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\adler32.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\algebra.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\algparam.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\arc4.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\asn.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\base64.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\basecode.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\bench.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\bfinit.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\blowfish.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\blumshub.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\cast.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\casts.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\channels.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\crc.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\cryptlib.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\default.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\des.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\dessp.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\dh.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\dh2.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\diamond.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\diamondt.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\dsa.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\ec2n.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\eccrypto.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\ecp.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\elgamal.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\eprecomp.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\esign.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\files.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\filters.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\fips140.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\fipstest.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gf256.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gf2_32.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gf2n.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gfpcrypt.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gost.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gzip.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\haval.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\hex.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\hrtimer.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\ida.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\idea.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\integer.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\iterhash.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\luc.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\mars.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\marss.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\md2.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\md4.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\md5.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\md5mac.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\misc.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\modes.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\modexppc.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\mqueue.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\mqv.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\nbtheory.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\network.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\oaep.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\osrng.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\panama.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\pch.cpp
# ADD CPP /Yc"pch.h"
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\pkcspad.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\polynomi.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\pubkey.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\queue.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rabin.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\randpool.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rc2.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rc5.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rc6.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rdtables.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rijndael.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\ripemd.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rng.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rsa.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rw.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\safer.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\sapphire.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\seal.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\serpent.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\sha.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\shark.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\sharkbox.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\simple.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\skipjack.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\socketft.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\square.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\squaretb.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\strciphr.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\tea.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\tftables.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\tiger.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\tigertab.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\trdlocal.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\twofish.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\validat1.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\validat2.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\validat3.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\wait.cpp

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# PROP Exclude_From_Build 1

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# PROP Exclude_From_Build 1

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\wake.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\winpipes.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\xtr.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\xtrcrypt.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\zdeflate.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\zinflate.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\zlib.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter ".;.h"
# Begin Source File

SOURCE=..\cryptopp50\3way.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\3way.h
InputName=3way

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\3way.h
InputName=3way

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\3way.h
InputName=3way

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\3way.h
InputName=3way

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\adler32.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\adler32.h
InputName=adler32

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\adler32.h
InputName=adler32

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\adler32.h
InputName=adler32

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\adler32.h
InputName=adler32

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\aes.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\aes.h
InputName=aes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\aes.h
InputName=aes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\aes.h
InputName=aes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\aes.h
InputName=aes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\algebra.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\algebra.h
InputName=algebra

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\algebra.h
InputName=algebra

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\algebra.h
InputName=algebra

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\algebra.h
InputName=algebra

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\algparam.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\algparam.h
InputName=algparam

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\algparam.h
InputName=algparam

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\algparam.h
InputName=algparam

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\algparam.h
InputName=algparam

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\arc4.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\arc4.h
InputName=arc4

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\arc4.h
InputName=arc4

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\arc4.h
InputName=arc4

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\arc4.h
InputName=arc4

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\argnames.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\argnames.h
InputName=argnames

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\argnames.h
InputName=argnames

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\argnames.h
InputName=argnames

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\argnames.h
InputName=argnames

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\asn.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\asn.h
InputName=asn

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\asn.h
InputName=asn

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\asn.h
InputName=asn

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\asn.h
InputName=asn

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\base64.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\base64.h
InputName=base64

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\base64.h
InputName=base64

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\base64.h
InputName=base64

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\base64.h
InputName=base64

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\basecode.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\basecode.h
InputName=basecode

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\basecode.h
InputName=basecode

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\basecode.h
InputName=basecode

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\basecode.h
InputName=basecode

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\bench.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\bench.h
InputName=bench

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\bench.h
InputName=bench

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\bench.h
InputName=bench

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\bench.h
InputName=bench

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\blowfish.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\blowfish.h
InputName=blowfish

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\blowfish.h
InputName=blowfish

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\blowfish.h
InputName=blowfish

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\blowfish.h
InputName=blowfish

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\blumshub.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\blumshub.h
InputName=blumshub

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\blumshub.h
InputName=blumshub

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\blumshub.h
InputName=blumshub

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\blumshub.h
InputName=blumshub

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\cast.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\cast.h
InputName=cast

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\cast.h
InputName=cast

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\cast.h
InputName=cast

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\cast.h
InputName=cast

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\cbcmac.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\cbcmac.h
InputName=cbcmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\cbcmac.h
InputName=cbcmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\cbcmac.h
InputName=cbcmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\cbcmac.h
InputName=cbcmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\channels.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\channels.h
InputName=channels

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\channels.h
InputName=channels

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\channels.h
InputName=channels

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\channels.h
InputName=channels

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\config.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\config.h
InputName=config

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\config.h
InputName=config

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\config.h
InputName=config

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\config.h
InputName=config

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\crc.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\crc.h
InputName=crc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\crc.h
InputName=crc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\crc.h
InputName=crc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\crc.h
InputName=crc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\cryptlib.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\cryptlib.h
InputName=cryptlib

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\cryptlib.h
InputName=cryptlib

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\cryptlib.h
InputName=cryptlib

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\cryptlib.h
InputName=cryptlib

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\default.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\default.h
InputName=default

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\default.h
InputName=default

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\default.h
InputName=default

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\default.h
InputName=default

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\des.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\des.h
InputName=des

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\des.h
InputName=des

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\des.h
InputName=des

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\des.h
InputName=des

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\dh.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\dh.h
InputName=dh

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\dh.h
InputName=dh

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\dh.h
InputName=dh

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\dh.h
InputName=dh

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\dh2.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\dh2.h
InputName=dh2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\dh2.h
InputName=dh2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\dh2.h
InputName=dh2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\dh2.h
InputName=dh2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\diamond.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\diamond.h
InputName=diamond

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\diamond.h
InputName=diamond

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\diamond.h
InputName=diamond

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\diamond.h
InputName=diamond

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\dmac.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\dmac.h
InputName=dmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\dmac.h
InputName=dmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\dmac.h
InputName=dmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\dmac.h
InputName=dmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\dsa.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\dsa.h
InputName=dsa

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\dsa.h
InputName=dsa

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\dsa.h
InputName=dsa

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\dsa.h
InputName=dsa

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\ec2n.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\ec2n.h
InputName=ec2n

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\ec2n.h
InputName=ec2n

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\ec2n.h
InputName=ec2n

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\ec2n.h
InputName=ec2n

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\eccrypto.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\eccrypto.h
InputName=eccrypto

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\eccrypto.h
InputName=eccrypto

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\eccrypto.h
InputName=eccrypto

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\eccrypto.h
InputName=eccrypto

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\ecp.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\ecp.h
InputName=ecp

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\ecp.h
InputName=ecp

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\ecp.h
InputName=ecp

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\ecp.h
InputName=ecp

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\elgamal.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\elgamal.h
InputName=elgamal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\elgamal.h
InputName=elgamal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\elgamal.h
InputName=elgamal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\elgamal.h
InputName=elgamal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\eprecomp.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\eprecomp.h
InputName=eprecomp

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\eprecomp.h
InputName=eprecomp

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\eprecomp.h
InputName=eprecomp

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\eprecomp.h
InputName=eprecomp

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\esign.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\esign.h
InputName=esign

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\esign.h
InputName=esign

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\esign.h
InputName=esign

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\esign.h
InputName=esign

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\files.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\files.h
InputName=files

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\files.h
InputName=files

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\files.h
InputName=files

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\files.h
InputName=files

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\filters.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\filters.h
InputName=filters

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\filters.h
InputName=filters

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\filters.h
InputName=filters

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\filters.h
InputName=filters

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\fips140.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\fips140.h
InputName=fips140

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\fips140.h
InputName=fips140

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\fips140.h
InputName=fips140

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\fips140.h
InputName=fips140

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\fltrimpl.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\fltrimpl.h
InputName=fltrimpl

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\fltrimpl.h
InputName=fltrimpl

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\fltrimpl.h
InputName=fltrimpl

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\fltrimpl.h
InputName=fltrimpl

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gf256.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gf256.h
InputName=gf256

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gf256.h
InputName=gf256

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gf256.h
InputName=gf256

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gf256.h
InputName=gf256

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gf2_32.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gf2_32.h
InputName=gf2_32

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gf2_32.h
InputName=gf2_32

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gf2_32.h
InputName=gf2_32

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gf2_32.h
InputName=gf2_32

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gf2n.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gf2n.h
InputName=gf2n

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gf2n.h
InputName=gf2n

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gf2n.h
InputName=gf2n

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gf2n.h
InputName=gf2n

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gfpcrypt.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gfpcrypt.h
InputName=gfpcrypt

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gfpcrypt.h
InputName=gfpcrypt

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gfpcrypt.h
InputName=gfpcrypt

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gfpcrypt.h
InputName=gfpcrypt

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gost.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gost.h
InputName=gost

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gost.h
InputName=gost

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gost.h
InputName=gost

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gost.h
InputName=gost

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\gzip.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gzip.h
InputName=gzip

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gzip.h
InputName=gzip

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\gzip.h
InputName=gzip

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\gzip.h
InputName=gzip

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\haval.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\haval.h
InputName=haval

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\haval.h
InputName=haval

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\haval.h
InputName=haval

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\haval.h
InputName=haval

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\hex.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\hex.h
InputName=hex

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\hex.h
InputName=hex

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\hex.h
InputName=hex

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\hex.h
InputName=hex

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\hmac.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\hmac.h
InputName=hmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\hmac.h
InputName=hmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\hmac.h
InputName=hmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\hmac.h
InputName=hmac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\hrtimer.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\hrtimer.h
InputName=hrtimer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\hrtimer.h
InputName=hrtimer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\hrtimer.h
InputName=hrtimer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\hrtimer.h
InputName=hrtimer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\ida.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\ida.h
InputName=ida

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\ida.h
InputName=ida

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\ida.h
InputName=ida

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\ida.h
InputName=ida

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\idea.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\idea.h
InputName=idea

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\idea.h
InputName=idea

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\idea.h
InputName=idea

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\idea.h
InputName=idea

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\integer.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\integer.h
InputName=integer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\integer.h
InputName=integer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\integer.h
InputName=integer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\integer.h
InputName=integer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\iterhash.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\iterhash.h
InputName=iterhash

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\iterhash.h
InputName=iterhash

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\iterhash.h
InputName=iterhash

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\iterhash.h
InputName=iterhash

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\lubyrack.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\lubyrack.h
InputName=lubyrack

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\lubyrack.h
InputName=lubyrack

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\lubyrack.h
InputName=lubyrack

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\lubyrack.h
InputName=lubyrack

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\luc.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\luc.h
InputName=luc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\luc.h
InputName=luc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\luc.h
InputName=luc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\luc.h
InputName=luc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\mars.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\mars.h
InputName=mars

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\mars.h
InputName=mars

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\mars.h
InputName=mars

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\mars.h
InputName=mars

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\md2.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\md2.h
InputName=md2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\md2.h
InputName=md2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\md2.h
InputName=md2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\md2.h
InputName=md2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\md4.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\md4.h
InputName=md4

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\md4.h
InputName=md4

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\md4.h
InputName=md4

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\md4.h
InputName=md4

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\md5.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\md5.h
InputName=md5

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\md5.h
InputName=md5

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\md5.h
InputName=md5

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\md5.h
InputName=md5

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\md5mac.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\md5mac.h
InputName=md5mac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\md5mac.h
InputName=md5mac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\md5mac.h
InputName=md5mac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\md5mac.h
InputName=md5mac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\mdc.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\mdc.h
InputName=mdc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\mdc.h
InputName=mdc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\mdc.h
InputName=mdc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\mdc.h
InputName=mdc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\misc.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\misc.h
InputName=misc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\misc.h
InputName=misc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\misc.h
InputName=misc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\misc.h
InputName=misc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\modarith.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\modarith.h
InputName=modarith

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\modarith.h
InputName=modarith

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\modarith.h
InputName=modarith

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\modarith.h
InputName=modarith

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\modes.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\modes.h
InputName=modes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\modes.h
InputName=modes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\modes.h
InputName=modes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\modes.h
InputName=modes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\modexppc.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\modexppc.h
InputName=modexppc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\modexppc.h
InputName=modexppc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\modexppc.h
InputName=modexppc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\modexppc.h
InputName=modexppc

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\mqueue.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\mqueue.h
InputName=mqueue

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\mqueue.h
InputName=mqueue

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\mqueue.h
InputName=mqueue

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\mqueue.h
InputName=mqueue

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\mqv.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\mqv.h
InputName=mqv

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\mqv.h
InputName=mqv

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\mqv.h
InputName=mqv

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\mqv.h
InputName=mqv

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\nbtheory.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\nbtheory.h
InputName=nbtheory

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\nbtheory.h
InputName=nbtheory

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\nbtheory.h
InputName=nbtheory

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\nbtheory.h
InputName=nbtheory

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\network.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\network.h
InputName=network

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\network.h
InputName=network

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\network.h
InputName=network

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\network.h
InputName=network

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\nr.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\nr.h
InputName=nr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\nr.h
InputName=nr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\nr.h
InputName=nr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\nr.h
InputName=nr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\oaep.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\oaep.h
InputName=oaep

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\oaep.h
InputName=oaep

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\oaep.h
InputName=oaep

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\oaep.h
InputName=oaep

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\oids.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\oids.h
InputName=oids

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\oids.h
InputName=oids

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\oids.h
InputName=oids

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\oids.h
InputName=oids

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\osrng.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\osrng.h
InputName=osrng

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\osrng.h
InputName=osrng

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\osrng.h
InputName=osrng

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\osrng.h
InputName=osrng

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\panama.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\panama.h
InputName=panama

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\panama.h
InputName=panama

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\panama.h
InputName=panama

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\panama.h
InputName=panama

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\pch.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\pch.h
InputName=pch

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\pch.h
InputName=pch

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\pch.h
InputName=pch

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\pch.h
InputName=pch

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\pkcspad.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\pkcspad.h
InputName=pkcspad

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\pkcspad.h
InputName=pkcspad

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\pkcspad.h
InputName=pkcspad

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\pkcspad.h
InputName=pkcspad

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\polynomi.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\polynomi.h
InputName=polynomi

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\polynomi.h
InputName=polynomi

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\polynomi.h
InputName=polynomi

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\polynomi.h
InputName=polynomi

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\pssr.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\pssr.h
InputName=pssr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\pssr.h
InputName=pssr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\pssr.h
InputName=pssr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\pssr.h
InputName=pssr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\pubkey.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\pubkey.h
InputName=pubkey

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\pubkey.h
InputName=pubkey

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\pubkey.h
InputName=pubkey

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\pubkey.h
InputName=pubkey

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\pwdbased.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\pwdbased.h
InputName=pwdbased

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\pwdbased.h
InputName=pwdbased

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\pwdbased.h
InputName=pwdbased

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\pwdbased.h
InputName=pwdbased

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\queue.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\queue.h
InputName=queue

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\queue.h
InputName=queue

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\queue.h
InputName=queue

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\queue.h
InputName=queue

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rabin.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rabin.h
InputName=rabin

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rabin.h
InputName=rabin

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rabin.h
InputName=rabin

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rabin.h
InputName=rabin

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\randpool.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\randpool.h
InputName=randpool

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\randpool.h
InputName=randpool

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\randpool.h
InputName=randpool

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\randpool.h
InputName=randpool

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rc2.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rc2.h
InputName=rc2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rc2.h
InputName=rc2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rc2.h
InputName=rc2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rc2.h
InputName=rc2

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rc5.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rc5.h
InputName=rc5

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rc5.h
InputName=rc5

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rc5.h
InputName=rc5

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rc5.h
InputName=rc5

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rc6.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rc6.h
InputName=rc6

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rc6.h
InputName=rc6

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rc6.h
InputName=rc6

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rc6.h
InputName=rc6

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rijndael.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rijndael.h
InputName=rijndael

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rijndael.h
InputName=rijndael

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rijndael.h
InputName=rijndael

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rijndael.h
InputName=rijndael

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\ripemd.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\ripemd.h
InputName=ripemd

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\ripemd.h
InputName=ripemd

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\ripemd.h
InputName=ripemd

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\ripemd.h
InputName=ripemd

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rng.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rng.h
InputName=rng

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rng.h
InputName=rng

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rng.h
InputName=rng

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rng.h
InputName=rng

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rsa.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rsa.h
InputName=rsa

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rsa.h
InputName=rsa

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rsa.h
InputName=rsa

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rsa.h
InputName=rsa

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\rw.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rw.h
InputName=rw

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rw.h
InputName=rw

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\rw.h
InputName=rw

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\rw.h
InputName=rw

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\safer.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\safer.h
InputName=safer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\safer.h
InputName=safer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\safer.h
InputName=safer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\safer.h
InputName=safer

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\sapphire.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\sapphire.h
InputName=sapphire

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\sapphire.h
InputName=sapphire

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\sapphire.h
InputName=sapphire

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\sapphire.h
InputName=sapphire

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\seal.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\seal.h
InputName=seal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\seal.h
InputName=seal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\seal.h
InputName=seal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\seal.h
InputName=seal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\secblock.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\secblock.h
InputName=secblock

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\secblock.h
InputName=secblock

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\secblock.h
InputName=secblock

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\secblock.h
InputName=secblock

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\seckey.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\seckey.h
InputName=seckey

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\seckey.h
InputName=seckey

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\seckey.h
InputName=seckey

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\seckey.h
InputName=seckey

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\serpent.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\serpent.h
InputName=serpent

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\serpent.h
InputName=serpent

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\serpent.h
InputName=serpent

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\serpent.h
InputName=serpent

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\sha.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\sha.h
InputName=sha

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\sha.h
InputName=sha

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\sha.h
InputName=sha

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\sha.h
InputName=sha

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\shark.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\shark.h
InputName=shark

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\shark.h
InputName=shark

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\shark.h
InputName=shark

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\shark.h
InputName=shark

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\simple.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\simple.h
InputName=simple

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\simple.h
InputName=simple

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\simple.h
InputName=simple

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\simple.h
InputName=simple

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\skipjack.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\skipjack.h
InputName=skipjack

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\skipjack.h
InputName=skipjack

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\skipjack.h
InputName=skipjack

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\skipjack.h
InputName=skipjack

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\smartptr.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\smartptr.h
InputName=smartptr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\smartptr.h
InputName=smartptr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\smartptr.h
InputName=smartptr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\smartptr.h
InputName=smartptr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\socketft.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\socketft.h
InputName=socketft

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\socketft.h
InputName=socketft

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\socketft.h
InputName=socketft

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\socketft.h
InputName=socketft

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\square.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\square.h
InputName=square

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\square.h
InputName=square

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\square.h
InputName=square

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\square.h
InputName=square

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\strciphr.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\strciphr.h
InputName=strciphr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\strciphr.h
InputName=strciphr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\strciphr.h
InputName=strciphr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\strciphr.h
InputName=strciphr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\tea.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\tea.h
InputName=tea

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\tea.h
InputName=tea

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\tea.h
InputName=tea

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\tea.h
InputName=tea

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\tiger.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\tiger.h
InputName=tiger

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\tiger.h
InputName=tiger

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\tiger.h
InputName=tiger

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\tiger.h
InputName=tiger

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\trdlocal.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\trdlocal.h
InputName=trdlocal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\trdlocal.h
InputName=trdlocal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\trdlocal.h
InputName=trdlocal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\trdlocal.h
InputName=trdlocal

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\trunhash.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\trunhash.h
InputName=trunhash

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\trunhash.h
InputName=trunhash

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\trunhash.h
InputName=trunhash

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\trunhash.h
InputName=trunhash

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\twofish.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\twofish.h
InputName=twofish

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\twofish.h
InputName=twofish

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\twofish.h
InputName=twofish

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\twofish.h
InputName=twofish

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\validate.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\validate.h
InputName=validate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\validate.h
InputName=validate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\validate.h
InputName=validate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\validate.h
InputName=validate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\wait.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\wait.h
InputName=wait

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\wait.h
InputName=wait

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\wait.h
InputName=wait

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\wait.h
InputName=wait

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\wake.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\wake.h
InputName=wake

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\wake.h
InputName=wake

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\wake.h
InputName=wake

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\wake.h
InputName=wake

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\winpipes.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\winpipes.h
InputName=winpipes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\winpipes.h
InputName=winpipes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\winpipes.h
InputName=winpipes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\winpipes.h
InputName=winpipes

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\words.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\words.h
InputName=words

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\words.h
InputName=words

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\words.h
InputName=words

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\words.h
InputName=words

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\xormac.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\xormac.h
InputName=xormac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\xormac.h
InputName=xormac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\xormac.h
InputName=xormac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\xormac.h
InputName=xormac

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\xtr.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\xtr.h
InputName=xtr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\xtr.h
InputName=xtr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\xtr.h
InputName=xtr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\xtr.h
InputName=xtr

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\xtrcrypt.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\xtrcrypt.h
InputName=xtrcrypt

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\xtrcrypt.h
InputName=xtrcrypt

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\xtrcrypt.h
InputName=xtrcrypt

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\xtrcrypt.h
InputName=xtrcrypt

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\zdeflate.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\zdeflate.h
InputName=zdeflate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\zdeflate.h
InputName=zdeflate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\zdeflate.h
InputName=zdeflate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\zdeflate.h
InputName=zdeflate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\zinflate.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\zinflate.h
InputName=zinflate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\zinflate.h
InputName=zinflate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\zinflate.h
InputName=zinflate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\zinflate.h
InputName=zinflate

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp50\zlib.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
InputPath=..\cryptopp50\zlib.h
InputName=zlib

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\zlib.h
InputName=zlib

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
InputPath=..\cryptopp50\zlib.h
InputName=zlib

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
InputPath=..\cryptopp50\zlib.h
InputName=zlib

"..\SMPDist\Algs\crypto++\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	echo $(InputPath)   $(InputName) 
	copy $(InputPath)   "..\SMPDist\Algs\crypto++" 
	
# End Custom Build

!ENDIF 

# End Source File
# End Group
# Begin Group "Miscellaneous"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\cryptopp50\Doxyfile
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\GNUmakefile
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\License.txt
# End Source File
# Begin Source File

SOURCE=..\cryptopp50\Readme.txt
# End Source File
# End Group
# End Target
# End Project
