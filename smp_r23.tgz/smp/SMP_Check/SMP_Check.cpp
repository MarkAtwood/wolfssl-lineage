// SMP_Check.cpp
//

//RWC; IF free3 CTIl is available, perform full test, otherwise 
//RWC;   comment next line out.
#define SM_FREE3_TEST

#include "sm_api.h"
#include "sm_AppLogin.h"
#include "sm_CM_AC_Support.h"   // LOCAL test include file.

using namespace SFL;
using namespace CERT;
using namespace CTIL;
using namespace SNACC;

#include <stdio.h>
#include "string.h"

extern "C" {
long DLLBuildTokenInterface(CTIL::CSM_CtilMgr &, char *);
}

void    checkCreate(CSMIME *pAppLogin, 
                       char *pszCertificateFileNamesForEncrypters[], 
                       const char *msgData, long msgLength, AsnOid *pmsgOid,
                       CSM_Buffer *pACLMsgLabel=NULL, acl::Session *pACLsession=NULL,
                       long lCMLSessionIdIN=0, long lSRLSessionIdIN=0);
void    checkRead(CSMIME *pAppLogin, 
                  const char *msgData=NULL, long msgLength=0, acl::Session *pACLsession=NULL,
                  long lCMLSessionIdIN=0, long lSRLSessionIdIN=0);
long SMP_Check_SetupCMLSession(CSMIME &CsmimeInstance, 
         CM_INADEQUATE_InitInterface *&pCML_Inadequate_Interface);
long SMP_Check_SetupACLSession(CSMIME &CsmimeInstance, const long lCmlSessionId, 
                               AC_INADEQUATE_InitInterface *&pACL_Inadequate_Interface);// RETURNED


/*#ifdef RWC_REMOVE_SINCE_INTEGRATED
long SMP_Check_ACLOutgoingRecip(acl::Session &ACLsession, char *pszCertificateFileNamesForEncrypters[],
                        CSM_Buffer &ACLMsgLabel);
long SMP_Check_ACLIncommingRecip(acl::Session &ACLsession, char *pszCertificateFileNamesForEncrypters[],
                                 CSM_Buffer &ACLMsgLabel, acl::SPIF *&pspif);
long SMP_Check_ACLIncommingOrig(acl::Session &ACLsession, char *pszOrigCertificateFileName,
                        CSM_Buffer &ACLMsgLabel, 
                        acl::SPIF &spif);// IN, MUST be same SPIF used for 
                                    // checking INCOMMING Recip (ourselves).
#endif  // RWC_REMOVE_SINCE_INTEGRATED*/

int main(int argc, char* argv[])
{
    long msgLength=0;
    char *lpszError=NULL;
    AsnOid *pmsgOid=NULL;
    CSM_AppLogin *pAppLogin=NULL;
    const char *msgData=NULL;
    char *pszCertificateFileNamesForEncrypters[]={
       "./Test1@Test1.sig", 
       ""};                            // NULL terminate array of data.
#ifdef _DEBUG
	#ifdef _UNIX
   		char *pCTILFree3="libsm_free3DLL_d";
	#else
   		char *pCTILFree3="sm_free3DLLd";
	#endif
#else
	#ifdef _UNIX
   		char *pCTILFree3="libsm_free3DLL";
	#else
   		char *pCTILFree3="sm_free3DLL";
	#endif
#endif
   CSM_Buffer EncapContentBuf;
   CM_INADEQUATE_InitInterface *pCML_Inadequate_Interface=NULL; // MINIMAL sessions
                           // NOTE:actual application should properly setup the 
                           //  CML/SRL/sessions, not use this class!!!!
   AC_INADEQUATE_InitInterface *pACL_Inadequate_Interface=NULL;
   CSM_Buffer ACLMsgLabel("./LABEL_ClearanceVersion.lbl");
   //CSM_Buffer *pACLMsgLabelIN=NULL;
   acl::SPIF *pRecipSpif=NULL;
   long lstatus;

   SME_SETUP ("main")

#ifndef _DEBUG
#ifdef _WIN32
   char *pCTILFree3="sm_free3DLL";
#else
   char *pCTILFree3="libsm_free3DLL";
#endif		// _WIN32
#else
#ifdef _WIN32
   char *pCTILFree3="sm_free3DLLd";
#else
   char *pCTILFree3="libsm_free3DLL_d";
#endif          // _WIN32
#endif      //DEBUG

     ////////////////////////////////////////////////////////////////
     // SETUP login details.
     pAppLogin = new CSM_AppLogin;
     // FOR THE FOLLOWING AddLogin(...) calls, the DLL file can be in the 
     //  PATH, where you could simply specify "sm_fere3DLLd"
#ifdef ENABLE_STATIC
	  DLLBuildTokenInterface(*pAppLogin, "sm_free3DLL ./Test1@Test1X_12.pfx password");
#elif defined (SM_FREE3_TEST)
     pAppLogin->AddLogin(pCTILFree3, "sm_free3DLL ./Test1@Test1X_12.pfx password");
     //pAppLogin->AddLogin(pCTILFree3, "sm_free3DLL ./AlicePrivRSASign.pri_12.pfx password");
     //pAppLogin->AddLogin(pCTILFree3, "sm_free3DLL ./DianePrivRSASignEncrypt.pri_12.pfx password");
#else
     //RWC;TBD; Create default login only for verification only and indicate such!
#endif      // SM_FREE3_TEST
   ////////////////////////////////////////////////////////////////
   // SETUP CML AND ACL input session details, MINIMAL!.
     lstatus = SMP_Check_SetupCMLSession(*pAppLogin, pCML_Inadequate_Interface);
     if (lstatus != 0)
     {
         std::cout << "error on SMP_Check_SetupCMLSession: lstatus=" << lstatus <<  "\n";
     }

     lstatus = SMP_Check_SetupACLSession(*pAppLogin, 
                                    pCML_Inadequate_Interface->m_lCmlSessionId,
                                    pACL_Inadequate_Interface);
     if (lstatus != 0)
     {
         std::cout << "error on SMP_Check_SetupACLSession: lstatus=" << lstatus << "\n";
         if (pACL_Inadequate_Interface->m_szError)
             std::cout << pACL_Inadequate_Interface->m_szError << "\n";
     }


#ifdef RWC_REMOVE_SINCE_INTEGRATED
   ////////////////////////////////////////////////////////////////
   // PERFORM ACL validation.
     lstatus = SMP_Check_ACLOutgoingRecip(*pACL_Inadequate_Interface->m_pAclSessionId, pszCertificateFileNamesForEncrypters,
                        ACLMsgLabel);
     if (lstatus == 0)
         std::cout << "SMP_Check_ACLOutgoingRecip: successful ACL validation with SPIF!\n";
#endif  // RWC_REMOVE_SINCE_INTEGRATED

   ////////////////////////////////////////////////////////////////
   // PERFORM creation, sign and encrypt.

   checkCreate(pAppLogin, pszCertificateFileNamesForEncrypters, 
      msgData, msgLength, pmsgOid, &ACLMsgLabel, 
      pACL_Inadequate_Interface->m_pAclSessionId,
      pCML_Inadequate_Interface->m_lCmlSessionId, 
      pCML_Inadequate_Interface->m_lSrlSessionId);

   ////////////////////////////////////////////////////////////////
   // CLEANUP.

   delete pCML_Inadequate_Interface;
   delete pACL_Inadequate_Interface;
   if (pAppLogin)
   {
       delete pAppLogin;
       pAppLogin = NULL;
   }
   pCML_Inadequate_Interface = NULL;
   pACL_Inadequate_Interface = NULL;
   std::cout.flush();

   
   //#############################################
   // SETUP login details for UNWRAP operation.
   pAppLogin = new CSM_AppLogin;
#ifdef ENABLE_STATIC
   DLLBuildTokenInterface(*pAppLogin, 
		"sm_free3DLL ./Test1@Test1X_12.pfx password");
#else
   pAppLogin->AddLogin(pCTILFree3, "sm_free3DLL ./Test1@Test1X_12.pfx password");
#endif
   //pAppLogin->AddLogin(pCTILFree3, "sm_free3DLL ./DianePrivRSASignEncrypt.pri_12.pfx password");
   // MUST re-load CML/SRL sessions, since logins were deleted!
   lstatus = SMP_Check_SetupCMLSession(*pAppLogin, pCML_Inadequate_Interface);
   lstatus = SMP_Check_SetupACLSession(*pAppLogin, 
                                    pCML_Inadequate_Interface->m_lCmlSessionId,
                                    pACL_Inadequate_Interface);

////////////////////////////////////////////////////////////////
   // PERFORM read, dedcrypt and verify.

   checkRead(pAppLogin, NULL, 0, 
      pACL_Inadequate_Interface->m_pAclSessionId,
      pCML_Inadequate_Interface->m_lCmlSessionId, 
      pCML_Inadequate_Interface->m_lSrlSessionId);

#ifdef RWC_REMOVE_SINCE_INTEGRATED
   if (pACLMsgLabelIN)      // ONLY perform ACL checks if we have an incomming 
                            //  label.
   {
       ////////////////////////////////////////////////////////////////
       // PERFORM ACL validation checks.  NORMALLY, this would be done before 
       //   decryption and verification of the signature, but for convenience we
       //   perform this operation after decryption/verification.  This program
       //   just checks that the SMP libraries behave.
       lstatus = SMP_Check_ACLIncommingRecip(*pACLsession, pszCertificateFileNamesForEncrypters,
                            *pACLMsgLabelIN, pRecipSpif);
       if (lstatus == 0)
          std::cout << "SMP_Check_ACLIncommingRecip: successful ACL validation with SPIF!\n";
       if (pRecipSpif == NULL)      // RWC; MUST have a SPIF, so if not loaded by 
       {                            // RWC;  SMP_Check_ACLIncommingRecip(...), then
                                    // RWC;  load hard-coded name.
           CSM_Buffer encodedSPIF("./tsp1pif1.spf");
           pRecipSpif = new acl::SPIF(encodedSPIF);
           std::cout << "                           : SPIF not provided by SMP_Check_ACLIncommingRecip(...); hard-coded!\n";
       }        // END pRecipSpif empty
       lstatus = SMP_Check_ACLIncommingOrig(*pACLsession, "./Test1@Test1.sig",
                            *pACLMsgLabelIN, *pRecipSpif);
       if (lstatus == 0)
          std::cout << "SMP_Check_ACLIncommingOrig: successful ACL validation with SPIF!\n";
   }        // END IF pACLMsgLabelIN.
#endif  // RWC_REMOVE_SINCE_INTEGRATED

   ////////////////////////////////////////////////////////////////
   // CLEANUP.
   delete pCML_Inadequate_Interface;
   delete pACL_Inadequate_Interface;
   if (pAppLogin)
   {
       delete pAppLogin;
       pAppLogin = NULL;
   }
   if (pRecipSpif)
       delete pRecipSpif;

   SME_FINISH
   SME_CATCH_SETUP
      Exception.getCallStack(std::cout);
      //RWC;NOTE; DO NOT DELETE pAppLogin inside this exception handler
      //RWC; in case exception thrown from a dynamically loaded CTIL.
   SME_CATCH_FINISH_C2(lpszError);

   if (lpszError)
   {
      std::cout << lpszError << "\n";
      std::cout.flush();
      free(lpszError);
   }

   if (pAppLogin)
   {
       delete pAppLogin;
       pAppLogin = NULL;
   }

   return(0);
}

//
//
long SMP_Check_SetupCMLSession(CSMIME &CsmimeInstance, 
         CM_INADEQUATE_InitInterface *&pCML_Inadequate_Interface)
{
      long lstatus = 0;
      CM_Interface CMLInterface; // Declare CML/SRL operations support class.
      CSM_BufferLst BufTrustedCertLst;

      SME_SETUP ("SMP_Check_SetupCMLSession")

      CSM_Buffer *pBufTrustedCert = BufTrustedCertLst.Append();

      pBufTrustedCert->SetFileName("./nistCARoot@nist.gov.sig");
      pCML_Inadequate_Interface = new CM_INADEQUATE_InitInterface;
      if ((lstatus = pCML_Inadequate_Interface->initializeSessions(NULL, NULL, 
                       BufTrustedCertLst, &CsmimeInstance)) != 0)
      {
         SME_THROW(lstatus, "Unable to create CM/SRL session!", NULL);
      }
      CMLInterface.setCMLSessions(pCML_Inadequate_Interface->m_lCmlSessionId, 
                                  pCML_Inadequate_Interface->m_lSrlSessionId);
      CSM_Buffer BufCRL("./RootTestNistCrl.out");
      CMLInterface.dbAddCRL(BufCRL);
      //OPTIONAL;CSM_Buffer BufCert("./CAFile_NOT_NOW");
      //OPTIONAL;CMLInterface.dbAddCert(BufCert);

      SME_FINISH_CATCH

      return(lstatus);
}     // END SMP_Check_SetupCMLSession(...)


//
//
using namespace acl;
long SMP_Check_SetupACLSession(CSMIME &CsmimeInstance, const long lCmlSessionId, 
                               AC_INADEQUATE_InitInterface *&pACL_Inadequate_Interface)   // RETURNED
{
   long lstatus = 0;
                            // WE DO NOT PASS in an existing ACL session here.
   CTIL::CSM_BufferLst TrustedSPIFBufLst;
   CTIL::CSM_BufferLst TrustedCertsBufLst;
   acl::TrustList TrustList;


   pACL_Inadequate_Interface = new AC_INADEQUATE_InitInterface(CsmimeInstance, lCmlSessionId);
   // SETUP SPIFs
   CSM_Buffer *pBuf = TrustedSPIFBufLst.Append();
   pBuf->SetFileName("./tsp1pif1.spf");
   // SETUP trusted certs
   pBuf = TrustedCertsBufLst.Append();
   pBuf->SetFileName("./Test1@Test1.sig");
   // SETUP trust list (OID and DN)
   AsnOid TmpPolicyId("2.16.840.1.101.2.1.12.0.1");
   char *pTmpDNPtr="emailAddress=test1@test1,CN=Test1 MultiClear Unclassified User,OU=Annapolis Junction,O=Getronics,C=US";
   CML::ASN::DN TmpDN(pTmpDNPtr);//*pSNACCName);
   acl::Trust *pTrust = TrustList.Append();
   pTrust->setOID(TmpPolicyId);
   pTrust->setDN(TmpDN);
   pTmpDNPtr="emailAddress=nistCARoot@nist.gov,CN=Nist Test DSA ROOT,OU=NIST,O=US Government,C=US";
   CML::ASN::DN TmpDN2(pTmpDNPtr);//*pSNACCName);
   pTrust = TrustList.Append();
   pTrust->setOID(TmpPolicyId);
   pTrust->setDN(TmpDN2);

   lstatus = pACL_Inadequate_Interface->initializeSessions(&TrustedSPIFBufLst,
        &TrustedCertsBufLst, &TrustList);

   /*FUNC("SMP_Check_SetupACLSession(...)");
   try
   {
      if (pACLsession == NULL)
         pACLsession = new acl::Session;

      CSM_Buffer spifBuf("./tsp1pif1.spf");//"tsp1apif1.spf");
      pACLsession->addSPIF(spifBuf);
      CSM_Buffer CCBuf("./Test1@Test1.sig");
      pACLsession->addCC(CCBuf);
      //
      pACLsession->m_acTTL = 24;
      pACLsession->m_spifTTL = 56;
      pACLsession->m_dms_mode = false;//TMP;true;

      //
      pACLsession->enableCML(lCmlSessionId);
      pACLsession->enableSPIFSignerAttribute(false);//TMP;true);
      pACLsession->disableValidation(false);
      pACLsession->disableTrustList(false);

      // LOAD ACL trust elements.
      AsnOid TmpPolicyId("2.16.840.1.101.2.1.12.0.1");
      SNACC::Name *pSNACCName=NULL;
      char *pTmpDNPtr="emailAddress=test1@test1,CN=Test1 MultiClear Unclassified User,OU=Annapolis Junction,O=Getronics,C=US";
      //str2dn(pTmpDNPtr, pSNACCName);
      CML::ASN::DN TmpDN(pTmpDNPtr);//*pSNACCName);
      lstatus = pACLsession->addTrust(TmpDN, TmpPolicyId);
      delete pSNACCName;
      pSNACCName = NULL;
      pTmpDNPtr="emailAddress=nistCARoot@nist.gov,CN=Nist Test DSA ROOT,OU=NIST,O=US Government,C=US";
      //str2dn(pTmpDNPtr, pSNACCName);
      CML::ASN::DN TmpDN2(pTmpDNPtr);//*pSNACCName);
      lstatus = pACLsession->addTrust(TmpDN2, TmpPolicyId);
      delete pSNACCName;

      //
   }
   catch (SnaccException &e)
   {
      std::cout << "SMP_Check_SetupACLSession: errorCode=" << e.errorCode << "\n";// .push(STACK_ENTRY);
      std::cout << "     error=" << e.what() << "\n";
      std::cout.flush();
      //throw;
   }*/


   return(lstatus);
}     // END SMP_Check_SetupACLSession(...)


//#################################################################################
// RWC; NOT USED; RWC_REMOVE_SINCE_INTEGRATED
#ifdef RWC_REMOVE_SINCE_INTEGRATED
//
//
long SMP_Check_ACLOutgoingRecip(Session &ACLsession, char *pszCertificateFileNamesForEncrypters[],
                        CSM_Buffer &ACLMsgLabel)
{
   long lstatus = 0;
   ACL_Interface ACLInterface(ACLsession);
   //RecipientCert *pTmpRC = NULL;
   CSM_Buffer *pbufCert;
   //SecurityLabel *pLabel=NULL;
   AsnOid usedPolicy;
   //OutgoingLabel *pTmpLabel=NULL;
   CTIL::CSM_BufferLst BufLst;
   //SPIF spif;

         //pLabel = new SecurityLabel(ACLMsgLabel);
         //pTmpLabel = new OutgoingLabel(*pLabel);
         pbufCert = BufLst.Append();
         pbufCert->SetFileName("./nistCARoot@nist.gov.sig");  //RWC;COULD NOT GET ACL TO READ CML ISSUER!

         char *ptr = pszCertificateFileNamesForEncrypters[0];
         for (int ii=1; ptr != NULL && strlen(ptr) > 0 && lstatus == 0; ii++)
         {
            pbufCert = new CSM_Buffer(ptr);  //Create buffer with file contents.
            lstatus = ACLInterface.Check_ACLOutgoingRecip(*pbufCert, ACLMsgLabel,
                usedPolicy, &BufLst);
            /*pTmpRC = new RecipientCert(*pbufCert);
            pTmpRC->intersect(&ACLsession, &BufLst);

            // FOR this recipient, check the label against its Clearance Extension
            pTmpRC->check(&ACLsession, *pTmpLabel, usedPolicy, NULL/*&spif*);*/

            delete pbufCert;
            pbufCert = NULL;
            //if (pTmpRC != NULL)
            //   delete pTmpRC;
            ptr = pszCertificateFileNamesForEncrypters[ii]; // GET next cert file name.
         }     // END for each recipient certificate file to load.

         /*if (pLabel)
            delete pLabel;
         if (pTmpLabel)
            delete pTmpLabel;*/
         if (lstatus != 0)      // REPORT ERROR
         {
              std::cout << "SMP_Check_ACLOutgoingRecip: ";
              if (ACLInterface.m_lpszError)
                  std::cout << ACLInterface.m_lpszError;
              std::cout << "\n";
              std::cout.flush();
         }      // END IF lstatus


   return(lstatus);
}     // END SMP_Check_ACLOutgoingRecip(...)

//
//
long SMP_Check_ACLIncommingRecip(Session &ACLsession, char *pszCertificateFileNamesForEncrypters[],
                        CSM_Buffer &ACLMsgLabel, SPIF *&pspif)
{
   long lstatus = 0;
   ACL_Interface ACLInterface(ACLsession);
   //RecipientCert *pTmpRC = NULL;
   CSM_Buffer *pbufCert;
   //SecurityLabel *pLabel=NULL;
   SecurityLabel *pEquivLabel=NULL;
   //IncomingLabel *pTmpLabel=NULL;
   CTIL::CSM_BufferLst BufLst;

         //pLabel = new SecurityLabel(ACLMsgLabel);
         //pTmpLabel = new IncomingLabel(*pLabel);
         pbufCert = BufLst.Append();
         pbufCert->SetFileName("./nistCARoot@nist.gov.sig");  //RWC;COULD NOT GET ACL TO READ CML ISSUER!

         char *ptr = pszCertificateFileNamesForEncrypters[0];
         for (int ii=1; ptr != NULL && strlen(ptr) > 0 && lstatus == 0; ii++)
         {
            pbufCert = new CSM_Buffer(ptr);  //Create buffer with file contents.
            //pTmpRC = new RecipientCert(*pbufCert);
            lstatus = ACLInterface.Check_ACLIncommingRecip(*pbufCert, 
                ACLMsgLabel, pspif, pEquivLabel, &BufLst);
            //pTmpRC->intersect(&ACLsession, &BufLst);

            // FOR this recipient, check the label against its Clearance Extension
            //pspif = new SPIF;
            //pTmpRC->check(&ACLsession, *pTmpLabel, pspif, pEquivLabel);

            delete pbufCert;
            pbufCert = NULL;
            //if (pTmpRC != NULL)
            //   delete pTmpRC;
            if (pEquivLabel)
                delete pEquivLabel;
            ptr = pszCertificateFileNamesForEncrypters[ii]; // GET next cert file name.
         }     // END for each recipient certificate file to load.

         //if (pLabel)
         //   delete pLabel;
         //if (pTmpLabel)
         //   delete pTmpLabel;
         if (lstatus != 0)      // REPORT ERROR
         {
              std::cout << "SMP_Check_ACLIncommingRecip: ";
              if (ACLInterface.m_lpszError)
                  std::cout << ACLInterface.m_lpszError;
              std::cout << "\n";
              std::cout.flush();
         }      // END IF lstatus


   return(lstatus);
}     // END SMP_Check_ACLIncommingRecip(...)

//
//  This routine acts like a recipient, checking his own certificate and extensions.
//  The incomming label is checked.
long SMP_Check_ACLIncommingOrig(Session &ACLsession, char *pszOrigCertificateFileName,
                        CSM_Buffer &ACLMsgLabel, 
                        SPIF &spif) // IN, MUST be same SPIF used for 
                                    // checking INCOMMING Recip (ourselves).
{
   long lstatus = 0;
   ACL_Interface ACLInterface(ACLsession);
   //OriginatorCert  *pTmpOC = NULL;
   CSM_Buffer *pbufCert;
   //SecurityLabel *pLabel=NULL;
   AsnOid usedPolicy;
   //IncomingLabel *pTmpLabel=NULL;
   CTIL::CSM_BufferLst BufLst;

         //pLabel = new SecurityLabel(ACLMsgLabel);
         //pTmpLabel = new IncomingLabel(*pLabel);
         pbufCert = BufLst.Append();
         pbufCert->SetFileName("./nistCARoot@nist.gov.sig");  //RWC;COULD NOT GET ACL TO READ CML ISSUER!

            pbufCert = new CSM_Buffer(pszOrigCertificateFileName);  //Create buffer with file contents.
            lstatus = ACLInterface.Check_ACLIncommingOrig(*pbufCert, 
                      ACLMsgLabel, spif, usedPolicy, &BufLst);

            //pTmpOC = new OriginatorCert(*pbufCert);
            //pTmpOC->intersect(&ACLsession, &BufLst);
            // FOR this recipient, check the label against its Clearance Extension
            //pTmpOC->check(&ACLsession, *pTmpLabel, spif);

            delete pbufCert;
            pbufCert = NULL;
            //if (pTmpOC != NULL)
            //   delete pTmpOC;

         /*if (pLabel)
            delete pLabel;
         if (pTmpLabel)
            delete pTmpLabel;*/
         if (lstatus != 0)      // REPORT ERROR
         {
              std::cout << "SMP_Check_ACLIncommingOrig: ";
              if (ACLInterface.m_lpszError)
                  std::cout << ACLInterface.m_lpszError;
              std::cout << "\n";
              std::cout.flush();
         }      // END IF lstatus


   return(lstatus);
}     // END SMP_Check_ACLIncommingOrig(...)
#endif //RWC_REMOVE_SINCE_INTEGRATED

// EOF SMP_Check.cpp

