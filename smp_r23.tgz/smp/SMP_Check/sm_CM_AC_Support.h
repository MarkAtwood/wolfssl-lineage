
//
// sm_CM_AC_Support.h
// This utility include file provides the CML and ACL support classes to setup
//  minimal sessions.

#ifndef _SM_CM_AC_SUPPORT_H_
#define _SM_CM_AC_SUPPORT_H_

#ifdef CML_USED
//
//
//########################################################################
//  THIS SPECIAL CLASS is labelled as "INADEQUATE" to indicate that it is up to 
//  the user to properly initialize the CML session for the appropriate security 
//  policies.  WITHOUT PROPER SETUP, VALIDATION MAY RETURN INVALID RESULTS!!!
//  (see the CML API document for details).  This class is provided as a 
//  convenient test initialization, but labelled to warn users it is inadequate
//  for a proper security-minded application setup.  See the CML user's manual.
//  It does provide a demonstration of the minimum necessary to setup a CML 
//  session.
class CM_INADEQUATE_InitInterface
{
private:
   static InitSettings_struct structGLOBALtool_settings;    
                                       // RETAINED for cleanup AND
                                       // for verify requirement where it may
                                       // be necessary to add a trusted root
                                       // for a specific user entry.
   void FreeSRLInitSettings (SRL_InitSettings_struct *settings);

public:
   CM_INADEQUATE_InitInterface();
   ~CM_INADEQUATE_InitInterface();

   short initializeSessions(char *pLdapServer, char *pLdapPort, 
       CTIL::CSM_BufferLst &TrustedCertsBufLst,/*EncCert_LL *pTrustedCerts*/
       void *pCsmime=NULL);
   short createSrlSession(char *pLdapServer, char *pLdapPort);  // returns 0 if successful
   short createCmlSession(EncCert_LL *pTrustedCerts);  // returns 0 if successful
   void  destroySrlSession(unsigned long *pSrlSessionId);  // returns 0 if successful
   void  destroyCmlSession(unsigned long *pCmlSessionId);  // returns 0 if successful
   EncCert_LL *getTrustedCerts() { return structGLOBALtool_settings.trustedCerts; }
   //short setPolicy();  // TBD returns 0 if successful
   bool usingCML() { return (m_lCmlSessionId != 0); }

   unsigned long   m_lSrlSessionId;
   unsigned long   m_lCmlSessionId;
   void            *m_pCtilMgr;
};

#endif  // CML_USED

#ifdef ACL_USED
//
//
//########################################################################
//  THIS SPECIAL CLASS is labelled as "INADEQUATE" to indicate that it is up to 
//  the user to properly initialize the ACL session for the appropriate security.
//  WITHOUT PROPER SETUP, VALIDATION MAY RETURN INVALID RESULTS!!!
//  (see the ACL API document for details).  This class is provided as a 
//  convenient test initialization, but labelled to warn users it is inadequate
//  for a proper security-minded application setup.  See the ACL user's manual.
//  It does provide a demonstration of the minimum necessary to setup a ACL 
//  session.
class AC_INADEQUATE_InitInterface
{
private:
    CERT::CSMIME  *m_pCsmime;         // NEVER delete, always use application pointer.
   long    m_lCmlSessionId;    // OPTIONAL pointer to CML session, if active.
   bool    m_bInitAclSessionHere;
public:
   AC_INADEQUATE_InitInterface() { m_pAclSessionId = NULL; m_pCsmime = NULL; 
                                   m_lCmlSessionId = 0; m_szError = NULL;
                                   m_bInitAclSessionHere = false; }
   AC_INADEQUATE_InitInterface(CERT::CSMIME &Csmime, long lCmlSessionId=0, 
                               acl::Session *pAclSession=NULL)
   { m_pCsmime = &Csmime; m_lCmlSessionId = lCmlSessionId; 
     m_pAclSessionId = pAclSession; m_szError = NULL; }
   ~AC_INADEQUATE_InitInterface() 
   { if (m_szError) free(m_szError); 
     if (m_bInitAclSessionHere && m_pAclSessionId) delete m_pAclSessionId; }
                        // DO NOT DESTROY m_pCsmime NOR m_pAclSessionId.

   long initializeSessions(
       CTIL::CSM_BufferLst *pTrustedSPIFBufLst=NULL,     // OPTIONAL setup.
       CTIL::CSM_BufferLst *pTrustedCertsBufLst=NULL,    // OPTIONAL setup.
       acl::TrustList *pTrustList=NULL);    // OPTIONAL setup.
   void  destroyAclSession() { if (m_pAclSessionId) 
                                { delete m_pAclSessionId; m_pAclSessionId = NULL; } }
                            // THIS call is explicit, since it may not always
                            //  be destroyed on class instance destruction.
   void  setAclSession(const acl::Session &AclSession) { m_pAclSessionId = 
                                               (acl::Session *)&AclSession; }

   // This member variable is directly accessible by the user for custom 
   //  modifications to the ACL session.  There are too many detail to attempt
   //  to create another wrapper for all possible permutations.
   acl::Session *m_pAclSessionId;
   char *m_szError;     // ACL error string returned to user, if present.
};

#endif  // ACL_USED

#endif  //_SM_CM_AC_SUPPORT_H_


// sm_CM_AC_Support.h

