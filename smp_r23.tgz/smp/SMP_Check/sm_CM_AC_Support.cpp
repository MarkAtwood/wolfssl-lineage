
// sm_CM_AC_Support.cpp
// This utility include file provides the CML and ACL support classes to setup
//  minimal sessions.

#include "sm_api.h"
#include "sm_CM_AC_Support.h"

#ifdef CML_USED

InitSettings_struct CM_INADEQUATE_InitInterface::structGLOBALtool_settings;
#define CM_Calloc calloc
#define CM_Free free

using namespace SFL;


///////////////////////////////////////////////////////////////////////////////
CM_INADEQUATE_InitInterface::CM_INADEQUATE_InitInterface()
{
   m_lSrlSessionId = 0;
   m_lCmlSessionId = 0;
   m_pCtilMgr = NULL;
   memset(&structGLOBALtool_settings, '\0', sizeof(structGLOBALtool_settings));

}       // END CM_INADEQUATE_InitInterface::CM_INADEQUATE_InitInterface()

///////////////////////////////////////////////////////////////////////////////
CM_INADEQUATE_InitInterface::~CM_INADEQUATE_InitInterface() 
{

   //RWC; cleanup structGLOBALtool_settings.
   CM_FreeEncCertList(
#ifdef USE_CML_R201
      m_lSrlSessionId, 
#endif //USE_CML_R201
      &structGLOBALtool_settings.trustedCerts);   //RWC;added.

   if (m_lSrlSessionId != 0)
    {
        SRL_DestroySession(&m_lSrlSessionId);
      m_lSrlSessionId = 0;
    }

   if (m_lCmlSessionId != 0)
    {
        CM_DestroySession(&m_lCmlSessionId);
      m_lCmlSessionId = 0;
    }
}       // END CM_INADEQUATE_InitInterface::~CM_INADEQUATE_InitInterface() 

////////////////////////////////////////////////////////////////////////////////////////////////
//
// createSrlSession 
//
//   Creates an srl session.  m_lSrlSessionId is assigned the srl session id.
//   If input parameters are NULL then ldap is not used
//
////////////////////////////////////////////////////////////////////////////////////////////////
short CM_INADEQUATE_InitInterface::createSrlSession(char *pLdapServer, char *pLdapPort)  // returns SRL_SUCCESS if successful
{
   short status = CM_NO_ERROR;
    SRL_InitSettings_struct *SRLtool_settings = NULL;

   // get memory for the initial settings struct
    SRLtool_settings = (SRL_InitSettings_struct *)CM_Calloc (1, sizeof (SRL_InitSettings_struct));

   if ((pLdapServer != NULL) && (pLdapPort != NULL))
   {
      // set up LDAPinfo
       SRLtool_settings->LDAPinfo = (LDAPInitSettings_struct *)calloc (1, sizeof (LDAPInitSettings_struct));
       if (SRLtool_settings->LDAPinfo == NULL)
           return (-1);   // memory error

      // set up LDAPServerInfo
      SRLtool_settings->LDAPinfo->LDAPServerInfo = (LDAPServerInit_struct *)calloc (1, sizeof (LDAPServerInit_struct));
       if (SRLtool_settings->LDAPinfo->LDAPServerInfo == NULL)
           return (-1);   // memory error

      // set up the ldap server
      SRLtool_settings->LDAPinfo->LDAPServerInfo->LDAPserver = strdup (pLdapServer);

      // set up the ldap port
       SRLtool_settings->LDAPinfo->LDAPServerInfo->LDAPport = atoi (pLdapPort);

      // set up LDAP shared library name dll defined in CM_Interface.h
      SRLtool_settings->LDAPinfo->SharedLibraryName = strdup (LDAP_DLL_NAME);
      SRLtool_settings->crlRefreshPeriod/*RefreshTime*/ = 60*60*24;  //1 day
      SRLtool_settings->removeStaleCRL = true;

   }
   else
   {
      SRLtool_settings->crlRefreshPeriod/*RefreshTime*/ = LONG_MAX;
      SRLtool_settings->removeStaleCRL = false;
   }

   // set up certificate and crl database name
#if defined (WIN32) || defined (WINDOWS)
    SRLtool_settings->CertFileName = strdup (".\\certs.db");
    SRLtool_settings->CRLFileName = strdup (".\\crl.db");
#else
    SRLtool_settings->CertFileName = strdup ("./certs.db");
    SRLtool_settings->CRLFileName = strdup ("./crl.db");
#endif


   // set up SRL session
   status = SRL_CreateSession(&m_lSrlSessionId, SRLtool_settings);
  
   FreeSRLInitSettings(SRLtool_settings);
   if (SRLtool_settings)
      free(SRLtool_settings);

   return status;
}       // END CM_INADEQUATE_InitInterface::createSrlSession(...)

////////////////////////////////////////////////////////////////////////////////////////////////
//
// createCmlSession 
//
//   Creates a cml session.  m_lCmlSessionId is assigned the cml session id.
//   Trusted certs are added to the certs.db file
//   THIS ROUTINE TAKES CONTROL OF "pTrustedCerts" MEMORY.
////////////////////////////////////////////////////////////////////////////////////////////////
short CM_INADEQUATE_InitInterface::createCmlSession(EncCert_LL *pTrustedCerts)  // returns SRL_SUCCESS if successful
{
   short               status = 1;
    //InitSettings_struct tool_settings;
   EncCert_LL          *TrustedTemp = NULL;
 
   // set up to create a CML session Ext id
    structGLOBALtool_settings.cbSize = sizeof(structGLOBALtool_settings);
    structGLOBALtool_settings.extHandle = &this->m_lSrlSessionId;
    structGLOBALtool_settings.pFreeObj = (ExtFreeObjFuncPtr) SRL_FreeObjs;
    structGLOBALtool_settings.pGetObj = (ExtGetObjFuncPtr) SRL_RequestObjs;
    structGLOBALtool_settings.pUrlGetObj = (ExtUrlGetObjFuncPtr) SRL_URLRequestObjs;
    structGLOBALtool_settings.revPolicy = CM_REVNONE;//RWC;TMP for R2.1;CM_REVCRL;
    //structGLOBALtool_settings.revPolicy = CM_REVCRL;
    structGLOBALtool_settings.pTokenObj = NULL;
    structGLOBALtool_settings.nCertCacheSize = 200;
    structGLOBALtool_settings.certCacheTTL = 0; /* Default every day */
    structGLOBALtool_settings.nCrlCacheSize = 200;
    structGLOBALtool_settings.crlCacheTTL = 0; /* Default every day */
    structGLOBALtool_settings.pTokenObj = (CM_TOKEN_TYPE *)this->m_pCtilMgr;

   // get trusted certs
   //RWC;Separated call in order to get specific failure message(s)
    //structGLOBALtool_settings.trustedCerts = pTrustedCerts;  // do not clean up tool_Settings.trustedCerts
   
   /* Create a CML session */
   status = CM_CreateSessionExt(&this->m_lCmlSessionId, &structGLOBALtool_settings);
   if (status != 0)
   {
      //#ifdef _DEBUG
      const char *ptr=CMU_GetErrorString(status);  // DEBUG only
      if (ptr)
          std::cout << "CM_INADEQUATE_InitInterface::createCmlSession:" << ptr << "\n";
      return(status);
      //#endif
   }

   /*RWC;LOOP THROUGH EACH CERT to attempt a trusted add, reporting errors on 
    any that fail, construct a new list, then perform a final add to set all 
    valid entries.  This is easier than figuring out which cert(s) in the list
    failed by searching for their DN; ALSO, CML only returns 1 at a time 
    (painful).*/
   ErrorInfo_List *perrInfo=NULL;
//#ifdef TRY_THIS
   EncCert_LL *pTrustedCertTmp=pTrustedCerts;
   EncCert_LL *pTrustedCertTmp2;
   EncCert_LL *pTrustedCertTmpPrevious=NULL;
   EncCert_LL TrustedCertTmp;
   while ( pTrustedCertTmp ) 
   {
       TrustedCertTmp = *pTrustedCertTmp;   // NO memory copied.
       TrustedCertTmp.next = NULL;      // ONLY process 1 entry.
       status = CM_SetTrustedCerts(m_lCmlSessionId, &TrustedCertTmp, &perrInfo);
       if (status != 0)
       {
          //#ifdef _DEBUG
          const char *ptr=CMU_GetErrorString(status);  // DEBUG only
          if (ptr)
              std::cout << "CM_INADEQUATE_InitInterface::createCmlSession: bad CM_SetTrustedCerts call; " << ptr << "\n";
          if (perrInfo)
          {
              ErrorInfo_List *perrInfoTmp=perrInfo;
              while (perrInfoTmp)
              {
                  ptr = CMU_GetErrorString(perrInfoTmp->error);  // DEBUG only
                  if (ptr)
                      std::cout << "    CM_SetTrustedCerts:perrInfo, status=|" << 
                                ptr << "|";
                  if (perrInfoTmp->dn)
                      std::cout << ", DN=|" << perrInfoTmp->dn << "|";
                  std::cout << "\n";
                  perrInfoTmp = perrInfoTmp->next;
              }     // END WHILE perrInfoTmp
              CM_FreeErrInfo(&perrInfo);
          }         // IF perrInfo
          //IGNORE; simply do not load invalid certs as trusted; we still want
          //  to process for error conditions for certain applications.  All
          //  errors are reported.
          //  return(status);
          //#endif
          // REMOVE this entry from the list.
          if (pTrustedCertTmpPrevious)
          {
              pTrustedCertTmpPrevious->next = pTrustedCertTmp->next;
          }
          else
          {
              pTrustedCerts = pTrustedCertTmp->next;    // REPLACE 1st entry.
          }     // END IF pTrustedCertTmpPrevious
          //DO NOT REPLACE SINCE PRESENT IS DELETED;pTrustedCertTmpPrevious = pTrustedCertTmp;
          pTrustedCertTmp2 = pTrustedCertTmp;
          pTrustedCertTmp = pTrustedCertTmp->next;  // JUST move forward.
          pTrustedCertTmp2->next = NULL;    //REMOVE from list.
          CM_FreeEncCertList(&pTrustedCertTmp2); 
                            // DELETE JUST this offending entry.
       }
       else
       {
          pTrustedCertTmpPrevious = pTrustedCertTmp;
          pTrustedCertTmp = pTrustedCertTmp->next;
       }
   }        // END WHILE each cert to loaded into the trusted list.
//#endif
   // NOW that we have eliminated any failing trusted certs (and reported these 
   //  failures), we can load the entire list that works as trusted.
   //status = CM_SetTrustedCerts(m_lCmlSessionId, pTrustedCerts, &perrInfo);
   //RWC;RE-OPEN the session (in R2.2, just re-setting the trusted certs 
   //RWC;  results in failures when attempting to validate signatures later./
   //RWC;  (NOT SURE WHY!)
   structGLOBALtool_settings.trustedCerts = pTrustedCerts;  // do not clean up tool_Settings.trustedCerts
   /* Re-Create a CML session */
   CM_DestroySession(&m_lCmlSessionId);
   m_lCmlSessionId = 0;
   status = CM_CreateSessionExt(&m_lCmlSessionId, &structGLOBALtool_settings);
   if (status != 0) // THIS AUGHT TO WORK JUST FINE...
   {
      //#ifdef _DEBUG
      const char *ptr=CMU_GetErrorString(status);  // DEBUG only
      if (ptr)
          std::cout << "CM_INADEQUATE_InitInterface::createCmlSession: bad 2nd CM_CreateSessionExt call; " << ptr << std::endl;
   }
   else 
       std::cout << "Session " << this->m_lCmlSessionId << " successfully created." << std::endl;

   /* add trusted cert to DB */
    if (structGLOBALtool_settings.trustedCerts != NULL)
    {
        TrustedTemp = structGLOBALtool_settings.trustedCerts;
        while (TrustedTemp != NULL)
        {
            std::cout << "Adding Trusted Certs to Database" << "\n";
            status = SRL_DatabaseAdd(m_lSrlSessionId, &TrustedTemp->encCert, 
                                  SRL_CERT_TYPE);
            TrustedTemp = TrustedTemp->next;
        }
    }

   //CM_FreeEncCertList(m_lSrlSessionId, structGLOBALtool_settings.trustedCerts);   //RWC;added.
   
   return(status);
}       // END CM_INADEQUATE_InitInterface::createCmlSession(...)

////////////////////////////////////////////////////////////////////////////////////////////////
//
//
void CM_INADEQUATE_InitInterface::destroySrlSession(ulong *pSrlSessionId)  
{
   // call srl library function
   SRL_DestroySession(pSrlSessionId);
}       // END CM_INADEQUATE_InitInterface::destroySrlSession(...)

void CM_INADEQUATE_InitInterface::destroyCmlSession(ulong *pCmlSessionId) 
{
   // call cml library function
   CM_DestroySession(pCmlSessionId);
}      // END CM_INADEQUATE_InitInterface::destroyCmlSession(...)


////////////////////////////////////////////////////////////////////////////////////////////////
//
// initializeSessions 
//
//    Calls createSrlSession and createCmlSession to initialize the srl and cml.  
//   
//
// returns status from SRL_DatabaseAdd call
//
//   THIS ROUTINE TAKES CONTROL OF "pTrustedCerts" MEMORY.
//
////////////////////////////////////////////////////////////////////////////////////////////////
short CM_INADEQUATE_InitInterface::initializeSessions(char *pLdapServer, char *pLdapPort, 
        CSM_BufferLst &TrustedCertsBufLst,/*EncCert_LL *pTrustedCerts*/ void *pCsmime)  
{
   short            status = 0;

   if (pCsmime)
      m_pCtilMgr = pCsmime;
   if ((status = createSrlSession(pLdapServer, pLdapPort)) == SRL_SUCCESS)
   {
      EncCert_LL *pTrustedCerts=NULL;
      EncCert_LL *pTrustedCertsTmp=NULL;
      CSM_Buffer *pTmpBuf;
      for (TrustedCertsBufLst.SetCurrToFirst(), pTmpBuf=TrustedCertsBufLst.Curr(); 
           pTmpBuf; pTmpBuf = TrustedCertsBufLst.GoNext())
      {
          CSM_CertificateChoice CertChoice(*pTmpBuf);
          CSM_Alg *pPublicKeyAlg = CertChoice.GetPublicKeyAlg();
          if (pPublicKeyAlg && (pPublicKeyAlg->algorithm != SNACC::id_dsa ||
              pPublicKeyAlg->parameters != NULL))  // CHECK for DSA Params missing.
          {
              if (pTrustedCertsTmp == NULL)
              {
                  pTrustedCerts = (EncCert_LL *)calloc(1, sizeof(EncCert_LL));
                  pTrustedCertsTmp = pTrustedCerts;
              }
              else
              {
                  pTrustedCertsTmp->next = (EncCert_LL *)calloc(1, sizeof(EncCert_LL));
                  pTrustedCertsTmp = pTrustedCertsTmp->next;
              }
              pTrustedCertsTmp->encCert.data = (uchar *)calloc(1, pTmpBuf->Length());
              memcpy(pTrustedCertsTmp->encCert.data, (uchar *)pTmpBuf->Access(),
                     pTmpBuf->Length());
              pTrustedCertsTmp->encCert.num = pTmpBuf->Length();
          }     // END IF DSA Params missing.
          if (pPublicKeyAlg)
              delete pPublicKeyAlg;
      }         // FOR each TrustedCertsBufLst element.

      status = createCmlSession(pTrustedCerts);
   }

   return status;  
}       // END CM_INADEQUATE_InitInterface::initializeSessions(...)

// local functions:        
void CM_INADEQUATE_InitInterface::FreeSRLInitSettings(SRL_InitSettings_struct *settings)
{
    if (settings == NULL)
        return;
    if (settings->CertFileName != NULL)
        CM_Free (settings->CertFileName);
    if (settings->CRLFileName != NULL)
        CM_Free (settings->CRLFileName);
    if (settings->LDAPinfo != NULL)
    {
        /* Free the contents of the LDAP information structure */

        /* LDAP functions are used in the session struct, don't free them here */
        if (settings->LDAPinfo->SharedLibraryName != NULL)
            CM_Free (settings->LDAPinfo->SharedLibraryName);
        if (settings->LDAPinfo->LDAPServerInfo != NULL)
        {
            if (settings->LDAPinfo->LDAPServerInfo->LDAPserver != NULL)
                CM_Free (settings->LDAPinfo->LDAPServerInfo->LDAPserver);
            CM_Free (settings->LDAPinfo->LDAPServerInfo);
        }
    }
    return;
}       // END CM_INADEQUATE_InitInterface::FreeSRLInitSettings(...)





#endif   //CML_USED


#ifdef ACL_USED

using namespace acl;
long AC_INADEQUATE_InitInterface::initializeSessions(
       CTIL::CSM_BufferLst *pTrustedSPIFBufLst,     // OPTIONAL setup.
       CTIL::CSM_BufferLst *pTrustedCertsBufLst,    // OPTIONAL setup.
       acl::TrustList *pTrustList)    // OPTIONAL setup.
{
   long lstatus = 0;
   FUNC("AC_INADEQUATE_InitInterface::initializeSession(...)");
   try
   {
      if (m_pAclSessionId == NULL)
      {                 // THEN load some initial values.
         m_pAclSessionId = new acl::Session;
         m_bInitAclSessionHere = true;
          /*
           AclString cacheString;
           pACLsession->displayCache(cacheString);
           cout << "ACL CACHE::: \n" << cacheString << "ACL CACHE END:::\n";
          */
          //
          m_pAclSessionId->m_acTTL = 24;
          m_pAclSessionId->m_spifTTL = 56;
          m_pAclSessionId->m_dms_mode = false;//TMP;true;

          //
          m_pAclSessionId->enableCML(m_lCmlSessionId);
          m_pAclSessionId->enableSPIFSignerAttribute(false);//TMP;true);
          m_pAclSessionId->disableValidation(false);
          m_pAclSessionId->disableTrustList(false);
      }     // END if m_pAclSessionId is NULL

      if (pTrustList)
      {
          // LOAD ACL trust elements.
          acl::Trust *pTmpTrust;
          for (pTrustList->SetCurrToFirst(),
               pTmpTrust = pTrustList->Curr(); 
               pTmpTrust && lstatus == 0; pTmpTrust = pTrustList->GoNext())
          {
                   lstatus = m_pAclSessionId->addTrust(
                       (CML::ASN::DN &)pTmpTrust->GetDN(), 
                       (SNACC::AsnOid &)pTmpTrust->GetOid());
          }         // END for each trust list element.
      }     // END if pTrustList

      if (pTrustedCertsBufLst)
      {
          CSM_Buffer *pTmpBuf;
          for (pTrustedCertsBufLst->SetCurrToFirst(),
               pTmpBuf = pTrustedCertsBufLst->Curr(); 
               pTmpBuf; pTmpBuf = pTrustedCertsBufLst->GoNext())
          {
              m_pAclSessionId->addCC(*pTmpBuf);
          }         // END for each SPIF buffer.
      }     // END if pTrustedCertsBufLst

      if (pTrustedSPIFBufLst)
      {
          CSM_Buffer *pTmpBuf;
          for (pTrustedSPIFBufLst->SetCurrToFirst(),
               pTmpBuf = pTrustedSPIFBufLst->Curr(); 
               pTmpBuf; pTmpBuf = pTrustedSPIFBufLst->GoNext())
          {
              m_pAclSessionId->addSPIF(*pTmpBuf);
          }         // END for each SPIF buffer.
      }     // END if pTrustedSPIFBufLst


      //
   }
   catch (SNACC::SnaccException &e)
   {
       this->m_szError = (char *) calloc(1, strlen(_func) + 
              strlen(": errorCode=") + strlen(e.what()) + 52);
       strcpy(m_szError, _func);
       strcat(m_szError, ": errorCode=");
       sprintf(&m_szError[strlen(m_szError)], "%d\n", e.m_errorCode);
       strcat(m_szError, "     error=");
       strcat(m_szError, e.what());
       strcat(m_szError, "\n");
       lstatus = -1;
      //throw;
   }


   return(lstatus);
}     // END SMP_Check_SetupACLSession(...)


#endif  // ACL_USED

// EOF sm_CM_AC_Support.cpp

