
//////////////////////////////////////////////////////////////////////////
// sm_certChoice.cpp
// methods for the CSM_CertificateChoice class

#include "sm_apiCert.h"
using namespace SNACC;
using SNACC::SnaccException;
_BEGIN_CERT_NAMESPACE 
//////////////////////////////////////////////////////////////////////////
// clear method
void CSM_CertificateChoice::Clear()
{
   m_pCert = NULL;
   m_pAttrCert = NULL;
   m_pSNACCCert = NULL;
   m_pSNACCAttrCert = NULL;
   m_bIssOrSki = true;
}

//////////////////////////////////////////////////////////////////////////
CSM_CertificateChoice::CSM_CertificateChoice(const Certificate &SNACCCert)
{
   Clear();
   m_pSNACCCert = new Certificate;
   *m_pSNACCCert = SNACCCert;
}

//////////////////////////////////////////////////////////////////////////
CSM_CertificateChoice::CSM_CertificateChoice(const CSM_Buffer &Cert)
{
   Clear();
   SetEncodedCert(Cert);
}

//////////////////////////////////////////////////////////////////////////
CSM_CertificateChoice::CSM_CertificateChoice(const CertificateChoices &SNACCCertChoices)
{
   Clear();
   SetSNACCCertChoices(SNACCCertChoices);
}

//////////////////////////////////////////////////////////////////////////
CSM_CertificateChoice::CSM_CertificateChoice(const CSM_CertificateChoice &certChoice)
{
   Clear();
   const CSM_Buffer *pBuf=certChoice.AccessEncodedCert();
   const CSM_Buffer *pAttrBuf=certChoice.AccessEncodedAttrCert();
   if (pBuf)
     m_pCert = new CSM_Buffer(*pBuf);
   if (pAttrBuf)
    this->m_pAttrCert = new CSM_Buffer(*pAttrBuf);
}
//
//
CSM_CertificateChoice::CSM_CertificateChoice(char *lpszFile, long choiceId)
{
   Clear();

   SME_SETUP("CSM_CSInst::CSM_CertificateChoice(char *,long)");

   const CSM_Buffer tmpBuf(lpszFile);

   if (choiceId == CertificateChoices::certificateCid)
      SetEncodedCert(tmpBuf);
   else if (choiceId == CertificateChoices::attrCertCid)
      SetEncodedAttrCert(tmpBuf);
   else
   {
      SME_THROW(28, "Bad SNACC::CertificateChoices::??:?Cid value", NULL);
   }
   SME_FINISH_CATCH
}

//////////////////////////////////////////////////////////////////////////
CSM_CertificateChoice::~CSM_CertificateChoice()
{
   // free memory if necessary
   if (m_pCert != NULL)
      delete m_pCert;
   if (m_pAttrCert != NULL)
      delete m_pAttrCert;
   if (m_pSNACCCert != NULL)
      delete m_pSNACCCert;
   if (m_pSNACCAttrCert != NULL)
      delete m_pSNACCAttrCert;
}

//////////////////////////////////////////////////////////////////////////
void CSM_CertificateChoice::SetEncodedCert(const CSM_Buffer &Cert)
{
    if (m_pAttrCert)
    {
        delete m_pAttrCert;
        m_pAttrCert = NULL;
    }
    if (m_pSNACCCert)
    {
        delete m_pSNACCCert;
        m_pSNACCCert = NULL;
    }
    if (m_pSNACCAttrCert)
    {
        delete m_pSNACCAttrCert;
        m_pSNACCAttrCert = NULL;
    }
    if (m_pCert == NULL)
        m_pCert = new CSM_Buffer;
    *m_pCert = Cert;
    AccessSNACCCertificate();
}

//////////////////////////////////////////////////////////////////////////
void CSM_CertificateChoice::SetEncodedAttrCert(const CSM_Buffer &AttrCert)
{
   SME_SETUP("CSM_CertificateChoice::SetEncodedAttrCert");
    if (m_pCert)
    {
        delete m_pCert;
        m_pCert = NULL;
    }
    if (m_pSNACCCert)
    {
        delete m_pSNACCCert;
        m_pSNACCCert = NULL;
    }
    if (m_pSNACCAttrCert)
    {
        delete m_pSNACCAttrCert;
        m_pSNACCAttrCert = NULL;
    }
    if (m_pAttrCert == NULL)
        m_pAttrCert = new CSM_Buffer;
    *m_pAttrCert = AttrCert;
   AccessSNACCAttrCertificate();

    SME_FINISH
    SME_CATCH_SETUP
    SME_CATCH_FINISH
}

//////////////////////////////////////////////////////////////////////////
void CSM_CertificateChoice::Decode() const
{
   SME_SETUP("CSM_CertificateChoice::Decode");

   // error if it isn't present
   if (m_pCert != NULL && m_pCert->Length() > 0)
   {
     if (m_pSNACCCert)
         delete m_pSNACCCert;
     if ((m_pSNACCCert = new Certificate) == NULL)
        SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

     // decode the certificate
     SME(DECODE_BUF(m_pSNACCCert, m_pCert));

     if (m_pSNACCCert->toBeSigned == NULL)
        SME_THROW(SM_CERT_DEC_ERROR, "Certificate missing CTS", NULL);
     if (m_pSNACCCert->toBeSigned->subjectPublicKeyInfo == NULL)
        SME_THROW(SM_CERT_DEC_ERROR, "Certificate missing subj pub key info",
            NULL);
   }
   else if (m_pAttrCert != NULL && m_pAttrCert->Length() > 0)
   {
     if (m_pSNACCAttrCert)
         delete m_pSNACCAttrCert;
     if ((m_pSNACCAttrCert = new AttributeCertificate) == NULL)
        SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

     // decode the certificate
     SME(DECODE_BUF(m_pSNACCAttrCert, m_pAttrCert));
   }
   else
       SME_THROW(SM_NO_CERT_SET, "encoded cert/AttrCert missing", NULL);


   SME_FINISH_CATCH;
}

//////////////////////////////////////////////////////////////////////////
AsnOid *CSM_CertificateChoice::GetKeyOID()
{
   AsnOid *pKeyOID=NULL;
   SME_SETUP("CSM_CertificateChoice::GetKeyOID");

   // if m_pKeyOID is null, then the cert has not been decoded
   // and we must decode it before we can return the requested value
   if (m_pSNACCCert == NULL && m_pSNACCAttrCert == NULL)    // Decode result.
      SME(Decode());
   if (m_pSNACCCert != NULL)
   {
       if ((pKeyOID = new AsnOid(m_pSNACCCert->toBeSigned->
          subjectPublicKeyInfo->algorithm->algorithm)) == NULL)
          SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
   }

   SME_FINISH_CATCH;
   return pKeyOID;
}

CSM_Buffer *CSM_CertificateChoice::GetPublicKey()
{
   CSM_Buffer *pRet = NULL;

   SME_SETUP("CSM_CertificateChoice::GetPublicKey");

   // if m_pSnaccCert is null then the cert has not been decoded
   // and we must decode it before we can return the requested value
   if (m_pSNACCCert == NULL && m_pSNACCAttrCert == NULL)    // Decode result.
      SME(Decode());

   if (m_pSNACCCert != NULL)
   {
     pRet = GetPublicKey(m_pSNACCCert->toBeSigned->subjectPublicKeyInfo->subjectPublicKey);
   }

   SME_FINISH_CATCH;
   return pRet;
}

CSM_Buffer *CSM_CertificateChoice::GetPublicKey(AsnBits &SNACCBits)
{
   CSM_Buffer *pRet = NULL;

   SME_SETUP("CSM_CertificateChoice::GetPublicKey");

   AsnBits *pY = &SNACCBits;

   pRet = new CSM_Buffer((const char *)SNACCBits.data(), SNACCBits.length());

   SME_FINISH_CATCH;
   return pRet;
}
//////////////////////////////////////////////////////////////////////////
CSM_Alg *CSM_CertificateChoice::GetPublicKeyAlg()
{
   CSM_Alg *pRet = NULL;

   SME_SETUP("CSM_CertificateChoice::GetPublicKeyAlg");

   // if m_pSnaccCert is null then the cert has not been decoded
   // and we must decode it before we can return the requested value
   if (m_pSNACCCert == NULL && m_pSNACCAttrCert == NULL)    // Decode result.
      SME(Decode());

   if (m_pSNACCCert != NULL)
   {
     if ((pRet = new CSM_Alg(*(m_pSNACCCert->toBeSigned->
         subjectPublicKeyInfo->algorithm))) == NULL)
        SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
   }

   SME_FINISH_CATCH;
   return pRet;
}


////////////////////////////////////////////////////////////////////////////
//   This method returns the issuer of a Certificate or an Attribute Certificate as
//  a CSM_DN pointer.  When an AttributeCertificate is been processed, also a list
//  of CSM_GeneralNames is constructed, then this list is searched to find if a
//  CSM_DN is available.  
//   NOTE : The fact that an issuer in the form of a CSM_DN is not found for an 
//         AttributeCertificate should NOT be interpreted by the caller as an 
//         indication of NO issuer provided.
CSM_DN * CSM_CertificateChoice::GetIssuer(CSM_GeneralNameLst *pIssuers)
{
   CSM_DN *pIssuer = NULL;

   SME_SETUP("CSM_CertificateChoice::GetIssuer");

   // if m_pSNACCCert and m_pSNACCAttrCert are null, then no objects 
   // have been decoded; so, call Decode
   if ((m_pSNACCCert == NULL) && (m_pSNACCAttrCert == NULL))
      SME(Decode());

   if (m_pSNACCCert != NULL)
   {
     if (m_pSNACCCert->toBeSigned->issuer == NULL)
        SME_THROW(SM_CERT_DEC_ERROR, "Certificate missing issuer", NULL);

     if ((pIssuer = new CSM_DN(*(m_pSNACCCert->toBeSigned->issuer))) == NULL)
        SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
   }
   else if (m_pSNACCAttrCert != NULL)
   {
      if (m_pSNACCAttrCert->toBeSigned->issuer->choiceId != AttCertIssuer::v1FormCid ||
          m_pSNACCAttrCert->toBeSigned->issuer->v1Form->Count() == 0)
         SME_THROW(SM_CERT_DEC_ERROR, "Attribute Certificate missing issuer", NULL);

      if (pIssuers)
         delete pIssuers;

      pIssuers = new CSM_GeneralNameLst;

      GeneralName *pIssuerName;

      for (m_pSNACCAttrCert->toBeSigned->issuer->v1Form->SetCurrToFirst(),
            pIssuerName = m_pSNACCAttrCert->toBeSigned->issuer->v1Form->Curr();
               pIssuerName; pIssuerName = m_pSNACCAttrCert->toBeSigned->issuer->v1Form->GoNext())
      {
         //CSM_GeneralName generalName(*pIssuerName);
         CSM_GeneralName *pgeneralName = pIssuers->Append();
         *pgeneralName = *pIssuerName;

         
         if (pIssuer == NULL)
            pIssuer = pIssuers->Curr()->GetGenNameDN();
      }
   }

   SME_FINISH_CATCH;

   return pIssuer;
}
//////////////////////////////////////////////////////////////////////////
CSM_Buffer *CSM_CertificateChoice::GetEncodedIssuer()
{
   CSM_Buffer *pEncodedIssuer=NULL;

   SME_SETUP("CSM_CertificateChoice::GetEncodedIssuer");

   // if m_pIssuer is null, then the Cert has not been decoded
   // and we must decode it before we can return the requested value
   if (m_pSNACCCert == NULL && m_pSNACCAttrCert == NULL)    // Decode result.
      SME(Decode());

   if (m_pSNACCCert != NULL)
   {
        if (m_pSNACCCert->toBeSigned->issuer == NULL)
            SME_THROW(SM_CERT_DEC_ERROR, "Certificate missing issuer", NULL);
    
        ENCODE_BUF(m_pSNACCCert->toBeSigned->issuer, pEncodedIssuer);
   }

   SME_FINISH_CATCH;
   return pEncodedIssuer;
}

////////////////////////////////////////////////////////////////////////////
//   This method returns the subject of a Certificate or an Attribute Certificate as
//  a CSM_DN pointer.  When an AttributeCertificate is being processed, also a list
//  of CSM_GeneralNames is constructed, then this list is searched to find if a
//  CSM_DN is available.  
//   NOTE : The fact that an subject in the form of a CSM_DN is not found for an 
//         AttributeCertificate should NOT be interpreted by the caller as an 
//         indication of NO subject provided.
CSM_DN * CSM_CertificateChoice::GetSubject(CSM_GeneralNameLst *pIssuers)
{   
   CSM_DN *pSubject=NULL;

   SME_SETUP("CSM_CertificateChoice::GetSubject");

   // if m_pSNACCCert and m_pSNACCAttrCert are null, then nothing has been decoded
   // so we must call to decode before we can return the requested value
   if ((m_pSNACCCert == NULL) && (m_pSNACCAttrCert == NULL))
      SME(Decode());

   if (m_pSNACCCert != NULL && m_pSNACCCert->toBeSigned != NULL)
   {
     if (m_pSNACCCert->toBeSigned->subject == NULL)
        SME_THROW(SM_CERT_DEC_ERROR, "Certificate missing subject", NULL);

     if ((pSubject = new CSM_DN(*(m_pSNACCCert->toBeSigned->subject))) == NULL)
        SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
   }
   else if (m_pSNACCAttrCert != NULL)
    {
       if (m_pSNACCAttrCert->toBeSigned->eitherHolder == NULL)
          SME_THROW(SM_CERT_DEC_ERROR, "Attribute Certificate missing subject", NULL);
 
      if (pIssuers == NULL)
         pIssuers = new CSM_GeneralNameLst();

      GeneralName *pIssuer = NULL;
 
      // The Subject of an AttributeCertificate is a choice between holder, baseCertificate
      // (which contains a GeneralName list, a serialNumber and a UniqueIdentifier)
      // and a subjectName (which is a list of General Names).
       if (m_pSNACCAttrCert->toBeSigned->eitherHolder->choiceId == 
                         AttributeCertificateInfoChoice::baseCertificateIDCid) // V1(0)
       {
          // IssuerSerial
          GeneralNames names;
          names = m_pSNACCAttrCert->toBeSigned->
                                     eitherHolder->baseCertificateID->issuer;
 
          // Make list of CSM_GeneralNames from list of GeneralNames for the issuer (a list of 
          // issuers does NOT mean multiple issuers, it means different representations of the
          // same isssuer).
          for (names.SetCurrToFirst(), 
               pIssuer = names.Curr(); pIssuer; pIssuer = names.GoNext())
          {
             CSM_GeneralName *pGeneralName = pIssuers->Append();
             *pGeneralName = *pIssuer;

            if (pSubject == NULL)
               pSubject = pIssuers->Curr()->GetGenNameDN();
          }
       }
       else if (m_pSNACCAttrCert->toBeSigned->eitherHolder->choiceId == 
                         AttributeCertificateInfoChoice::holderCid) // V2(1)
       {
          // IssuerSerial
          GeneralNames names;

          if (m_pSNACCAttrCert->toBeSigned->eitherHolder->holder != NULL &&
              m_pSNACCAttrCert->toBeSigned->eitherHolder->holder->entityName != NULL)
          {
             names = *m_pSNACCAttrCert->toBeSigned->
                                     eitherHolder->holder->entityName;
          }  
          else if (m_pSNACCAttrCert->toBeSigned->eitherHolder->holder != NULL &&
              m_pSNACCAttrCert->toBeSigned->eitherHolder->holder->baseCertificateID != NULL)
          {

             names = m_pSNACCAttrCert->toBeSigned->
                                     eitherHolder->holder->baseCertificateID->issuer;
          }
 
          // Make list of CSM_GeneralNames from list of GeneralNames for the issuer (a list of 
          // issuers does NOT mean multiple issuers, it means different representations of the
          // same isssuer).
          for (names.SetCurrToFirst(), 
               pIssuer = names.Curr(); pIssuer; pIssuer = names.GoNext())
          {
             CSM_GeneralName *pGeneralName = pIssuers->Append();
             *pGeneralName = *pIssuer;

            if (pSubject == NULL)
               pSubject = pIssuers->Curr()->GetGenNameDN();
          }
       }     
       else if (m_pSNACCAttrCert->toBeSigned->eitherHolder->choiceId ==
                               AttributeCertificateInfoChoice::subjectNameCid)
       {
          // GeneralNames
         GeneralNames *pNames = NULL;

         if ((pNames = m_pSNACCAttrCert->toBeSigned->eitherHolder->subjectName) != NULL)
         {      
            for (pNames->SetCurrToFirst(), 
                  pIssuer = pNames->Curr(); pIssuer; pIssuer = pNames->GoNext())
            {
               CSM_GeneralName *pgeneralName = pIssuers->Append();
               *pgeneralName = *pIssuer;

               if (pSubject == NULL)
                  pSubject = pIssuers->Curr()->GetGenNameDN();
            }
         }
       }
    }
 
    SME_FINISH_CATCH;

   return pSubject;
}
//////////////////////////////////////////////////////////////////////////
CSM_Buffer *CSM_CertificateChoice::GetEncodedSubject()
{
   CSM_Buffer *pEncodedSubject=NULL;

   SME_SETUP("CSM_CertificateChoice::GetEncodedSubject");

   // if m_pSubject is null, then the Cert has not been decoded
   // and we must decode it before we can return the requested value
   if (m_pSNACCCert == NULL && m_pSNACCAttrCert == NULL)    // Decode result.
      SME(Decode());
      // store subject
   if (m_pSNACCCert != NULL)
   {
       if (m_pSNACCCert->toBeSigned->subject == NULL)
           SME_THROW(SM_CERT_DEC_ERROR, "Certificate missing subject", NULL);

       ENCODE_BUF(m_pSNACCCert->toBeSigned->subject, pEncodedSubject);
   }

   SME_FINISH_CATCH;
   return pEncodedSubject;
}
//////////////////////////////////////////////////////////////////////////
CSM_Buffer* CSM_CertificateChoice::GetSerial()
{
   CSM_Buffer *pRet = NULL;

   SME_SETUP("CSM_CertificateChoice::GetSerial");

   // if m_pSnaccCert and m_pSnaccAttrCert are null then no object 
   // has been decoded; so, call Decode
   if ( (m_pSNACCCert == NULL) && (m_pSNACCAttrCert == NULL) )
      SME(Decode());

   // Do we have a Cert ?
   if (m_pSNACCCert != NULL)
   {
     if ((pRet = new CSM_Buffer(
         (const char *)m_pSNACCCert->toBeSigned->serialNumber.c_str(),
         m_pSNACCCert->toBeSigned->serialNumber.length())) == NULL)
        SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
   }
   else if (m_pSNACCAttrCert != NULL)
   {
      if ((pRet = new CSM_Buffer(
         (const char *)m_pSNACCAttrCert->toBeSigned->serialNumber.c_str(),
         m_pSNACCAttrCert->toBeSigned->serialNumber.length())) == NULL)
         SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
   }

   SME_FINISH_CATCH;
   return pRet;
}
///////////////////////////////////////////////////////////////////////////
// GetRid member function
CSM_Identifier *CSM_CertificateChoice::GetRid(CSM_Identifier &RID)
{
   CSM_Identifier *pRID=NULL;

   SME_SETUP("CSM_CertificateChoice::GetRid(CSM_Identifier &)");

   if (RID.AccessSubjectKeyIdentifier())
       pRID = GetRid(false);
   else
       pRID = GetRid(true);

   SME_FINISH_CATCH;
   return(pRID);
}

///////////////////////////////////////////////////////////////////////////
// GetRid member function
CSM_Identifier *CSM_CertificateChoice::GetRid(bool m_bIssOrSki)
{
    CSM_Identifier *pRID=NULL;

    SME_SETUP("CSM_Identifier::GetRid(bool)"); 

    // if m_pSnaccCert is null then the cert has not been decoded
    // and we must decode it before we can return the requested value
    if (m_pSNACCCert == NULL && m_pSNACCAttrCert == NULL)    // Decode result.
    {
       SME(Decode());
    }

    if (!m_bIssOrSki)
    {
     CSM_Buffer *pSki = NULL;
     
     pSki = GetSubjectKeyIdentifier();

     if(pSki)
        pRID = new CSM_Identifier(*pSki);
    }
   //Issuer and Serial Number is Loaded if Subject Key Identifier is
   //missing from certificate.
   if (m_bIssOrSki)
   {
     CSM_IssuerAndSerialNumber *pIas = NULL;

      pIas = GetIssuerAndSerialNumber();

      if(pIas)
      {
          pRID = new CSM_Identifier(*pIas);
          delete pIas;
      }
   }

    SME_FINISH_CATCH
    return pRID;
}
///////////////////////////////////////////////////////////////////////////
// GetIssuerAndSerialNumber member function
CSM_IssuerAndSerialNumber *CSM_CertificateChoice::GetIssuerAndSerialNumber()
{
    CSM_IssuerAndSerialNumber *pResult=NULL;

    SME_SETUP("CSM_CertificateChoice::GetIssuerAndSerialNumber");

   // if m_pSnaccCert is null then the cert has not been decoded
   // and we must decode it before we can return the requested value
   if (m_pSNACCCert == NULL && m_pSNACCAttrCert == NULL)    // Decode result.
   {
       SME(Decode());
   }

   if(m_pSNACCCert)
   {
      pResult = new  CSM_IssuerAndSerialNumber;

      pResult->SetIssuer(*m_pSNACCCert->toBeSigned->issuer);
      pResult->SetSerialNo(m_pSNACCCert->toBeSigned->serialNumber);
   }

    SME_FINISH_CATCH
    return pResult;
}

///////////////////////////////////////////////////////////////////////////
// GetSubjectKeyIdentifier member function
CSM_Buffer *CSM_CertificateChoice::GetSubjectKeyIdentifier()
{
    CSM_Buffer *pResult=NULL;
    Extension *pSNACCExt;
    SubjectKeyIdentifier *pSNACCSKI;

    SME_SETUP("CSM_CertificateChoice::GetSubjectKeyIdentifier");

   // if m_pSnaccCert and m_pSnaccAttrCert are null then no object has been decoded
   // and we must decode one before we can return the requested value
   if ((m_pSNACCCert == NULL) && (m_pSNACCAttrCert == NULL))    // Decode result.
   {
       SME(Decode());
   }

   Extensions *pExtensions = NULL;

   if(m_pSNACCCert)
   {
      if(m_pSNACCCert->toBeSigned->extensions)
        pExtensions = m_pSNACCCert->toBeSigned->extensions;
   }
   else if (m_pSNACCAttrCert)
   {
      if (m_pSNACCAttrCert->toBeSigned->extensions)
         pExtensions = m_pSNACCAttrCert->toBeSigned->extensions;
   }

   if (pExtensions)
   {
      for(pExtensions->SetCurrToFirst(),
            pSNACCExt = pExtensions->Curr();
               pSNACCExt; pSNACCExt = pExtensions->GoNext())
      {
         if(pSNACCExt->extnId == id_ce_subjectKeyIdentifier)
         {
            pSNACCSKI = (SubjectKeyIdentifier *)pSNACCExt->extnValue.value;
            //RWC;DECODE_BUF(&snaccInt, pTmpBuf);
            pResult = new CSM_Buffer(pSNACCSKI->c_str(), pSNACCSKI->Len());
         }
      }
   }

    SME_FINISH_CATCH
    return pResult;
}

//////////////////////////////////////////////////////////////////////////
void CSM_CertificateChoice::SetSNACCCertChoices(
    const CertificateChoices &SNACCCertChoices)
{
   SME_SETUP("CSM_CertificateChoice::SetSNACCCertChoices");
   if (m_pCert)
      delete m_pCert;
   m_pCert = NULL;
   if (m_pAttrCert)
      delete m_pAttrCert;
   m_pAttrCert = NULL;
   if (SNACCCertChoices.choiceId == CertificateChoices::certificateCid)
   {
      if (m_pSNACCCert == NULL &&   // ONLY if not already allocated.
         (m_pSNACCCert = new Certificate) == NULL)
         SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
      *m_pSNACCCert = *SNACCCertChoices.certificate;
      if (m_pSNACCAttrCert)     // Delete opposite
          delete m_pSNACCAttrCert;
      m_pSNACCAttrCert  = NULL;
   }
   else if (SNACCCertChoices.choiceId == CertificateChoices::attrCertCid)
   {
      if (m_pSNACCAttrCert == NULL &&   // ONLY if not already allocated.
         (m_pSNACCAttrCert = new AttributeCertificate) == NULL)
         SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
      *m_pSNACCAttrCert = *SNACCCertChoices.attrCert;
      if (m_pSNACCCert)     // Delete opposite
          delete m_pSNACCCert;
      m_pSNACCCert  = NULL;
   }
   else
      SME_THROW(SM_MEMORY_ERROR, 
            "Unsupported Certificate Choice(Extended)", NULL);

   SME_FINISH_CATCH;
}

//////////////////////////////////////////////////////////////////////////
// Make a copy of our SNACC Certificate.
Certificate *CSM_CertificateChoice::GetSNACCCertificate()
{
    Certificate *pSNACCCert=new Certificate;
    SME_SETUP("CSM_CertificateChoice::GetSNACCCertificate");

    if (m_pSNACCCert == NULL && m_pSNACCAttrCert == NULL)    // Decode result.
        Decode();
    if (m_pSNACCCert)
      *pSNACCCert = *AccessSNACCCertificate();

    SME_FINISH_CATCH;
    return pSNACCCert;
}


//////////////////////////////////////////////////////////////////////////
// Access internal SNACC Certificate.
const Certificate *CSM_CertificateChoice::AccessSNACCCertificate() const
{
   SME_SETUP("CSM_CertificateChoice::AccessSNACCCertificate");
   if (m_pSNACCCert == NULL && m_pCert != NULL)    // Decode result.
   {
       Decode();
   }

   SME_FINISH_CATCH;
   return m_pSNACCCert;
}


//////////////////////////////////////////////////////////////////////////
// Make a copy of our SNACC Certificate.
AttributeCertificate *CSM_CertificateChoice::GetSNACCAttrCertificate()
{
    AttributeCertificate *pSNACCAttrCert=new AttributeCertificate;
    SME_SETUP("CSM_CertificateChoice::GetSNACCAttrCertificate");

    if (m_pSNACCCert == NULL && m_pSNACCAttrCert == NULL)    // Decode result.
        Decode();
    if (m_pSNACCAttrCert)
      *pSNACCAttrCert = *AccessSNACCAttrCertificate();

    SME_FINISH_CATCH;
    return pSNACCAttrCert;
}


//////////////////////////////////////////////////////////////////////////
// Access internal SNACC Certificate.
const AttributeCertificate *CSM_CertificateChoice::AccessSNACCAttrCertificate() const
{
   SME_SETUP("CSM_CertificateChoice::AccessSNACCAttrCertificate");
   if (m_pSNACCAttrCert == NULL && m_pAttrCert != NULL)    // Decode result.
   {
       Decode();
   }

   SME_FINISH_CATCH;
   return m_pSNACCAttrCert;
}


//////////////////////////////////////////////////////////////////////////
CSM_Buffer *CSM_CertificateChoice::GetEncodedAttrCert() 
{ 
    CSM_Buffer *pBuf=NULL;

    if (AccessEncodedAttrCert() != NULL)
        pBuf = new CSM_Buffer(*AccessEncodedAttrCert());
    return pBuf;
}

//////////////////////////////////////////////////////////////////////////
const CSM_Buffer *CSM_CertificateChoice::AccessEncodedAttrCert() const
{ 
    SME_SETUP("CSM_CertificateChoice::AccessEncodedAttrCert");
    if (m_pAttrCert == NULL && m_pSNACCAttrCert != NULL)
       ENCODE_BUF(m_pSNACCAttrCert, m_pAttrCert);
    SME_FINISH_CATCH;
    return m_pAttrCert; 
}

//////////////////////////////////////////////////////////////////////////
CSM_Buffer *CSM_CertificateChoice::GetEncodedCert() 
{ 
    CSM_Buffer *pBuf=NULL;

    if (AccessEncodedCert() != NULL)
        pBuf = new CSM_Buffer(*AccessEncodedCert());
    return pBuf;
}

//////////////////////////////////////////////////////////////////////////
const CSM_Buffer *CSM_CertificateChoice::AccessEncodedCert() const
{ 
    SME_SETUP("CSM_CertificateChoice::AccessEncodedCert");

    if (m_pCert == NULL && m_pSNACCCert != NULL)
       SME(ENCODE_BUF(m_pSNACCCert, m_pCert));
    
    SME_FINISH_CATCH;
    return m_pCert; 
}

void CSM_CertificateChoice::UpdateSNACCCertificate(Certificate *Cert)
{
   if(m_pSNACCCert)
      delete m_pSNACCCert;

   m_pSNACCCert = Cert;
}

void CSM_CertificateChoice::UpdateSNACCAttrCertificate(AttributeCertificate *pAttrCert)
{
   if(m_pSNACCAttrCert)
      delete m_pSNACCAttrCert;

   m_pSNACCAttrCert = pAttrCert;
}

CSM_CertificateChoice &CSM_CertificateChoice::operator = (const CSM_CertificateChoice &CertChoice)
{
    Clear();
    m_bIssOrSki = CertChoice.m_bIssOrSki;
    if (CertChoice.AccessEncodedAttrCert())
    {
       if (m_pAttrCert)
          delete m_pAttrCert;
       m_pAttrCert = new CSM_Buffer(*CertChoice.AccessEncodedAttrCert());
    }    // END IF encoded Attribute cert present.
    if (CertChoice.AccessEncodedCert())
    {
        if (m_pCert)
           delete m_pCert;
        m_pCert = new CSM_Buffer(*CertChoice.AccessEncodedCert());
    }    // END IF encoded cert present
    return(*this);
}
SM_RET_VAL CSM_CertificateChoice::GetAttrCertSubjectSerialNumber(CertificateSerialNumber &serialNumber)
{
   SM_RET_VAL status = SM_NO_ERROR;

   SME_SETUP("CSM_CertificateChoice::GetAttrCertSubjectSerialNumber");

   if ((m_pSNACCAttrCert == NULL) && (m_pSNACCCert == NULL))
      SME(Decode());

   if (m_pSNACCAttrCert)
   {
      if (m_pSNACCAttrCert->toBeSigned->eitherHolder->choiceId ==
                        AttributeCertificateInfoChoice::baseCertificateIDCid)
      {
         if (m_pSNACCAttrCert->toBeSigned->
                                    eitherHolder->baseCertificateID != NULL)
         {
            serialNumber = m_pSNACCAttrCert->toBeSigned->
                                    eitherHolder->baseCertificateID->serial;
         }
         else
            status = -1;
      }
      else if (m_pSNACCAttrCert->toBeSigned->eitherHolder->choiceId ==
                        AttributeCertificateInfoChoice::holderCid)
      {
         if (m_pSNACCAttrCert->toBeSigned->
                                    eitherHolder->baseCertificateID != NULL)
         {
            serialNumber = m_pSNACCAttrCert->toBeSigned->
                                    eitherHolder->holder->baseCertificateID->serial;
         }
         else 
            status = -1;
      }
   }
   else
   {
      // No AttributeCertificate available; should not be fatal error at this point
      status = -1;
   }

   SME_FINISH_CATCH;

   return status;
}

SM_RET_VAL CSM_CertificateChoice::GetAttrCertSubjectIssuerUID(UniqueIdentifier *&pIssuerUID)
{
   SM_RET_VAL status = SM_NO_ERROR;

   SME_SETUP("CSM_CertificateChoice::GetAttrCertSubjectIssuerUID");

   if ((m_pSNACCAttrCert == NULL) && (m_pSNACCCert == NULL))
      SME(Decode());

   if (m_pSNACCAttrCert)
   {
      if (m_pSNACCAttrCert->toBeSigned->eitherHolder->choiceId ==
                        AttributeCertificateInfoChoice::baseCertificateIDCid)
      {
         pIssuerUID = m_pSNACCAttrCert->toBeSigned->
                              eitherHolder->baseCertificateID->issuerUID;
      }
      else if (m_pSNACCAttrCert->toBeSigned->eitherHolder->choiceId ==
                        AttributeCertificateInfoChoice::holderCid)
      {
         pIssuerUID = m_pSNACCAttrCert->toBeSigned->
                     eitherHolder->holder->baseCertificateID->issuerUID;
      }
      else 
         status = -1;
   }
   else
   {
      // No AttributeCertificate available; should not be fatal error at this point
      status = -1;
   }

   SME_FINISH_CATCH;

   return status;
}   // END CSM_CertificateChoice::GetAttrCertSubjectIssuerUID(...)

////////////////////////////////////////////////////////////////////////////
// THIS routine returns the FIRST rfc822 type GeneralName located in this
//  certificate's AlgSubjectName extension.
char *CSM_CertificateChoice::pszGetAltSubjectName_rfc822()
{
    char *pszResult=NULL;

     Extensions *pExtensions=m_pSNACCCert->toBeSigned->extensions;
     Extension *pSNACCExt = NULL;
     // Loading of Extentsions Listbox values always the same.
     for(pExtensions->SetCurrToFirst(),
         pSNACCExt = pExtensions->Curr();
         pSNACCExt; pSNACCExt = pExtensions->GoNext())
      {
          if(pSNACCExt->extnId == id_ce_subjectAltName)
          {
               SNACC::GeneralNames *pSNACCsubjAltNames=(SNACC::GeneralNames *)pSNACCExt->extnValue.value;
               SNACC::GeneralName  *pSNACCsubjAltName;
               bool bDoneFlag=false;
               pSNACCsubjAltNames->SetCurrToFirst();
               for (pSNACCsubjAltName=pSNACCsubjAltNames->Curr(); 
                    pSNACCsubjAltName && !bDoneFlag;
                    pSNACCsubjAltName=pSNACCsubjAltNames->GoNext())
               {
                  if (pSNACCsubjAltName->choiceId == SNACC::GeneralName::rfc822NameCid)
                  {
                     pszResult = strdup(pSNACCsubjAltName->rfc822Name->c_str()); 
                     break;
                  }  // END if rfc822NameCid
               }     // END for (each subjAltName GeneralName in subjectAltName extension
          }    // END IF subjectAltName
      }        // END FOR each extension in the cert.

    return(pszResult);
}       // EOF CSM_CertificateChoice::pszGetAltSubjectName_rfc822()


////////////////////////////////////////////////////////////////////////////
//
//   This method returns the issuerSerial of an Attribute Certificate 
//
//   Also the following output parameters are filled in when data is present: 
//      GeneralNames             *pIssuerSerial
//      CertificateSerialNumber  *sn
//      UniqueIdentifier         *uniqueId
//
////////////////////////////////////////////////////////////////////////////
long CSM_CertificateChoice::GetIssuersBaseCert( SNACC::IssuerSerial *&pIssSN)
{
   long status = 0;
   IssuerSerial *pIssuerSerial = NULL;

   SME_SETUP("CSM_CertificateChoice::GetIssuerBaseCert");

   // if m_pSNACCCert and m_pSNACCAttrCert are null, then no objects 
   // have been decoded; so, call Decode
   if ((m_pSNACCCert == NULL) && (m_pSNACCAttrCert == NULL))
      SME(Decode());

   if (m_pSNACCAttrCert != NULL)
   {
      if (m_pSNACCAttrCert->toBeSigned->issuer->choiceId == AttCertIssuer::v2FormCid) 
      {  
         if (pIssSN)
            delete pIssSN;

         pIssSN = new SNACC::IssuerSerial(*m_pSNACCAttrCert->toBeSigned->issuer->
            v2Form->baseCertificateID);
      }
   }

   SME_FINISH_CATCH;

   return status;
}


_END_CERT_NAMESPACE 

// EOF sm_certChoice.cpp
