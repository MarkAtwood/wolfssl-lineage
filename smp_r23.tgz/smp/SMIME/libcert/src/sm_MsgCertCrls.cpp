
//////////////////////////////////////////////////////////////////////////
// sm_MsgCertCrls.cpp
// methods for the CSM_MsgCertCrls class

#include "sm_apiCert.h"
_BEGIN_CERT_NAMESPACE 
using namespace SNACC;

//////////////////////////////////////////////////////////////////////////
CSM_MsgCertCrls::~CSM_MsgCertCrls()
{
   ClearCerts();
   ClearACs();
   ClearCRLs();
   ClearCRLLst(); 
}
//////////////////////////////////////////////////////////////////////////
void CSM_MsgCertCrls::ClearCerts()
{
   if (m_pCerts)
   {
      delete (m_pCerts);
      m_pCerts = NULL;
   }
}

//////////////////////////////////////////////////////////////////////////
void CSM_MsgCertCrls::ClearACs()
{
   if (m_pACs)
   {
      delete (m_pACs);
      m_pACs = NULL;
   }
}

//////////////////////////////////////////////////////////////////////////
void CSM_MsgCertCrls::ClearCRLs()
{
   if (m_pCRLs)
   {
      delete (m_pCRLs);
      m_pCRLs = NULL;
   }
}
//////////////////////////////////////////////////////////////////////////
void CSM_MsgCertCrls::ClearCRLLst()
{
    if (m_pCRLLst)
    {
        delete (m_pCRLLst);
        m_pCRLLst = NULL;
    }
}
//////////////////////////////////////////////////////////////////////////
// SetCertificates COPIES the Buffers from the provided buffer list into
// a list of cert choice classes.  In other words, each buffer from the
// provided list is duplicated and added to or placed into a new list
// of cert choice classes.  Therefore, the caller can delete the provided
// buffer list after SetCertificates returns
void CSM_MsgCertCrls::SetCertificates(CSM_BufferLst *pCerts)
{
   CSM_Buffer *pbufTemp;
   CSM_CertificateChoice *pTmpNewCert;

   SME_SETUP("CSM_MsgCertCrls::SetCertificates(CSM_BufferLst*)");

   if (pCerts)
   {
      pCerts->SetCurrToFirst();
      pbufTemp = pCerts->Curr();
      do
      {
         // place the new buffer (cert) into a CSM_CertificateChoice
         // create a new list of CSM_CertificateChoices if necessary
         if (m_pCerts == NULL)
         {
            if ((m_pCerts = new CSM_CertificateChoiceLst) 
                  == NULL)
               SME_THROW(SM_MEMORY_ERROR, "MEMORY", NULL);
         }
         // add the cert choice to the end of the list
         if ((pTmpNewCert = m_pCerts->Append()) == NULL)
            SME_THROW(SM_MEMORY_ERROR, "MEMORY", NULL);
         pTmpNewCert->SetEncodedCert(*pbufTemp);
      } while ((pbufTemp = pCerts->GoNext()) != NULL);
   }
   SME_FINISH
   SME_CATCH_SETUP
      // local cleanup logic
   SME_CATCH_FINISH
}

//////////////////////////////////////////////////////////////////////////
// SetCertificates COPIES the CertChoices from the provided list into
// the right list of cert choice classes.  In other words, each cert choice
// from the provided list is duplicated and added or placed into a new
// list of cert choice classes depending on the type of the given
// cert choice (cert or AC), therefore, the caller can delete the provided
// cert choice list after SetCertificates returns
void CSM_MsgCertCrls::SetCertificates(CSM_CertificateChoiceLst *pCerts)
{
   CSM_CertificateChoice *pCert;

   SME_SETUP("CSM_MsgCertCrls::SetCertificates(CSM_CertificateChoiceLst*)");

   if (pCerts)
   {
      pCerts->SetCurrToFirst();
      pCert = pCerts->Curr();
      do
      {
         CSM_CertificateChoice *pNewCert = new CSM_CertificateChoice(*pCert);
         SME(AddCert(pNewCert));
         delete pNewCert; // sib 9/27/02 AddCert no longer deletes pNewCert
      } while ((pCert = pCerts->GoNext()) != NULL);
   }
   SME_FINISH_CATCH
}
//////////////////////////////////////////////////////////////////////////
// SetCRLLst COPIES the CSM_CertificateListLst from the provided list into
// the object's CSM_CertificateListLst member variable.  In other words, 
// each CRL from the provided list is duplicated and added or placed into a new
// list of CSM_CertificateListLst, therefore, the caller can delete the provided
// CRL list after SetCRLLst returns.
void CSM_MsgCertCrls::SetCRLLst(CSM_CertificateListLst *pCRLs)
{
   CSM_CertificateList *pCRL;

   SME_SETUP("CSM_MsgCertCrls::SetCRLLst(CertificateRevocationList*)");

   if (pCRLs)
   {
      pCRLs->SetCurrToFirst();
      pCRL = pCRLs->Curr();
      do
      {
          CSM_CertificateList *pNewCRL = NULL;
          //pNewCRL = new CSM_CertificateList;

          pNewCRL = new CSM_CertificateList(*pCRL);
          SME(AddCRL(pNewCRL));
          delete pNewCRL;  // sib 0/27/02 AddCRL no longer deletes pNewCRL
      } while ((pCRL = pCRLs->GoNext()) != NULL);
   }
   SME_FINISH_CATCH
}
//////////////////////////////////////////////////////////////////////////
void CSM_MsgCertCrls::SetCRLs(CSM_BufferLst *pCRLs)
{
   CSM_Buffer *pbufTemp;
   CSM_Buffer *pNewBuffer;

   SME_SETUP("CSM_MsgCertCrls::SetCRLs");

   if (pCRLs)
   {
      pCRLs->SetCurrToFirst();
      pbufTemp = pCRLs->Curr();
      do
      {
         // create a new list of CSM_Buffers if necessary
         if (m_pCRLs == NULL)
         {
            if ((m_pCRLs = new CSM_BufferLst) == NULL)
               SME_THROW(SM_MEMORY_ERROR, "MEMORY", NULL);
         }
         // add the CRL buffer to the end of the list
         if ((pNewBuffer = m_pCRLs->Append()) == NULL)
            SME_THROW(SM_MEMORY_ERROR, "MEMORY", NULL);
         // copy the CRL from the provided list
         *pNewBuffer = *pbufTemp;
      } while ((pbufTemp = pCRLs->GoNext()) != NULL);
   }
   SME_FINISH_CATCH
}

//////////////////////////////////////////////////////////////////////////
// AddCert adds the provided cert to the m_pCerts or m_pACs according
// to the type of the provided cert.  This function no longer deletes
// the input parameter pCert
void CSM_MsgCertCrls::AddCert(CSM_CertificateChoice *pCert)
{
   CSM_Identifier *pRID=NULL;
   CSM_CertificateChoice *pCertAlreadyHere=NULL;
   bool bLoadCert=true;

   SME_SETUP("CSM_MsgCertCrls::AddCert");

   pRID = pCert->GetRid(true);
   if (pRID)
   {
      pCertAlreadyHere = FindCert(*pRID);
      delete pRID;
   }
   if (pCertAlreadyHere == NULL && pCert->AccessSNACCAttrCertificate())
   {            // TRY looking for Attr cert specifically, if possible.
       pCertAlreadyHere = FindCert(*pCert);
   }
   // depending on the type, add it accordingly
   if (pCertAlreadyHere)      // MAY not be loading this new cert, already here.
   {              // CHECK that the certs/ACs are consistent.
       if (pCertAlreadyHere->AccessEncodedCert() && //Be sure both certs.
           pCert->AccessEncodedCert())
           bLoadCert = false;    // not opposite AC.
       else if (pCertAlreadyHere->AccessEncodedAttrCert() && //Be sure both ACs.
           pCert->AccessEncodedAttrCert())
           bLoadCert = false;    // not opposite cert.
       delete pCertAlreadyHere;
       pCertAlreadyHere = NULL;
   }
   if (bLoadCert && pCert->AccessEncodedCert() != NULL)
   {
      // create a new list of CSM_CertificateChoices if necessary
      if (m_pCerts == NULL)
         if ((m_pCerts = new CSM_CertificateChoiceLst) == NULL)
            SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
      // add the cert choice to the end of the list
      CSM_CertificateChoice *pCert2 = m_pCerts->Append();
      *pCert2 = *pCert;
   }
   else if (bLoadCert && pCert->AccessEncodedAttrCert() != NULL)

   {
      // create a new list of CSM_CertificateChoices if necessary
      if (m_pACs == NULL)
         if ((m_pACs = new CSM_CertificateChoiceLst) == NULL)
            SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
      // add the cert choice to the end of the list
      CSM_CertificateChoice *pCert2 = m_pACs->Append();
      *pCert2 = *pCert;
   }

   SME_FINISH_CATCH
}
//////////////////////////////////////////////////////////////////////////
// AddCRL adds the provided CRL to the m_pCRLLst.  This function no longer
// deletes pCRL
//  
void CSM_MsgCertCrls::AddCRL(CSM_CertificateList *pCRL)
{
   bool bFound=false;
   CSM_CertificateList *pTmpCRL;
   SME_SETUP("CSM_MsgCertCrls::AddCRL");

   if (m_pCRLLst == NULL)
   {
     if ((m_pCRLLst = new CSM_CertificateListLst) == NULL)
         SME_THROW(SM_MEMORY_ERROR, "MEMORY", NULL);
   }

   for (m_pCRLLst->SetCurrToFirst(), pTmpCRL=m_pCRLLst->Curr(); 
        pTmpCRL && !bFound; 
        pTmpCRL=m_pCRLLst->GoNext())
   {
      if (*pTmpCRL->AccessEncodedCRL() == *pCRL->AccessEncodedCRL())
          bFound = true;
   }

   if (!bFound)
   {
       // add the crl to the end of the list
       CSM_CertificateList *pCRL2 = m_pCRLLst->Append();
       *pCRL2 = *pCRL;
   }


   SME_FINISH_CATCH
}
//////////////////////////////////////////////////////////////////////////
// PutSNACCCerts ASN.1 decodes the m_pCerts AND Attribute Certificates, 
//  then returns them in the provided pCertificateSet
void CSM_MsgCertCrls::PutSNACCCerts(CertificateSet *&pCertificateSet)
{
   CSM_CertificateChoice *pCert;
   CertificateChoices *tmnSNACCCertChoices=NULL;
   AttributeCertificate *pSNACCAttrCert;
   Certificate *pSNACCCert;

   SME_SETUP("CSM_MsgCertCrls::PutSNACCCerts");

   if (pCertificateSet == NULL)    // initialize for application
      if ((pCertificateSet = new CertificateSet) == NULL)
            SME_THROW(SM_MEMORY_ERROR, 
                  "SNACC Certificate bad memory alloc", NULL);

   if (pCertificateSet)
   {
      // we can only do this if we have ASN.1 encoded certs
      if (m_pCerts)
      {
         // loop through the m_pCerts here
         for (m_pCerts->SetCurrToFirst(), pCert = m_pCerts->Curr(); pCert;
               pCert = m_pCerts->GoNext())
         { // For each cert buffer, load into SNACC cert list.
            tmnSNACCCertChoices = pCertificateSet->Append();

            // do a regular cert
            if ((pSNACCCert = pCert->GetSNACCCertificate()) != NULL)
            {
               // set the type to cert
               tmnSNACCCertChoices->choiceId = 
                     CertificateChoices::certificateCid;
               // allocate a snacc cert class
               tmnSNACCCertChoices->certificate = pSNACCCert;
            }
         }  // END for each cert in list
      }     // END IF m_pCerts

      if (m_pACs)
      {
         for (m_pACs->SetCurrToFirst(), pCert = m_pACs->Curr(); 
              pCert; pCert = m_pACs->GoNext())
         { // For each cert buffer, load into SNACC cert list.
            tmnSNACCCertChoices = pCertificateSet->Append();
            // do an attribute cert
            if ((pSNACCAttrCert = pCert->GetSNACCAttrCertificate()) 
                     != NULL)
            {
               // set the type to attribute cert
               tmnSNACCCertChoices->choiceId = 
                     CertificateChoices::attrCertCid;
               // allocate a snacc attribute cert class
               tmnSNACCCertChoices->attrCert = pSNACCAttrCert;
            }
            // extended cert not handled
         }  // END for each Attribute cert in list
      }     // END IF m_pAttrCerts
   }        // END IF pCertificateSet

   SME_FINISH_CATCH
}       // END CSM_MsgCertCrls::PutSNACCCerts(...)

#ifdef RWC_NOT_USED_YET
//////////////////////////////////////////////////////////////////////////
// PutSNACCAttrCerts ASN.1 decodes the Attribute Certificates and returns them in the
// provided pCertificateSet
void CSM_MsgCertCrls::PutSNACCAttrCerts(CertificateSet *&pCertificateSet)
{
   CSM_CertificateChoice *pCert;
   CertificateChoices *tmnSNACCCertChoices=NULL;
   AttributeCertificate *pSNACCAttrCert;

   SME_SETUP("CSM_MsgCertCrls::PutSNACCCerts");

   if (pCertificateSet == NULL)    // initialize for application
      if ((pCertificateSet = new CertificateSet) == NULL)
            SME_THROW(SM_MEMORY_ERROR, 
                  "SNACC Certificate bad memory alloc", NULL);

   if (pCertificateSet)
   {
      // we can only do this if we have ASN.1 encoded certs
      if (m_pACs)
      {
         // loop through the m_pCerts here
         for (m_pACs->SetCurrToFirst(), pCert = m_pACs->Curr(); pCert;
               pCert = m_pACs->GoNext())
         { // For each cert buffer, load into SNACC cert list.
            tmnSNACCCertChoices = pCertificateSet->Append();
            // do an attribute cert
            else if ((pSNACCAttrCert = pCert->GetSNACCAttrCertificate()) 
                     != NULL)
            {
               // set the type to attribute cert
               tmnSNACCCertChoices->choiceId = 
                     CertificateChoices::attrCertCid;
               // allocate a snacc attribute cert class
               tmnSNACCCertChoices->attrCert = pSNACCAttrCert;
            }
            // extended cert not handled
         }
      }
   }

   SME_FINISH_CATCH
}       // END CSM_MsgCertCrls::PutSNACCAttrCerts(...)
#endif // RWC_NOT_USED_YET

//////////////////////////////////////////////////////////////////////////
// PutSNACCCRLLst ASN.1 decodes the m_pCRLLst and returns them in the
// provided pCertificateRevocationList
void CSM_MsgCertCrls::PutSNACCCRLLst(CertificateRevocationLists *&pCRLLst)
{
    CSM_CertificateList *pCRL = NULL;
    CertificateList *ptmpSNACCCRL = NULL;

   SME_SETUP("CSM_MsgCertCrls::PutSNACCCRLLst");

   if (m_pCRLLst != NULL && pCRLLst == NULL)    // initialize for application
      if ((pCRLLst = new CertificateRevocationLists) == NULL)
            SME_THROW(SM_MEMORY_ERROR, 
                  "SNACC CertificateRevocationList bad memory alloc", NULL);

    if (pCRLLst)
    {
        // we can only do this if we have ASN.1 encoded crls
        if (m_pCRLLst)
        {
            // loop through the crl list
            for (m_pCRLLst->SetCurrToFirst(), pCRL = m_pCRLLst->Curr(); pCRL;
                    pCRL = m_pCRLLst->GoNext())
            {
                // For each crl buffer, load into SNACC crls list
                ptmpSNACCCRL = NULL;

                if ((ptmpSNACCCRL = pCRL->GetSNACCCRL()) == NULL)
                    SME_THROW(SM_MEMORY_ERROR,
                                "Unable to retrieve GetSNACCCRL", NULL);

                pCRLLst->AppendCopy(*ptmpSNACCCRL);
            }
        }
    }

   SME_FINISH_CATCH
}       // END CSM_MsgCertCrls::PutSNACCCRLLst(...)

//////////////////////////////////////////////////////////////////////////
// SetSNACCCerts places the provided snacc decoded certs
// into this appropriately
void CSM_MsgCertCrls::SetSNACCCerts(CertificateSet *pCertificateSet)
{
   CertificateChoices *pTmpSNACCCert;
   CSM_CertificateChoice *pCertChoice;

   SME_SETUP("CSM_MsgCertCrls::SetSNACCCerts");

   if (pCertificateSet == NULL)
      SME_THROW(SM_MISSING_PARAM, NULL, NULL);

   for (pCertificateSet->SetCurrToFirst(),
         pTmpSNACCCert = pCertificateSet->Curr();
         pTmpSNACCCert;
         pTmpSNACCCert = pCertificateSet->GoNext())
   {
      if ((pCertChoice = new CSM_CertificateChoice(*pTmpSNACCCert)) == NULL)
         SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
      SME(AddCert(pCertChoice));
      delete pCertChoice; // sib 09/27/02 AddCert no longer deletes pCertChoice
   }
   SME_FINISH
   SME_CATCH_SETUP
      // local cleanup logic
   SME_CATCH_FINISH
}

//////////////////////////////////////////////////////////////////////////
// SetSNACCCrls places the provided snacc decoded crls
// into this appropriately
void CSM_MsgCertCrls::SetSNACCCrls(CertificateRevocationLists *pCrls)
{
   CertificateList *pTmpSNACCCRL;
   CSM_Buffer *pbuf=NULL;

   SME_SETUP("CSM_MsgCertCrls::SetSNACCCrls");

   if (pCrls == NULL)
      SME_THROW(SM_MISSING_PARAM, NULL, NULL);

   for (pCrls->SetCurrToFirst(), pTmpSNACCCRL = pCrls->Curr();
         pTmpSNACCCRL; pTmpSNACCCRL = pCrls->GoNext())
   {
      ENCODE_BUF(pTmpSNACCCRL, pbuf);
      if (m_pCRLs == NULL)
         if ((m_pCRLs = new CSM_BufferLst) == NULL)
            SME_THROW(SM_MEMORY_ERROR, NULL, NULL)
      CSM_Buffer *pBuf2=m_pCRLs->Append();
      *pBuf2 = *pbuf;
      delete pbuf;
   }

   SME_FINISH_CATCH
}
//////////////////////////////////////////////////////////////////////////
// SetSNACCCRLLst COPIES the snacc decoded CRLs provided in CertificateRevocationList 
// into a list of CSM_CertificateList. This gives the caller access to
// functions in CSM_CertificateList that allow her to retrieve specific data
// in the CRL.
void CSM_MsgCertCrls::SetSNACCCRLst(CertificateRevocationLists *pCRLs)
{
    CertificateList *pTmpSNACCCRL;
    CSM_CertificateList *pTmpCRL;

    SME_SETUP("CSM_MsgCertCrls::SetSNACCCRLst");

    if (pCRLs == NULL)
        SME_THROW(SM_MISSING_PARAM, NULL, NULL);

    for (pCRLs->SetCurrToFirst(),
        pTmpSNACCCRL = pCRLs->Curr();
        pTmpSNACCCRL;
        pTmpSNACCCRL = pCRLs->GoNext())
    {
       if ((pTmpCRL = new CSM_CertificateList(*pTmpSNACCCRL)) == NULL)
            SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
        SME(AddCRL(pTmpCRL));
        delete pTmpCRL; // sib 09/27/02 AddCRL no longer deletes pTmpCRL
    }

    SME_FINISH
    SME_CATCH_SETUP

    SME_CATCH_FINISH
}
//////////////////////////////////////////////////////////////////////////
// this method returns a pointer to the specific requested certificate,
//  IMPORTANT:  The application MUST not free the memory pointer returned.
CSM_CertificateChoice *CSM_MsgCertCrls::FindCert(CSM_Buffer &SKI)
{
   CSM_CertificateChoice *pCert=NULL;
   
   SME_SETUP("CSM_MsgCertCrls::FindCert(CSM_Buffer &SKI)");

   CSM_Identifier RID(SKI);
   pCert = FindCert(RID);
      SME_FINISH_CATCH

   return(pCert);
}

//////////////////////////////////////////////////////////////////////////
// this method returns a pointer to the specific requested certificate,
//  IMPORTANT:  The application MUST not free the memory pointer returned.
CSM_CertificateChoice *CSM_MsgCertCrls::FindCert(CSM_IssuerAndSerialNumber
&IssSN)
{
   CSM_CertificateChoice *pCert=NULL;
 
   SME_SETUP("CSM_MsgCertCrls::FindCert(CSM_IssuerAndSerialNumber &IssSN)");

   CSM_Identifier RID(IssSN);
   pCert = FindCert(RID);
      SME_FINISH_CATCH

   return(pCert);
}

//////////////////////////////////////////////////////////////////////////
// this method returns a pointer to the specific requested certificate,
//  IMPORTANT:  The application MUST not free the memory pointer returned.
CSM_CertificateChoice *CSM_MsgCertCrls::FindCert(CSM_Identifier &RID)
{
   CSM_CertificateChoiceLst *pCerts = NULL;
   CSM_CertificateChoice    *pResultCert=NULL;
   CSM_Identifier  *pTmpRID;

   SME_SETUP("CSM_MsgCertCrls::FindCert(CSM_Identifier &RID)");

   // move certs from this to pRet
   if ((pCerts = AccessCertificates()) != NULL)
   {
      pCerts->SetCurrToFirst();
      CSM_CertificateChoice *pCert = pCerts->Curr();
      while (pCert)
      {
         SME(pTmpRID = pCert->GetRid(RID));
         if (pTmpRID)
         {
            if (*pTmpRID == RID)
            {
               delete pTmpRID;
               break;
            }
            else
            {
               if (pTmpRID)
                  delete pTmpRID;
            }
         }   
         
         pCert = pCerts->GoNext();
      }
      if (pCert)
         pResultCert = new CSM_CertificateChoice (*pCert);
   }

   SME_FINISH_CATCH

   return(pResultCert);
}           // END CSM_MsgCertCrls::FindCert(CSM_Identifier &RID)

//////////////////////////////////////////////////////////////////////////
CSM_CertificateChoice *CSM_MsgCertCrls::FindCert(CSM_DN &DN)
{
   CSM_CertificateChoiceLst *pCerts = NULL;
   CSM_CertificateChoice    *pResultCert=NULL;
   CSM_DN  *pTmpDN;

   SME_SETUP("CSM_MsgCertCrls::FindCert(CSM_DN &DN)");

   // move certs from this to pRet
   if ((pCerts = AccessCertificates()) != NULL)
   {
      pCerts->SetCurrToFirst();
      CSM_CertificateChoice *pCert = pCerts->Curr();
      while (pCert)
      {
         SME(pTmpDN = pCert->GetSubject());
         if (pTmpDN)
         {
            if (*pTmpDN == DN)
            {
               delete pTmpDN;
               break;
            }
            else
            {
               if (pTmpDN)
                  delete pTmpDN;
            }
         }   
         
         pCert = pCerts->GoNext();
      }
      if (pCert)
         pResultCert = new CSM_CertificateChoice (*pCert);
   }

   SME_FINISH_CATCH

   return(pResultCert);
}       // END CSM_MsgCertCrls::FindCert(CSM_DN &DN)

//////////////////////////////////////////////////////////////////////////
CSM_CertificateChoice *CSM_MsgCertCrls::FindCert(CSM_CertificateChoice &AttrCert)
{
   CSM_CertificateChoiceLst *pCerts = NULL;
   CSM_CertificateChoice    *pResultCert=NULL;

   SME_SETUP("CSM_MsgCertCrls::FindCert(pSNACCEitherHolder)");

   if (AttrCert.AccessEncodedAttrCert() == NULL)
       return(pResultCert); // IGNORE if not available.

   // move certs from this to pRet
   if ((pCerts = this->AccessACs()) != NULL)
   {
      pCerts->SetCurrToFirst();
      CSM_CertificateChoice *pCert = pCerts->Curr();
      while (pCert)
      {
         if (pCert->AccessEncodedAttrCert()  && 
            *pCert->AccessEncodedAttrCert() == *AttrCert.AccessEncodedAttrCert())
         {
             /*if (pCert->AccessSNACCAttrCertificate()->toBeSigned->eitherHolder->choiceId ==      
                 SNACC::AttributeCertificateInfoChoice::holderCid &&
                 pSNACCEitherHolder->choiceId ==
                 SNACC::AttributeCertificateInfoChoice::holderCid &&
                 *pCert->AccessSNACCAttrCertificate()->toBeSigned->eitherHolder->holder ==
                 *pSNACCEitherHolder->holder)
                 break; RWC; Fails without == operators in SNACC gen code.*/
                 break;
         }      // END IF pointer available
         pCert = pCerts->GoNext();
      }
      if (pCert)
         pResultCert = new CSM_CertificateChoice (*pCert);
   }

   SME_FINISH_CATCH

   return(pResultCert);
}       // END CSM_MsgCertCrls::FindCert(SNACC::AttributeCertificateInfoChoice *pSNACCEitherHolder)


//////////////////////////////////////////////////////////////////////////
// UpdateParams
// This method attempts to load DSA ONLY algorithm parameters from the 
//  specified certificate.  If not found, it attempts to search the internal
//  list for the issuer and so on.
bool CSM_MsgCertCrls::UpdateParams(CSM_Alg &alg, CSM_CertificateChoice &Cert, CSM_DN *pTopDN)
{
    bool bResult=false;
    CSM_CertificateChoice *pCert = NULL;
    CSM_Buffer *pCBuf=NULL;
    CSM_IssuerAndSerialNumber *pIssSN;
     CSM_DN *pSubjectDN;
    
    SME_SETUP("CSM_MsgCertCrls::UpdateParams");

    // [PIERCE] Why do we need algorithm specific details here?
    //
    AsnOid tmpoid("1.3.14.3.2.12");

//	changed by DHT ( cryptovision ) , 2k+1.05.17
//	change was neccesary for ECDSA-support.
//
//	  if ((alg.algorithm == id_dsa || alg.algorithm == id_dsa_with_sha1 ||
//         alg.algorithm == *CSM_Alg(tmpoid).AccessSNACCId()) &&
//              alg.HasNullParams())        // Attempt to search cert path.
//
	if ( alg.HasNullParams() )           // Attempt to search cert path.
    {
      // FIRST, the user certificate (passed-in as an argument in Cert) will be
      // checked for the parameters.  NEXT, if the parameters are not found, we 
      // will go up the cert-path until they are found OR we run-out of certs.
        pCert = &Cert;

        while (!bResult && pCert)
        {        
         // Search for parameters
         if (pCert->AccessSNACCCertificate()->toBeSigned->
                    subjectPublicKeyInfo->algorithm->parameters)
            {
                SM_EXTRACT_ANYBUF(pCBuf, pCert->AccessSNACCCertificate()->toBeSigned->
                           subjectPublicKeyInfo->algorithm->parameters);

                if (alg.parameters)
                  delete alg.parameters;
                  //RWC;11/14/02;delete (AsnAnyBuffer *)alg.parameters->value;
                //RWC;11/14/02;else
                alg.parameters = new AsnAny;

                SM_ASSIGN_ANYBUF(pCBuf, alg.parameters);
                delete pCBuf;
                pCBuf = NULL;
                bResult = !alg.HasNullParams();
            }

            if (!bResult)
            {
              if ((pIssSN = pCert->GetIssuerAndSerialNumber()) != NULL)
              {
               // Get the subjectDN for the issuer so we can use it 
               // in FindCert.
               pSubjectDN = pIssSN->GetIssuer();
               CSM_DN *pActualSubjectDN=pCert->GetSubject();
               if (*pSubjectDN == *pActualSubjectDN)
               {
                   delete pActualSubjectDN;
                   if (pCert != &Cert)     // Ignore first Cert.
                      delete pCert;
                   if (pSubjectDN)
                      delete pSubjectDN;
                   delete pIssSN;
                   break;           // FINISHED.
               }
               else
                   delete pActualSubjectDN;

               if (pCert != &Cert)     // Ignore first Cert.
                  delete pCert;
   
               if (pSubjectDN && pTopDN)
               {
                  *pTopDN = *pSubjectDN;
               }

               pCert = FindCert(*pSubjectDN); 

               if (pSubjectDN)
                  delete pSubjectDN;
               delete pIssSN;
              }
              else
              {
                 pCert = NULL;
              }
            }
            else
            {
                if (pCert != &Cert)     // Ignore first Cert.
                {
                    delete pCert;
                    pCert = NULL;
                }
            }
       }
    }

   SME_FINISH_CATCH

   return(bResult);
}       // END CSM_MsgCertCrls::UpdateParams(...)


//////////////////////////////////////////////////////////////////////////
// this method builds a SM_StrLst of the ASN.1 encoded certs and ACs in
// this object
SM_StrLst* CSM_MsgCertCrls::GetStrLstOfCerts()
{
   SM_StrLst *pRet = NULL;
   SM_StrLst *pTemp = NULL;
   CSM_CertificateChoiceLst *pCerts;
   CSM_CertificateChoice *pCert;

   SME_SETUP("CSM_MsgCertCrls::GetStrLstOfCerts");

   // move certs from this to pRet
   if ((pCerts = AccessCertificates()) != NULL)
   {
      pCerts->SetCurrToFirst();
      pCert = pCerts->Curr();
      do
      {
         // allocate memory for the ASN.1 encoded cert
         if (pTemp)
         {
            pTemp->pNext = (SM_StrLst *)calloc(1, sizeof(SM_StrLst));
            pTemp = pTemp->pNext;
         }
         else
            pTemp = pRet = (SM_StrLst *)calloc(1, sizeof(SM_StrLst));
         if (pTemp == NULL)
            SME_THROW(SM_MEMORY_ERROR, NULL, NULL);
         SME(pTemp->str.pchData = pCert->AccessEncodedCert()->
               Get(pTemp->str.lLength));
      } while ((pCert = pCerts->GoNext()) != NULL);
   }

   // move ACs from this to pRet
   if ((pCerts = AccessACs()) != NULL)
   {
      pCerts->SetCurrToFirst();
      pCert = pCerts->Curr();
      do
      {
         // allocate memory for the ASN.1 encoded cert
         if (pTemp)
         {
            pTemp->pNext = (SM_StrLst *)calloc(1, sizeof(SM_StrLst));
            pTemp = pTemp->pNext;
         }
         else
            pTemp = pRet = (SM_StrLst *)calloc(1, sizeof(SM_StrLst));
         if (pTemp == NULL)
            SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

         SME(pTemp->str.pchData = pCert->AccessEncodedAttrCert()->
               Get(pTemp->str.lLength));
      } while ((pCert = pCerts->GoNext()) != NULL);
   }

   SME_FINISH_CATCH

   return pRet;
}

_END_CERT_NAMESPACE 

// EOF sm_MsgCertCrls.cpp
