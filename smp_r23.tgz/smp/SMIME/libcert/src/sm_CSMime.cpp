
//////////////////////////////////////////////////////////////////////////
// CSM_CSMime.cpp
// These routines support the CSMIME class.

#include <string.h>
#include "sm_apiCert.h"
#include "sm_common.h"
#include "sm_CtilCommon.h"
#include "sm_AppLogin.h"
_BEGIN_CERT_NAMESPACE 

typedef CSM_ListC<CSM_CSInst> CSM_CSInstLstInternal;
typedef CSM_ListC<CTIL::CSM_CtilInst> CSM_CtilInstLstInternal;

using namespace CTIL;//SNACC;
using SNACC::SnaccException;
//////////////////////////////////////////////////////////////////////////
CSMIME::CSMIME() 
{
}



//////////////////////////////////////////////////////////////////////////
CSMIME::~CSMIME()
{ 
}           // END ~CSMIME

//////////////////////////////////////////////////////////////////////////
CSM_CSInst *CSMIME::FindInstByDN_SignerOrEncrypter(char *pDn, bool bSignerFlag)
{
   CSM_CtilInst *pInst   = NULL;
   CSM_CSInst *pInstCS = NULL;
   CSM_DN *pDn2    = NULL;
   char *pszDn = ConvertDNString(pDn);  //CONVERT to "," delimited form  
   CSM_DN Dn2(pszDn);
   bool        found   = false;

   m_pCSInsts->SetCurrToFirst();
   while ( ((pInst = m_pCSInsts->Curr()) != NULL) && (found == false) )
   {
      pInstCS = (CSM_CSInst *)pInst->AccessTokenInterface()->AccessCSInst();
      if (pInstCS)
      {
        pDn2 = pInstCS->AccessSubjectDN();
         if (pDn2)
         {
           const char *pszDn2=*pDn2;   //DEBUG only.
           if (pszDn)
           {
             if (strcmp(pszDn, pszDn2) == 0 ||
                 Dn2 == *pDn2)
             {
                if (bSignerFlag && pInstCS->IsSigner())          // Signer
                   found=true;
                else if (!bSignerFlag && pInstCS->IsEncrypter())   // Encrypter
                   found=true;
             }    // END if DN strings match
           }
         }
      }        // END IF instance handles certificates.
      if (!found)
        m_pCSInsts->GoNext();
   }
   
   if (pszDn)
      free(pszDn);

   if (found == false)
      pInstCS = NULL;
   return pInstCS;
}     // END CSMIME::FindInstByDN_SignerOrEncrypter(...)

//////////////////////////////////////////////////////////////////////////
CSM_CSInst *CSMIME::FindInstByDN(char *pDn)
{
   CSM_CtilInst *pInst   = NULL;
   CSM_CSInst *pInstCS   = NULL;
   CSM_DN *pDn2    = NULL;
   char *pszDn = ConvertDNString(pDn);  //CONVERT to "," delimited form  
   CSM_DN Dn2(pszDn);
   bool        found   = false;
   if (m_pCSInsts == NULL)
       return(pInstCS);

   m_pCSInsts->SetCurrToFirst();
   while ( ((pInst = m_pCSInsts->Curr()) != NULL) && (found == false) )
   {
      pInstCS = (CSM_CSInst *)pInst->AccessTokenInterface()->AccessCSInst();
      if (pInstCS)
      {
         pDn2 = pInstCS->AccessSubjectDN();
         if (pDn2)
         {
           const char *pszDn2=*pDn2;   //DEBUG only.
           if (pszDn)
           {
             if (strcmp(pszDn, pszDn2) == 0 ||
                 Dn2 == *pDn2)
                found=true;
           }
         }
      }        // END IF instance handles certificates.
      if (!found)
        m_pCSInsts->GoNext();
   }
   
   if (pszDn)
      free(pszDn);

   if (found == false)
      pInstCS = NULL;
   return pInstCS;
}     // END CSMIME::FindInstByDN(...)


//////////////////////////////////////////////////////////////////////////
// IT IS ASSUMED that FindInstByDN(...) has already been called to set 1st 
// DN by string search.  This routine allows a search for multiple logins
//  with the same DN name.
CSM_CSInst *CSMIME::FindNextInstByDN(char *pDn)
{
   CSM_CtilInst *pInst   = NULL;
   CSM_CSInst *pInstCS   = NULL;
   CSM_DN *pDn2    = NULL;
   char *pszDn = ConvertDNString(pDn);  //CONVERT to "," delimited form  
   CSM_DN Dn2(pszDn);
   bool        found   = false;
   if (m_pCSInsts == NULL)
       return(pInstCS);

   //RWC;NOT HERE;m_pCSInsts->SetCurrToFirst();
   if (m_pCSInsts->Curr() != NULL)
       m_pCSInsts->GoNext();    // SET PAST CURRENT entry, assuming current 
                                //  entry is our own.
   while ( ((pInst = m_pCSInsts->Curr()) != NULL) && (found == false) )
   {
      pInstCS = (CSM_CSInst *)pInst->AccessTokenInterface()->AccessCSInst();
      if (pInstCS)
      {
         pDn2 = pInstCS->AccessSubjectDN();
         if (pDn2)
         {
           const char *pszDn2=*pDn2;   //DEBUG only.
           if (pszDn)
           {
             if (strcmp(pszDn, pszDn2) == 0 ||
                 Dn2 == *pDn2)
                found=true;
           }
         }
      }        // END IF instance handles certificates.
      if (!found)
        m_pCSInsts->GoNext();
   }
   
   if (pszDn)
      free(pszDn);

   if (found == false)
      pInstCS = NULL;
   return pInstCS;
}   // END CSMIME::FindNextInstByDN(...)


//////////////////////////////////////////////////////////////////////////
void CSMIME::SetDefaultCTIL() 
{
   CSM_CSInst *pNewInstance = NULL;
   CSM_CtilInst *pNewInstanceReturned = NULL;

   SME_SETUP("SetDefaultCTIL");

   if ((pNewInstance = new CSM_CSInst) == NULL)
          SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

   CSM_CommonCTIL *pCommonCTIL=new CSM_CommonCTIL;
   pCommonCTIL->SetCSInst(pNewInstance); // ALLOW access to the CSM_CSInst 
                                         //  beyond CSM_TokenInterface.
                                         //  (This feature is optional, but
                                         //  necessary for cert access).

   pNewInstanceReturned = GLOBALAddLoginFinishCTIL(*this, pNewInstance, 
       pCommonCTIL, "CommonCTIL");

   //this->m_pCSInsts->FirstL()
   pNewInstanceReturned->SetApplicable();
   //this->m_pCSInsts->FirstL()
   pNewInstanceReturned->SetUseThis();
            // PRE-Load a common CTIL entry for access to certain algs.

   SME_FINISH
   SME_CATCH_SETUP
      // catch/cleanup logic as necessary
   SME_CATCH_FINISH
}



_END_CERT_NAMESPACE 

// EOF CSM_CSMime.cpp
