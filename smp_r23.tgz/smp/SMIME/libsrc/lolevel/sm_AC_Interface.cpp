
//
//  sm_AC_Interface.cpp
//
//################

#include <iostream.h>

#include "sm_api.h"

#ifndef NO_NAMESPACE
#define _BEGIN_SFL_NAMESPACE namespace SFL { \
    using namespace CERT;
#define _END_SFL_NAMESPACE }
#else
#define _BEGIN_SFL_NAMESPACE
#define _END_SFL_NAMESPACE
#endif

#include "sm_AC_Interface.h"

#ifdef ACL_USED

  using namespace SNACC;  using namespace CTIL;
  using namespace CERT;
#include <malloc.h>
//#include <string.h>

using namespace acl;

_BEGIN_SFL_NAMESPACE

ACL_Interface::ACL_Interface(const ACL_Interface &that)
{
    m_usedPolicy = that.m_usedPolicy;
    if (that.m_pAclSessionId)
        m_pAclSessionId = that.m_pAclSessionId;
    if (that.m_lpszError)
        m_lpszError = strdup(that.m_lpszError);
    else
        m_lpszError = NULL;
    if (that.m_pACLMsgLabel)
       m_pACLMsgLabel = new CSM_Buffer(*that.m_pACLMsgLabel); 
    if (that.m_pPathBufs)
    {
        m_pPathBufs = new CTIL::CSM_BufferLst;
        *m_pPathBufs = *that.m_pPathBufs;
    }       // END if m_pPathBufs
    else
        m_pPathBufs = NULL;
    if (that.m_pEquivLabel)
    {
        m_pEquivLabel = new SecurityLabel;
       *m_pEquivLabel = *that.m_pEquivLabel;     
    }   // END If m_pEquivLabel
    else
        m_pEquivLabel = NULL;
}       // END ACL_Interface(const ACL_Interface &that)


///////////////////////////////////////////////////////////////////////////////
// THE following methods will return an error code if an ACL validation error is
//  is encountered.  It is up to the calling application to check m_lpszError.
long ACL_Interface::Check_ACLOutgoingRecip(
                           const CTIL::CSM_Buffer &CertificateEncrypterB) // INPUT
{
   long lstatus = 0;
   RecipientCert *pTmpRC = NULL;
   SecurityLabel *pLabel=NULL;
   OutgoingLabel *pTmpLabel=NULL;
   SPIF spif;

   if (m_pAclSessionId == NULL || m_pACLMsgLabel == NULL)
   {
       this->m_lpszError = strdup("ACL_Interface::Check_ACLOutgoingRecip: NO ACL Session OR Msg Label present!");
       return(-1);
   }
   FUNC("ACL_Interface::Check_ACLOutgoingRecip(...)");
   try
   {
         pLabel = new SecurityLabel(*m_pACLMsgLabel);
         pTmpLabel = new OutgoingLabel(*pLabel);
         pTmpRC = new RecipientCert((CTIL::CSM_Buffer &)CertificateEncrypterB);
         pTmpRC->intersect(this->m_pAclSessionId, m_pPathBufs);

         // FOR this recipient, check the label against its Clearance Extension
         pTmpRC->check(this->m_pAclSessionId, *pTmpLabel, m_usedPolicy, NULL/*&spif*/);

         if (pTmpRC != NULL)
            delete pTmpRC;

         if (pLabel)
            delete pLabel;
         if (pTmpLabel)
            delete pTmpLabel;      
   }
   catch (SnaccException &e)
   {
      if (pLabel)
         delete pLabel;
      if (pTmpRC != NULL)
         delete pTmpRC;
      if (this->m_lpszError == NULL)
         this->m_lpszError = (char *) calloc(1, 
              strlen(_func) + strlen(": errorCode=") + 
              strlen(e.what()) + 52);
       strcat(m_lpszError, _func);
       strcat(m_lpszError, ": errorCode=");
       sprintf(&m_lpszError[strlen(m_lpszError)], "%d\n", e.m_errorCode);
       strcat(m_lpszError, "     error=");
       strcat(m_lpszError, e.what());
       strcat(m_lpszError, "\n");
       //throw;
       lstatus = -1;
   }            // END catch(...)


   return(lstatus);
}   // END ACL_Interface::Check_ACLOutgoingRecip(...)


///////////////////////////////////////////////////////////////////////////////
long ACL_Interface::Check_ACLIncommingRecip(
                           const CTIL::CSM_Buffer &CertificateEncrypterB,// INPUT
                           acl::SPIF *&pspif)                             // RETURNED
{
   long lstatus = 0;
   RecipientCert *pTmpRC = NULL;
   SecurityLabel *pLabel=NULL;
   IncomingLabel *pTmpLabel=NULL;

   if (m_pAclSessionId == NULL || m_pACLMsgLabel == NULL)
   {
       this->m_lpszError = strdup("ACL_Interface::Check_ACLIncommingRecip: NO ACL Session OR Msg Label present!");
       return(-1);
   }
   FUNC("ACL_Interface::Check_ACLIncommingRecip(...)");
   try
   {
         pLabel = new SecurityLabel(*this->m_pACLMsgLabel);
         pTmpLabel = new IncomingLabel(*pLabel);

        pTmpRC = new RecipientCert((CSM_Buffer &)CertificateEncrypterB);
        pTmpRC->intersect(this->m_pAclSessionId, m_pPathBufs);

        // FOR this recipient, check the label against its Clearance Extension
        //  (RWC; this routine throws an exception, it does not return 
        //   an error code).
        //pspif = new SPIF;
        pTmpRC->check(this->m_pAclSessionId, *pTmpLabel, pspif, m_pEquivLabel);

        if (pTmpRC != NULL)
           delete pTmpRC;
         if (pLabel)
            delete pLabel;
         if (pTmpLabel)
            delete pTmpLabel;      
   }
   catch (SnaccException &e)
   {
      if (pLabel)
         delete pLabel;
      if (pTmpRC != NULL)
         delete pTmpRC;
      if (this->m_lpszError == NULL)
         this->m_lpszError = (char *) calloc(1, 
              strlen(_func) + strlen(": errorCode=") + 
              strlen(e.what()) + 52);
       strcat(m_lpszError, _func);
       strcat(m_lpszError, ": errorCode=");
       sprintf(&m_lpszError[strlen(m_lpszError)], "%d\n", e.m_errorCode);
       strcat(m_lpszError, "     error=");
       strcat(m_lpszError, e.what());
       strcat(m_lpszError, "\n");
       //throw;
       lstatus = -1;
   }        // END catch(...)


   return(lstatus);
}       // END ACL_Interface::Check_ACLIncommingRecip(...)


///////////////////////////////////////////////////////////////////////////////
long ACL_Interface::Check_ACLIncommingOrig(
                           const CTIL::CSM_Buffer &OrigCertificateB,      // INPUT
                           acl::SPIF &spif)// IN, MUST be same SPIF used for 
                                             // checking INCOMMING Recip 
                                             // (ourselves).
{
   long lstatus = 0;
   OriginatorCert  *pTmpOC = NULL;
   SecurityLabel *pLabel=NULL;
   IncomingLabel *pTmpLabel=NULL;

   if (m_pAclSessionId == NULL || m_pACLMsgLabel == NULL)
   {
       this->m_lpszError = strdup("ACL_Interface::Check_ACLIncommingOrig: NO ACL Session OR Msg Label present!");
       return(-1);
   }
   FUNC("ACL_Interface::Check_ACLIncommingOrig(...)");
   try
   {
         pLabel = new SecurityLabel(*m_pACLMsgLabel);
         pTmpLabel = new IncomingLabel(*pLabel);

            pTmpOC = new OriginatorCert((CSM_Buffer &)OrigCertificateB);
            pTmpOC->intersect(this->m_pAclSessionId, m_pPathBufs);

            // FOR this recipient, check the label against its Clearance Extension
            pTmpOC->check(this->m_pAclSessionId, *pTmpLabel, spif);

            if (pTmpOC != NULL)
               delete pTmpOC;

         if (pLabel)
            delete pLabel;
         if (pTmpLabel)
            delete pTmpLabel;      
   }
   catch (SnaccException &e)
   {
      if (pLabel)
         delete pLabel;
      if (pTmpOC != NULL)
         delete pTmpOC;
      if (this->m_lpszError == NULL)
         this->m_lpszError = (char *) calloc(1, 
              strlen(_func) + strlen(": errorCode=") + 
              strlen(e.what()) + 52);
       strcat(m_lpszError, _func);
       strcat(m_lpszError, ": errorCode=");
       sprintf(&m_lpszError[strlen(m_lpszError)], "%d\n", e.m_errorCode);
       strcat(m_lpszError, "     error=");
       strcat(m_lpszError, e.what());
       strcat(m_lpszError, "\n");
       //throw;
       lstatus = -1;
   }        // END catch(...)


   return(lstatus);
}       // END ACL_Interface::Check_ACLIncommingOrig(...)


///////////////////////////////////////////////////////////////////////////////
long ACL_Interface::Check_ACLOutgoingOrig(
                           const CTIL::CSM_Buffer &OrigCertificateB)   // INPUT
{
   long lstatus = 0;
   OriginatorCert  *pTmpOC = NULL;
   SecurityLabel *pLabel=NULL;
   OutgoingLabel *pTmpLabel=NULL;

   if (m_pAclSessionId == NULL || m_pACLMsgLabel == NULL)
   {
       this->m_lpszError = strdup("ACL_Interface::Check_ACLOutgoingOrig: NO ACL Session OR Msg Label present!");
       return(-1);
   }
   FUNC("ACL_Interface::Check_ACLOutgoingOrig(...)");
   try
   {
         pLabel = new SecurityLabel(*m_pACLMsgLabel);
         pTmpLabel = new OutgoingLabel(*pLabel);

            pTmpOC = new OriginatorCert((CSM_Buffer &)OrigCertificateB);
            pTmpOC->intersect(this->m_pAclSessionId, m_pPathBufs);

            // FOR this recipient, check the label against its Clearance Extension
            pTmpOC->check(this->m_pAclSessionId, *pTmpLabel, NULL/*spif*/);

            if (pTmpOC != NULL)
               delete pTmpOC;

         if (pLabel)
            delete pLabel;
         if (pTmpLabel)
            delete pTmpLabel;      
   }
   catch (SnaccException &e)
   {
      if (pLabel)
         delete pLabel;
      if (pTmpOC != NULL)
         delete pTmpOC;
      if (this->m_lpszError == NULL)
         this->m_lpszError = (char *) calloc(1, 
              strlen(_func) + strlen(": errorCode=") + 
              strlen(e.what()) + 52);
       strcat(m_lpszError, _func);
       strcat(m_lpszError, ": errorCode=");
       sprintf(&m_lpszError[strlen(m_lpszError)], "%d\n", e.m_errorCode);
       strcat(m_lpszError, "     error=");
       strcat(m_lpszError, e.what());
       strcat(m_lpszError, "\n");
       //throw;
       lstatus = -1;
   }        // END catch(...)


   return(lstatus);
}       // END ACL_Interface::Check_ACLOutgoingOrig(...)


//
//
ACL_Interface::ACL_Interface(acl::Session &AclSessionId, 
              const CTIL::CSM_Buffer *pACLMsgLabel,
              CTIL::CSM_BufferLst *pPathBufs)
{ 
    setACLSession(AclSessionId); 
    m_lpszError=NULL; 
    m_pEquivLabel = NULL;
    if (pACLMsgLabel) 
        setACLMsgLabel(*pACLMsgLabel);
    else 
        m_pACLMsgLabel = NULL;
    if (pPathBufs)    
        setPathBufs(*pPathBufs);
    else 
        m_pPathBufs = NULL;
}

//
//
ACL_Interface::~ACL_Interface() 
{ 
    if (m_lpszError) 
        free(m_lpszError);
    if (m_pACLMsgLabel) 
        delete m_pACLMsgLabel;
    if (m_pEquivLabel)
        delete m_pEquivLabel;
    if (m_pPathBufs) 
        delete m_pPathBufs;
    // DO NOT DESTOY m_pAclSessionId.
}

//
//
void ACL_Interface::setACLSession(const acl::Session &AclSessionId) 
{ 
    m_pAclSessionId = (acl::Session *)&AclSessionId; 
}

//
//
void ACL_Interface::setACLMsgLabel(const CTIL::CSM_Buffer &ACLMsgLabel)
{ 
    if (m_pACLMsgLabel) 
        delete m_pACLMsgLabel;
    m_pACLMsgLabel = new CSM_Buffer(ACLMsgLabel); 
}

//
//
void ACL_Interface::setPathBufs(const CTIL::CSM_BufferLst &PathBufs)
{ 
    if (m_pPathBufs) 
        delete m_pPathBufs;
    m_pPathBufs = new CTIL::CSM_BufferLst;
    *m_pPathBufs = PathBufs; 
}


//
//
acl::SPIF *ACL_Interface::lookupSpif(const SNACC::AsnOid &oidPolicyId)
{
    MatchInfo matchInfo;
    acl::SPIF *pSpif=NULL;
    matchInfo.setPolicyId(oidPolicyId);
    acl::SPIFList *pSpifList = m_pAclSessionId->getSPIF(matchInfo);
    if (pSpifList)
    {
        pSpif = pSpifList->First();
    }       // END if pSpifList
    return pSpif;
}

_END_SFL_NAMESPACE
#endif  // CML_USED

// END AC_Interface.cpp
