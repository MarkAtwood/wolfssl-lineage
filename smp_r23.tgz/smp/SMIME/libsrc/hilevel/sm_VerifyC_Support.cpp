// sm_VerifyC_Support.cpp
// This file implements SM_VerifyC_Support which is a C wrapper for 
// CSM_MsgToVerify

#include <string.h>
#include "sm_api.h"
extern "C" {
#include "sm_apic.h"
}

    using namespace SFL;
    using namespace CERT;
    using namespace CTIL;
    using namespace SNACC;

/* SM_VerifyC_Support verifys a CMS SignedData */
SM_RET_VAL SM_VerifyC_Support(
      SM_OBJECT *pCSMIME, /* CSMIME that will be used to process this */
      SM_Content **pContent, /* input or output */
      Bytes_struct *pInput, /* ASN.1 encoded SignedData */
      SM_SignerInfoLst **pSignerInfos, /* optional list of SignerInfos */
      EncCert_LL **pCerts, /* list of certs */
      SM_BufferLst **pACs, /* list of attribute certs */
      EncCRL_LL **pCrls, /* list of crls */
      SM_Buffer *pSignedRec, /* Signed Receipt File Name */
      long *receiptreq,      /* is a receipt requested */
      CSM_MsgToVerify &smVerifyMsg)

{
   SM_RET_VAL lRet = SM_NO_ERROR;
   char *lpszError = "";     
   SM_SignerInfoLst *pTmpSignerInfos = NULL;
   CSM_Buffer *pbufInput = NULL;   
   const CSM_Content *pbufContent;
   CSM_CertificateChoiceLst *pCertLst = NULL;
   CSM_CertificateChoiceLst *pACertLst = NULL;
   CSM_BufferLst *pCrlLst = NULL;
   CSM_CertificateChoice *pTmpCert = NULL;
   CSM_CertificateChoice *pTmpAC = NULL;
   CSM_Buffer *pTmpCrl = NULL;
   EncCert_LL *pTmpCerts = NULL;
   SM_BufferLst *pTmpACerts = NULL;
   EncCRL_LL *pTmpCrls = NULL;
   CSM_Attrib *pTmpAttr = NULL;
   CSM_AttribLst *pSAttrLst = NULL;
   CSM_AttribLst *pUnSAttrLst = NULL;
   SM_AttribLst *pTmpSAttrs = NULL;
   SM_AttribLst *pTmpUnSAttrs = NULL;
   CSM_MsgSignerInfo *tmpSI;
   CSM_Buffer *pbuf;
   short count = 1;

   SME_SETUP("SM_VerifyC_Support");

   // check for missing parameters
   if ((pCSMIME == NULL) || (pInput == NULL))
      SME_THROW(SM_MISSING_PARAM, NULL, NULL);

   // convert the input from the C Bytes_struct structure to a C++ CSM_Buffer
   pbufInput = new CSM_Buffer((char *)pInput->data, pInput->num);
   if (pbufInput == NULL)
      SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

   // process the input as a content info
   CSM_ContentInfoMsg contentInfo(pbufInput);
   if (!contentInfo.IsSignedData())
      SME_THROW(SM_UNKNOWN_ERROR, "content doesn't contain a SignedData", NULL);
   delete pbufInput;

   // Pre Process the encoded blob as a content info
   SME(smVerifyMsg.PreProc((CSMIME *)pCSMIME, 
      &(contentInfo.AccessEncapContentFromAsn1()->m_content)));

   // set EnableReceipt to return a receipt if one is requested 
   if ((receiptreq) && (*receiptreq))
   {
      smVerifyMsg.EnableReceipt(true);
   }

   // pull out the inner content - if it's null, the content is separate
   // from the signed data
   if ((pbufContent = smVerifyMsg.AccessEncapContentFromAsn1()) != NULL && pContent && 
       (*pContent) != NULL)
   {
      // set up pContent as a Buffer and fill with the encapsulated content
      (*pContent)->bufContent.flag = SM_BUFFER_USED;
      if ((*pContent)->bufContent.data.pchData != NULL)
         free((*pContent)->bufContent.data.pchData);
      (*pContent)->bufContent.data.pchData = (char *)calloc(1,
         pbufContent->m_content.Length());
      SME(memcpy((*pContent)->bufContent.data.pchData, 
         pbufContent->m_content.Access(), pbufContent->m_content.Length()));
      SME((*pContent)->bufContent.data.lLength = 
         pbufContent->m_content.Length());

      /* set the content type */
      (*pContent)->poidType = pbufContent->m_contentType.GetChar();
   }
   else  if (pContent && (*pContent) != NULL)/* content was separate */
   {
      if ((*pContent)->bufContent.flag == SM_FILE_USED)
         pbuf = new CSM_Buffer((*pContent)->bufContent.data.pchData);
      else
         pbuf = new CSM_Buffer((*pContent)->bufContent.data.pchData,
                  (*pContent)->bufContent.data.lLength);
      if (pbuf == NULL)
         SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

      // set the encapsulated content and the content type
      SME(smVerifyMsg.SetEncapContentFromAsn1(*pbuf));
      delete (pbuf);
   }

   // handle the SignerInfo
   if (smVerifyMsg.m_pSignerInfos != NULL)
   {
      pTmpSignerInfos = *pSignerInfos = (SM_SignerInfoLst *)calloc(1, 
         sizeof(SM_SignerInfoLst));
      for (smVerifyMsg.m_pSignerInfos->SetCurrToFirst(), 
           tmpSI = smVerifyMsg.m_pSignerInfos->Curr(); tmpSI; 
           tmpSI = smVerifyMsg.m_pSignerInfos->GoNext())
      {
        if (count > 1)
        {
          pTmpSignerInfos->pNext = (SM_SignerInfoLst *)
            calloc(1, sizeof(SM_SignerInfoLst));
          pTmpSignerInfos = pTmpSignerInfos->pNext;
        }

        // load Signed Attributes
        if (tmpSI->m_pSignedAttrs != NULL)
        {
          pSAttrLst = tmpSI->m_pSignedAttrs->m_pAttrs;

          pTmpSAttrs = pTmpSignerInfos->pSignedAttrs = NULL;
          if (pSAttrLst != NULL)
          {
           /* get the first attribute */
            pSAttrLst->SetCurrToFirst();
            pTmpAttr = pSAttrLst->Curr();
            do
            {
            /* calloc C version of attribute list if necessary */
              if (pTmpSAttrs == NULL)
               pTmpSAttrs = pTmpSignerInfos->pSignedAttrs = (SM_AttribLst *)
                  calloc(1, sizeof(SM_AttribLst));
              else
              {
               pTmpSAttrs->pNext = (SM_AttribLst *)calloc(1, 
                  sizeof(SM_AttribLst));
               pTmpSAttrs = pTmpSAttrs->pNext;
              }

              AsnOid *pOid = NULL;        
              CSM_Buffer *pEncodedAttr = NULL;

            /* Get oid and encoded buffer of attribute. 
              Set the C attribute list with the values. */
              pTmpAttr->GetEncodedAttr(pOid, pEncodedAttr);
              pTmpSAttrs->poidType = pOid->GetChar();
              pTmpSAttrs->buffer.flag = SM_BUFFER_USED;
              pTmpSAttrs->buffer.data.pchData = pEncodedAttr->Get(); 
              pTmpSAttrs->buffer.data.lLength = pEncodedAttr->Length();
              delete pOid;
              delete pEncodedAttr;
            } while ((pTmpAttr = pSAttrLst->GoNext()) != NULL);
           }
        }   

        // load Unsigned Attributes
        if (tmpSI->m_pUnsignedAttrs != NULL)
        {
          pUnSAttrLst = tmpSI->m_pUnsignedAttrs->m_pAttrs;

          pTmpUnSAttrs = pTmpSignerInfos->pUnSignedAttrs = NULL;
          if (pUnSAttrLst != NULL)
          {
           /* get the first attribute */
            pSAttrLst->SetCurrToFirst();
            pTmpAttr = pSAttrLst->Curr();
            do
            {
            /* calloc C version of attribute list if necessary */
              if (pTmpUnSAttrs == NULL)
               pTmpUnSAttrs = pTmpSignerInfos->pUnSignedAttrs = (SM_AttribLst *)
                  calloc(1, sizeof(SM_AttribLst));
              else
              {
               pTmpUnSAttrs->pNext = (SM_AttribLst *)calloc(1, 
                  sizeof(SM_AttribLst));
               pTmpUnSAttrs = pTmpUnSAttrs->pNext;
              }

              AsnOid *pOid = NULL;        
              CSM_Buffer *pEncodedAttr = NULL;

            /* Get oid and encoded buffer of attribute.
              Set the C attribute list with the values. */
              pTmpAttr->GetEncodedAttr(pOid, pEncodedAttr);
              pTmpUnSAttrs->poidType = pOid->GetChar();
              pTmpUnSAttrs->buffer.flag = SM_BUFFER_USED;
              pTmpUnSAttrs->buffer.data.pchData = pEncodedAttr->Get(); 
              pTmpUnSAttrs->buffer.data.lLength = pEncodedAttr->Length();
              delete pOid;
              delete pEncodedAttr;
            } while ((pTmpAttr = pUnSAttrLst->GoNext()) != NULL);
           }
        }
        count++;
     }
   }
      
   // load the certs, Attribute certs and crls if necessary
   if (smVerifyMsg.m_pMsgCertCrls != NULL)
   {
     // load the certs if there are any
     pCertLst = smVerifyMsg.m_pMsgCertCrls->AccessCertificates();

     pTmpCerts = *pCerts = NULL;
     if (pCertLst != NULL)
     {
        pCertLst->SetCurrToFirst();
        pTmpCert = pCertLst->Curr();
        do
        {
          if (pTmpCerts == NULL)
            pTmpCerts = *pCerts = (EncCert_LL *)calloc(1, sizeof(EncCert_LL));
          else
          {
            pTmpCerts->next = (EncCert_LL *)calloc(1, sizeof(EncCert_LL));
            pTmpCerts = pTmpCerts->next;
          }
          pTmpCerts->encCert.data = 
             (uchar *)pTmpCert->AccessEncodedCert()->Get();
          pTmpCerts->encCert.num = 
             pTmpCert->AccessEncodedCert()->Length();
        } while ((pTmpCert = pCertLst->GoNext()) != NULL);
      }

     // load the attribute certs if there are any
     pACertLst = smVerifyMsg.m_pMsgCertCrls->AccessACs();

     pTmpACerts = *pACs = NULL;
     if (pACertLst != NULL)
     {
        pACertLst->SetCurrToFirst();
        pTmpAC = pACertLst->Curr();
        do
        {
          if (pTmpACerts == NULL)
            pTmpACerts = *pACs = (SM_BufferLst *)calloc(1, 
            sizeof(SM_BufferLst));
          else
          {
            pTmpACerts->pNext = (SM_BufferLst *)calloc(1,
               sizeof(SM_BufferLst));
            pTmpACerts = pTmpACerts->pNext;
          }
          pTmpACerts->buffer.flag = SM_BUFFER_USED;
          pTmpACerts->buffer.data.pchData =
             pTmpAC->AccessEncodedAttrCert()->Get();
          pTmpACerts->buffer.data.lLength = 
             pTmpAC->AccessEncodedAttrCert()->Length();
        } while ((pTmpAC = pACertLst->GoNext()) != NULL);
      }

      // load the crls if there are any
      pCrlLst = smVerifyMsg.m_pMsgCertCrls->AccessCRLs();

      if (pCrls)
          *pCrls = NULL;   
      pTmpCrls = NULL;
      if (pCrlLst != NULL)
      {
        pCrlLst->SetCurrToFirst();
        pTmpCrl = pCrlLst->Curr();
        do
        {
          if (pTmpCrls == NULL)
            pTmpCrls = *pCrls = (EncCRL_LL *)calloc(1, sizeof(EncCRL_LL));
          else
          {
            pTmpCrls->next = (EncCRL_LL *)calloc(1, sizeof(EncCRL_LL));
            pTmpCrls = pTmpCrls->next;
          }
          pTmpCrls->encCRL.data = (uchar *)pTmpCrl->Get(); // should this be access?
          pTmpCrls->encCRL.num = pTmpCrl->Length();
        } while ((pTmpCrl = pCrlLst->GoNext()) != NULL);
      }
   }

   SME_FINISH
   SME_CATCH_SETUP
      /* cleanup code */
      lRet = -1;
   SME_CATCH_FINISH_C2(lpszError);
   if (lpszError && strlen(lpszError))
       std::cout << lpszError;
   std::cout.flush();
   pSignedRec; //AVOIDS warning

   return lRet;
}


/* EOF sm_VerifyC_Support.cpp */
