for i in `find . -name "*.$1" -print`; do
   file $i | grep -i "text" >/dev/null
   if [ $? = 0 ]; then
      echo "converting $i to UNIX.."
      dos2unix $i $i
   fi 
done
