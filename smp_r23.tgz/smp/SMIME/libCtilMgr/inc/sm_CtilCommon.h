/* @(#) sm_CtilCommon.h 1.2 08/29/00 14:16:42 */

#ifndef _SM_CTIL_COMMON_H_
#define _SM_CTIL_COMMON_H_

#include "sm_apiCtilMgr.h"
#include "sm_common.h"
//#include "sm_VDASupport_asn.h"

_BEGIN_CTIL_NAMESPACE 

class LIBCTILMGRDLL_API CSM_DSAParams
{
    public: 
       char       *P;
       char       *Q;
       char       *G;

       long m_lParamLength;
   
       CSM_DSAParams();
       ~CSM_DSAParams();
       SM_RET_VAL Decode(CSM_Buffer *pParams);
          
};


class LIBCTILMGRDLL_API CSM_CommonCTIL: virtual public CSM_Common
{
public:
   CSM_CommonCTIL();
   ~CSM_CommonCTIL();

   // The SMTI_* functions below are the standard CTI API functions 
   // implemented according to the SFL CTI API Document
   SM_RET_VAL SMTI_Login(void);
   SM_RET_VAL SMTI_Sign(
            CSM_Buffer *pData, // input, data to be signed
            CSM_Buffer *pEncryptedDigest, // signature
            CSM_Buffer *pDigest); // digest
   SM_RET_VAL SMTI_Verify(
            CSM_Buffer *pSignerKey, // input
            CSM_Alg    *pDigestAlg, // input
            CSM_Alg    *pSignatureAlg, // input
            CSM_Buffer *pData, // input
            CSM_Buffer *pSignature); // input
   SM_RET_VAL SMTI_Encrypt(
            CSM_Buffer *pData, // input (data to be encrypted)
            CSM_Buffer *pEncryptedData, // output
            CSM_Buffer *pParameters, // OUT, for KeyAgree algs.
            CSM_Buffer *pMEK, // In/output; may be specified.
            CSM_Buffer *pIV=NULL);// In, to avoid specific alg encoding by app.
   SM_RET_VAL SMTI_GenerateEMEK(
            CSM_Buffer *pRecipient, // input, Y of recip
            CSM_Buffer *pParameters, // IN/OUT, may re-use
            CSM_Buffer *pMEK, // input, MEK or special phrase
            CSM_Buffer *pEMEK, // output, encrypted MEK
            CSM_Buffer *pUKM, // output
            CSM_Buffer *pSubjKeyId=NULL); // output
   SM_RET_VAL SMTI_ExtractMEK(
            CSM_Buffer *pOriginator, // input, Y of originator
            CSM_Buffer *pParameters, // input
            CSM_Buffer *pEMEK, // input, encrypted MEK
            CSM_Buffer *pUKM, // input
            CSM_Buffer *pMEK); // output
   SM_RET_VAL SMTI_Decrypt(
            CSM_Buffer *pParameters, // input (initialization vector)
            CSM_Buffer *pEncryptedData, // input (data to be decrypted)
            CSM_Buffer *pMEK, // input (MEK or special phrase)
            CSM_Buffer *pData); // output (decrypted data)
   SM_RET_VAL SMTI_DigestData(
            CSM_Buffer *pData, // input
            CSM_Buffer *pDigest); // output
   SM_RET_VAL SMTI_Random(
            CSM_Buffer *pSeed, // input
            CSM_Buffer *pRandom, // input/output
            SM_SIZE_T lLength); // input
   SM_RET_VAL SMTI_GenerateKeyAgreement(
            CSM_Buffer *pRecipient, // input, Y of recip
            CSM_Buffer *pParameters, // IN,OUT may be passed in for shared use
                                     //  OR for ESDH. (p, g, and/or IV).
            CSM_Buffer *pUKM, // input/output may be passed in for shared use.
                              //   UserKeyMaterial (random number).
            CSM_Buffer *pbufferIV,  // input/output may be passed in for shared use.
                              //   Initialization vector, part of DH params.
            SNACC::AsnOid *pEncryptionOID,  // IN, specified encryption of key,
                     //   used here in key generation, but alg not implemented.
            CSM_Buffer *pbufKeyAgree, // output, encryption key for this recip.
            long lKekLength);        // Input, for OtherInfo load.
   SM_RET_VAL SMTI_GenerateKeyWrap(
            CSM_Buffer *pData, // input (data to be encrypted)
            CSM_Buffer *pEncryptedData, // output
            CSM_Buffer *pParameters, // OUT, for KeyAgree algs.
            CSM_Buffer *pMEK, // In/output; may be specified.
            CSM_Buffer *pIV); // In, to avoid specific alg encoding by app.
   SM_RET_VAL SMTI_ExtractKeyWrapFinish(
            CSM_Buffer *pData, // Output
            CSM_Buffer &CEKICVPAD);  // Input
   CSM_Buffer *SMTI_GenerateKeyWrapIV(
    long &lKekLength,   // OUT, returned algorithm specific length
    CSM_Alg *pWrapAlg=NULL);  // OUT, returned since params are alg specific.

   SM_RET_VAL SMTI_ExtractKeyAgreement(
            CSM_Buffer *pOriginator, // input, Y of originator
            //CSM_Buffer *pParameters, // IN,OUT may be passed in for shared use
                                     //  OR for ESDH. (p, g, and/or IV).
            CSM_Buffer *pUKM, // input/output may be passed in for shared use.
                              //   UserKeyMaterial (random number).
            CSM_Buffer *pbufferIV,  // input/output may be passed in for shared use.
                              //   Initialization vector, part of DH params.
            SNACC::AsnOid *pEncryptionOID,  // IN, specified encryption of key,
                     //   used here in key generation, but alg not implemented.
            CSM_Buffer *pbufKeyAgree, // output, encryption key for this recip.
            long lKekLength);       // Input, for OtherInfo load.
   // this CTI does nothing with locking/unlocking 
   SM_RET_VAL SMTI_Lock() { return SM_NO_ERROR; };
   SM_RET_VAL SMTI_Unlock() { return SM_NO_ERROR; };
   bool SMTI_IsKeyAgreement();         // FALSE indicates key transfer.
                                       // TRUE indicates key agreement 
                                       //  encryption, not key transfer.
   void CSM_TokenInterfaceDestroy();

   // The methods below this pointer are outside of the CTI API and are custom
   // to this CTI Class

   // This CTI will override BTIFindAlgIds because in CEA and KEA's
   // case, we only want to compare OIDs and are not interested in 
   // comparing the parameters part of the AlgId
   bool BTIFindAlgIds(CSM_Alg *pdigestAlgID, 
            CSM_Alg *pdigestEncryptionAlgID,
            CSM_Alg *pkeyEncryptionAlgID,
            CSM_Alg *pcontentEncryptionAlgID);

   // set or restore the default Alg OIDs
   void SetDefaultOIDs();  // Param specifies this instance Algs.
   char *m_pszPrefix; // ID Prefix specified by app

private:
   void Clear() { m_pszPrefix = NULL; }

};

_END_CTIL_NAMESPACE 

#endif
