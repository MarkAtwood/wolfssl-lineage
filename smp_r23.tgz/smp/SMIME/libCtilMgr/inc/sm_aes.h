

#ifndef __SM_AES_H
#define __SM_AES_H

#include "rijndael-api-ref.h"

#define AES_IV_SIZE     16

#define AES_128			128
#define AES_192			192
#define AES_256			256

//#define AES_MODE_ECB        1    /*  Are we ciphering in ECB mode?   */
//#define AES_MODE_CBC        2    /*  Are we ciphering in CBC mode?   */
//#define AES_MODE_CFB        3    /*  Are we ciphering in 1-bit CFB mode? */

// ERROR DEFINITIONS: move to sm_apiCCert.h

// prototypes
int sm_EncryptAES(
    char *pdataIn,                /* NOTE:  block aligned for padding
	                                 aligned according to blockLength which could
	                                 be 128,192, or 256*/
	long dataLength,              /* Length of data */
    keyInstance *pkey,            /* key data */
	long blockLength,             /* key length */
	char **ppdataOut,             /* double pointer to output data */
	const int mode,               /* mode for encryption */
	char *pIV,                    /*  pointer to IV */
    int bKeyWrapFlag);            /* FLAG to indicate key wrap algorithm.*/

int sm_EncryptAESPad(char *pdataIn, long dataLength, keyInstance *pkey, long blockLength,
				  char **ppdataOut, long *outputLength, const int mode,  char *ppIV);

int sm_DecryptAES(
    char *pdataIn,         /* input NOTE:  block aligned for padding */
	long dataLength,       /* input length of data  */
	keyInstance *pkey,     /* input decryption key data */
	int blockLength,       /* input block length */
	char **ppdataOut,      /* output double pointer to output data */
	int mode,              /* input cipher mode */
	char *pIV,             /* input pointer to iv */
    int bKeyWrapFlag);     /* input FLAG to indicate key wrap algorithm.*/

int sm_DecryptAESPad(char *pdataIn, long dataLength, keyInstance *pkey, int blockLength, 
				  char **ppdataOut, long *outputLength, int mode, char *pIV);

long sm_KeyAES(keyInstance *keyInst, int direction, int blockLength, int keyLength, 
			  char *key);

#endif /* __SM_AES_H */
