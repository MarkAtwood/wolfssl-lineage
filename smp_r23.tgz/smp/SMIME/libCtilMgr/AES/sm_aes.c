#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sm_aes.h"
#include "sm_apicCtilMgr.h"

#ifdef AES_MAIN_TEST

static void blockPrint (FILE *fp, const BYTE *block, int blockBits, const char *tag)
{
	int i;

	fprintf (fp, "%s=", tag);
	for (i = 0; i < blockBits/8; i++) {
		fprintf (fp, "%02X", block[i]);
	}
	fprintf (fp, "\n");
	fflush (fp);
} /* blockPrint */

static void HexToBin (BYTE *binBlock, const BYTE *hexBlock, int blockLen)
{
	int j = 0, t;
	while (blockLen > 0) {
		t = *hexBlock++;
		if ((t >= '0') && (t <= '9')) j = (t - '0') << 4;
		else if ((t >= 'a') && (t <= 'f')) j = (t - 'a' + 10) << 4; 
		else if ((t >= 'A') && (t <= 'F')) j = (t - 'A' + 10) << 4; 		
		
		t = *hexBlock++;
		if ((t >= '0') && (t <= '9')) j ^= (t - '0');
		else if ((t >= 'a') && (t <= 'f')) j ^= (t - 'a' + 10); 
		else if ((t >= 'A') && (t <= 'F')) j ^= (t - 'A' + 10); 

		*binBlock++ = (unsigned char)j;
		blockLen -= 8;
	}
} /* HexToBin */

void MAIN (
	char *pplainText,                   /* I - input data to encrypt */
	long  blockLength,                  /* I - length of block to encrypt 128, 192, 256 */
	char *pkey,                         /* I - encryption key data */
	long  keyLength,                    /* I - encryption key length 128, 192, 256 */
	char *pIV,                          /* I - IV */
	char *poutputFile)                  /* O - output file(encrypted data)) */
{
	char           *pachIn = NULL;
	char           *pachOut = NULL;
	char           *pachDecryptOut = NULL;
    BYTE           binKey[256/8];
	char           *pcv;                /* [256/8] */
	unsigned char  keyMaterial[320];    /* holds key data */
	keyInstance    keyInst;             /* */
	FILE           *fp;
	int            status;
	int            cbcMode;
	long           dataLength = 0;
	long           inputLength = 0;
    int            alignLength = 0;
	int            bitLength   = 0;
	long           outputLength = 0;

#ifdef TRACE_KAT_MCT
	printf ("Executing AES Variable Text (key %d): ", keyLength);
	fflush (stdout);
#endif /* ?TRACE_KAT_MCT */

	/* initialize */
	memset(&keyInst, '0',sizeof(keyInstance));

	fp = fopen (poutputFile, "w");
	
    pachOut=(char *)calloc(1,4*MAXBC + 1);
	pcv=(char *)calloc(1,32);  /* could change tbd */

	fprintf (fp,
		"\n"
		"==========\n"
		"\n"
		"KEYSIZE=%d\n"
		"\n", keyLength);
	fflush (fp);

    fprintf(fp, "IV =%s\n", pIV);
	fprintf(fp, "PT =%s\n", pplainText);
	fprintf(fp, "KEY=%s\n\n", pkey);

/*	HexToBin (pcv, pIV, blockLength);*/
/*	HexToBin (inBlock, pplainText, blockLength);*/ /* this is either PT0 or CT0 */
	HexToBin (binKey, (const unsigned char *)pkey, keyLength);
	
	/* initialize keyMaterial and assign the key with the key input */
	memset (keyMaterial, 0, sizeof (keyMaterial));
	
	/* prepare key:  */
#ifdef NOTDEF
	for (j = 0; j < keyLength/8; j++) 
	{
/*		sprintf (&keyMaterial[2*j], "%02X", pkey[j]); */
		sprintf (&keyMaterial[2*j], "%02X", binKey[j]);
	}
	keyMaterial[keyLength/4] = 0;
#endif
	/* prepare the key instance --- 0 for encrypt */
	sm_KeyAES(&keyInst, 0, blockLength, keyLength, (char *)binKey); /*keyMaterial);*/


	fprintf (fp, "Encrypt:\n");

	fprintf (fp, "keyMaterial KEY=%s\n", keyMaterial);
	fprintf (fp, "keyInst     KEY=%s\n", keyInst.keyMaterial);

	blockPrint (fp, (const unsigned char *)pplainText, blockLength, "PT ");

    /* MODE_ECB        1   */  /*  Are we ciphering in ECB mode?   */
    /* MODE_CBC        2   */  /*  Are we ciphering in CBC mode?   */
    /* MODE_CFB1       3   */  /*  Are we ciphering in 1-bit CFB mode? */
	cbcMode = 2;

	/* block align the data */
	dataLength = strlen(pplainText);

	if ((alignLength = dataLength%(bitLength = blockLength/8)) != 0)
	{
		alignLength = bitLength - alignLength;
        pachIn = (char *)calloc(1, dataLength + alignLength);
		strncpy(pachIn,pplainText, dataLength + alignLength);
		inputLength = dataLength + alignLength;
	}
	else
	{
        pachIn = (char *)calloc(1,dataLength);
		strncpy(pachIn,pplainText,dataLength);
		inputLength = dataLength;
	}


	/* call to encrypt the plain text */
	if ((status = sm_EncryptAESPad(pachIn, dataLength, &keyInst, blockLength, &pachOut, 
      &outputLength, cbcMode, pIV)) != 0 )  
/*		&pcv)) != 0 ) */
	{
		printf("sm_EncryptAES returned:  %d\n", status);
	}

	blockPrint (fp, (const unsigned char *)pachOut, blockLength, "CT ");

	/* prepare to decrypt */
	fprintf (fp, "Decrypt:\n");

	pachDecryptOut=(char *)calloc(1,4*MAXBC + 1);

	/* prepare the key instance for decryption, keeping the same settings from encryption */
	keyInst.direction = DIR_DECRYPT;   /* 1 */
		
	fprintf (fp, "keyInst     KEY=%s\n", keyInst.keyMaterial);

	blockPrint (fp, (const unsigned char *)pachOut, blockLength, "CT ");

	/* call to decrypt cipher text */
	status = sm_DecryptAESPad(pachOut, inputLength, &keyInst, blockLength, &pachDecryptOut, 
		&outputLength, cbcMode, pIV);
	
	blockPrint (fp, (const unsigned char *)pachDecryptOut, blockLength, "PT ");
	fprintf(fp,"PT =%s\n",pachDecryptOut);

	fclose(fp);

	/* add code here to compare input data to output data from the sm_DecryptAESPad call */
    printf("Decrypted result in file %s\n", poutputFile);

	if (memcmp(pplainText,pachDecryptOut,outputLength) != 0)
        printf("SM_CfgCheckDecrypt: WARNING no orig content kw\n");
    else
		printf("Comparison of original content and decrypted content SUCCESSFUL!\n");
	
#ifdef TRACE_KAT_MCT
	printf (" done.\n");
#endif /* ?TRACE_KAT_MCT */
}

#endif  // AES_MAIN_TEST

/* */
long sm_KeyAES(keyInstance *pkeyInst, int direction, int blockLength, int keyLength, 
			  char *pkey)
{
    int status = 0;

	/* check input parameters */
	if (pkeyInst == NULL)
	{
		return SM_MISSING_PARAM;
	}
	if (blockLength <=0 || keyLength <= 0)
	{
		return SM_MISSING_PARAM;
	}
	if (pkey == NULL)
	{
		return SM_MISSING_PARAM;
	}

	/* process according if encryption or decryption is requested */
	if (direction == DIR_ENCRYPT)
	{
		/* set for encrypt */
		pkeyInst->blockLen = blockLength;
		makeKey(pkeyInst, DIR_ENCRYPT, keyLength, pkey);
	}
	else if (direction == DIR_DECRYPT)
	{
		/* set for decrypt */
		pkeyInst->blockLen = blockLength;
		makeKey(pkeyInst, DIR_DECRYPT, keyLength, pkey);
	}
	else
	{
		status = SM_AES_KEYINST_ERROR;
	}

	return status;
}


int sm_EncryptAES(
    char *pdataIn,                /* NOTE:  block aligned for padding
	                                 aligned according to blockLength which could
	                                 be 128,192, or 256*/
	long dataLength,              /* Length of data */
    keyInstance *pkey,            /* key data */
	long blockLength,             /* key length */
	char **ppdataOut,             /* double pointer to output data */
	const int mode,               /* mode for encryption */
	char *pIV,                    /*  pointer to IV */
    int bKeyWrapFlag)            /* FLAG to indicate key wrap algorithm.*/
{
	cipherInstance cipherInst;                  /* cipher information */
	int            status = 1;                  /* holds status from function calls */
	int            i;                           /* index */
	long           blockCount = 0;              /* number of complete blocks */
	long           blockByte = blockLength/8;   /* number of bytes per complete block */
	                                            /* 128/8, 192/8, or 256/8 */

	/* check for 100% block alignment */
	/* check parameters*/
	if(pdataIn == NULL)
	{
		return SM_MISSING_PARAM;
	}
	if (pkey == NULL)
	{
		return SM_MISSING_PARAM;
	}
	if (blockLength <= 0)
	{
		return SM_MISSING_PARAM;
	}
	/* RWC;NOW OPTIONAL;if (pIV == NULL)
	{
		return SM_MISSING_PARAM;
	}*/

	/* if memory wasn't allocated before-hand, allocate it now */
	if (*ppdataOut == NULL)
	{
		if ((*ppdataOut = (char *) calloc(1,dataLength*2)) == NULL)
		{           // LENGTH must be larger to accommodate constant IV check.
			status = SM_MEMORY_ERROR;
		}
	}

	if (status == 1)
	{
	   /* prepare cipher instance */
	   //strcpy((char *)&cipherInst.IV, pIV); RWC;strcpy fails 1st, also, 
                                //  already copied in "cipherInit(...)".
	   cipherInst.blockLen = blockLength;
	   if ((status = cipherInit (&cipherInst, (unsigned char)mode, pIV)) != 1)
	   {
		  status = SM_AES_CIPHER_ERROR;
	   }
	}

	if (status == 1)
	{
	    status = 0;  /* re-initialize success */

        /* encrypt data */
        if (bKeyWrapFlag != 0)
        {
			//ALWAYS "dataLength" bytes, since only a single loop executed.
     	    if ((SM_KeyWrap_blockEncrypt(&cipherInst, pkey, (unsigned char *)pdataIn, 
		    	dataLength*8/*blockLength*/, (unsigned char *)(*ppdataOut)) ) <= 0)
			{
				status = SM_AES_ENCRYPT_ERROR;
			}
        }
        else    // IF bKeyWrapFlag
        {
		    /* encrypt by blocks */
	        blockCount = dataLength/blockByte;
	        for (i = 0; i < blockCount; i++)
		    {
	            if ((dataLength % blockByte) != 0)
	            {
		            return SM_AES_MISALIGNED_DATA;
	            }

     	        if ((blockEncrypt(&cipherInst, pkey, (unsigned char *)(&pdataIn[i*blockByte]), 
		    	    blockLength, (unsigned char *)(&(*ppdataOut)[i*blockByte])) ) <= 0)
			    {
				    status = SM_AES_ENCRYPT_ERROR;
			    }
            }   // END FOR each block (non-key wrap.
        }       // END IF bKeyWrapFlag
	}           // END IF status

	return status;
}       // END sm_EncryptAES(...)

int sm_EncryptAESPad(
    char        *pdataIn,         /* input NOTE:  block aligned for padding */
    long        dataLength,       /* input Length of data */
    keyInstance *pkey,            /* input key data */
    long        blockLength,      /* input key length */
    char        **ppdataOut,      /* output double pointer to output data */
    long        *outputLength,    /* output length */
    const int   mode,             /* input mode for encryption */
    char        *pIV)             /* input pointer to IV */
{
    int            status = 1;    /* success */
    int            blockCount = 0;
    long           blockMod = 0;
    long           blockByte = blockLength/8;
    int            i;
    int            padCount = 0;

	/* check parameters */
	if(pdataIn == NULL)
	{
		return SM_MISSING_PARAM;
	}
	if(dataLength <= 0)
	{
		return SM_MISSING_PARAM;
	}
	if (pkey == NULL)
	{
		return SM_MISSING_PARAM;
	}
	if (blockLength <= 0)
	{
		return SM_MISSING_PARAM;
	}
	if (pIV == NULL)
	{
		return SM_MISSING_PARAM;
	}


	/* check if padding is necessary */
	blockCount = dataLength/blockByte;
	blockMod = dataLength - (blockCount * blockByte);
	padCount = blockByte - blockMod;

    /* padding is necessary for count of blockMod */
	for(i = 0; i < padCount; i++)
	{
    	/* pad with length blockMod to be padded */
	   pdataIn[blockCount * blockByte + i + blockMod] = (char) padCount;
	}

	/* if memory wasn't allocated before-hand, allocate it now */
	/* memory is given to api -- no need to delete when finished */
	if (*ppdataOut == NULL)
	{
		if ((*ppdataOut = (char *) calloc(1,dataLength + padCount)) == NULL)
		{
		    *outputLength = 0;
			status = SM_MEMORY_ERROR;
		}

	}

	if (status == 1)
	{
	   /* encrypt the data  */
	   if ((status = sm_EncryptAES(pdataIn, dataLength + padCount, pkey, blockLength, 
	    	ppdataOut, mode, pIV, 0)) != 0 )
	   {
	   	   *outputLength = 0;
		   if (*ppdataOut)
		   {
			   free(*ppdataOut);
			   *ppdataOut = NULL;
		   }
		   status = SM_AES_ENCRYPT_ERROR;
	   }
	   else
	   {
     	   /* set new dataLength */
    	   *outputLength = dataLength + padCount;
	   }
	}

    return status;
}       // END sm_EncryptAESPad(...)


int sm_DecryptAES(
    char *pdataIn,         /* input NOTE:  block aligned for padding */
	long dataLength,       /* input length of data  */
	keyInstance *pkey,     /* input decryption key data */
	int blockLength,       /* input block length */
	char **ppdataOut,      /* output double pointer to output data */
	int mode,              /* input cipher mode */
	char *pIV,             /* input pointer to iv */
    int bKeyWrapFlag)      /* input FLAG to indicate key wrap algorithm.*/
{
	int  status = 1;       /* success */
	int  i;                /* index */
	long blockCount = 0;   /* number of blocks to decrypt */
	long blockByte = blockLength/8;  /* number of bytes in a block */
	cipherInstance cipherInst;       /* cipher data instance */

	/* check for 100% block alignment  */
	/* check parameters */
	if(pdataIn == NULL)
	{
		return SM_MISSING_PARAM;
	}
	if (pkey == NULL)
	{
		return SM_MISSING_PARAM;
	}
	if (blockLength <= 0)
	{
		return SM_MISSING_PARAM;
	}

	/* if memory wasn't allocated before-hand, allocate it now */
	if (*ppdataOut == NULL)
	{
		if ((*ppdataOut = (char *) calloc(1,dataLength)) == NULL)
		{
			status = SM_MEMORY_ERROR;
		}
	}

	if (status == 1)
	{
	   /* prepare cipher instance */
       cipherInst.blockLen = blockLength;
	   if ((status = cipherInit (&cipherInst, (unsigned char)mode, pIV)) != 1)
	   {
		  status = SM_AES_CIPHER_ERROR;
	   }
	}

	if (status == 1)
	{
		status = 0; // re-initialize to success

       if (bKeyWrapFlag != 0)
       {
			/*ALWAYS "dataLength" bytes, since only a single loop executed.*/
	       if ((SM_KeyWrap_blockDecrypt(&cipherInst, pkey, (unsigned char *)pdataIn, 
               dataLength*8/*blockLength*/, (unsigned char *)*ppdataOut)) <= 0)
		   {
              status = SM_AES_DECRYPT_ERROR;
		   }
       }        // IF bKeyWrapFlag
       else
       {
            /* decrypt data by blocks */
            blockCount = dataLength/blockByte;
	        for (i = 0; i < blockCount; i++)
            {
       	       /* decrypt data */
	               if ((blockDecrypt(&cipherInst, pkey, (unsigned char *)&pdataIn[i*blockByte], blockLength, 
	        	        (unsigned char *)&(*ppdataOut)[i*blockByte])) <= 0)
		           {
                      status = SM_AES_DECRYPT_ERROR;
		           }
            }    /* END FOR loop */
       }         /* END IF bKeyWrapFlag */
	}

	return status;
}       /* END sm_DecryptAES(...)*/

int sm_DecryptAESPad(
    char        *pdataIn,         /* input NOTE:  block aligned for padding */  
	long        dataLength,       /* input length of data  */
	keyInstance *pkey,            /* input cipher key data */
	int         blockLength,      /* input block length  */
	char        **ppdataOut,      /* output double pointer to output data */
	long        *outputLength,    /* output pointer to output length */
	int         mode,             /* input cipher mode */
	char        *pIV)             /* input pointer to iv */
{
	int  status = 1;              /* success */
	int  padCount = 0;

	/* check parameters */
	if(pdataIn == NULL)
	{
		return SM_MISSING_PARAM;
	}
	if (pkey == NULL)
	{
		return SM_MISSING_PARAM;
	}
	if (blockLength <= 0)
	{
		return SM_MISSING_PARAM;
	}

	/* if memory wasn't allocated before-hand, allocate it now */
	if (ppdataOut == NULL)
	{
		if ((*ppdataOut = (char *) calloc(1,dataLength)) == NULL)
		{
            *outputLength = 0;
			status = SM_MEMORY_ERROR;
		}

	}

	if (status == 1)
	{
	   /* call to decrypt cipher text */
	   if ((status = sm_DecryptAES(pdataIn, dataLength, pkey, blockLength, ppdataOut, 
	   	   mode, pIV, 0)) != 0) /* 0 successful */
	   {
           *outputLength = 0;
		   if (*ppdataOut)
		   {
			   free(*ppdataOut);
			   *ppdataOut=NULL;
		   }
		   status = SM_AES_DECRYPT_ERROR;
	   }
       else
	   {
		   int i, ok = 1;

		   /* go to end and get the last byte data.  This will always be the number  */
		   /* of bytes padded */
           padCount = (int)(*ppdataOut)[dataLength - 1];
		   if (padCount < blockLength)
		   {
			  /* check to see if each padded is == to padCount data */
			  for( i=0; i < padCount; i++)
			  {
                 if ((*ppdataOut)[dataLength -padCount + i ] != padCount)
				 {
					 /* error with padding */
	                 ok = 0;
					 *outputLength = 0;
					 status = SM_AES_PAD_ERROR;
				 }
			  }

			  /* if padded data ok then set output length */
			  if (ok)
			  {
			   	 *outputLength = dataLength - padCount;
				 (*ppdataOut)[*outputLength] = '\0';
		         status = 0;	
			  }
		   }
		   else
		   {
			  /* error with padding */
			  *outputLength = 0;
			  status = SM_AES_PAD_ERROR;
		   }
	   }
	}

	return status;
}       // END sm_DecryptAESPad(...)


/* EOF of sm_aes.c */
