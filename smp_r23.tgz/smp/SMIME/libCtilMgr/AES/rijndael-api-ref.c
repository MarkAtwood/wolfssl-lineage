/* rijndael-api-ref.c   v2.0   August '99
 * Reference ANSI C code
 * authors: Paulo Barreto
 *          Vincent Rijmen
 */
/*
                        ------------------------------
                        Rijndael ANSI C Reference Code
                        ------------------------------

                                October 24, 2000

                                  Disclaimer


This software package was submitted to the National Institute of Standards and
Technology (NIST) during the Advanced Encryption Standard (AES) development
effort by Joan Daemen and Vincent Rijmen, the developers of the Rijndael algorithm.

This software is distributed in compliance with export regulations (see below), and
it is intended for non-commercial use, only.   NIST does not support this software 
and does not provide any guarantees or warranties as to its performance, fitness 
for any particular application, or validation under the Cryptographic Module
Validation Program (CMVP) <http://csrc.nist.gov/cryptval/>.  NIST does not accept 
any liability associated with its use or misuse.  This software is provided as-is. 
By accepting this software the user agrees to the terms stated herein.

                            -----------------------

                              Export Restrictions


Implementations of cryptography are subject to United States Federal
Government export controls.  Export controls on commercial encryption products 
are administered by the Bureau of Export Administration (BXA) 
<http://www.bxa.doc.gov/Encryption/> in the U.S. Department of Commerce. 
Regulations governing exports of encryption are found in the Export 
Administration Regulations (EAR), 15 C.F.R. Parts 730-774.
*/

#include <stdlib.h>
#include <string.h>

#include "rijndael-alg-ref.h"
#include "rijndael-api-ref.h"

/*  new code fixes the ascii conversion - key material is not ascii */

int makeKey(keyInstance *key, BYTE direction, int keyLen, char *keyMaterial)
{
    word8 k[4][MAXKC];
//    int i, j, t;
    int i;
    
    if (key == NULL) {
        return BAD_KEY_INSTANCE;
    }

    if ((direction == DIR_ENCRYPT) || (direction == DIR_DECRYPT)) {
        key->direction = direction;
    } else {
        return BAD_KEY_DIR;
    }

    if ((keyLen == 128) || (keyLen == 192) || (keyLen == 256)) { 
        key->keyLen = keyLen;
    } else {
        return BAD_KEY_MAT;
    }

    if ( keyMaterial ) {
#ifdef  ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        memcpy(key->keyMaterial, keyMaterial, keyLen/4);
#else     //ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        memcpy(key->keyData, keyMaterial, keyLen/4);
#endif // ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
    }

    /* initialize key schedule: */ 
     for(i = 0; i < key->keyLen/8; i++) {
/*        t = key->keyMaterial[2*i];
        if ((t >= '0') && (t <= '9')) j = (t - '0') << 4;
        else if ((t >= 'a') && (t <= 'f')) j = (t - 'a' + 10) << 4; 
        else if ((t >= 'A') && (t <= 'F')) j = (t - 'A' + 10) << 4; 
        else return BAD_KEY_MAT;
        
        t = key->keyMaterial[2*i+1];
        if ((t >= '0') && (t <= '9')) j ^= (t - '0');
        else if ((t >= 'a') && (t <= 'f')) j ^= (t - 'a' + 10); 
        else if ((t >= 'A') && (t <= 'F')) j ^= (t - 'A' + 10); 
        else return BAD_KEY_MAT;
*/
#ifdef  ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        k[i % 4][i / 4] = (word8) key->keyMaterial[i]; 
#else     //ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        k[i % 4][i / 4] = (word8) key->keyData[i]; 
#endif // ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
    }    
    
    rijndaelKeySched (k, key->keyLen, key->blockLen, key->keySched);
    
    return TRUE;
}

int makeKeyOrig(keyInstance *key, BYTE direction, int keyLen, char *keyMaterial)
{
    word8 k[4][MAXKC];
    int i, j, t;
    
    if (key == NULL) {
        return BAD_KEY_INSTANCE;
    }

    if ((direction == DIR_ENCRYPT) || (direction == DIR_DECRYPT)) {
        key->direction = direction;
    } else {
        return BAD_KEY_DIR;
    }

    if ((keyLen == 128) || (keyLen == 192) || (keyLen == 256)) { 
        key->keyLen = keyLen;
    } else {
        return BAD_KEY_MAT;
    }

    if ( keyMaterial ) {
#ifdef  ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        strncpy(key->keyMaterial, keyMaterial, keyLen/4);
#else     //ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        strncpy(key->keyData, keyMaterial, keyLen/4);
#endif // ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
    }

    /* initialize key schedule: */ 
     for(i = 0; i < key->keyLen/8; i++) {
#ifdef  ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        t = key->keyMaterial[2*i];
#else     //ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        t = key->keyData[2*i];
#endif // ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        if ((t >= '0') && (t <= '9')) j = (t - '0') << 4;
        else if ((t >= 'a') && (t <= 'f')) j = (t - 'a' + 10) << 4; 
        else if ((t >= 'A') && (t <= 'F')) j = (t - 'A' + 10) << 4; 
        else return BAD_KEY_MAT;
        
#ifdef  ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        t = key->keyMaterial[2*i+1];
#else     //ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        t = key->keyData[2*i+1];
#endif // ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
        if ((t >= '0') && (t <= '9')) j ^= (t - '0');
        else if ((t >= 'a') && (t <= 'f')) j ^= (t - 'a' + 10); 
        else if ((t >= 'A') && (t <= 'F')) j ^= (t - 'A' + 10); 
        else return BAD_KEY_MAT;
        
        k[i % 4][i / 4] = (word8) j; 
    }    
    
    rijndaelKeySched (k, key->keyLen, key->blockLen, key->keySched);
    
    return TRUE;
}

/*  new code fixes the ascii conversion - IV is not ascii */
int cipherInit(cipherInstance *cipher, BYTE mode, char *IV)
{
    //int i, j, t;
    int i;
    
    if ((mode == MODE_ECB) || (mode == MODE_CBC) || (mode == MODE_CFB1)) {
        cipher->mode = mode;
    } else {
        return BAD_CIPHER_MODE;
    }
    
    if (IV != NULL) {
         for(i = 0; i < cipher->blockLen/8; i++) {        
        /*    t = IV[2*i];
            if ((t >= '0') && (t <= '9')) j = (t - '0') << 4;
            else if ((t >= 'a') && (t <= 'f')) j = (t - 'a' + 10) << 4; 
            else if ((t >= 'A') && (t <= 'F')) j = (t - 'A' + 10) << 4; 
            else return BAD_CIPHER_INSTANCE;
        
            t = IV[2*i+1];
            if ((t >= '0') && (t <= '9')) j ^= (t - '0');
            else if ((t >= 'a') && (t <= 'f')) j ^= (t - 'a' + 10); 
            else if ((t >= 'A') && (t <= 'F')) j ^= (t - 'A' + 10); 
            else return BAD_CIPHER_INSTANCE;
            */
            cipher->IV[i] = (BYTE) IV[i];
        } 
    }

    return TRUE;
}

int cipherInitOrig(cipherInstance *cipher, BYTE mode, char *IV)
{
    int i, j, t;
    
    if ((mode == MODE_ECB) || (mode == MODE_CBC) || (mode == MODE_CFB1)) {
        cipher->mode = mode;
    } else {
        return BAD_CIPHER_MODE;
    }
    
    if (IV != NULL) {
         for(i = 0; i < cipher->blockLen/8; i++) {        
            t = IV[2*i];
            if ((t >= '0') && (t <= '9')) j = (t - '0') << 4;
            else if ((t >= 'a') && (t <= 'f')) j = (t - 'a' + 10) << 4; 
            else if ((t >= 'A') && (t <= 'F')) j = (t - 'A' + 10) << 4; 
            else return BAD_CIPHER_INSTANCE;
        
            t = IV[2*i+1];
            if ((t >= '0') && (t <= '9')) j ^= (t - '0');
            else if ((t >= 'a') && (t <= 'f')) j ^= (t - 'a' + 10); 
            else if ((t >= 'A') && (t <= 'F')) j ^= (t - 'A' + 10); 
            else return BAD_CIPHER_INSTANCE;
            
            cipher->IV[i] = (BYTE) j;
        } 
    }

    return TRUE;
}


#ifdef ORIGINAL_ENTRY_WRONG_SECOND_BLOCK
int blockEncrypt(cipherInstance *cipher,
    keyInstance *key, BYTE *input, int inputLen, BYTE *outBuffer)
{
    int i, j, t, numBlocks;
    word8 block[4][MAXBC];

    
        /* check parameter consistency: */
        if (key == NULL ||
                key->direction != DIR_ENCRYPT ||
                (key->keyLen != 128 && key->keyLen != 192 && key->keyLen != 256)) {
                return BAD_KEY_MAT;
        }
        if (cipher == NULL ||
                (cipher->mode != MODE_ECB && cipher->mode != MODE_CBC && cipher->mode != MODE_CFB1) ||
                (cipher->blockLen != 128 && cipher->blockLen != 192 && cipher->blockLen != 256)) {
                return BAD_CIPHER_STATE;
        }


    numBlocks = inputLen/cipher->blockLen;
    
    switch (cipher->mode) {
    case MODE_ECB: 
        for (i = 0; i < numBlocks; i++) {
            for (j = 0; j < cipher->blockLen/32; j++) {
                for(t = 0; t < 4; t++)
                /* parse input stream into rectangular array */
                    block[t][j] = (unsigned char) (input[4*j+t] & 0xFF);
            }
            rijndaelEncrypt (block, key->keyLen, cipher->blockLen, key->keySched);
            for (j = 0; j < cipher->blockLen/32; j++) {
                /* parse rectangular array into output ciphertext bytes */
                for(t = 0; t < 4; t++)
                    outBuffer[4*j+t] = (BYTE) block[t][j];
            }
        }
        break;
        
    case MODE_CBC:
        for (j = 0; j < cipher->blockLen/32; j++) {
            for(t = 0; t < 4; t++)
            /* parse initial value into rectangular array */
                    block[t][j] = (unsigned char)(cipher->IV[t+4*j] & 0xFF);
            }
        for (i = 0; i < numBlocks; i++) {
            for (j = 0; j < cipher->blockLen/32; j++) {
                for(t = 0; t < 4; t++)
                /* parse input stream into rectangular array and exor with 
                   IV or the previous ciphertext */
                    block[t][j] ^= input[4*j+t] & 0xFF;
            }
            rijndaelEncrypt (block, key->keyLen, cipher->blockLen, key->keySched);
            for (j = 0; j < cipher->blockLen/32; j++) {
                /* parse rectangular array into output ciphertext bytes */
                for(t = 0; t < 4; t++)
                    outBuffer[4*j+t] = (BYTE) block[t][j];
            }
        }
        break;
    
    default: return BAD_CIPHER_STATE;
    }
    
    return numBlocks*cipher->blockLen;
}       // END blockEncrypt(...)


int blockDecrypt(cipherInstance *cipher,
    keyInstance *key, BYTE *input, int inputLen, BYTE *outBuffer)
{
    int i, j, t, numBlocks;
    word8 block[4][MAXBC];

    if (cipher == NULL ||
        key == NULL ||
        key->direction == DIR_ENCRYPT ||
        cipher->blockLen != key->blockLen) {
        return BAD_CIPHER_STATE;
    }

        /* check parameter consistency: */
        if (key == NULL ||
                key->direction != DIR_DECRYPT ||
                (key->keyLen != 128 && key->keyLen != 192 && key->keyLen != 256)) {
                return BAD_KEY_MAT;
        }
        if (cipher == NULL ||
                (cipher->mode != MODE_ECB && cipher->mode != MODE_CBC && cipher->mode != MODE_CFB1) ||
                (cipher->blockLen != 128 && cipher->blockLen != 192 && cipher->blockLen != 256)) {
                return BAD_CIPHER_STATE;
        }
    

    numBlocks = inputLen/cipher->blockLen;
    
    switch (cipher->mode) {
    case MODE_ECB: 
        for (i = 0; i < numBlocks; i++) {
            for (j = 0; j < cipher->blockLen/32; j++) {
                for(t = 0; t < 4; t++)
                /* parse input stream into rectangular array */
                    block[t][j] = (unsigned char)(input[4*j+t] & 0xFF);
            }
            rijndaelDecrypt (block, key->keyLen, cipher->blockLen, key->keySched);
            for (j = 0; j < cipher->blockLen/32; j++) {
                /* parse rectangular array into output ciphertext bytes */
                for(t = 0; t < 4; t++)
                    outBuffer[4*j+t] = (BYTE) block[t][j];
            }
        }
        break;
        
    case MODE_CBC:
        /* first block */
        for (j = 0; j < cipher->blockLen/32; j++) {
            for(t = 0; t < 4; t++)
            /* parse input stream into rectangular array */
                block[t][j] = (unsigned char)(input[4*j+t] & 0xFF);
        }
        rijndaelDecrypt (block, key->keyLen, cipher->blockLen, key->keySched);
        
        for (j = 0; j < cipher->blockLen/32; j++) {
            /* exor the IV and parse rectangular array into output ciphertext bytes */
            for(t = 0; t < 4; t++)
                outBuffer[4*j+t] = (BYTE) (block[t][j] ^ cipher->IV[t+4*j]);
        }
        
        /* next blocks */
        for (i = 1; i < numBlocks; i++) {
            for (j = 0; j < cipher->blockLen/32; j++) {
                for(t = 0; t < 4; t++)
                /* parse input stream into rectangular array */
                    block[t][j] = (unsigned char)(input[cipher->blockLen/8+4*j+t] & 0xFF);
            }
            rijndaelDecrypt (block, key->keyLen, cipher->blockLen, key->keySched);
            
            for (j = 0; j < cipher->blockLen/32; j++) {
                /* exor previous ciphertext block and parse rectangular array 
                       into output ciphertext bytes */
                for(t = 0; t < 4; t++)
                    outBuffer[cipher->blockLen/8+4*j+t] = (BYTE) (block[t][j] ^ 
                        input[4*j+t-4*cipher->blockLen/32]);
            }
        }
        break;
    
    default: return BAD_CIPHER_STATE;
    }
    
    return numBlocks*cipher->blockLen;
}       // END blockDecrypt(...)
#else
BYTE GetBit(BYTE ch, int i)
{
	BYTE	mask = 0x01;

	mask <<= 7 - (i % 8);
	if ( ch & mask )
		return 0x01;
	else
		return 0x00;
}
void PutBit(BYTE *outbyte, BYTE data, int i)
{
	BYTE	mask = 0x01;

	mask <<= 7 - (i % 8);
	if ( data & 0x80 )
		*outbyte |= mask;
	else
		*outbyte &= ~mask;
}
void bumpCount(BYTE *IV, int blockLen)
{
	int		i;

	for ( i=blockLen/8-1; i>=0; i-- )
		if ( IV[i] == 0xff )
			IV[i] = 0x00;
		else {
			IV[i]++;
			return;
			}
}
int blockEncrypt(cipherInstance *cipher, keyInstance *key, BYTE *input,
				 int inputLen, BYTE *outBuffer)
{
	int		i, j, t, numBlocks;
	BYTE	block[4][MAXBC];
	BYTE	IV[MAX_IV_SIZE];
	BYTE	inbit;

	/* check parameter consistency: */
	if ( (key == NULL) ||
		 (((cipher->mode == MODE_ECB) || (cipher->mode == MODE_CBC)) && (key->direction != DIR_ENCRYPT)) ||
		 ((key->keyLen != 128) && (key->keyLen != 192) && (key->keyLen != 256)) )
			return BAD_KEY_MAT;
	if ( (cipher == NULL) ||
		 ((cipher->mode != MODE_ECB) && (cipher->mode != MODE_CBC) &&
		  (cipher->mode != MODE_CFB1) && (cipher->mode != MODE_CFB8) &&
		  (cipher->mode != MODE_CFB128) && (cipher->mode != MODE_OFB) &&
		  (cipher->mode != MODE_COUNTER) && (cipher->mode != MODE_CBC_MAC)) ||
		 (cipher->blockLen != 128) )
			return BAD_CIPHER_STATE;
	numBlocks = inputLen/cipher->blockLen;
	switch (cipher->mode) {
		case MODE_ECB: 
			for ( i=0; i<numBlocks; i++ ) {
				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						block[t][j] = input[i*16+4*j+t];

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						outBuffer[i*16+4*j+t] = block[t][j];
				}
			break;
		
		case MODE_CBC:
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					block[t][j] = cipher->IV[t+4*j];
			for ( i=0; i<numBlocks; i++ ) {
				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						block[t][j] ^= input[i*16+4*j+t];

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						outBuffer[i*16+4*j+t] = block[t][j];
				}
			/*  Update the IV when done for next call  */
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					cipher->IV[t+4*j] = block[t][j];
			break;

		case MODE_CFB1:
			numBlocks = inputLen / cipher->segLen;
			for ( i=0; i<numBlocks; i++ ) {
				if ( i == 0 )
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							IV[t+4*j] = block[t][j] = cipher->IV[t+4*j];
				else {
					for ( j=0; j<cipher->blockLen/8-1; j++ )
						IV[j] = ((IV[j] << 1) & 0xfe) | ((IV[j+1] >> 7) & 0x01);
					IV[cipher->blockLen/8-1] =
						((IV[cipher->blockLen/8-1] << 1) & 0xfe) | ((block[0][0] >> 7) & 0x01);

					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = IV[t+4*j];
					}

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				inbit = GetBit(input[i/8], i);

				block[0][0] ^= (inbit << 7);
				PutBit(&(outBuffer[i/8]), block[0][0], i);
				}
			/*  Update IV for the next call  */
			for ( j=0; j<cipher->blockLen/8-1; j++ )
				cipher->IV[j] = ((IV[j] << 1) & 0xfe) | ((IV[j+1] >> 7) & 0x01);
			cipher->IV[cipher->blockLen/8-1] =
				((IV[cipher->blockLen/8-1] << 1) & 0xfe) | ((block[0][0] >> 7) & 0x01);
			return numBlocks*cipher->segLen;
			break;

		case MODE_CFB8:
			numBlocks = inputLen / cipher->segLen;
			for ( i=0; i<numBlocks; i++ ) {
				if ( i == 0 )
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							IV[t+4*j] = block[t][j] = cipher->IV[t+4*j];
				else {
					for ( j=0; j<cipher->blockLen/8-1; j++ )
						IV[j] = IV[j+1];
					IV[cipher->blockLen/8-1] = block[0][0];

					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = IV[t+4*j];
					}

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				block[0][0] ^= input[i];
				outBuffer[i] = block[0][0];
				}
			/*  Update IV for the next call  */
			for ( j=0; j<cipher->blockLen/8-1; j++ )
				cipher->IV[j] = IV[j+1];
			cipher->IV[cipher->blockLen/8-1] = block[0][0];
			return numBlocks*cipher->segLen;
			break;

		case MODE_CFB128:
			numBlocks = inputLen / cipher->segLen;
			for ( i=0; i<numBlocks; i++ ) {
				if ( i == 0 )
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = cipher->IV[t+4*j];

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						outBuffer[i*16+4*j+t] = block[t][j] ^= input[i*16+4*j+t];
				}
			/*  Update IV for the next call  */
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					cipher->IV[4*j+t] = block[t][j];
			return numBlocks*cipher->segLen;
			break;

		case MODE_OFB:
			for ( i=0; i<numBlocks; i++ ) {
				if ( i == 0 )
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = cipher->IV[t+4*j];

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						outBuffer[i*16+4*j+t] = block[t][j] ^ input[i*16+4*j+t];
				}
			/*  Update IV for the next call  */
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					cipher->IV[4*j+t] = block[t][j];
			break;

		case MODE_COUNTER:
			for ( i=0; i<numBlocks; i++ ) {
				if ( i == 0 ) 
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = IV[t+4*j] = cipher->IV[t+4*j];
				else {
					bumpCount(IV, cipher->blockLen);
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = IV[t+4*j];
					}

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						outBuffer[i*16+4*j+t] = block[t][j] ^ input[i*16+4*j+t];
				}
			/*  Update IV for the next call  */
			bumpCount(IV, cipher->blockLen);
			for ( j=0; j<cipher->blockLen/8; j++ )
				cipher->IV[j] = IV[j];
			break;
		
		case MODE_CBC_MAC:
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					block[t][j] = cipher->IV[t+4*j];
			for ( i=0; i<numBlocks; i++ ) {
				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						block[t][j] ^= input[i*16+4*j+t];

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				}
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					cipher->IV[4*j+t] = outBuffer[4*j+t] = block[t][j];
			break;
	
		default: return BAD_CIPHER_STATE;
		}
	
	return numBlocks*cipher->blockLen;
}

int blockDecrypt(cipherInstance *cipher, keyInstance *key, BYTE *input,
				 int inputLen, BYTE *outBuffer)
{
	int		i, j, t, numBlocks;
	BYTE	block[4][MAXBC];
	BYTE	IV[MAX_IV_SIZE];
	BYTE	inbit;

	if ( (cipher==NULL) || (key==NULL) || (cipher->blockLen != key->blockLen) )
		return BAD_CIPHER_STATE;
	if ( (key->direction == DIR_ENCRYPT) && ((cipher->mode==MODE_ECB) || (cipher->mode==MODE_CBC)) )
		return BAD_CIPHER_STATE;

	/* check parameter consistency: */
	if ( (key == NULL) ||
		 (((cipher->mode == MODE_ECB) || (cipher->mode == MODE_CBC)) && (key->direction != DIR_DECRYPT)) ||
		 ((key->keyLen != 128) && (key->keyLen != 192) && (key->keyLen != 256)) )
			return BAD_KEY_MAT;
	if ( (cipher == NULL) ||
		 ((cipher->mode != MODE_ECB) && (cipher->mode != MODE_CBC) &&
		  (cipher->mode != MODE_CFB1) && (cipher->mode != MODE_CFB8) &&
		  (cipher->mode != MODE_CFB128) && (cipher->mode != MODE_OFB) &&
		  (cipher->mode != MODE_COUNTER) && (cipher->mode != MODE_CBC_MAC)) ||
		 (cipher->blockLen != 128) )
			return BAD_CIPHER_STATE;

	numBlocks = inputLen/cipher->blockLen;
	
	switch (cipher->mode) {
		case MODE_ECB: 
			for ( i=0; i<numBlocks; i++ ) {
				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						block[t][j] = input[i*16+4*j+t];

				rijndaelDecrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						outBuffer[i*16+4*j+t] = block[t][j];
				}
			break;
		
		case MODE_CBC:
			/* first block */
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					block[t][j] = input[4*j+t];

			rijndaelDecrypt(block, key->keyLen, cipher->blockLen, key->keySched);
			
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					outBuffer[4*j+t] = block[t][j] ^ cipher->IV[t+4*j];
			
			/* next blocks */
			for ( i=1; i<numBlocks; i++ ) {
				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						block[t][j] = input[i*16+4*j+t];

				rijndaelDecrypt(block, key->keyLen, cipher->blockLen, key->keySched);
				
				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						outBuffer[i*16+4*j+t] = block[t][j] ^ input[4*j+t+(i-1)*16];
				}
			/*  Update the IV when done for next call  */
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					cipher->IV[t+4*j] = input[4*j+t+(numBlocks-1)*16];
			break;

		case MODE_CFB1:
			numBlocks = inputLen / cipher->segLen;
			for ( i=0; i<numBlocks; i++ ) {
				if ( i == 0 )
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							IV[t+4*j] = block[t][j] = cipher->IV[t+4*j];
				else {
					for ( j=0; j<cipher->blockLen/8-1; j++ )
						IV[j] = ((IV[j] << 1) & 0xfe) | ((IV[j+1] >> 7) & 0x01);
					inbit = GetBit(input[(i-1)/8], i-1);
					IV[cipher->blockLen/8-1] =
						((IV[cipher->blockLen/8-1] << 1) & 0xfe) | inbit;

					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = IV[t+4*j];
					}

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				inbit = GetBit(input[i/8], i);

				block[0][0] ^= (inbit << 7);
				PutBit(&(outBuffer[i/8]), block[0][0], i);
				}
			/*  Update IV for the next call  */
			for ( j=0; j<cipher->blockLen/8-1; j++ )
				cipher->IV[j] = ((IV[j] << 1) & 0xfe) | ((IV[j+1] >> 7) & 0x01);
			inbit = GetBit(input[(i-1)/8], i-1);
			cipher->IV[cipher->blockLen/8-1] =
				((IV[cipher->blockLen/8-1] << 1) & 0xfe) | inbit;
			return numBlocks*cipher->segLen;
			break;

		case MODE_CFB8:
			numBlocks = inputLen / cipher->segLen;
			for ( i=0; i<numBlocks; i++ ) {
				if ( i == 0 )
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							IV[t+4*j] = block[t][j] = cipher->IV[t+4*j];
				else {
					for ( j=0; j<cipher->blockLen/8-1; j++ )
						IV[j] = IV[j+1];
					IV[cipher->blockLen/8-1] = input[i-1];

					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = IV[t+4*j];
					}

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				outBuffer[i] = block[0][0] ^ input[i];
				}
			/*  Update IV for the next call  */
			for ( j=0; j<cipher->blockLen/8-1; j++ )
				cipher->IV[j] = IV[j+1];
			cipher->IV[cipher->blockLen/8-1] = input[i-1];
			return numBlocks*cipher->segLen;
			break;

		case MODE_CFB128:
			numBlocks = inputLen / cipher->segLen;
			for ( i=0; i<numBlocks; i++ ) {
				if ( i == 0 )
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = cipher->IV[t+4*j];
				else {
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = input[(i-1)*16+4*j+t];
					}

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						outBuffer[i*16+4*j+t] = input[i*16+4*j+t] ^ block[t][j];
				}
			/*  Update IV for the next call  */
			for ( j=0; j<cipher->blockLen/8; j++ )
				cipher->IV[j] = input[(i-1)*16+j];
			return numBlocks*cipher->segLen;
			break;

		case MODE_OFB:
			for ( i=0; i<numBlocks; i++ ) {
				if ( i == 0 )
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = cipher->IV[t+4*j];

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						outBuffer[i*16+4*j+t] = block[t][j] ^ input[i*16+4*j+t];
				}
			/*  Update IV for the next call  */
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					cipher->IV[4*j+t] = block[t][j];
			break;

		case MODE_COUNTER:
			for ( i=0; i<numBlocks; i++ ) {
				if ( i == 0 ) 
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = IV[t+4*j] = cipher->IV[t+4*j];
				else {
					bumpCount(IV, cipher->blockLen);
					for ( j=0; j<cipher->blockLen/32; j++ )
						for( t=0; t<4; t++ )
							block[t][j] = IV[t+4*j];
					}

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);

				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						outBuffer[i*16+4*j+t] = block[t][j] ^ input[i*16+4*j+t];
				}
			/*  Update IV for the next call  */
			bumpCount(IV, cipher->blockLen);
			for ( j=0; j<cipher->blockLen/8; j++ )
				cipher->IV[j] = IV[j];
			break;
		
		case MODE_CBC_MAC:
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					block[t][j] = cipher->IV[t+4*j];
			for ( i=0; i<numBlocks; i++ ) {
				for ( j=0; j<cipher->blockLen/32; j++ )
					for( t=0; t<4; t++ )
						block[t][j] ^= input[i*16+4*j+t];

				rijndaelEncrypt(block, key->keyLen, cipher->blockLen, key->keySched);
				}
			for ( j=0; j<cipher->blockLen/32; j++ )
				for( t=0; t<4; t++ )
					cipher->IV[4*j+t] = outBuffer[4*j+t] = block[t][j];
			break;
	
		default:
			return BAD_CIPHER_STATE;
		}
	
	return numBlocks*cipher->blockLen;
}
#endif // ORIGINAL_ENTRY_WRONG_SECOND_BLOCK


/**
 *    cipherUpdateRounds:
 *
 *    Encrypts/Decrypts exactly one full block a specified number of rounds.
 *    Only used in the Intermediate Value Known Answer Test.    
 *
 *    Returns:
 *        TRUE - on success
 *        BAD_CIPHER_STATE - cipher in bad state (e.g., not initialized)
 */
int cipherUpdateRounds(cipherInstance *cipher,
    keyInstance *key, BYTE *input, int inputLen, BYTE *outBuffer, int rounds)
{
    int j, t;
    word8 block[4][MAXBC];

    if (cipher == NULL ||
        key == NULL ||
        cipher->blockLen != key->blockLen) {
        return BAD_CIPHER_STATE;
    }

    for (j = 0; j < cipher->blockLen/32; j++) {
        for(t = 0; t < 4; t++)
            /* parse input stream into rectangular array */
            block[t][j] = (unsigned char)(input[4*j+t] & 0xFF);
    }
    switch (key->direction) {
    case DIR_ENCRYPT:
        rijndaelEncryptRound (block, key->keyLen, cipher->blockLen, 
                key->keySched, rounds);
    break;
        
    case DIR_DECRYPT:
        rijndaelDecryptRound (block, key->keyLen, cipher->blockLen, 
                key->keySched, rounds);
    break;
        
    default: return BAD_KEY_DIR;
    } 
    for (j = 0; j < cipher->blockLen/32; j++) {
        /* parse rectangular array into output ciphertext bytes */
        for(t = 0; t < 4; t++)
            outBuffer[4*j+t] = (BYTE) block[t][j];
    }


#ifdef WIN32
    inputLen;   // AVOIDS warning.
#endif
    
    return TRUE;
}


//
//
// THIS ROUTINE IGNORES THE IV vector in the cipherInstance.  It is unnecessary 
// for the key wrap algorithm described in RFC3394 (it is hard-coded).
// RWC; IT IS ASSUMED that the input length and the key length are the same, 
//      since it is a requirement that the content encryption algorithm and
//      the key wrap algorithm be the same (e.g. both must be 256 bits).
/* RWC;FROM RFC3394:
   Inputs:  Plaintext, n 64-bit values {P1, P2, ..., Pn}, and
            Key, K (the KEK).
   Outputs: Ciphertext, (n+1) 64-bit values {C0, C1, ..., Cn}.

   RWC; Alternative approach.  
   1) Initialize variables.

       Set A = IV, an initial value (see 2.2.3)
       For i = 1 to n
           R[i] = P[i]

   2) Calculate intermediate values.

       For j = 0 to 5
           For i=1 to n
               B = AES(K, A | R[i])
               A = MSB(64, B) ^ t where t = (n*j)+i
               R[i] = LSB(64, B)

   3) Output the results.

       Set C[0] = A
       For i = 1 to n
           C[i] = R[i]

  RWC; in our case, each "n" refers to a 64 bit block count, 
       for 128 bits, our n=2.  Our maximum "n" will be 4 (for 256 bits).
*/
#define RWC_DEBUG
int SM_KeyWrap_blockEncrypt(cipherInstance *cipher,
        keyInstance *key, BYTE *input, int inputLen, BYTE *outBuffer)
{
    int ii, jj, k, t; //RWC;, i, numBlocks;
    word8 block[4][MAXBC];
    word8 wA[4][2] = { 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6 };
    word8 wR[4][MAXBC*4];   // MAX 256 bit key input
    int n = inputLen/*RWC;cipher->blockLen*//32;

    
        /* check parameter consistency: */
        if (key == NULL ||
                key->direction != DIR_ENCRYPT ||
                (key->keyLen != 128 && key->keyLen != 192 && key->keyLen != 256)) {
                return BAD_KEY_MAT;
        }
        if (cipher == NULL ||
                (cipher->mode != MODE_ECB && cipher->mode != MODE_CBC && cipher->mode != MODE_CFB1) ||
                (cipher->blockLen != 128 && cipher->blockLen != 192 && cipher->blockLen != 256)) {
                return BAD_CIPHER_STATE;
        }


    //RWC;numBlocks = inputLen/cipher->blockLen;
 
        // *** FIRST, INIT, setup the initial block entry, with init above (done by data)
        // *** SECOND, INIT, setup input data into register
        for (ii = 0; ii < n/2; ii++) 
        {
            for(t = 0; t < 4; t++)
            {
               //block[t][ii] = (unsigned char)(cipher->IV[t+4*j] & 0xFF);
                wR[t][ii] = input[4*ii+t] & 0xFF;
                wR[t][(n/2)+ii] = input[4*ii+(n*4/2)+t] & 0xFF;
            }   // END FOR t
        }       // END FOR cipher->blockLen/32
        // *** THIRD, Perform transformation on register contents
#ifdef RWC_DEBUG
        printf("Step t            A                R1               R2\n");
#endif //RWC_DEBUG
        //RWC;for (i = 0; i < numBlocks; i++)     // RWC;SHOULD ALWAYS BE 1
        //RWC;{
        for (jj = 0; jj < 6; jj++)  // LOOP 6 times for WRAP operation.
        {
#ifdef RWC_DEBUG
            printf("  Step %d\n", jj);
#endif //RWC_DEBUG
        for (ii = 0; ii < n/2; ii++)
        {
            // *** COMBINE A (64 bits) with R (64 bits) to make complete 
            //     block (128 bit)
            for (k = 0; k < 2; k++) 
            {
                for(t = 0; t < 4; t++)
                {
                    block[t][k]   = wA[t][k] & 0xFF;
                    block[t][k+2] = wR[t][ii*2+k] & 0xFF;
                }   // END FOR t
            }       // END FOR cipher->blockLen/32
#ifdef RWC_DEBUG
                printf("  in ");
                for (k = 0; k < 2; k++) 
                {
                    for(t = 0; t < 4; t++)
                        printf("%2.2x", wA[t][k] & 0xFF);
                }       // END FOR cipher->blockLen/32
                for (k = 0; k < n; k++) 
                {
                    if (k%2 == 0)     // SPLIT "R"
                       printf("    ");
                    for(t = 0; t < 4; t++)
                        printf("%2.2x", wR[t][k] & 0xFF);
                }       // END FOR cipher->blockLen/32
                printf("\n");
#endif //RWC_DEBUG
            rijndaelEncrypt (block, key->keyLen, /*128/*/cipher->blockLen, 
                             key->keySched);
            // *** EXTRACT A (64 bits) and R (64 bits) from AES processed 
            //     block (128 bit)
            for (k = 0; k < 2; k++) 
            {
                for(t = 0; t < 4; t++)
                {
                    wA[t][k]      = block[t][k] & 0xFF;
                    wR[t][ii*2+k] = block[t][k+2] & 0xFF;
                }   // END FOR t
            }       // END FOR cipher->blockLen/32
            wA[3][1] ^= ((n/2)*jj) + (ii+1); //t = (n*j)+i;
                                            //RWC;ALWAYS in MSB byte of "A"
        }           // END FOR n
        }           // END FOR jj


        //RWC;}           // END FOR numBlocks
        // *** CREATE OUTPUT from A (64 bits) THEN R 
        for (k = 0; k < 2; k++) 
        {
            for(t = 0; t < 4; t++)
                outBuffer[0 + k*4 + t] = wA[t][k] & 0xFF;
        }       // END FOR cipher->blockLen/32
        for (ii = 0; ii < n/2; ii++)
        {
            for (k = 0; k < 2; k++) 
            {
                for(t = 0; t < 4; t++)
                    outBuffer[(ii+1)*8 + k*4 + t] = wR[t][ii*2+k] & 0xFF;
            }       // END FOR cipher->blockLen/32
        }           // END FOR n
#ifdef RWC_DEBUG
            printf("CipherText out: ");
            for (k = 0; k < 8; k++)
               printf("%2.2x", outBuffer[k] & 0xFF);
            for (ii=0; ii < n/2; ii++)
            {
                printf("    ");
                for (k = 0; k < 8; k++)
                   printf("%2.2x", outBuffer[(ii+1)*8+k] & 0xFF);
            }
            printf("\n");
#endif //RWC_DEBUG
    
    return (n*32)+64;//RWC;numBlocks*cipher->blockLen;
}       // END SM_KeyWrap_blockEncrypt(...)



//
// SM_KeyWrap_blockDecrypt
/*
   Inputs:  Ciphertext, (n+1) 64-bit values {C0, C1, ..., Cn}, and
            Key, K (the KEK).
   Outputs: Plaintext, n 64-bit values {P0, P1, K, Pn}.

   1) Initialize variables.

       Set A = C[0]
       For i = 1 to n
           R[i] = C[i]

   2) Compute intermediate values.

       For j = 5 to 0
           For i = n to 1
               B = AES-1(K, (A ^ t) | R[i]) where t = n*j+i
               A = MSB(64, B)
               R[i] = LSB(64, B)

   3) Output results.

   If A is an appropriate initial value (see 2.2.3),
   Then
       For i = 1 to n
           P[i] = R[i]
   Else
       Return an error 
*/
//
//
int SM_KeyWrap_blockDecrypt(cipherInstance *cipher,
    keyInstance *key, BYTE *input, int inputLen, BYTE *outBuffer)
{
    int ii, jj, k, t; //RWC;, i, numBlocks;
    int status=-1;
    word8 block[4][MAXBC];
    word8 wAExpected[4][2] = { 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6, 0xA6 };
    word8 wA[4][2];
    word8 wR[4][MAXBC*4];   // MAX 256 bit key input
    int n = (inputLen-64)/32;   // RWC; be sure to subtract init, "wA", 
                                //      length above.


    if (cipher == NULL ||
        key == NULL ||
        key->direction == DIR_ENCRYPT ||
        cipher->blockLen != key->blockLen) {
        return BAD_CIPHER_STATE;
    }

        /* check parameter consistency: */
        if (key == NULL ||
                key->direction != DIR_DECRYPT ||
                (key->keyLen != 128 && key->keyLen != 192 && key->keyLen != 256)) {
                return BAD_KEY_MAT;
        }
        if (cipher == NULL ||
                (cipher->mode != MODE_ECB && cipher->mode != MODE_CBC && cipher->mode != MODE_CFB1) ||
                (cipher->blockLen != 128 && cipher->blockLen != 192 && cipher->blockLen != 256)) {
                return BAD_CIPHER_STATE;
        }
    

    //RWC;numBlocks = (inputLen-64)/cipher->blockLen;  //subtract init bits for data.
    
        // *** FIRST, INIT, setup the initial block entry, with init above 
        // ***              (1st block of data)
        for (k = 0; k < 2; k++) 
        {
            for(t = 0; t < 4; t++)
            {
                wA[t][k] = input[4*k+t] & 0xFF;
            }   // END FOR t
        }       // END FOR k
        // *** SECOND, INIT, setup input data into register
        for (ii = 0; ii < n/2; ii++) 
        {
            for(t = 0; t < 4; t++)
            {
                wR[t][ii] = input[4*(ii+2)+t] & 0xFF;
                wR[t][(n/2)+ii] = input[4*(ii+2)+(n*4/2)+t] & 0xFF;
            }   // END FOR t
        }       // END FOR k


#ifdef RWC_DEBUG
        printf("Step t            A                R1               R2\n");
#endif //RWC_DEBUG
        //RWC;for (i = 0; i < numBlocks; i++) 
        //{
        for (jj = 5; jj >=0; jj--)  // LOOP 6 times for WRAP operation.
        {
#ifdef RWC_DEBUG
            printf("  Step %d\n", jj);
#endif //RWC_DEBUG
        for (ii = n/2-1; ii >= 0; ii--)
        {
            // *** COMBINE A (64 bits) with R (64 bits) to make complete 
            //     block (128 bit)
            wA[3][1] ^= ((n/2)*jj) + (ii+1); //t = (n*j)+i;
                                            //RWC;ALWAYS in MSB byte of "A"
            for (k = 0; k < 2; k++) 
            {
                for(t = 0; t < 4; t++)
                {
                    block[t][k]   = wA[t][k] & 0xFF;
                    block[t][k+2] = wR[t][ii*2+k] & 0xFF;
                }   // END FOR t
            }       // END FOR k
#ifdef RWC_DEBUG
                printf("  in ");
                for (k = 0; k < 2; k++) 
                {
                    for(t = 0; t < 4; t++)
                        printf("%2.2x", wA[t][k] & 0xFF);
                }       // END FOR k
                for (k = 0; k < n; k++) 
                {
                    if (k%2 == 0)     // SPLIT "R"
                       printf("    ");
                    for(t = 0; t < 4; t++)
                        printf("%2.2x", wR[t][k] & 0xFF);
                }       // END FOR k
                printf("\n");
#endif //RWC_DEBUG
            rijndaelDecrypt (block, key->keyLen, cipher->blockLen, key->keySched);

            // *** EXTRACT A (64 bits) and R (64 bits) from AES processed 
            //     block (128 bit)
            for (k = 0; k < 2; k++) 
            {
                for(t = 0; t < 4; t++)
                {
                    wA[t][k]      = block[t][k] & 0xFF;
                    wR[t][ii*2+k] = block[t][k+2] & 0xFF;
                }   // END FOR t
            }       // END FOR k
        }           // END FOR n
        }           // END FOR jj


        //}
        // *** CREATE OUTPUT from A (64 bits) THEN R 
        status = 0;
        for (k = 0; k < 2; k++) 
        {
            for(t = 0; t < 4; t++)
                if (wAExpected[t][k] != wA[t][k])
                    status = -1;// ERROR, since INIT array not reconstructed.
        }       // END FOR cipher->blockLen/32
        if (status == 0)
            status = n*32;//RWC;numBlocks*cipher->blockLen;    //RETURN count.
        for (ii = 0; ii < n/2; ii++)
        {
            for (k = 0; k < 2; k++) 
            {
                for(t = 0; t < 4; t++)
                    outBuffer[ii*8 + k*4 + t] = wR[t][ii*2+k] & 0xFF;
            }       // END FOR cipher->blockLen/32
        }           // END FOR n
#ifdef RWC_DEBUG
            printf("Decrypted CipherText out: ");
            for (ii=0; ii < n/2; ii++)
            {
                printf("    ");
                for (k = 0; k < 8; k++)
                   printf("%2.2x", outBuffer[ii*8+k] & 0xFF);
            }
            printf("\n");
#endif //RWC_DEBUG
    
    return status;
}       // END SM_KeyWrap_blockDecrypt(...)

// EOF rijndael-api-ref.c