rem
rem SMP_libcert_BuildDist.bat

echo SMP_libcert_BuildDist.bat batch file.
rem set MAKE=..\..\SMPDist\util\bin\make.exe 
rem @IF NOT EXIST %MAKE% goto error 
 
IF NOT EXIST ..\..\..\SMPDist                     mkdir ..\..\..\SMPDist
IF NOT EXIST ..\..\..\SMPDist\sfl                 mkdir ..\..\..\SMPDist\sfl
IF NOT EXIST ..\..\..\SMPDist\sfl\libcert mkdir ..\..\..\SMPDist\sfl\libcert 
IF NOT EXIST ..\..\..\SMPDist\sfl\libcert\include mkdir ..\..\..\SMPDist\sfl\libcert\include 
IF NOT EXIST ..\..\..\SMPDist\sfl\libcert\lib     mkdir ..\..\..\SMPDist\sfl\libcert\lib 
IF NOT EXIST ..\..\..\SMPDist\sfl\libcert\asn1    mkdir ..\..\..\SMPDist\sfl\libcert\asn1 
IF NOT EXIST ..\..\..\SMPDist\sfl\libCtilMgr mkdir ..\..\..\SMPDist\sfl\libCtilMgr 
IF NOT EXIST ..\..\..\SMPDist\sfl\libCtilMgr\include mkdir ..\..\..\SMPDist\sfl\libCtilMgr\include 
IF NOT EXIST ..\..\..\SMPDist\sfl\libCtilMgr\lib     mkdir ..\..\..\SMPDist\sfl\libCtilMgr\lib 


xcopy ..\..\libcert\include\*.h   ..\..\..\SMPDist\sfl\libcert\include /d 
xcopy ..\..\libcert\asn1\*.asn   ..\..\..\SMPDist\sfl\libcert\asn1 /d 
xcopy ..\..\libcert\libcertDLL\Debug\*.lib  ..\..\..\SMPDist\sfl\libcert\lib /d 
xcopy ..\..\libcert\libcertDLL\Release\*.lib  ..\..\..\SMPDist\sfl\libcert\lib /d 
xcopy ..\..\test\libcert*.dll ..\..\..\SMPDist\sfl\libcert\lib /d 
xcopy ..\..\libcert\src\sm_listCert.cpp   ..\..\..\SMPDist\sfl\libcert\include /d
xcopy ..\..\lib\libcert*.lib ..\..\..\SMPDist\sfl\libcert\lib /d 
xcopy ..\..\libCtilMgr\include\*.h   ..\..\..\SMPDist\sfl\libCtilMgr\include /d 
xcopy ..\..\test\libCtilMgr*.dll ..\..\..\SMPDist\sfl\libCtilMgr\lib /d 
xcopy ..\..\libCtilMgr\src\sm_listCtil.cpp   ..\..\..\SMPDist\sfl\libCtilMgr\include /d
xcopy ..\..\lib\libCtilMgr*.lib ..\..\..\SMPDist\sfl\libCtilMgr\lib /d 

xcopy ..\..\test\libcert*.dll %windir%\system32 /d 
xcopy ..\..\test\libCtilMgr*.dll %windir%\system32 /d 

rem EOF SMP_SFL_BuildDist.bat