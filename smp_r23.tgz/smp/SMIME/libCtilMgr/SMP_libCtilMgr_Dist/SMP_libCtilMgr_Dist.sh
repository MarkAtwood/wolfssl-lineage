#
# SMP_libCtilMgr_Dist.sh
#
echo Copy CTIL Manager to SMPDist

mkdir -p ../../../SMPDist/sfl/inc
mkdir -p ../../../SMPDist/sfl/lib
mkdir -p ../../../SMPDist/sfl/asn1

cp  ../libctil.so      ../../../SMPDist/sfl/lib
cp  ../inc/*.h      ../../../SMPDist/sfl/inc
cp  ../src/*.asn      ../../../SMPDist/sfl/asn1

echo CTIL Manager copy DONE!
# EOF SMP_libCtilMgr_Dist.sh
