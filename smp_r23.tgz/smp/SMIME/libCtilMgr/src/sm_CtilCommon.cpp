#include "sm_CtilCommon.h"
#include "sm_usefulTypes.h"

_BEGIN_CTIL_NAMESPACE 
using namespace SNACC; 
// FUNCTION: CSM_DSAParams Constructor
//
// PURPOSE: Initialize P,Q,G private members to 0.
//
CSM_DSAParams::CSM_DSAParams()
{
   P = NULL;
   Q = NULL;
   G = NULL;
   m_lParamLength = 128;		// DEFAULT
}

//
//
CSM_DSAParams::~CSM_DSAParams()
{
   if (P) free(P);
   if (Q) free(Q);
   if (G) free(G);
}


// FUNCTION: DecodeParams
//
// PURPOSE: To decoded the ASN.1 encoded DSAWithSHA1Parameters from
//          pParams into the private member variable m_pSnaccParams
//
SM_RET_VAL CSM_DSAParams::Decode(CSM_Buffer *pParams)
{
   SM_RET_VAL status = SM_NO_ERROR;
   DSAWithSHA1Parameters *pSnaccV3CertParams;
   Kea_Dss_Parms           *pSnaccV1CertParams;
   size_t                 paramLen = 0;
   long error =  0;
   int pParamSize=0;
   unsigned char *ptr;

   SME_SETUP("CSM_DSAParams::Decode()");

   // V3 Certificate style parameters
   //
   pSnaccV3CertParams = new DSAWithSHA1Parameters;

   DECODE_BUF_NOFAIL(pSnaccV3CertParams, pParams,  error);
   
   // IF no error then use CSM_BigIntegerStr class to 
   //    perform big integer processing on  P, Q, and G.
   //
   //    note: this is only necessary for V3 certs
   //
   if (error == 0)
   {
       if (pSnaccV3CertParams->p.length() <= 65)
           pParamSize = 64;     // Smaller signature.
       else
           pParamSize = SM_DSA_P_LEN; // larger signature.
       pSnaccV3CertParams->p.getPadded/*RWC;Get*/(ptr, 
          paramLen, pParamSize);
       if (paramLen && ptr)
       {
           P = (char *)calloc(1, paramLen);
           memcpy(P, ptr, paramLen);
           free(ptr);
           ptr = NULL;
       }
       pSnaccV3CertParams->q.getPadded/*RWC;Get*/(ptr, 
          paramLen, (unsigned int) SM_DSA_Q_LEN);
       if (paramLen && ptr)
       {
           Q = (char *)calloc(1, paramLen);
           memcpy(Q, ptr, paramLen);
           free(ptr);
           ptr = NULL;
       }
       pSnaccV3CertParams->g.getPadded/*RWC;Get*/(ptr, 
          paramLen, (unsigned int) pParamSize);
       if (paramLen && ptr)
       {
           G = (char *)calloc(1, paramLen);
           memcpy(G, ptr, paramLen);
           free(ptr);
           ptr = NULL;
       }
       m_lParamLength = paramLen;
   }
   else
   {
      // Try V1 Certificate style DSS Parameters
      //
      P = (char *) calloc(1, SM_DSA_P_LEN);
      Q = (char *) calloc(1, SM_DSA_Q_LEN);
      G = (char *) calloc(1, SM_DSA_G_LEN);

      pSnaccV1CertParams = new Kea_Dss_Parms;
      DECODE_BUF_NOFAIL(pSnaccV1CertParams, pParams, error);

      if (error)
         SME_THROW(error,"Error decoding Subject Public Key parameters", NULL);

      if ( pSnaccV1CertParams->choiceId == pSnaccV1CertParams->different_ParmsCid )
      {
         if ( (pSnaccV1CertParams->different_Parms->dss_Parms->p.Len() != SM_DSA_P_LEN) ||
              (pSnaccV1CertParams->different_Parms->dss_Parms->q.Len() != SM_DSA_Q_LEN) ||  
              (pSnaccV1CertParams->different_Parms->dss_Parms->g.Len() != SM_DSA_G_LEN) )
            
         {
            SME_THROW(-1,"Invalid DSS Parameters", NULL);
         }
         else
         {
            memcpy(P, pSnaccV1CertParams->different_Parms->dss_Parms->p.c_str(), 
                                                                     SM_DSA_P_LEN);
            memcpy(Q, pSnaccV1CertParams->different_Parms->dss_Parms->q.c_str(), 
                                                                     SM_DSA_Q_LEN);
            memcpy(G, pSnaccV1CertParams->different_Parms->dss_Parms->g.c_str(), 
                                                                     SM_DSA_G_LEN);
         }
      }
      else if ( pSnaccV1CertParams->choiceId == pSnaccV1CertParams->common_ParmsCid )
      {
         if ( (pSnaccV1CertParams->common_Parms->p.Len() != SM_DSA_P_LEN) ||
              (pSnaccV1CertParams->common_Parms->q.Len() != SM_DSA_Q_LEN) ||
              (pSnaccV1CertParams->common_Parms->g.Len() != SM_DSA_G_LEN) )
         {
            SME_THROW(-1,"Invalid DSS Parameters", NULL);
         }
         else
         {
            memcpy(P, pSnaccV1CertParams->common_Parms->p.c_str(), SM_DSA_P_LEN);
            memcpy(Q, pSnaccV1CertParams->common_Parms->q.c_str(), SM_DSA_Q_LEN);
            memcpy(G, pSnaccV1CertParams->common_Parms->g.c_str(), SM_DSA_G_LEN);
         }
      }
      delete pSnaccV1CertParams;
      m_lParamLength = SM_DSA_P_LEN;
   }

   delete pSnaccV3CertParams;

   return status;

   SME_FINISH_CATCH;
}

_END_CTIL_NAMESPACE 

// EOF sm_CtilCommon.cpp
