
//////////////////////////////////////////////////////////////////////////
// sm_commonCTIL.cpp
//
// This CTI Library implements DSA, 3DES, and DH using crypto++ and AES
// It will inherit SHA1 from the sm_common CTI
//  RWC; THIS VERSION integrates "crpypto++ 3.0".
//
//////////////////////////////////////////////////////////////////////////
// THIS CTILf DOES NOT FOLLOW THE Typical rules for the dynamic loaded CTILs.
//  IT IS statically linked and available to all CSMIME instances.

#ifdef WIN32
#pragma  warning( disable : 4512 4100 4511 4663 4018 4244 4146 4097 ) 
                                    // IGNORE warnings from MS includes? 
                                    //  (?WHY present in MSVC?).
#endif
#include "sm_common.h"
//#include "sm_cms.h"
//#include "sm_VDASupport_asn.h"
#include "sm_apiCtilMgr.h"
//#include "sm_AppLogin.h"
#include "sm_CtilCommon.h"

_BEGIN_CTIL_NAMESPACE 
using namespace SNACC; 

//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_CommonCTIL::SMTI_Login(void)
{
   return SM_NO_ERROR;
}

//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_CommonCTIL::SMTI_Sign(
            CSM_Buffer *pData, // input, data to be signed
            CSM_Buffer *pEncryptedDigest, // signature output
            CSM_Buffer *pDigest) // digest
{

   SME_SETUP("CSM_CommonCTIL::SMTI_Sign");
   SME_THROW(22, "SMTI_Sign NOT SUPPORTED BY SMTI_CommonCTIL.", NULL);
   SME_FINISH_CATCH

   return SM_NO_ERROR;
}
//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_CommonCTIL::SMTI_Verify(
            CSM_Buffer *pSignerKey, // input
            CSM_Alg    *pDigestAlg, // input
            CSM_Alg    *pSignatureAlg, // input
            CSM_Buffer *pData, // input
            CSM_Buffer *pSignature) // input
{
   SM_RET_VAL lRet = -1;
   SME_SETUP("CSM_CommonCTIL::SMTI_Verify");

   lRet = CSM_Common::SMTI_Verify(pSignerKey, pDigestAlg, pSignatureAlg,  
            pData, pSignature);

   SME_FINISH_CATCH

   return lRet;
}

//////////////////////////////////////////////////////////////////////////
// This routine now handles just the common AES content encryption alg.
SM_RET_VAL CSM_CommonCTIL::SMTI_Encrypt(
            CSM_Buffer *pData, // input (data to be encrypted)
            CSM_Buffer *pEncryptedData, // output
            CSM_Buffer *pParameters, // OUT, for KeyAgree algs.
            CSM_Buffer *pMEK, // In/output; may be specified.
            CSM_Buffer *pIV)  // In, to avoid specific alg encoding by app.
{
   long status = SM_NO_ERROR;

   SME_SETUP("CSM_CommonCTIL::SMTI_Encrypt");

   // check incoming parameters
   if ((pData == NULL) || (pEncryptedData == NULL) ||
       (pParameters == NULL) || (pMEK == NULL))
      SME_THROW(22, "MISSING Parameters", NULL);

   
	  status = 0;

	  // try AES encryption
   SME(status = SMTI_EncryptAES(pData,pEncryptedData, pParameters, pMEK, pIV));
   if (status == 2)
   {
	   SME_THROW(99,"Encryption ERROR invalid Alogrithm oid", NULL);
   }

   SME_FINISH_CATCH

   return SM_NO_ERROR;
}

//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_CommonCTIL::SMTI_GenerateEMEK(
            CSM_Buffer *pRecipient, // input, Y of recip
            CSM_Buffer *pParameters, // IN,OUT may be passed in for shared use
                                     //  OR for ESDH. (p, g, and/or IV).
            CSM_Buffer *pMEK, // input, MEK or special phrase
            CSM_Buffer *pEMEK, // output, encrypted MEK
            CSM_Buffer *pUKM, // input/output may be passed in for shared use.
            CSM_Buffer *pSubjKeyId) // output
{
   SM_RET_VAL status = -1;

   SME_SETUP("CSM_CommonCTIL::SMTI_GenerateEMEK");
   SME_THROW(23, "SMTI_GenerateEMEK NOT SUPPORTED BY SMTI_CommonCTIL.", NULL);
   SME_FINISH_CATCH

   return status;
}

CSM_Buffer *CSM_CommonCTIL::SMTI_GenerateKeyWrapIV(
    long &lKekLength,   // OUT, returned algorithm specific length
    CSM_Alg *pWrapAlg)   // OUT, returned since params are alg specific.
{
   SME_SETUP("CSM_CommonCTIL::SMTI_GenerateKeyWrapIV");
   SME_THROW(23, "SMTI_GenerateKeyWrapIV NOT SUPPORTED BY SMTI_CommonCTIL.", NULL);
   SME_FINISH_CATCH

   return(NULL);
}

//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_CommonCTIL::SMTI_GenerateKeyAgreement(
            CSM_Buffer *pRecipient, // input, Y of recip
            CSM_Buffer *pParameters, // IN,OUT may be passed in for shared use
                                     //  OR for ESDH. (p, g, and/or IV).
            CSM_Buffer *pUKM, // input/output may be passed in for shared use.
                              //   UserKeyMaterial (random number).
            CSM_Buffer *pbufferIV,  // input/output may be passed in for shared use.
                              //   Initialization vector, part of DH params.
            AsnOid *pEncryptionOID,  // IN, specified encryption of key,
                     //   used here in key generation, but alg not implemented.
            CSM_Buffer *pbufKeyAgree, // output, encryption key for this recip.
            long lKekLength)        // Input, for OtherInfo load.
{
   SME_SETUP("CSM_CommonCTIL::SMTI_GenerateKeyAgreement");
   SME_THROW(23, 
       "SMTI_GenerateKeyAgreement NOT SUPPORTED BY SMTI_CommonCTIL.", NULL);
   SME_FINISH_CATCH
   return -1;
}

//
//  This logic is separated out to handle KARI and KEK CMS processing which
//  both use the same KeyWrap algorithm and processing.
SM_RET_VAL CSM_CommonCTIL::SMTI_GenerateKeyWrap(
            CSM_Buffer *pData, // input (data to be encrypted)
            CSM_Buffer *pEncryptedData, // output
            CSM_Buffer *pParameters, // OUT, for KeyAgree algs.
            CSM_Buffer *pMEK, // In/output; may be specified.
            CSM_Buffer *pIV)  // In, to avoid specific alg encoding by app.
{
   SM_RET_VAL lStatus;

   SME_SETUP("CSM_CommonCTIL::SMTI_GenerateKeyWrap")

   lStatus = CSM_Common::SMTI_GenerateKeyWrap(
            pData, pEncryptedData, pParameters, pMEK, pIV);

   SME_FINISH_CATCH
   return(lStatus);
}


//
//  This logic is separated out to handle KARI and KEK CMS processing which
//  both use the same KeyWrap algorithm and processing.
SM_RET_VAL CSM_CommonCTIL::SMTI_ExtractKeyWrapFinish(
            CSM_Buffer *pData, // Output
            CSM_Buffer &CEKICVPAD)  // Input
{
   SME_SETUP("CSM_CommonCTIL::SMTI_ExtractKeyWrapFinish")
   SME_THROW(23, 
       "SMTI_ExtractKeyWrapFinish NOT SUPPORTED BY SMTI_CommonCTIL.", NULL);
   SME_FINISH_CATCH
   return(-1);
}


/////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_CommonCTIL::SMTI_Decrypt(
            CSM_Buffer *pParameters, // input (initialization vector)
            CSM_Buffer *pEncryptedData, // input (data to be decrypted)
            CSM_Buffer *pMEK, // input (MEK or special phrase)
            CSM_Buffer *pData) // output (decrypted data)
{
   long status = SM_NO_ERROR;
   CSM_Buffer *pParamDecodedBuf=NULL;
   AsnOid *pPreferredOID = GetPrefContentEncryption();
   SME_SETUP("CSM_CommonCTIL::SMTI_Decrypt");

   // check incoming parameters
   if ((pData == NULL) || (pEncryptedData == NULL) || (pParameters == NULL)
         || (pMEK == NULL) || pMEK->Access() == NULL)
      SME_THROW(23, "MISSING Parameters", NULL);

   status = 0;
   // unload the parameters to get the iv
   pParamDecodedBuf = UnloadParams(pPreferredOID, *pParameters);

   // try AES encryption
   SME(status = SMTI_DecryptAES(pParameters, pEncryptedData, pMEK, pData, 
		  pParamDecodedBuf));

   if (status == 2)
   {
	   SME_THROW(99,"Decryption ERROR invalid Alogrithm oid", NULL);
   }

   if (pParamDecodedBuf)
	   delete (pParamDecodedBuf);

   SME_FINISH
   SME_CATCH_SETUP
   if (pParamDecodedBuf)
	   delete (pParamDecodedBuf);
   SME_CATCH_FINISH

   return SM_NO_ERROR;
}


//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_CommonCTIL::SMTI_ExtractKeyAgreement(
            CSM_Buffer *pOriginator, // input, Y of originator
            //CSM_Buffer *pParameters, // IN,OUT may be passed in for shared use
                                     //  OR for ESDH. (p, g, and/or IV).
            CSM_Buffer *pUKM, // input/output may be passed in for shared use.
                              //   UserKeyMaterial (random number).
            CSM_Buffer *pbufferIV,  //RWC;TBD;REMOVE
                              // input/output may be passed in for shared use.
                              //   Initialization vector, part of DH params.
            AsnOid *pEncryptionOID,  // IN, specified encryption of key,
                     //   used here in key generation, but alg not implemented.
            CSM_Buffer *pbufKeyAgree, // output, encryption key for this recip.
            long lKekLength)        // Input, for OtherInfo load.                         
{
   SME_SETUP("CSM_CommonCTIL::SMTI_ExtractKeyAgreement")
   SME_THROW(23, 
       "SMTI_ExtractKeyAgreement NOT SUPPORTED BY SMTI_CommonCTIL.", NULL);
   SME_FINISH_CATCH
   return(-1);
}

//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_CommonCTIL::SMTI_ExtractMEK(
            CSM_Buffer *pOriginator, // input, Y of originator
            CSM_Buffer *pParameters, // input
            CSM_Buffer *pEMEK, // input, encrypted MEK
            CSM_Buffer *pUKM, // input
            CSM_Buffer *pMEK) // output (MEK or special phrase)
{
   SME_SETUP("CSM_CommonCTIL::SMTI_ExtractMEK")
   SME_THROW(23, 
       "SMTI_ExtractMEK NOT SUPPORTED BY SMTI_CommonCTIL.", NULL);
   SME_FINISH_CATCH
   return(-1);
}


//////////////////////////////////////////////////////////////////////////
// SMTI_DigestData uses CSM_Common for SHA1 and Crypto++ for MD5
SM_RET_VAL CSM_CommonCTIL::SMTI_DigestData(
            CSM_Buffer *pData, // input
            CSM_Buffer *pDigest) // output
{
   SM_RET_VAL status=0;
   SME_SETUP("CSM_CommonCTIL::SMTI_DigestData");

   SME((status=CSM_Common::SMTI_DigestData(pData, pDigest)));
   if (status != SM_NO_ERROR)
   {
      SME_THROW(23, 
         "SMTI_DigestData: only supports SHA1 & SHA2 digest algorithm.", NULL);
   }

   SME_FINISH
   SME_CATCH_SETUP
   SME_CATCH_FINISH

   return SM_NO_ERROR;
}

//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_CommonCTIL::SMTI_Random(
            CSM_Buffer *pSeed,   // input
            CSM_Buffer *pRandom, // input/output
            SM_SIZE_T lLength)   // input
{
   SME_SETUP("CSM_CommonCTIL::SMTI_Random")
   SME_THROW(23, 
       "SMTI_Random NOT SUPPORTED BY SMTI_CommonCTIL.", NULL);
   SME_FINISH_CATCH
   return(-1);
}


//////////////////////////////////////////////////////////////////////////
CSM_CommonCTIL::~CSM_CommonCTIL()
{           // NOTHING to do.
}

//////////////////////////////////////////////////////////////////////////
CSM_CommonCTIL::CSM_CommonCTIL()
{
   this->SetDefaultOIDs();
}


//////////////////////////////////////////////////////////////////////////
void CSM_CommonCTIL::CSM_TokenInterfaceDestroy()
{
   delete this;
}


//////////////////////////////////////////////////////////////////////////
// This function restores or sets the default OIDs in the BTI
//  THE PARAMETER designates the specific algorithms of the supported CTIL
//  list that are valid for this certificate:  RSA, DSA, DH or RSA ktri.
//  RWC;12/6/00; This method is now smart enough to pre-load existing algs if 
//      present OR load the initial algs.  This allows an app to load 
//      additional algs (e.g. for verify, DSA & RSA).
void CSM_CommonCTIL::SetDefaultOIDs()
{
   AsnOid *pSignOid = NULL;
   AsnOid *pEncryptOid = NULL;
   CSM_AlgLst *pDigestAlgs = new CSM_AlgLst;
   CSM_AlgLst *pKeyEncryption = new CSM_AlgLst;
   CSM_AlgLst *pDigestEncryption = new CSM_AlgLst;
   CSM_AlgLst *pContentEncryption = new CSM_AlgLst;

   SME_SETUP("CSM_CommonCTIL::SetDefaultOIDs");

   BTIGetAlgIDs(&pDigestAlgs, &pDigestEncryption, &pKeyEncryption,
            &pContentEncryption);   // pre-load
   //RWC;CANNOT REMEMBER WHY THIS WAS ADDED???if (pDigestEncryption->CountL())
   {                // ONLY if already present.
       CSM_Common::SetDefaultOIDLists(pDigestAlgs, pDigestEncryption, 
           pKeyEncryption, pContentEncryption);
       // put the CSM_AlgLsts in the base token interface
       SME(BTISetAlgIDs(pDigestAlgs, pDigestEncryption, pKeyEncryption, 
             pContentEncryption));
   }
   if (pDigestAlgs)
   {
      delete pDigestAlgs;
      pDigestAlgs = NULL;
   }
   if (pDigestEncryption)
   {
      delete pDigestEncryption;
      pDigestEncryption = NULL;
   }
   if (pKeyEncryption)
   {
      delete pKeyEncryption;
      pKeyEncryption = NULL;
   }
   if (pContentEncryption)
   {
      delete pContentEncryption;
      pContentEncryption = NULL;
   }
   // make sha1, dsa, dh, and tdes the preferred algs
   AsnOid oidSha1(sha_1);
   AsnOid oidDsa(id_dsa);
   AsnOid oidAES(id_aes128_ECB);
   //AsnOid oidDh(id_dhStatic);
   //RWC;DOESN'T WORK;TRY EMPTY;AsnOid oidKeyEncrypt(ENDOID);

   SME(BTISetPreferredCSInstAlgs(&oidSha1, &oidDsa, NULL, &oidAES));
   // set the local key alg
   //SME(SetLocalKeyAlg(&oidDhPublicNumber));

   if (pSignOid)
      delete pSignOid;

   if (pEncryptOid)
      delete pEncryptOid;

   SME_FINISH_CATCH
}

//////////////////////////////////////////////////////////////////////////
// This CTI will override BTIFindAlgIds because in CEA and KEA's
// case, we only want to compare OIDs and are not interested in 
// comparing the parameters part of the AlgId
bool CSM_CommonCTIL::BTIFindAlgIds(CSM_Alg *pdigestAlgID, 
            CSM_Alg *pdigestEncryptionAlgID,
            CSM_Alg *pkeyEncryptionAlgID,
            CSM_Alg *pcontentEncryptionAlgID)
{
   CSM_Alg *ptmpCEAlgID = NULL;
   CSM_Alg *ptmpKEAlgID = NULL;
   bool bRet = false;

   SME_SETUP("CSM_CommonCTIL:BTIFindAlgIds");

   // if we have a content encryption AlgId, create a temporary AlgID with
   // only the OID from the one we got from the caller
   if (pcontentEncryptionAlgID)
   {
      AsnOid tmpoid = (*(pcontentEncryptionAlgID->AccessSNACCId()));
      if ((ptmpCEAlgID = new CSM_Alg(tmpoid)) == NULL)
         SME_THROW(SM_MEMORY_ERROR, "couldn't duplicate CEA OID", NULL);
   }

   // if we have a key encryption AlgId, create a temporary AlgID with
   // only the OID from the one we got from the caller
   if (pkeyEncryptionAlgID)
   {
      AsnOid tmpoid = (*(pkeyEncryptionAlgID->AccessSNACCId()));
      if ((ptmpKEAlgID = new CSM_Alg(tmpoid)) == NULL)
         SME_THROW(SM_MEMORY_ERROR, "couldn't duplicate KEA OID", NULL);
   }

   // call the lolevel BTIFindAlgIds with our modified CEA and/or KEA AlgId
   SME(bRet = CSM_BaseTokenInterface::BTIFindAlgIds(pdigestAlgID, 
         pdigestEncryptionAlgID, ptmpKEAlgID, ptmpCEAlgID));

   // delete the modified CE and/or KE Alg ID if it exists (cleanup)
   if (ptmpCEAlgID)
      delete ptmpCEAlgID;
   if (ptmpKEAlgID)
      delete ptmpKEAlgID;

   SME_FINISH_CATCH

   return bRet;
}


// determines if preferred oid is RSA (which is key transfer) and returns false, else this
// returns true its a key agreement
bool CSM_CommonCTIL::SMTI_IsKeyAgreement() 
{  
   bool keyAgree = false;
   return (keyAgree);
}

_END_CTIL_NAMESPACE 

// EOF sm_commonCTIL.cpp
