
#define PKCS11_OUTPUT_CERTS  //RWC;

#ifndef WIN32
#include <stream.h>
#endif
#include <string.h>
#include <strstrea.h>
#include "sm_pkcs11.h"
#include "sm_tlistC.h"
_BEGIN_CERT_NAMESPACE
using namespace CTIL;
using namespace SNACC;
typedef CSM_ListC<CSM_CtilInst> CSM_CtilInstLstInternal;

// static global which SHOULD only be accessible to this module.
CK_BBOOL CSM_Pkcs11::Pkcs11LibIsInitialized = FALSE;

//
// This is the Initialization routine for C
//
extern "C" {
SM_RET_VAL SMPkcs11Init(void *pCSMIME, int slotId, char *pUserPin, char *pDllName)
{
   CSM_CtilMgr *pUseCSMIME = (CSM_CtilMgr *) pCSMIME;

   SME_SETUP("SMPkcs11Init()");

   // generate a new fortezza class
   // Call Pkcs11 CTIL contructor to load up pCSMIME
   // with instances.
   CSM_Pkcs11 pkcs11(pUseCSMIME, (CK_SLOT_ID) slotId, pUserPin, pDllName);

   return SM_NO_ERROR;   
   
   SME_FINISH_CATCH;
}
} // end extern 'C'

// Initialization routines (Constructors) for C++
//
CSM_Pkcs11::CSM_Pkcs11()                    
{
   SME_SETUP("CSM_Pkcs11::CSM_Pkcs11()");

   Clear();

   SME_FINISH_CATCH;
}
////////////////////////////////////////////////////////////////////////////////////
// The following constructor requires the slot where the Pkcs11 token "resides" 
// (this does not neccessarily mean hardware slot (see Pkcs11 document), the 
// UserPin required by C_Login to have access to certain functions (i.e. crypto 
// functions) and the name of the Pkcs11 DLL.  The instance created by this 
// constructor will hold data that will be copied to instances created for each 
// certificate/Private key pair found on the token.  
////////////////////////////////////////////////////////////////////////////////////
CSM_Pkcs11::CSM_Pkcs11(CSM_CtilMgr *pCSMIME, 
                       CK_SLOT_ID slotId,
                       char *pUserPin, 
                       char *pDllName)
{
   long status = 0;
   SME_SETUP("CSM_Pkcs11::CSM_Pkcs11");
 
   if (pCSMIME == NULL || pUserPin == NULL)
      SME_THROW(SM_MISSING_PARAM,NULL, NULL);

   Clear();
      
   // Load function pointers into class variables.
   LoadDllFunctions(pDllName);

   SME(status = Initialize());

   SME(status = CreateInstances(pCSMIME, pUserPin, slotId));

   SME_FINISH_CATCH;
}
///////////////////////////////////////////////////////////////////////////////////
// The following constructor could be used to create an instance (personality)
// in a Pkcs11 token.
///////////////////////////////////////////////////////////////////////////////////
CSM_Pkcs11::CSM_Pkcs11 (CSM_Buffer &Certificate, CSM_Buffer *pPrivateKey, 
                        char *pPin, CK_SLOT_ID slotId)
{
    SME_SETUP("CSM_Pkcs11::CSM_Pkcs11");

    // Unfinished constructor

    SME_FINISH_CATCH;
}
CSM_Pkcs11::~CSM_Pkcs11()
{
   //sfl_c_finalize(NULL_PTR);
   //sfl_c_closeSession(m_hSession);
   if (m_pId)
      free (m_pId);
   if (m_pSubject)
      free (m_pSubject);
   if (m_pSlot)
      delete m_pSlot;

   if (m_pLabel)  
      free(m_pLabel);

   if (m_pCertificateChoice != NULL)
      delete m_pCertificateChoice;

   if(m_pPkcs11DllName)
      free (m_pPkcs11DllName);
}
void CSM_Pkcs11::Clear()
{
   m_slotId = -1;
   m_hSession = SM_PKCS11_INVALID_HANDLE;
   m_hCertificate = SM_PKCS11_INVALID_HANDLE;
   m_hPrivateKey = SM_PKCS11_INVALID_HANDLE;
   m_hSecretKey = SM_PKCS11_INVALID_HANDLE;
   m_hPinObject = SM_PKCS11_INVALID_HANDLE;

   m_subjectLen = 0;
   m_idLen = 0;

   m_pPkcs11DllName = NULL;
   m_pSlot = NULL;
   m_pId = NULL_PTR;
   m_pSubject = NULL_PTR;
   m_pLabel = NULL_PTR;
   m_pCertificateChoice = NULL;

   m_pSlotList = NULL;

   // Function pointers for each Pkcs11 function (Version 2.1)
   sfl_c_initialize = NULL;
   sfl_c_finalize = NULL;
   sfl_c_getInfo = NULL;
   sfl_c_getFunctionList = NULL;
   sfl_c_getSlotList = NULL;
   sfl_c_getSlotInfo = NULL;
   sfl_c_getTokenInfo = NULL;
   sfl_c_getMechanismList = NULL;
   sfl_c_getMechanismInfo = NULL;
   sfl_c_initToken = NULL;
   sfl_c_initPIN = NULL;
   sfl_c_setPIN = NULL;
   sfl_c_openSession = NULL;
   sfl_c_closeSession = NULL;
   sfl_c_closeAllSessions = NULL;
   sfl_c_getSessionInfo = NULL;
   sfl_c_getOperationState = NULL;
   sfl_c_setOperationState = NULL;
   sfl_c_login = NULL;
   sfl_c_logout = NULL;
   sfl_c_createObject = NULL;
   sfl_c_copyObject = NULL;
   sfl_c_destroyObject = NULL;
   sfl_c_getObjectSize = NULL;
   sfl_c_getAttributeValue = NULL;
   sfl_c_setAttributeValue = NULL;
   sfl_c_findObjectsInit = NULL;
   sfl_c_findObjects = NULL;
   sfl_c_findObjectsFinal = NULL;
   sfl_c_encryptInit = NULL;
   sfl_c_encrypt = NULL;
   sfl_c_encryptUpdate = NULL;
   sfl_c_encryptFinal = NULL;
   sfl_c_decryptInit = NULL;
   sfl_c_decrypt = NULL;
   sfl_c_decryptUpdate = NULL;
   sfl_c_decryptFinal = NULL;
   sfl_c_digestInit = NULL;
   sfl_c_digest = NULL;
   sfl_c_digestUpdate = NULL;
   sfl_c_digestKey = NULL;
   sfl_c_digestFinal = NULL;
   sfl_c_signInit = NULL;
   sfl_c_sign = NULL;
   sfl_c_signUpdate = NULL;
   sfl_c_signFinal = NULL;
   sfl_c_signRecoverInit = NULL;
   sfl_c_signRecover = NULL;
   sfl_c_verifyInit = NULL;
   sfl_c_verify = NULL;
   sfl_c_verifyUpdate = NULL;
   sfl_c_verifyFinal = NULL;
   sfl_c_verifyRecoverInit = NULL;
   sfl_c_verifyRecover = NULL;
   sfl_c_digestEncryptUpdate = NULL;
   sfl_c_decryptDigestUpdate = NULL;
   sfl_c_signEncryptUpdate = NULL;
   sfl_c_decryptVerifyUpdate = NULL;
   sfl_c_generateKey = NULL;
   sfl_c_generateKeyPair = NULL;
   sfl_c_wrapKey = NULL;
   sfl_c_unwrapKey = NULL;
   sfl_c_deriveKey = NULL;
   sfl_c_seedRandom = NULL;
   sfl_c_generateRandom = NULL;
   sfl_c_getFunctionStatus = NULL;
   sfl_c_cancelFunction = NULL;
}
SM_RET_VAL CSM_Pkcs11::Initialize ()
{
    SM_RET_VAL status = SM_NO_ERROR;

    SME_SETUP("CSM_Pkcs11::Initialize");

    CK_VOID_PTR pReserved = NULL_PTR;

    if (!Pkcs11LibIsInitialized)
    {
       if ((status = Initialize (pReserved)) != SM_NO_ERROR)
          return status;

       // Initialize SHOULD only be called once so a static Boolean
       // will be used to indicate initialization has been performed.
       Pkcs11LibIsInitialized = TRUE;
    }

    if (m_pSlotList == NULL)
        if ((status = LoadSlotList()) != SM_NO_ERROR)
            SME_THROW(status, "Unable to LoadSlotList.", NULL);

    SME_FINISH_CATCH;

    return status;
}
// FUNCTION: CreateInstances
//
// PURPOSE: Create an instance for each certificate
//          in the Token.
//
SM_RET_VAL CSM_Pkcs11::CreateInstances(CSM_CtilMgr *pCSMIME, char *pUserPin, int slotId)
{
#define MAX_NUMBER_OF_CERTS 100
#define MAX_NUMBER_OF_PRIVATE_KEYS   100

   SM_RET_VAL status = SM_NO_ERROR;

   CSM_CSInstLst *pNewCsInsts = NULL;
   CSM_CSInst *pNewInst = NULL;
   CSM_Pkcs11 *pNewPkcs11 = NULL;
   CSM_BufferLst *pCertBufLst = NULL;
   CSM_Buffer *pNewCertBuf = NULL; 

   // A unique ID will be built for each certificate using 
   // the pkcs11 dll, the slotId and the certificate index.
   char *pInstID = 
      (char *) malloc(strlen(m_pPkcs11DllName) + 
                                 2 /*slotId*/ + 2 /*cert index*/ + 3); 

   CK_ULONG ulObjectCount;
   CK_SESSION_HANDLE hSession;
   CK_OBJECT_HANDLE_PTR phObject = NULL_PTR;
   CK_OBJECT_HANDLE_PTR ptmphObject = NULL_PTR;
   // CKF_SERIAL_SESSION  must always be set for backward compatability
   // first time for open session should be masked with CKF_RW_SESSION
   CK_FLAGS sessionFlags = CKF_RW_SESSION | CKF_SERIAL_SESSION;

   SME_SETUP("CSM_Pkcs11::CreateInstances");

   if ((status = OpenSession((CK_SLOT_ID) slotId,
                             sessionFlags,
                             NULL_PTR,
                             NULL_PTR,
                             &hSession)) != SM_NO_ERROR)
   {
      // try opening session in read only mode.  This means that there  
      // was a read write session already opened and another one couldn't be opened.
      // read only is the false setting for mask CKF_RW_SESSION (0x00000002)
      sessionFlags = CKF_SERIAL_SESSION;

      status = OpenSession((CK_SLOT_ID) slotId,
                             sessionFlags,
                             NULL_PTR,
                             NULL_PTR,
                             &hSession);
   }

   if (status == SM_NO_ERROR)
   {
      status = Login(hSession, 
                          CKU_USER, 
                          (CK_CHAR_PTR) pUserPin, 
                          strlen(pUserPin));
      if (status == SM_NO_ERROR || status == CKR_USER_ALREADY_LOGGED_IN)
      {   
         // Some extra oids might be available from CSM_Free3 if 
         // this method is being called withing CSM_Pkcs11Free3.
         LoadExtraOids();

         //  Find all X-509 Certificates in the token and create an 
         //  instance for each one.
         CK_OBJECT_CLASS objClass = CKO_CERTIFICATE;
         CK_CERTIFICATE_TYPE certType = CKC_X_509;

         CK_ATTRIBUTE certTemplate[] = {
            {CKA_CLASS, &objClass, sizeof(objClass)},
            {CKA_CERTIFICATE_TYPE, &certType, sizeof(certType)}};

         CK_ULONG ulAttributeCount = sizeof(certTemplate) / sizeof(CK_ATTRIBUTE);
         
         if ((status = FindObjects(hSession,
                                   certTemplate,
                                   ulAttributeCount,
                                   MAX_NUMBER_OF_CERTS,
                                   ulObjectCount,
                                   phObject)) == SM_NO_ERROR)
         {
            // phObject points to a list (array) of object handles.
            // Copy the pointer into a temporary variable so we can
            // advance it (ptmphObject++) but still keep phObject
            // so the memory can be freed at the end of the loop.
            ptmphObject = phObject;

            if ((pNewCsInsts = new CSM_CSInstLst) == NULL)
               SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

            for (CK_ULONG i = 1; i <= ulObjectCount; i++)
            {
               cout << "Certificate #" << i << ".\n";
               cout.flush();

               //  NOTE : This method might be called from a
               //         CSM_Pkcs11Free3 or CSM_Pkcs11 instance,
               //         GetInstancePointer will create the appropriate
               //         instance (of "this") and will then return
               //         a CSM_Pkcs11 pointer.

               // Get new pointer for each certificate.
               pNewPkcs11 = GetInstancePointer();

               // Copy information from the orignal instance 
               // into each new instance.
               // NOTE : The session handle and the dll functions MUST
               //        be copied before any other information.
               pNewPkcs11->SetSession(hSession);
               pNewPkcs11->SetDllFunctions(this);

               // Using the object handle (returned from call to FindObjects)
               // create a CSM_CertificateChoice in every instance. SetCertificate
               // will return an error if no private key is found to match
               // the certificate in which case the instance will be delete.
               if (pNewPkcs11->SetCertificate(*ptmphObject) == SM_NO_ERROR)
               {
                  pNewPkcs11->SetPin(pUserPin);
                  // Set processed slot list into each instance.
                  pNewPkcs11->SetSlotLst(m_pSlotList);
                  pNewPkcs11->SetSlot((CK_SLOT_ID) slotId);
                  pNewPkcs11->SetAlgsAndOids();

                  if ((pNewInst = pNewCsInsts->Append()) == NULL)
                    SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

                  pNewInst->SetCertificates(pNewPkcs11->m_pCertificateChoice);

                  // Build unique ID for each certificate.
                  sprintf(pInstID,"%s-%02d-%02d", m_pPkcs11DllName, slotId, i);

                  pNewInst->SetID(pInstID);

                  pNewInst->SetTokenInterface((CSM_TokenInterface *) pNewPkcs11);
                  AsnOid *pSignOid = pNewPkcs11->GetPrefDigestEncryption();
                  CSM_AlgLst *pkeyEncryptionAlgID = NULL;
                  pNewPkcs11->BTIGetAlgIDs(NULL, NULL, &pkeyEncryptionAlgID, NULL);
                  if (pSignOid && (*pSignOid == rsa || *pSignOid == rsaEncryption) && 
                      pkeyEncryptionAlgID == NULL && 
                      pNewInst->CheckKeyUsageBit(KeyUsage::keyEncipherment))
                  {             // RWC;SPECIAL CASE, GemPlus in particular 
                                //  indicates both signer and encrypter with 
                                //  CKF_SIGN/CKF_VERIFY not with CKF_WRAP as 
                                //  expected to indicate both, must check cert 
                                //  to determine if both signing/encrypting 
                                //  are valid.
                      pkeyEncryptionAlgID = new CSM_AlgLst;
                      CSM_Alg *pAlg = pkeyEncryptionAlgID->Append();
                      *pAlg = *pSignOid;
                      pNewPkcs11->BTISetAlgIDs(NULL, NULL, pkeyEncryptionAlgID, NULL);
                  }
                  if (pSignOid)
                      delete pSignOid;

// Turn on this define block to create a file for each 
// certificate found in the token.
#ifdef PKCS11_OUTPUT_CERTS

                  char *pCertName = 
                     (char *) calloc(1,strlen(pInstID) + strlen("Cert.out") + 1);
              
                  strcpy(pCertName, pInstID);

                  strcat(pCertName,"Cert.out");

                  char *pFilePathAndName = 
                     (char *) calloc(1,strlen("./sm_pkcs11/Recipients/") + 
                                                           strlen(pCertName) + 1);
                
                  //strcpy(pFilePathAndName, "./sm_pkcs11/Recipients/");

                  strcat(pFilePathAndName, pCertName);

                  const CSM_Buffer *tmpBuffer = pNewInst->AccessUserCertificate()->
                                        /*pNewPkcs11->m_pCertificateChoice->*/
                                        AccessEncodedCert();

                  long status = ((CSM_Buffer *)tmpBuffer)->ConvertMemoryToFile(pFilePathAndName);

                  free (pCertName);
                  free (pFilePathAndName);
#endif
               }
               else
               {
                  // Unable to complete instance so delete memory.
                  delete pNewPkcs11;
               }
            
               // Next object handle
               ptmphObject++;

               if (pNewInst != NULL)
               {
                  if (pCSMIME->m_pCSInsts == NULL)
                     pCSMIME->m_pCSInsts = new CSM_CtilInstLst;

               //RWC;5/12/02; SPECIAL NOTE; using SFL version of list here in order
               //  to specially load the CTIL MGR version of the list with the same
               //  sub-class pointer as the CSMIME libCert version.
               CSM_CtilInstLstInternal *pCSInstsInternal=
                    (CSM_CtilInstLstInternal *)pCSMIME->m_pCSInsts;
               // put it in the instance list in pCSMIME
               pCSInstsInternal/*pCSMIME->m_pCSInsts*/->AppendL(pNewInst);  // ADD to end of list.
               //sib
			      pNewPkcs11->SetCSInst(pNewInst);   
                  // SINCE we generated a CSM_CSInst, not a CSM_CtilInst.
                  //  (THIS member is not used by the CTIL, but by the
                  //   application if a CSMIME (not CSM_CtilMgr) 
                  //   container is used for certificate access.

               }
               else
               {
                  cout << "No instances created.\n";
               }
            }     // END FOR ulObjectCount of certificates in PKCS11
         }        // END IF FindObjects

         if (phObject)
            free (phObject);
         phObject = NULL_PTR;
      }     // IF Already logged in
      else
      {
         // Close the session since the user was unable to Login.
         status = sfl_c_finalize(NULL_PTR);
         status = sfl_c_closeSession(hSession);
      }     // END IF Already logged in
    }
    else
    {
       // fatal error couldn't open the session
       SME_THROW(status, "Couldn't open a session!", NULL);
    }

   if (phObject)
      free (phObject);
   if (pInstID)
      free(pInstID);

   SME_FINISH
    SME_CATCH_SETUP
       // catch/cleanup logic as necessary
       if (phObject)
          free (phObject);
       if (pInstID)
          free(pInstID);
    SME_CATCH_FINISH

    return status;
}

//
//
CSM_Pkcs11 * CSM_Pkcs11::GetInstancePointer()
{
   CSM_Pkcs11 *pPkcs11 = NULL;

   SME_SETUP("CSM_Pkcs11::GetInstancePointer")

   if ((pPkcs11 = new CSM_Pkcs11) == NULL)
      SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

   SME_FINISH_CATCH;

   return pPkcs11;
}
void CSM_Pkcs11::SetSlotLst(CSM_Pkcs11SlotLst *pSlotList)
{
   if (m_pSlotList)
      delete m_pSlotList;

   m_pSlotList = pSlotList;
}
SM_RET_VAL CSM_Pkcs11::SetSlot (CK_SLOT_ID slotId)
{
   SM_RET_VAL status = SM_NO_ERROR;

   SME_SETUP ("CSM_Pkcs11::SetSlot");

   CSM_Pkcs11Slot *pSlot = NULL;

   for ( pSlot = m_pSlotList->SetCurrToFirst();
         pSlot; pSlot = m_pSlotList->GoNext())
   {
      if (pSlot->AccessSlotId() == slotId)
      {
         m_pSlot = pSlot;
         break;
      }
   }

   if (pSlot == NULL)
      status = -1;

   SME_FINISH
      SME_CATCH_SETUP
      SME_CATCH_FINISH

   return status;
}
SM_RET_VAL CSM_Pkcs11::LoadSlotList ()
{
   SM_RET_VAL status = SM_NO_ERROR;

   CK_ULONG ulCount = 0;
   CK_SLOT_ID_PTR pSlotList = NULL_PTR;
   CK_BBOOL tokenPresent = TRUE;   // we are only interested in slots with tokens

   SME_SETUP("CSM_Pkcs11::LoadSlotList")

   if ((status = GetSlotList(tokenPresent, pSlotList, ulCount)) == SM_NO_ERROR)
      status = ProcessSlotList(pSlotList, ulCount);
 
   if (pSlotList)
      free (pSlotList);

   SME_FINISH_CATCH

   return status;
}
SM_RET_VAL CSM_Pkcs11::ProcessSlotList (CK_SLOT_ID_PTR pSlotList,
                                        CK_ULONG slotCount)
{
    SM_RET_VAL status = SM_NO_ERROR;
    CSM_Pkcs11Slot *pSlot;
    CK_SLOT_ID_PTR pCurrSlot = pSlotList;

    SME_SETUP("CSM_Pkcs11::ProcessSlotList");

    for (CK_ULONG i = 0; i < slotCount; i++)
    {
        pSlot = NULL;

        if (m_pSlotList == NULL)
            if ((m_pSlotList = new CSM_Pkcs11SlotLst) == NULL)
                SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

        if ((pSlot = m_pSlotList->AppendL()) == NULL)
            SME_THROW(SM_MEMORY_ERROR, NULL, NULL)

        pSlot->SetDllFunctions(sfl_c_getSlotList,
                                sfl_c_getSlotInfo, 
                                sfl_c_getTokenInfo,
                                sfl_c_getMechanismInfo,
                                sfl_c_getMechanismList);

        pSlot->SetSlotId(*pCurrSlot);
        pSlot->GetSlotInfo();
        pSlot->GetTokenInfo();

        // Load mechanisms available in the slot.
        pSlot->LoadMechanisms();
        
        pCurrSlot++; // Next Slot
    }

    SME_FINISH_CATCH

    return status;
}
void CSM_Pkcs11::SetPin (char *pPin)
{
   SME_SETUP("CSM_Pkcs11::SetPin");

   CK_OBJECT_HANDLE hObj;
   CK_ULONG ulObjAttributeCount;

   CK_OBJECT_CLASS objClass = CKO_DATA;
   CK_CHAR label [] = "Data object for Pin";

   CK_BYTE_PTR pPinValue = (CK_BYTE_PTR) pPin;
   CK_ULONG valueLen = (CK_ULONG) strlen(pPin);
   CK_BBOOL isSensitive = TRUE;
   CK_BBOOL isExtractable = FALSE;
   CK_BBOOL isTokenObj = TRUE;

   CK_ATTRIBUTE objTemplate[] = {
      {CKA_CLASS, &objClass, sizeof(objClass)},
      {CKA_TOKEN, &isTokenObj, sizeof(isTokenObj)},
      {CKA_LABEL, label, sizeof(label - 1)},
      {CKA_EXTRACTABLE, &isExtractable, sizeof(isExtractable)},
      {CKA_SENSITIVE, &isSensitive, sizeof(isSensitive)},
      {CKA_VALUE, pPinValue, valueLen}
   };

   ulObjAttributeCount = sizeof(objTemplate) / sizeof(CK_ATTRIBUTE);

   if (CreateObject
            (m_hSession, objTemplate, ulObjAttributeCount, hObj) == SM_NO_ERROR)
      m_hPinObject = hObj;
    
    SME_FINISH_CATCH
}
/////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_Pkcs11::SetAlgsAndOids()
{
   SM_RET_VAL status = SM_NO_ERROR;

   AsnOid *pTmpDigestOid = NULL;
   AsnOid *pDigestOid = NULL;
   AsnOid *pDigestEncryptionOid = NULL;
   AsnOid *pKeyEncryptionOid = NULL;
   AsnOid *pContentEncryptionOid = NULL;

   CSM_AlgLst *pDigestEncryptionAlgLst = NULL;
   CSM_AlgLst *pKeyEncryptionAlgLst = NULL;

   // ASSUME we can support all digest and content encryption 
   // algorithms supported by the token.
   CSM_AlgLst *pDigestAlgLst = m_pSlot->AccessDigestAlgLst();
   CSM_AlgLst *pContentEncryptionAlgLst = m_pSlot->AccessContentEncryptionAlgLst();

   // Retrieve oid from SubjectPulicKeyInfo in Certificate.
   AsnOid *pPublicKeyOID = m_pCertificateChoice->GetKeyOID();

   // Default preferred Digest oid and Content encryption oid 
   // to first one found in list.
   if (pDigestAlgLst != NULL)
   {
      pDigestAlgLst->SetCurrToFirst();
      pDigestOid = new AsnOid(pDigestAlgLst->Curr()->algorithm);

      // If the first digest Oid supported is MD2 check if there is an
      // alternative since MD2 has been, in most crypto libraries, replaced 
      // (more than likely with MD5).
      if ((id_md2 == *pDigestOid) || *pDigestOid == "1.2.840.113549.2.2")
      {
         //AsnOid pasnoid = pDigestAlgLst->NextL()->algorithm;
         if ((pDigestAlgLst->Count() > 1 ) && 
            ((pTmpDigestOid = new AsnOid(pDigestAlgLst->Next()->algorithm)) != NULL))
         {
            delete pDigestOid;
            pDigestOid = pTmpDigestOid;
         }
      }
   }

   if (pContentEncryptionAlgLst != NULL)
      pContentEncryptionOid = 
            new AsnOid(pContentEncryptionAlgLst->First()->algorithm);

   CK_MECHANISM_INFO_PTR pMechInfo = GetMechanismInfo(pPublicKeyOID);

   if (((pMechInfo->flags & CKF_SIGN) != 0) ||
       ((pMechInfo->flags & CKF_VERIFY) !=0))
   {
      // Set preferred oid for signing
      pDigestEncryptionOid = pPublicKeyOID;


      // Create CSM_Alg entry to insert into AlgIds list for this instance.
       pDigestEncryptionAlgLst = new CSM_AlgLst();
       CSM_Alg *pDigestEncryptionAlg = pDigestEncryptionAlgLst->Append();
       pDigestEncryptionAlg->algorithm = *pDigestEncryptionOid;
       if (*pDigestEncryptionOid == rsa || *pDigestEncryptionOid == rsaEncryption)
       {
            pDigestEncryptionAlg = pDigestEncryptionAlgLst->Append();
            pDigestEncryptionAlg->algorithm = sha_1WithRSAEncryption;
            pDigestEncryptionAlg = pDigestEncryptionAlgLst->Append();
            pDigestEncryptionAlg->algorithm = sha_1WithRSAEncryption_ALT;
            pDigestEncryptionAlg = pDigestEncryptionAlgLst->Append();
            pDigestEncryptionAlg->algorithm = AsnOid("1.2.840.113549.1.2");
            pDigestEncryptionAlg = pDigestEncryptionAlgLst->Append();
            pDigestEncryptionAlg->algorithm = rsaEncryption;
            pDigestEncryptionAlg = pDigestEncryptionAlgLst->Append();
            pDigestEncryptionAlg->algorithm = md5WithRSAEncryption;
            pDigestEncryptionAlg = pDigestEncryptionAlgLst->Append();
            pDigestEncryptionAlg->algorithm = AsnOid("1.3.14.3.2.3"); //md5WithRSAEncryptionOIW;
       }       // IF RSA
       else if (*pDigestEncryptionOid == id_dsa)
       {
            pDigestEncryptionAlg = pDigestEncryptionAlgLst->Append();
            pDigestEncryptionAlg->algorithm = id_dsa_with_sha1;
            pDigestEncryptionAlg = pDigestEncryptionAlgLst->Append();
            pDigestEncryptionAlg->algorithm = id_OIW_secsig_algorithm_dsa;
       }       // END IF RSA/DSA check.
  }             // END IF SIGN or VERIFY mechanism.

   if ( ((pMechInfo->flags & CKF_WRAP) != 0) ||
        ((pMechInfo->flags & CKF_UNWRAP) != 0) )
   {
       pKeyEncryptionOid = pPublicKeyOID;

       pKeyEncryptionAlgLst = new CSM_AlgLst();
       CSM_Alg *pKeyEncryptionAlg = pKeyEncryptionAlgLst->Append();
       pKeyEncryptionAlg->algorithm = *pKeyEncryptionOid;
   }

   BTISetAlgIDs(pDigestAlgLst,
             pDigestEncryptionAlgLst,
             pKeyEncryptionAlgLst,
             pContentEncryptionAlgLst);

   BTISetPreferredCSInstAlgs(pDigestOid,
                        pDigestEncryptionOid,
                       pKeyEncryptionOid,
                       pContentEncryptionOid);

   return status;
}
//////////////////////////////////////////////////////////////////////////
bool CSM_Pkcs11::IsOidSupported(AsnOid oid)
{
   bool oidSupported = false;

    CSM_Pkcs11MechanismInfo *pMechanism;

    pMechanism = m_pSlot->AccessMechanismLst()->SetCurrToFirst();

    while ( (pMechanism != NULL) &&
            (!oidSupported) )
    {
        if (oid == *pMechanism->AccessOid())
            oidSupported = TRUE;
        else
            pMechanism = m_pSlot->AccessMechanismLst()->GoNext();
    }
    
   return oidSupported;
}

//
//
CSM_Alg *CSM_Pkcs11::DeriveMsgAlgFromCert(CSM_Alg &Alg) 
{   
	return new CSM_Alg(Alg); 
}

//

CSM_Alg * CSM_Pkcs11::DeriveMsgAlgFromCert(CSM_CertificateChoice &cert)
{ 
   CSM_Alg *pubKeyAlg = NULL;

   pubKeyAlg = cert.GetPublicKeyAlg();
 
   return(pubKeyAlg);
}
//////////////////////////////////////////////////////////////////////////
// This function restores or sets the default OIDs in the BTI
void CSM_Pkcs11::SetDefaultOIDs()
{
   SME_SETUP("CSM_Pkcs11::SetDefaultOIDs");
/*
   AsnOid ENDOID("0.0.0");

   AsnOid oidHash[] = { 
       sha_1, 
       sha_1WithRSAEncryption_ALT,
       sha_1WithRSAEncryption, 
       md5, 
       md5WithRSAEncryption,
      "1.3.14.3.2.12",
       ENDOID };
   AsnOid oidSign[] = {
      id_dsa,
      id_dsa_with_sha1,
      "1.3.14.3.2.12",
       rsa, 
       sha_1WithRSAEncryption_ALT,
       sha_1WithRSAEncryption, 
      md5WithRSAEncryption,
////////       bsafe_id_rsa_encr,
       rsaEncryption,
      "1.2.840.113549.1.2",
       ENDOID };
   AsnOid oidContentEncrypt[] = { 
       des_ede3_cbc,
       id_alg_CMS3DESwrap,
       rc2_cbc,
       id_alg_CMSRC2wrap,
/////       bsafe_id_rc2_encr,
       ENDOID };
   AsnOid oidKeyEncrypt[] = { 
      id_dhStatic,
      dh_public_number,
      id_alg_ESDH,
       rsa, 
       sha_1WithRSAEncryption_ALT,
       sha_1WithRSAEncryption, 
//////       bsafe_id_rsa_encr,
       rsaEncryption,
       ENDOID };

   CSM_Alg *pAlg;
   int i;

   CSM_AlgLst *pDigestAlgs = new CSM_AlgLst;
   CSM_AlgLst *pKeyEncryption = new CSM_AlgLst;
   CSM_AlgLst *pDigestEncryption = new CSM_AlgLst;
   CSM_AlgLst *pContentEncryption = new CSM_AlgLst;

   // Produce list of separate alg lists.
   for (i=0; oidHash[i] != ENDOID; i++)
   {
      if (IsOidSupported(oidHash[i]))
      {
          pAlg = new CSM_Alg(oidHash[i]);
         pDigestAlgs->AppendL(pAlg);
      }
   }
   for (i=0; oidSign[i] != ENDOID; i++)
   {
      if (IsOidSupported(oidHash[i]))
      {
          pAlg = new CSM_Alg(oidSign[i]);
         pDigestEncryption->AppendL(pAlg);
      }
   }
   for (i=0; oidContentEncrypt[i] != ENDOID; i++)
   {
      if (IsOidSupported(oidHash[i]))
      {
          pAlg = new CSM_Alg(oidContentEncrypt[i]);
         pContentEncryption->AppendL(pAlg);
      }
   }
   for (i=0; oidKeyEncrypt[i] != ENDOID; i++)
   {
      if (IsOidSupported(oidHash[i]))
      {
          pAlg = new CSM_Alg(oidKeyEncrypt[i]);
         pKeyEncryption->AppendL(pAlg);
      }
   }

   // put the CSM_AlgLsts in the base token interface
   BTISetAlgIDs(pDigestAlgs, pDigestEncryption, pKeyEncryption, 
         pContentEncryption);

   if (pDigestAlgs)
   {
      delete pDigestAlgs;
      pDigestAlgs = NULL;
   }
   if (pDigestEncryption)
   {
      delete pDigestEncryption;
      pDigestEncryption = NULL;
   }
   if (pKeyEncryption)
   {
      delete pKeyEncryption;
      pKeyEncryption = NULL;
   }
   if (pContentEncryption)
   {
      delete pContentEncryption;
      pContentEncryption = NULL;
   }
*////
   /*******************
   // make Md5, RsaEncryption, RsaEncryption, and RC2Encryption the
   // preferred algs
   AsnOid oidMd5(bsafe_id_md5);
   AsnOid oidSha1(sha_1);
   AsnOid oidRsaEncr(rsaEncryption);
   AsnOid oidRc2Encr(bsafe_id_rc2_encr);
   BTISetPreferredCSInstAlgs(&oidSha1, &oidRsaEncr, &oidRsaEncr, &oidRc2Encr);
  *******************************/

   SME_FINISH_CATCH
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef NO_DLL
#ifdef WIN32
extern "C" {
   long Make_argv(char *string, int *pargc, char ***pargv);

   SM_PKCS11DLL_API SM_RET_VAL DLLBuildTokenInterface(CSMIME &Csmime,
      char *lpszBuildArgs)
   {
      SM_RET_VAL status = 0;
      int argc1 = 0;
      char **argv1;
      char ptr[30];

      memset(ptr, '\0', 30);
      for (int i = 0; i < (int)strlen("sm_Pkcs11DLL"); i++)
         ptr[i] = toupper(lpszBuildArgs[i]);
      // Preliminary check that this request if for out library
      if (strncmp(ptr, "SM_PKCS11DLL", strlen("sm_Pkcs11DLL")) == 0)
      {
         Make_argv(lpszBuildArgs, &argc1, &argv1);
         if (argc1 == 4)
         {
            // Pass char *pszAddressBook, char *pUserPin
            SMPkcs11Init(&Csmime, atoi(argv1[1]), argv1[2], argv1[3]);
         }
         else
         {
            status = -1;
         }
      }
      else
      {
         status = -1;
         cout << "DLLBuildTokenInterface failed!!!\n";
      }

      return(status);
   }

   SM_PKCS11DLL_API char * DLLGetId()
   {
      return (strdup("sm_Pkcs11DLL"));
   }
}

// THE FOLLOWING MUST BE called ONLY once in an application/DLL in order
// for force generation of the CSM_ListC code for the specified classes.
// template class CTIL::CSM_ListC<CSM_Pkcs11Slot>;
// template class CTIL::CSM_ListC<CSM_Pkcs11MechanismInfo>;

_END_CERT_NAMESPACE


#endif
#endif