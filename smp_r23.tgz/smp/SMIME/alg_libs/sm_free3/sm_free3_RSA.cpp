
//////////////////////////////////////////////////////////////////////////
// sm_free.cpp
//
// This CTI Library implements RSA using crypto++
// It will inherit SHA1 from the sm_common CTI
//  RWC; THIS VERSION integrates "crpypto++ 3.0".
//
//////////////////////////////////////////////////////////////////////////

#ifdef WIN32
#pragma  warning( disable : 4512 4100 4511 4663 4018 4244 4146 4097 ) 
                                    // IGNORE warnings from MS includes? 
                                    //  (?WHY present in MSVC?).
#include <process.h>
#include <winsock2.h>
#endif
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <setjmp.h>
#include <sys/stat.h>
#ifdef SM_FREE3_RSA_INCLUDED
#include "sm_free3.h"
#include "sm_cms.h"
#include "sm_VDASupport_asn.h"
#include "rsa.h"     // From cryptopp3.
#include "rc2.h"     // From cryptopp3.
#include "sm_vda_cbc.h"  // For use with unpadded encryption/decryption
#ifdef WIN32
#pragma  warning( default: 4512 4100 4511 )  // IGNORE warnings from MS includes? 
#endif
using CTIL::CSM_Buffer;
using SNACC::AsnLen;
_BEGIN_CERT_NAMESPACE

//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_Free3::RSA_GenerateEMEK(
            CSM_Buffer *pRecipientIN, // input, Y of recipient, public key
            CSM_Buffer *pParameters, // IN,OUT may be passed in for shared use
                                     //  OR for ESDH. (p, g, and/or IV).
            CSM_Buffer *pData, // input, Content Encryption Key to be encrypted
            CSM_Buffer *pEMEK, // output, encrypted Content Encryption Key
            CSM_Buffer *pUKM, // input/output may be passed in for shared use.
            CSM_Buffer *pSubjKeyId) // output
{
   CSM_Buffer *pRecipient=NULL;  // COPY in case it has to be re-built (Crypto++5.0)
   SM_RET_VAL           status = 0;
   CryptoPP::ByteQueue  byteQueueBuffer;
   unsigned int         modulus;
   byte                 *pOutCipher = NULL;
 
   SME_SETUP("CSM_Free3::RSA_GenerateEMEK");

   // check incoming parameters
   if ((pRecipientIN == NULL) || (pEMEK == NULL) || (pData == NULL))
      SME_THROW(SM_FREE_MISSING_PARAM, "MISSING PARAMS", NULL);

#ifdef NODEF
   // decode the public key ?

   // RWC; ATTEMPTING different format form MS Outlook Express.
   RSAPublicKey SnaccRSAPublicKey;
   A_RSA_KEY rsaKey;

   DECODE_BUF(&SnaccRSAPublicKey, pRecipient);  // will create exception if 
                                                   //  decode fails.
   rsaKey.modulus.data = (unsigned char *)(char *)SnaccRSAPublicKey.modulus;
   rsaKey.modulus.len = SnaccRSAPublicKey.modulus.Len();
   rsaKey.exponent.data = (unsigned char *)(char *)SnaccRSAPublicKey.publicExponent;
   rsaKey.exponent.len = SnaccRSAPublicKey.publicExponent.Len();
#endif
#ifndef CRYPTOPP_5_0
        pRecipient = pRecipientIN;
#else   //  CRYPTOPP_5_0
        //RWC; Crypto++5.0 changed from just the bitstring to an ASN.1 encoded 
        //RWC;  SubjectPublicKeyInfo.
        SNACC::SubjectPublicKeyInfo SNACCsubjectPublicKeyInfo;
        SNACCsubjectPublicKeyInfo.algorithm = new SNACC::AlgorithmIdentifier;
        SNACCsubjectPublicKeyInfo.algorithm->algorithm = SNACC::rsaEncryption; // OR rsa OID.
        CTIL::CSM_Alg::LoadNullParams(SNACCsubjectPublicKeyInfo.algorithm);
        /* USELESS; SNACC removes the 0x00//RWC; TRYING to fix a problem when the expoonent is only 1 byte, 
        //RWC;  artificially making it 2 bytes...
        SNACC::RSAPublicKey SnaccRSAPublicKey;
        DECODE_BUF(&SnaccRSAPublicKey, pRecipientIN);
        if (SnaccRSAPublicKey.publicExponent.Len() < 2)
        {   // THEN add a preceeding 0
            unsigned char pNewData[2];
            pNewData[0] = '\0';
            pNewData[1] = SnaccRSAPublicKey.publicExponent[0];
            SnaccRSAPublicKey.publicExponent.Set(pNewData, 2);
            pRecipient = NULL;
            ENCODE_BUF(&SnaccRSAPublicKey, pRecipient);
            if (pRecipient)
            {
              SNACCsubjectPublicKeyInfo.subjectPublicKey.Set(pRecipient->Access(), 
                                                             pRecipient->Length()*8);
              pRecipient = NULL;
            }   // END if pRecipient
        }       // END if modulus length < 2
        //RWC; END TRYING
        else*/
            SNACCsubjectPublicKeyInfo.subjectPublicKey.Set(pRecipientIN->Access(), 
                                                       pRecipientIN->Length()*8);
        pRecipient = NULL;
        ENCODE_BUF(&SNACCsubjectPublicKeyInfo, pRecipient);
#endif  // CRYPTOPP_5_0

   // NOTE:  RSAES_OAEP_SHA_Encryptor needs a BufferedTransformation object
   // a ByteQueue is used for simple buffering into one of these objects
   // Prepare input into a bufferedTransformation object for encryption
   // with the recipient's public key
   // bufferedTransformation objects may assume that pointers to input
   // and output blocks are aligned on 32 bit boundaries
   byteQueueBuffer.Put((unsigned char *)pRecipient->Access(), pRecipient->Length());
   
   // create public key encryptor object
   // RSAES_OAEP_SHA_Encryptor rsaPub(buffer);
   RSAES_PKCS1v15_Encryptor rsaPub(byteQueueBuffer);

   // modulus = m_keygenParams.modulusBits 1024 / 8 = 128;
#ifndef CRYPTOPP_5_0
   modulus = rsaPub.CipherTextLength(); /*SM_FREE_DEFAULT_KEYBITS / 8;*/
#else // CRYPTOPP_5_0
   modulus = rsaPub.FixedCiphertextLength();//RWC;CiphertextLength(0); 
                /*RWC;???BASED on key I hope!!!??? */
#endif // CRYPTOPP_5_0
            // RWC;12/5/00; MADE modulus releative to key in recip cert.
   //RWC;Crypto++ 5.0 AccessKey()

   // get memory for the output cipher
   if ((pOutCipher = (byte *)calloc(1, modulus)) == NULL)
      SME_THROW(SM_MEMORY_ERROR, NULL, NULL);

   // inputs: m_pRng (random number), already done during login process
   //         pData to be encrypted, content encryption key
   //         length of data to be encrypted, 
   //         pOutCipher is output produced
   rsaPub.Encrypt(*m_pRng, (unsigned char *)pData->Access(), pData->Length(), pOutCipher);

   // transfer encrypted content encryption key to the output buffer
   SME(pEMEK->Open(SM_FOPEN_WRITE));
   SME(pEMEK->Write((char *)pOutCipher, modulus));  

   SME(pEMEK->Close());

   if (pOutCipher)
      free(pOutCipher);

   // RWC;2/7/00; If successful, load NULL PARAMS according to spec
   // ONLY FOR RSA.
   if (pParameters)
   {
       CSM_Buffer *pTmpBuf=CTIL::CSM_Alg::GetNullParams();
       *pParameters = *pTmpBuf;
       delete pTmpBuf;
   }

   
   SME_FINISH
   SME_CATCH_SETUP
      // put any local cleanup here
      status = -1;
      if (pRecipient && pRecipient != pRecipientIN)
          delete pRecipient;

   SME_CATCH_FINISH

#ifdef WIN32
    pSubjKeyId;pUKM;pParameters; //AVOIDS warning.
#endif
    if (pRecipient != pRecipientIN) // ONLY delete if a new copy was made.
       delete pRecipient;

   return(status);
}

//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_Free3::RSA_ExtractMEK(
            CSM_Buffer *pOriginator, // input, Y of originator
            CSM_Buffer *pParameters, // input
            CSM_Buffer *pEMEK, // input, encrypted MEK
            CSM_Buffer *pUKM, // input
            CSM_Buffer *pMEK) // output (MEK or special phrase)
{
   SM_RET_VAL   status            = 0;
   CryptoPP::ByteQueue            byteQueueBuffer;
   byte         *pchDecryptedData = NULL;
   unsigned int outLen;
   CSM_Buffer   *pbufX            = NULL; // temp spot for X value
   char         *pszPassword      = NULL; // temp spot for password
   Integer      x;                        // x value in integer form

   SME_SETUP("CSM_Free3::SMTI_RSA_ExtractMEK");

   // check incoming parameters
   if (/*(pOriginator == NULL) || */(pEMEK == NULL) || (pMEK == NULL))
      SME_THROW(SM_FREE_MISSING_PARAM, "Missing parameter, pEMEK or pMEK", NULL);

   // get the rsa private key
   // load current private key X
   SME(pszPassword = GetPassword()); // get the password
   // and then use the password to decrypt the EncryptedPrivateKeyInfo
   SME(pbufX = DecryptPrivateKey(pszPassword, m_pX));

   // Use the RSA private key associated with the public key used
   // to encrypt.
   byteQueueBuffer.Put((unsigned char *)pbufX->Access(), pbufX->Length());

   // NOTE:  RSAES_PKCS1v15_Decryptor needs a BufferedTransformation object
   // a ByteQueue is used for simple buffering into one of these objects
   // Prepare input into a bufferedTransformation object for decryption
   // bufferedTransformation objects may assume that pointers to input
   // and output blocks are aligned on 32 bit boundaries
   // byteQueueBuffer.Put((unsigned char *)pRecipient->Access(), pRecipient->Length());

   // decrypt the emek
#ifndef CRYPTOPP_5_0
   RSAES_PKCS1v15_Decryptor rsaPriv(byteQueueBuffer);
   //RSAES_OAEP_SHA_Decryptor rsaPriv(byteQueueBuffer);
   pchDecryptedData = (byte *)calloc(1,pEMEK->Length());
   outLen = rsaPriv.Decrypt(( const byte *)pEMEK->Access(), pchDecryptedData); 
#else // CRYPTOPP_5_0/5_1
   RSAES_PKCS1v15_Decryptor  rsaPriv(byteQueueBuffer);
   //const PrivateKey &keyPrivate = rsaPriv.GetPrivateKey();
   //CryptoMaterial &cryptoMaterial = rsaPriv.AccessMaterial();
   //Key &key = rsaPriv.GetKey();
   long lCipherLength = rsaPriv.CiphertextLength(pEMEK->Length());
   long lPlainLength  = rsaPriv.MaxPlaintextLength(pEMEK->Length());
   //RWC;DOES NOT WORK;Attempt to encode value as an Cryptopp::Integer
   /*CryptoPP::Integer ciData((const unsigned char*)pEMEK->Access(), pEMEK->Length());
   unsigned char achData[1024];
   ciData.Encode(&achData[0], pEMEK->Length());*/
   pchDecryptedData = (byte *)calloc(1,rsaPriv.MaxPlaintextLength(pEMEK->Length()));
#ifdef CRYPTOPP_5_1
   DecodingResult drResult = rsaPriv.Decrypt(*m_pRng, ( const byte *)/*achData/*/pEMEK->Access(), 
                             pEMEK->Length(), pchDecryptedData); 
#else // CRYPTOPP_5_0
   DecodingResult drResult = rsaPriv.Decrypt(( const byte *)/*achData/*/pEMEK->Access(), 
                             pEMEK->Length(), pchDecryptedData); 
#endif // CRYPTOPP_5_1
   outLen = drResult.messageLength;
   // ProcessLastBlock(...) AND MinLastBlockSize(...)
#endif // CRYPTOPP_5_0

   if (outLen == 0)        // IT DIDN'T WORK!!!
   {
      SME_THROW(22, "Bad rsaPriv.Decrypt!", NULL);
   }

   // put the decrypted data pchDecryptedData into the MEK
   pMEK->Set((char *)pchDecryptedData, outLen);

   if (pchDecryptedData)
       free(pchDecryptedData);
   if (pszPassword)
       free(pszPassword);
   if (pbufX)
       delete pbufX;

   SME_FINISH
   SME_CATCH_SETUP
      // put any local cleanup here
   SME_CATCH_FINISH

#ifdef WIN32
    pUKM;pParameters;pOriginator; //AVOIDS warning.
#endif
   return(status);
}

_END_CERT_NAMESPACE

#endif      // SM_FREE3_RSA_INCLUDED

// EOF sm_free3.cpp
