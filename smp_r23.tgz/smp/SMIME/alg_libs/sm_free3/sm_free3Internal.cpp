
//////////////////////////////////////////////////////////////////////////
// sm_Free3Internal.cpp
//
// This file contains some internal routines; specifically PKCS12 support.
//
//  Author:  Robert.Colestock@getronicsgov.com
//  
//
//////////////////////////////////////////////////////////////////////////

#ifdef WIN32
#pragma  warning( disable : 4505 4512 4100 4511 4516 4663 4018 4245 4244 4146 4097 ) 
                                    // IGNORE warnings from MS includes? 
                                    //  (?WHY present in MSVC?).
#include <process.h>
#include <winsock2.h>
#elif defined (SunOS) || defined (SOLARIS)
#include <unistd.h>
#include <arpa/inet.h>
#elif defined(Linux) || defined (SCO_SV)
#include <unistd.h>
#include <netinet/in.h>
#endif
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <sys/stat.h>
#include "sm_free3.h"
#include "sm_cms.h"
#include "rsa.h"     // From cryptopp.
#include "rc2.h"     // From cryptopp.
#include "randpool.h"
RandomPool rndRandom2;

#include "sm_CryptoKeysDsaExport.h"
#include "sm_CryptoKeysECDsaExport.h"
#include "sm_CryptoKeysDHExport.h"
#include "sm_CryptoKeysF3RsaExport.h"
#include "sm_free3_asn.h"
#include "sm_apiCert.h"
#include "sm_AppLogin.h"

#ifdef CRYPTOPP_5_0
#include "pwdbased.h"
typedef CBC_Mode_ExternalCipher::Encryption CBCPaddedEncryptor;
typedef CBC_Mode_ExternalCipher::Decryption CBCPaddedDecryptor;
#endif // CRYPTOPP_5_0

#ifdef PRE_R2_3     // PATCH for a customer before R2.3 released!!!
SNACC::AsnOid pkcs_9_at_friendlyName("1.2.840.113549.1.9.20");
SNACC::AsnOid pkcs_9_at_localKeyId("1.2.840.113549.1.9.21");
#endif

long Pkcs12_Decode(char *lpszPkcs12, CERT::CSMIME *pCsmime);

using namespace SNACC;
using CTIL::CSM_Buffer;
_BEGIN_CERT_NAMESPACE

//#define RC2BSAFE_TEST  // define to disable free rc2 library definitions
//END RWC;TMP
#ifdef OPENSSL_PKCS12_ENABLED
extern "C" {
#include "SFLpkcs12_support.h"
long SFLFree3PKCS12Init(CSM_CtilMgr &Csmime, char *pszPassword, char *pszPFXFile,
                        CSM_MsgCertCrls *pCertPathIN);
}
#endif   //OPENSSL_PKCS12_ENABLED
#ifdef WIN32
#pragma  warning( default: 4512 4100 4511 )  // IGNORE warnings from MS includes? 
#endif

#define OIDSafeBag_certBag                "1.2.840.113549.1.12.10.1.3"
#define OIDSafeBag_keyBag                 "1.2.840.113549.1.12.10.1.1"
#define OIDSafeBag_pkcs8ShroudedKeyBag    "1.2.840.113549.1.12.10.1.2"
#define OIDSafeBagContent_x509Certificate "1.2.840.113549.1.9.22.1"


#ifdef SM_FREE3_RSA_INCLUDED
//////////////////////////////////////////////////////////////////////////
SM_RET_VAL CSM_Free3::SMTI_VerifyRSA(
            CSM_Buffer *pSignerKeyIN, // input
            CSM_Alg    *pDigestAlg, // input
            CSM_Alg    *pSignatureAlg, // input
            CSM_Buffer *pData, // input
            CSM_Buffer *pSignature) // input
{
	const char* _func= "CSM_Free3::SMTI_VerifyRSA";
    CSM_Buffer *pSignerKey=NULL;
    RSASSA_PKCS1v15_SHA_Verifier *prsaPub=NULL;
    RSASSA_PKCS1v15_MD5_Verifier *prsaPubMD5=NULL;
	// Initialize return value
    SM_RET_VAL lRet = SM_NO_ERROR;


	try {
		// get the alg oid
		AsnOid algOid = pSignatureAlg->algorithm;
		AsnOid digOid;
		if (pDigestAlg)
			digOid = pDigestAlg->algorithm;
		else
			digOid = algOid;
        if (digOid == md5WithRSAEncryption ||
            digOid == md5WithRSAEncryptionOIW)
            digOid = md5;

		// digest incoming data
		CSM_Buffer bufferDigest;
        SME(CSM_Free3::SMTI_DigestData(pData, &bufferDigest, digOid));
	
		// prepare a bytequeue with the signers public key
		// NOTE:  RSASSA_PKCS1v15_SHA_Verifier needs a BufferedTransformation object
		// a ByteQueue is used for simple buffering into one of these objects
		// Prepare input into a bufferedTransformation object for encryption
		// with the recipient's public key
		// bufferedTransformation objects may assume that pointers to input
		// and output blocks are aligned on 32 bit boundaries
#ifndef CRYPTOPP_5_0
        pSignerKey = pSignerKeyIN;
#else   //  CRYPTOPP_5_0
        //RWC; Crypto++5.0 changed from just the bitstring to an ASN.1 encoded 
        //RWC;  SubjectPublicKeyInfo.
        //*** Incommin Key must always be reformatted
        SubjectPublicKeyInfo SNACCsubjectPublicKeyInfo;
        SNACCsubjectPublicKeyInfo.algorithm = new AlgorithmIdentifier;
        SNACCsubjectPublicKeyInfo.algorithm->algorithm = rsaEncryption; // OR rsa OID.
        CSM_Alg::LoadNullParams(SNACCsubjectPublicKeyInfo.algorithm);
        SNACCsubjectPublicKeyInfo.subjectPublicKey.Set(pSignerKeyIN->Access(), 
                                                       pSignerKeyIN->Length()*8);
        pSignerKey = NULL;
        ENCODE_BUF(&SNACCsubjectPublicKeyInfo, pSignerKey);
        lRet = SM_NO_ERROR;
#endif  // CRYPTOPP_5_0
		CryptoPP::ByteQueue publicKey;
		publicKey.Put((const byte*)pSignerKey->Access(), pSignerKey->Length());

		// determine rsa algorithm
		if (algOid == sha_1WithRSAEncryption ||
			algOid == sha_1WithRSAEncryption_ALT ||
			((algOid == rsaEncryption || algOid == rsa ||
			algOid == AsnOid("1.2.840.113549.1.2")) && 
			(digOid == sha_1 || digOid == sha_1WithRSAEncryption ) ) )
		{
			// prepare the DigestInfo object with null parameters 
			DigestInfo rsaDigestInfo;
			rsaDigestInfo.digestAlgorithm = new DigestAlgorithmIdentifier;
			rsaDigestInfo.digestAlgorithm->algorithm = sha_1;
			CSM_Alg::LoadNullParams(rsaDigestInfo.digestAlgorithm);
			rsaDigestInfo.digest.Set(bufferDigest.Access(), bufferDigest.Length());

			CSM_Buffer tempBuf;
			tempBuf.Encode(rsaDigestInfo);
            try
            {
                prsaPub = new RSASSA_PKCS1v15_SHA_Verifier(publicKey);
	        }
	        catch(CryptoPP::Exception &e)
	        {
#ifdef CRYPTOPP_5_0
                e.what();   // TO avoid compiler warning.
                //RWC; TRY using the key directly, not re-wrapped as PublicKeyInfo
                delete pSignerKey;
                pSignerKey = pSignerKeyIN;
		        CryptoPP::ByteQueue publicKey2;
		        publicKey2.Put((const byte*)pSignerKey->Access(), pSignerKey->Length());
                try
                {
                    prsaPub = new RSASSA_PKCS1v15_SHA_Verifier(publicKey2);
	            }
	            catch(CryptoPP::Exception &e)
	            {
#endif  //CRYPTOPP_5_0
                char pstrBuf[1024];
                strcpy(pstrBuf, "Crypto++ error: BAD RSA Public key.");
                int icount = strlen(e.what());
                if (icount < 1024 - strlen(pstrBuf))
                    strcat(pstrBuf, e.what());
                else
                    strncat(pstrBuf, e.what(), 1024 - strlen(pstrBuf));
                SME_THROW(22, pstrBuf, NULL);
            }       // END Catch
#ifdef CRYPTOPP_5_0
            }       // END Catch
#endif  //CRYPTOPP_5_0

			// verify the signature
            bool bVer = false;
#ifndef CRYPTOPP_5_0
			bVer = prsaPub->VerifyDigest((const byte *)tempBuf.Access(),
				(unsigned int)tempBuf.Length(),
				(unsigned char *)pSignature->Access());
#else // CRYPTOPP_5_0
            try {
#ifdef CRYPTOPP_5_1
                int iPubSigLen = prsaPub->SignatureLength();
#else  // CRYPTOPP_5_1
                int iPubSigLen = prsaPub->AccessDigestSignatureScheme().DigestSignatureLength(); //->SignatureLength();
#endif // CRYPTOPP_5_1
                if (pSignature->Length() >=  iPubSigLen + 1 ||
                    pSignature->Length() <=  iPubSigLen - 1)
                {
                    SME_THROW(22, "Bad public key length OR Signature length not valid!", NULL);
                }
                bVer = prsaPub->VerifyMessage((const byte *)pData->Access(),
				    (unsigned int)pData->Length(),
				    (const byte *)pSignature->Access()
#ifdef CRYPTOPP_5_1
                    ,pSignature->Length());
#else  // CRYPTOPP_5_1
                    );
#endif // CRYPTOPP_5_1
	        }
	        catch(CryptoPP::Exception &e)
	        {
                char pstrBuf[1024];
                strcpy(pstrBuf, "Crypto++ error: BAD RSA VerifyMessage. ");
                int icount = strlen(e.what());
                if (icount < 1024 - strlen(pstrBuf))
                    strcat(pstrBuf, e.what());
                else
                    strncat(pstrBuf, e.what(), 1024 - strlen(pstrBuf));
                SME_THROW(22, pstrBuf, NULL);
            }       // END Catch
#endif // CRYPTOPP_5_0
		
			if (!bVer)
				lRet = SM_FREE_VERIFY_FAILED;
            delete prsaPub;
            prsaPub = NULL;
		}
		else if (algOid == md5WithRSAEncryption ||
                 algOid == md5WithRSAEncryptionOIW ||
			((algOid == rsaEncryption || algOid == rsa ||
			algOid == AsnOid("1.2.840.113549.1.2")) && digOid == md5))
		{
			// prepare the DigestInfo object with null parameters
			DigestInfo rsaDigestInfo;
			rsaDigestInfo.digestAlgorithm = new DigestAlgorithmIdentifier;
			rsaDigestInfo.digestAlgorithm->algorithm = md5;
			CSM_Alg::LoadNullParams(rsaDigestInfo.digestAlgorithm);
			rsaDigestInfo.digest.Set(bufferDigest.Access(), bufferDigest.Length());

			CSM_Buffer tempBuf;
			tempBuf.Encode(rsaDigestInfo);
            // REN -- 9/5/03 -- ENCODE_BUF(&rsaDigestInfo, ptempBuf);
			/*RWC;11/15/02;if (!encodeBuf(rsaDigestInfo, tempBuf))
				SME_THROW(33, "Error encoding RSA DigestInfo", NULL);*/
            try 
            {
               prsaPubMD5 = new RSASSA_PKCS1v15_MD5_Verifier(publicKey);
	        }
	        catch(CryptoPP::Exception &e)
	        {
                char pstrBuf[1024];
                strcpy(pstrBuf, "Crypto++ error: BAD RSA Public key.");
                int icount = strlen(e.what());
                if (icount < 1024 - strlen(pstrBuf))
                    strcat(pstrBuf, e.what());
                else
                    strncat(pstrBuf, e.what(), 1024 - strlen(pstrBuf));
                SME_THROW(22, pstrBuf, NULL);
            }       // END Catch
		
			// verify the signature
            bool bVer=false;
#ifndef CRYPTOPP_5_0
			bVer = prsaPubMD5->VerifyDigest((const byte *)tempBuf.Access(),
				(unsigned int)tempBuf.Length(),
				(unsigned char *)pSignature->Access());
#else // CRYPTOPP_5_0
#ifdef CRYPTOPP_5_1
            try {
               bVer = prsaPubMD5->VerifyMessage((byte *)pData->Access(), 
                 (unsigned int)pData->Length(), 
                 (const byte *)pSignature->Access(), pSignature->Length());
            }
	        catch(CryptoPP::Exception &e)
	        {
                delete prsaPubMD5;
                char pstrBuf[1024];
                strcpy(pstrBuf, "Crypto++ error: BAD RSA VerifyDigest.");
                int icount = strlen(e.what());
                if (icount < 1024 - strlen(pstrBuf))
                    strcat(pstrBuf, e.what());
                else
                    strncat(pstrBuf, e.what(), 1024 - strlen(pstrBuf));
                SME_THROW(22, pstrBuf, NULL);
            }       // END Catch
#else   // CRYPTOPP_5_1
            try {
                DigestVerifier &dvVerifier = prsaPubMD5->AccessDigestSignatureScheme();
                bVer = dvVerifier.VerifyDigest((const byte *)tempBuf.Access(),
				    (unsigned int)tempBuf.Length(),
				    (const byte *)pSignature->Access());
            }
	        catch(CryptoPP::Exception &e)
	        {
                delete prsaPubMD5;
                char pstrBuf[1024];
                strcpy(pstrBuf, "Crypto++ error: BAD RSA VerifyDigest.");
                int icount = strlen(e.what());
                if (icount < 1024 - strlen(pstrBuf))
                    strcat(pstrBuf, e.what());
                else
                    strncat(pstrBuf, e.what(), 1024 - strlen(pstrBuf));
                SME_THROW(22, pstrBuf, NULL);
            }       // END Catch
#endif  // CRYPTOPP_5_1
#endif  // CRYPTOPP_5_0
		
			if (!bVer)
				lRet = SM_FREE_VERIFY_FAILED;
            delete prsaPubMD5;
            prsaPubMD5 = NULL;
		}
		else if (algOid == md2WithRSAEncryption ||
			((algOid == rsaEncryption || algOid == rsa ||
			algOid == AsnOid("1.2.840.113549.1.2")) && digOid == id_md2))
		{
			RSASSA_PKCS1v15_MD2_Verifier rsaPub(publicKey);
            bool bVer=false;
			// verify the signature
#ifndef CRYPTOPP_5_0
			bVer = rsaPub.VerifyDigest((const byte*)bufferDigest.Access(),
				(unsigned int) bufferDigest.Length(),
				(unsigned char *)pSignature->Access());
#else // CRYPTOPP_5_0
#ifdef CRYPTOPP_5_1
            try {
               bVer = rsaPub.VerifyMessage((byte *)pData->Access(), 
                 (unsigned int)pData->Length(), 
                 (const byte *)pSignature->Access(), pSignature->Length());
            }
	        catch(CryptoPP::Exception &e)
	        {
                char pstrBuf[1024];
                strcpy(pstrBuf, "Crypto++ error: BAD RSA VerifyDigest.");
                int icount = strlen(e.what());
                if (icount < 1024 - strlen(pstrBuf))
                    strcat(pstrBuf, e.what());
                else
                    strncat(pstrBuf, e.what(), 1024 - strlen(pstrBuf));
                SME_THROW(22, pstrBuf, NULL);
            }       // END Catch
#else  // CRYPTOPP_5_1
            DigestVerifier &dvVerifier = rsaPub.AccessDigestSignatureScheme();
            bVer = dvVerifier.VerifyDigest((const byte *)bufferDigest.Access(),
				(unsigned int) bufferDigest.Length(),
				(const byte *)pSignature->Access());
#endif // CRYPTOPP_5_1
#endif // CRYPTOPP_5_0
			if (!bVer)
				lRet = SM_FREE_VERIFY_FAILED;
		}
		else
		{
			SME_THROW(22, "RSA OID Unknown or Not Handled Yet!", NULL);
		
		}
	}
	catch (SNACC::SnaccException& snaccE) {
        if (prsaPub)
            delete prsaPub;
        if (prsaPubMD5)
            delete prsaPubMD5;
        if (pSignerKey != NULL && pSignerKey != pSignerKeyIN)
            delete pSignerKey; // THEN we created this local version.
		snaccE.push(STACK_ENTRY);
		throw;
	}
	catch(CryptoPP::Exception &e)
	{
        if (prsaPub)
            delete prsaPub;
        if (pSignerKey != NULL && pSignerKey != pSignerKeyIN)
            delete pSignerKey; // THEN we created this local version.
        if (prsaPubMD5)
            delete prsaPubMD5;
        char pstrBuf[1024];
        strcpy(pstrBuf, "Crypto++ error: CSM_Free3::SMTI_VerifyRSA. ");
        int icount = strlen(e.what());
        if (icount < 1024 - strlen(pstrBuf))
            strcat(pstrBuf, e.what());
        else
            strncat(pstrBuf, e.what(), 1024 - strlen(pstrBuf));
        SME_THROW(22, pstrBuf, NULL);
    }       // END Catch

    if (pSignerKey != NULL && pSignerKey != pSignerKeyIN)
        delete pSignerKey; // THEN we created this local version.
    return lRet;
}       // END CSM_Free3::SMTI_VerifyRSA(...)
#endif

//
//
//////////////////////////////////////////////////////////////////////////
CSM_Buffer* CSM_Free3::GeneratePKCS12PBEKey(CSM_Buffer *pbufSalt, int nIterCount, 
                  int iID, char *pszPassword, AsnOid &o, int nKeyLength, 
                  int lPassword, int lBlockSize, long lRequested)
{
   CSM_Buffer *pK = NULL;
   CSM_Buffer *pKOut = NULL;
   CSM_Buffer *pTemp;
   int nLoop;
   int i;
   long status=0;

   SME_SETUP("CSM_Free3::GeneratePKCS12PBEKey");

   // create the DES key by concatentating bufferSalt onto the password
   // and then digesting the result nIterCount times

     /*if ( o == md5)
     {
          if (nKeyLength > 16)
          {
              SME_THROW(27, "CSM_Free3::GeneratePKCS12PBEKey: bad md5 length", NULL);
          }
     }
     else*/
     if (o == sha_1)
     {
          if (nKeyLength > 20)
          {
              SME_THROW(27, "bad sha1 length2", NULL);
          }
     }
     else
     {
          SME_THROW(27, "Non-supported Hash OID for PKCS12 PBE (ONLY SHA-1)", NULL);
     }

   // check length
   if (lPassword == 0)
     lPassword = strlen(pszPassword);
   //if (lPassword > nKeyLength) //pbufSalt->Length()))
   //   lPassword = nKeyLength; //pbufSalt->Length();

   const char *pSalt=pbufSalt->Access();
   char *pWorkingSalt_Password=(char *)calloc(1, lBlockSize*2);
   char *ptr2=pWorkingSalt_Password;
   char *pID=(char *)calloc(1, lBlockSize);
   memset(pID, iID, lBlockSize);
	for (i = 0; i < lBlockSize; i++) *ptr2++ = pSalt[i % pbufSalt->Length()];
	for (i = 0; i < lBlockSize; i++) *ptr2++ = pszPassword[i % lPassword];
   if ((pKOut = new CSM_Buffer) == NULL)
         SME_THROW(SM_MEMORY_ERROR, "memory", NULL);

	for (;;) 
   {
      if ((pK = new CSM_Buffer) == NULL)
         SME_THROW(SM_MEMORY_ERROR, "memory", NULL);

      // PRE-INIT hash for PKCS12 PBE.
      SME(pK->Open(SM_FOPEN_WRITE));
      SME(pK->Write(pID, lBlockSize)); 
      SME(pK->Write(pWorkingSalt_Password, lBlockSize*2)); 
      pK->Close();

      for (nLoop = 0; nLoop < nIterCount; nLoop++)
      {
         if ((pTemp = new CSM_Buffer) == NULL)
            SME_THROW(SM_MEMORY_ERROR, "MEMORY ERROR!", NULL);
         if (o == sha_1)
         {
            SME((status=SMTI_DigestDataSHA1(pK, pTemp)));
         }     // IF o==sha_1
         else
         {
            SME((status=SMTI_DigestDataInternal(pK, pTemp, o)));
         }     // END if o==sha_1
         if (status != 0)
         {
            SME_THROW(SM_MEMORY_ERROR, "SMTI_DigestData alg not supported!", NULL);
         }
         // now, move digest result to K and empty temp
         delete (pK);
         pK = pTemp;
      }     // END for iteration loop

      SME(pKOut->Open(SM_FOPEN_APPEND));
      SME(pKOut->Write(pK->Access(), pK->Length())); 
      pKOut->Close();
  	   if (pKOut->Length() >= lRequested || lRequested == 0/*flag to IGNORE*/) 
      {
         delete pK;
         pK = NULL;
         break;
      }
      else     // IF enough data.
      {
         // Continue hash creation beyong default length
         //  (20 bytes hash ++; Big Integer math)
         long lHashLength=pK->Length(); 
         const char *pHash=pK->Access();
         char *pFinalKey=(char *)calloc(1, lBlockSize);
         int j;
		   for (j = 0; j < lBlockSize; j++) 
            pFinalKey[j] = pHash[j % lHashLength];
         //CryptoPP::ByteQueue binKey;
         //binKey.Put((unsigned char *)pFinalKey, lBlockSize);
                     //RWC;Careful, Big-endian order.
         Integer biKeyKeep(/*binKey*/(const unsigned char *)pFinalKey, lBlockSize/*, 
                        Integer::SIGNED*/);
                  //		Integer(BufferedTransformation &bt, unsigned int byteCount, Signedness s=UNSIGNED);
         /*&char *pTmpWorkingSalt_Password=(char *)calloc(1, lBlockSize*2);
         memcpy(pTmpWorkingSalt_Password, pWorkingSalt_Password, lBlockSize*2);
         for (j=0; j < lBlockSize; j++)      // REVERSE 1st half
            pTmpWorkingSalt_Password[lBlockSize-j-1] = pWorkingSalt_Password[j];
         for (j=0; j < lBlockSize; j++)      // REVERSE 2nd half
            pTmpWorkingSalt_Password[lBlockSize+lBlockSize-j-1] = 
               pWorkingSalt_Password[lBlockSize+j];*/
         biKeyKeep += Integer::One();
         Integer biKey;
		   for (j = 0; j < lBlockSize*2; j+=lBlockSize) 
         {
            biKey = biKeyKeep;
            //CryptoPP::ByteQueue binTmpQue;
            //binTmpQue.Put((unsigned char *)&pTmpWorkingSalt_Password[j], lBlockSize);
            Integer biTmp(/*binTmpQue*/(const unsigned char *)
                 &pWorkingSalt_Password[j], lBlockSize/*, Integer::SIGNED*/);
            biKey += biTmp;
            //RWC; NO CONVENIENT WAY TO GET RAW DATA BACK; must put them in 
            //RWC;  forward, but get them back backwards...
            for (int ii2=0; ii2 < lBlockSize; ii2++)
              pWorkingSalt_Password[j+lBlockSize-ii2-1] = biKey.GetByte(ii2);
                                    // RWC;WATCH OUT FOR "0" padding on MSB.
         }  // END for prep for next computation.
         //RWC;TBD; be sure to copy pTmpWorkingSalt_Password back to pWorkingSalt_Password.
         free(pFinalKey);
         delete(pK);
      }     // END if not enough data.
   }        // END for ;;
   free(pID);                       // Free ONLY at end...
   free(pWorkingSalt_Password);     // Free ONLY at end...

   SME_FINISH
   SME_CATCH_SETUP
   SME_CATCH_FINISH
   
   return pKOut;
}

//////////////////////////////////////////////////////////////////////////
// THIS routine was updated to reflect ONLY PKCS12 decryption.
//  (different ASN.1 definitions from PKCS8, but similar algorithm processing).
long CSM_Free3::DecryptPKCS12PrivateKey(CSM_Buffer *pEncryptedPrivateKeyInfo, 
    const char *pszPassword, CSM_PrivDataLst &PrivList)//CSM_Buffer *pCert)
{
    PFX Pfx;
    EncryptedData *pencryptedData=NULL;
    CSM_Buffer *pencryptedDataBuf;
    SafeContents SeqContentInfos;  // Actually not SafeContents, but
                                    //   convenient definition.
    CSM_BufferLst BufPrivList;
    CSM_BufferLst BufCertList;
    long lStatus=-1;       // Default failure.
#ifdef _DEBUG
    long lStatus2=0;
#endif //_DEBUG


   SME_SETUP("CSM_Free3::DecryptPKCS12PrivateKey");

   if ((pEncryptedPrivateKeyInfo == NULL) || (pszPassword == NULL))
      SME_THROW(SM_MISSING_PARAM, "MISSING PARAMS", NULL);

    DECODE_BUF(&Pfx, pEncryptedPrivateKeyInfo);
    if (Pfx.macData == NULL || Pfx.macData->safeMac->digestAlgorithm == NULL)
    {
        SME_THROW(SM_UNKNOWN_ERROR, 
                     "optional macData MUST be present (password)", NULL);
    }

    int iter = 1;       // DEFAULT
    if (Pfx.macData->macIterationCount)
        iter = *Pfx.macData->macIterationCount;
    CSM_Buffer bufSalt(Pfx.macData->macSalt.c_str(), Pfx.macData->macSalt.Len());
    CSM_Buffer *pBuf=NULL;
    CSM_Buffer *pBuf2=NULL;
    ENCODE_BUF(&Pfx.authSafe->content, pBuf);/*RWC;11/15/02;.GetUndecodedAny();*/
    if (pBuf)
    {
#ifndef PRE_R2_3     // PATCH for a customer before R2.3 released!!!
        AsnOcts SNACCOcts;
        DECODE_BUF(&SNACCOcts, pBuf);
        pBuf2 = new CSM_Buffer(SNACCOcts.c_str(), SNACCOcts.Len());
        CSM_Buffer *pBufComputedMac = ComputePkcs12MAC(bufSalt, 
                     Pfx.macData->safeMac->digestAlgorithm->algorithm, 
                     pszPassword, *pBuf2, iter);
        CSM_Buffer BufSafeMac(Pfx.macData->safeMac->digest.c_str(), 
            Pfx.macData->safeMac->digest.Len());
        if (pBufComputedMac && *pBufComputedMac != BufSafeMac)
        {
#ifndef _DEBUG
                SME_THROW(30,"macData DOES NOT MATCH computed MAC!!!", NULL);
#else   //_DEBUG
                std::cout << "macData DOES NOT MATCH computed MAC (DEBUG IGNORES)!!!"  << std::endl;
                lStatus2 = -100;
#endif //_DEBUG
        }       // END IF 1st mac value check
        if (pBufComputedMac)
            delete pBufComputedMac;
#endif //PRE_R2_3     // PATCH for a customer before R2.3 released!!!
        delete pBuf;
    }       // END IF pBuf MAC from PKCS12

    if (Pfx.authSafe->contentType == id_data)
    {
        if (pBuf2)
        {
#ifdef _DEBUG
           pBuf2->ConvertMemoryToFile("./tmpSm_free3InternalBuf2.out");
#endif //_DEBUG
           DECODE_BUF(&SeqContentInfos, pBuf2);
           delete pBuf2;
        }
        else            
        {
           SME_THROW(SM_UNKNOWN_ERROR, "Pfx.authSafe->content "
               "ASN.1 decode failure.", NULL);
        }
                        // From our class, should be decoded Octet String.

        SeqContentInfos.SetCurrToFirst();
        SafeBag *pSNACCCSafeBag;  //ContentInfo *pSNACCContentInfo;
        for (pSNACCCSafeBag=SeqContentInfos.Curr(); pSNACCCSafeBag; 
             pSNACCCSafeBag=SeqContentInfos.GoNext())
        {
         if (pSNACCCSafeBag->safeBagType == id_encryptedData)
         {
            pencryptedDataBuf = NULL;
            ENCODE_BUF(&pSNACCCSafeBag->safeBagContent, pencryptedDataBuf);
            /*RWC;11/15/02.GetUndecodedAny();
            if (pencryptedDataBuf != NULL)   // THEN decoded...
            {*/
               pencryptedData = new EncryptedData;
               DECODE_BUF(pencryptedData, pencryptedDataBuf);
               //RWC;2nd;DECODE_ANY(pencryptedData,      // NOT id-data.
               //RWC;2nd;    &(pSNACCCSafeBag->safeBagContent));
            /*RWC;11/15/02;}
            else
               pencryptedData = (EncryptedData *)
                   pSNACCCSafeBag->safeBagContent.value;*/

            if (pencryptedData &&
                pencryptedData->encryptedContentInfo->contentType == id_data)
            {
                    CSM_Buffer *pbufEncryptedKey=NULL;
                    ENCODE_BUF(pencryptedData->encryptedContentInfo, pbufEncryptedKey);
                    lStatus = DecryptPKCS12Cert( 
                       pbufEncryptedKey, pszPassword, BufPrivList, BufCertList);
                    if (lStatus != 0)
                    {
                       SME_THROW(lStatus, "DecryptPKCS12Cert error", NULL);
                    }      // END if pDecryptedPKCS12Cert.
                    delete pencryptedData;
                    if (pbufEncryptedKey)
                       delete pbufEncryptedKey;
            }
            else
            {
                SME_THROW(SM_UNKNOWN_ERROR, "EncryptedData.encryptedContentInfo"
                    " MUST be id-data", NULL);
            }
            if (pencryptedDataBuf)
               delete pencryptedDataBuf;
         }           // IF id_encryptedData
         else if (pSNACCCSafeBag->safeBagType == id_data)
         {
            /*SignedData *pSNACCSignedData;*/
            CSM_Buffer *pDataBuf = NULL;
            ENCODE_BUF(&pSNACCCSafeBag->safeBagContent, pDataBuf);//RWC;11/15/02;.GetUndecodedAny();
            if (pDataBuf != NULL)   // THEN decoded...
            {
               AsnOcts SNACCOcts;
               DECODE_BUF(&SNACCOcts, pDataBuf);
               pDataBuf->Set(SNACCOcts.c_str(), SNACCOcts.Len());
            }
            else
            {
               SME_THROW(44, "NEED TO ENCODE_BUF!!!!!", NULL);
               /*pSNACCSignedData = (SignedData *)
                   pSNACCCSafeBag->safeBagContent.value;*/
            }
            if (pDataBuf)
            {
               lStatus = DecryptPKCS12_ProcessBags(*pDataBuf, pszPassword, 
                                                  BufPrivList, BufCertList);
               delete pDataBuf;
            }     // END if pSNACCSignedData

         }           // IF id_data
         else
         {
            SME_THROW(SM_UNKNOWN_ERROR, "MUST be EncryptedData", NULL);
         }
        }      // END FOR each SafeBag.
    }
    else
    {
        SME_THROW(SM_UNKNOWN_ERROR, 
                     "MUST be id-data ContentInfo", NULL);
    }

    // NOW that we have processed the list of potential private keys and certs
    //  align them if necessary.
    if (BufPrivList.Count() && BufCertList.Count()) // ONLY if at least 1 of each.
    {
       CSM_Buffer   *pBufPublicKeyFromCert;
       if (BufPrivList.Count() == 1)
       {
          CSM_PrivData *pPrivData = PrivList.Append();
          pPrivData->m_BufCertList = BufCertList;     //COPY ALL CERTS.
          pPrivData->m_BufPriv = *BufPrivList.First(); //COPY only priv key.
          lStatus = 0;     // INDICATE at least 1 was matched.
          /*DEBUG CHECK of public/private keys.* /
          CSM_CertificateChoice CertChoice;
          CertChoice.SetEncodedCert(*BufPrivList.FirstL());
          pBufPublicKeyFromCert = CertChoice.GetPublicKey();
          */
       }
       else // IF BufPrivList.CountL() is not 1
       {          // HERE we must align the private key(s) with their 
                  //  respective certs.
          CSM_PrivData *pPrivData;
          CSM_Buffer   *ptmpPriv;
          CSM_Buffer   *ptmpCert, *ptmpCert2;
          //CSM_Buffer   *pBufPublicKeyFromPrivateKey;
          CSM_CertificateChoice CertChoice;
          for (BufPrivList.SetCurrToFirst(),
               ptmpPriv=BufPrivList.Curr(); 
               ptmpPriv; ptmpPriv=BufPrivList.GoNext())
          {             // FOR each private key, search for a corresponding cert.
             // FIRST determine public key matching this private key!
             for (BufCertList.SetCurrToFirst(),
                  ptmpCert=BufCertList.Curr(); 
                  ptmpCert; ptmpCert=BufCertList.GoNext())
             {             // FOR each private key, search for a corresponding cert.
                CertChoice.SetEncodedCert(*ptmpCert);
                pBufPublicKeyFromCert = CertChoice.GetPublicKey();
                lStatus = DecryptPKCS12_CheckPublicWithPrivate(
                                    *pBufPublicKeyFromCert, *ptmpPriv);
                if (lStatus == 0)
                {
                   pPrivData = PrivList.Append();
                   ptmpCert2 = pPrivData->m_BufCertList.Append();
                   *ptmpCert2 = *ptmpCert;   //COPY.
                                 // BE SURE our EndEntity cert is 1st!!!
                   CSM_Buffer *pTmpBufP12Cert;
                   CSM_Buffer *pTmpBuf;
                   for (BufCertList.SetCurrToFirst(),
                        pTmpBufP12Cert=BufCertList.Curr(); 
                        pTmpBufP12Cert; pTmpBufP12Cert=BufCertList.GoNext())
                   {                // ONE is a duplicate, but will not make it
                                    //    into the actual login cert list.
                      pTmpBuf = pPrivData->m_BufCertList.Append(); 
                      *pTmpBuf = *pTmpBufP12Cert;     //COPY EACH CERTS.
                   }    // END for each PKCS12 cert in list.
                   pPrivData->m_BufPriv = *ptmpPriv;          //COPY only priv key.
                   break;           // STOP checking for matching cert.
                }    // END if pBufPublicKeyFromPrivateKey
                else
                   delete pBufPublicKeyFromCert;
             }    // END for each cert in list.
          }    // END for each private key.
       }    //END if BufPrivList.CountL() == 1
    }    // END if 1 of each.

   SME_FINISH
   SME_CATCH_SETUP
   SME_CATCH_FINISH

#ifdef _DEBUG
   if (lStatus2 != 0 && lStatus == 0)        // SUCCESSFUL except for the MAC check...
       lStatus = lStatus2;
#endif // _DEBUG

   return lStatus;
}     // END CSM_Free3::DecryptPKCS12PrivateKey(...)


//////////////////////////////////////////////////////////////////////////
//
long CSM_Free3::DecryptPKCS12_CheckPublicWithPrivate(
      CSM_Buffer &BufCheckPublic, CSM_Buffer &BufPrivateKey)
{
   Integer      *px;         // x value in integer form
   long lStatus=-1;
   CSM_Buffer *pBufRawPrivateKey;
   CSM_Buffer BufDerivedPublicKey;
   PrivateKeyInfo snaccX;
   char b[2048];
   int nLen;
   CSM_SFLDSAPrivateKey *pdsaX=NULL;
   CryptoPP::Integer *pintDSAY;
   CryptoPP::Integer paramDSAP;
   CryptoPP::Integer paramDSAQ;
   CryptoPP::Integer paramDSAG;
   CryptoPP::ByteQueue  byteQueueBuffer;

   SME_SETUP("CSM_Free3::DecryptPKCS12_CheckPublicWithPrivate");

   // ASN.1 decode the private key
   DECODE_BUF(&snaccX, &BufPrivateKey);

   if (snaccX.privateKeyAlgorithm->algorithm  ==  id_dsa_with_sha1 ||
       snaccX.privateKeyAlgorithm->algorithm ==  id_dsa)
   {
       pintDSAY = sm_Free3CryptoppBERDecode(BufCheckPublic.Access(), 
          BufCheckPublic.Length());
       //DSAPublicKey dsaY(*pP, *pQ, *pG, *py);

       pBufRawPrivateKey = new CSM_Buffer(snaccX.privateKey.c_str(), 
            snaccX.privateKey.Len());
       FREE_DSAParameters snaccDSAParams;
       DECODE_ANY((&snaccDSAParams), (snaccX.privateKeyAlgorithm->parameters));
       // extract P
       long lParam = 128;
       if (snaccDSAParams.p.length() <= 64)
          lParam = 64;
       Integer *pTmpBI;
       pTmpBI = ComputeBigInteger(snaccDSAParams.p, lParam);
       paramDSAP = *pTmpBI; //RWC;.Decode(pbyte, snaccDSAParams.p.Len());
       delete pTmpBI;
       pTmpBI = ComputeBigInteger(snaccDSAParams.q, 20);
       paramDSAQ = *pTmpBI; //RWC;.Decode(pbyte, snaccDSAParams.q.Len());
       delete pTmpBI;
       pTmpBI = ComputeBigInteger(snaccDSAParams.g, lParam);
       paramDSAG = *pTmpBI; //RWC;.Decode(pbyte, snaccDSAParams.g.Len());
       delete pTmpBI;

       px = sm_Free3CryptoppBERDecode(pBufRawPrivateKey->Access(), pBufRawPrivateKey->Length());
       if (px && pintDSAY)
       {
          pdsaX = new CSM_SFLDSAPrivateKey(paramDSAP, paramDSAQ, paramDSAG, *pintDSAY, *px);
       }

       if (pBufRawPrivateKey)
          delete pBufRawPrivateKey;
       if (px)
          delete px;        // Destroy Integer after load.
       if (pintDSAY)
          delete pintDSAY;

       if (pdsaX && pdsaX->Access_y())
       {          // IT WORKED!!!!
          /*nLen = sm_Free3CryptoppDEREncode(*pdsaX->Access_y(), (unsigned char *)&b[0], 2048);
          pBufResult = new CSM_Buffer;
          pBufResult->Open(SM_FOPEN_WRITE);
          pBufResult->Write((char *)(&b[0]), nLen);
          pBufResult->Close();*/
          lStatus = 0;
       }    // END if pdsaX->Access_y()
   }     // IF id_dsa
   else if (snaccX.privateKeyAlgorithm->algorithm ==  rsaEncryption ||
            snaccX.privateKeyAlgorithm->algorithm ==  rsa)
   {
      CryptoPP::ByteQueue ByteQue_privateKey;
      ByteQue_privateKey.Put((unsigned char *)BufPrivateKey.Access(), 
                                              BufPrivateKey.Length());
      RSASSA_PKCS1v15_SHA_Signer rsaPriv(ByteQue_privateKey);
      RSASSA_PKCS1v15_SHA_Verifier rsaPub(rsaPriv);
      rsaPub.DEREncode(byteQueueBuffer); 
      nLen = byteQueueBuffer.Get((unsigned char *)&b[0], 2048);
      BufDerivedPublicKey.Set((char *)(&b[0]), nLen);
      SubjectPublicKeyInfo snaccPKI;
      DECODE_BUF(&snaccPKI, &BufDerivedPublicKey);
      BufDerivedPublicKey.Set(snaccPKI.subjectPublicKey.data(), 
                              snaccPKI.subjectPublicKey.length());   
                              // RE-use buffer.
      if (BufDerivedPublicKey == BufCheckPublic)
          lStatus = 0;
   }     // IF rsa
   else
   {
      char pBuf[2048];
      sprintf(&pBuf[0], "privateKeyAlgorithm not supported, %s.", 
         snaccX.privateKeyAlgorithm->algorithm.GetChar());
      SME_THROW(27, pBuf, NULL);
   }     //END if dsa OR rsa

   SME_FINISH
   SME_CATCH_SETUP
      lStatus = -1;
#ifdef WIN32
      Exception;        // removes compiler warning.
#endif // WIN32
      //const char *ptr=Exception.what();      //IGNORE error.
      // DO NOT THROW AN EXCEPTION HERE, just allow a return of an error.
   }     // END exception processing.
   //SME_CATCH_FINISH

    return(lStatus);
}     // END DecryptPKCS12_GetPublicFromPrivate(...)

//////////////////////////////////////////////////////////////////////////
//
long CSM_Free3::DecryptPKCS12Cert(CSM_Buffer *pEncryptedPrivateKeyInfo, 
   const char *pszPasswordIn, CSM_BufferLst &BufPrivList, CSM_BufferLst &BufCertList)
{
   long lStatus=0;
   PBEParameter snaccEncryptionParams;
   AsnOid oidHash;
   long status=0;
   EncryptedContentInfo snaccEncryptedCI;
   CSM_Buffer *pbufEncodedPrivateKey=NULL;

   SME_SETUP("CSM_Free3::DecryptPKCS12Cert");

   if ((pEncryptedPrivateKeyInfo == NULL) || (pszPasswordIn == NULL))
      SME_THROW(SM_MISSING_PARAM, "MISSING PARAMS", NULL);

   // ASN.1 decode the EncryptedPrivateKeyInfo
   DECODE_BUF(&snaccEncryptedCI, pEncryptedPrivateKeyInfo);
   CSM_Buffer bufEncryptedKey(snaccEncryptedCI.encryptedContent->c_str(),
            snaccEncryptedCI.encryptedContent->Len());

#ifdef _DEBUG
   bufEncryptedKey.ConvertMemoryToFile("./tmpSm_free3InternalBuf3.out");
#endif
   pbufEncodedPrivateKey = DecryptPKCS12Blob(pszPasswordIn, 
         *snaccEncryptedCI.contentEncryptionAlgorithm, bufEncryptedKey);
    //RWC;11/28/02;TBD; BAD DATA RETURNED, 1st buffer good, later bad?????
   //BROKEN!!!!
   if (pbufEncodedPrivateKey)
   {
#ifdef _DEBUG
       pbufEncodedPrivateKey->ConvertMemoryToFile("./tmpSm_free3InternalBuf4.out");
#endif
      // for debug only - to be taken out
      /*#ifdef _DEBUG
      pbufEncodedPrivateKey->ConvertMemoryToFile("./decryptedPrivateKey.log");
      #endif*/

      status = DecryptPKCS12_ProcessBags(*pbufEncodedPrivateKey, pszPasswordIn, 
         BufPrivList, BufCertList);

      delete pbufEncodedPrivateKey;

   }     // END IF pbufEncodedPrivateKey

   SME_FINISH
   SME_CATCH_SETUP
   SME_CATCH_FINISH

   return lStatus;
}


//////////////////////////////////////////////////////////////////////////
// RETURNS decrypted Blob.
CSM_Buffer *CSM_Free3::DecryptPKCS12Blob(const char *pszPasswordIn, 
   AlgorithmIdentifier &EncryptionAlgorithm, CSM_Buffer &bufEncryptedKey)
{
   PBEParameter snaccEncryptionParams;
   RC2Decryption *pRC2Decryption = NULL;
   DESDecryption *pDESDecryption = NULL;
   DES_EDE3_Decryption *p3DESDecryption = NULL;
   CSM_Buffer *pbufEncodedEncryptionParams = NULL;
   CSM_Buffer *pK = NULL;
   CSM_Buffer *pIV = NULL;
   CBCPaddedDecryptor *cbc_decryption=NULL;
   int blocksize = 0;
   AsnOid oidHash;
   int iLength = 20;
   int iPBEKeyBits=SM_FREE_RC2_DEFAULT_PBE_KEYBITS;
   EncryptedContentInfo snaccEncryptedCI;
   char *pszPassword=NULL;
   long lPassword2=(strlen(pszPasswordIn)+1)*2;
   long lRequestedLength=0;
   CSM_Buffer *pbufOut=NULL;

   SME_SETUP("CSM_Free3::DecryptPKCS12Blob");

   if (pszPasswordIn == NULL)
      SME_THROW(SM_MISSING_PARAM, "MISSING PARAMS", NULL);

   pszPassword=(char *)calloc(1, lPassword2);
   for (int iii=0; iii < strlen(pszPasswordIn); iii++)
        pszPassword[iii*2+1] = pszPasswordIn[iii];

   if (EncryptionAlgorithm.algorithm != pbewithSHAAnd40BitRC2_CBC &&
       EncryptionAlgorithm.algorithm != pbeWithSHAAnd3_KeyTripleDES_CBC)
   {
      SME_THROW(33, "EncryptionAlgorithm not supported, ONLY pbewithSHAAnd40BitRC2_CBC.", NULL);
   }

   // extract the encryption algorithm parameters and asn.1 decode them
   SM_EXTRACT_ANYBUF(pbufEncodedEncryptionParams, 
         EncryptionAlgorithm.parameters);
   DECODE_BUF((&snaccEncryptionParams), pbufEncodedEncryptionParams);

   delete pbufEncodedEncryptionParams;
   pbufEncodedEncryptionParams = NULL;

   int nIterCount = snaccEncryptionParams.iterationCount;
   CSM_Buffer bufSalt(snaccEncryptionParams.salt.c_str(), 
         snaccEncryptionParams.salt.Len());

   if (EncryptionAlgorithm.algorithm == pbewithSHAAnd40BitRC2_CBC ||
       EncryptionAlgorithm.algorithm == pbeWithSHAAnd3_KeyTripleDES_CBC)
   {
       oidHash = sha_1;
       iLength = 20;
       blocksize = SM_COMMON_RC2_BLOCKSIZE;//iPBEKeyBits/8;
       if (EncryptionAlgorithm.algorithm == pbeWithSHAAnd3_KeyTripleDES_CBC)
          lRequestedLength = 24;    // MUST request larger value since SHA-1
                                    //  only provides 20 bytes...
      // generate the key using the salt, the iteration count, and the password
      SME(pK = GeneratePKCS12PBEKey(&bufSalt, nIterCount, 0x01, pszPassword, 
               oidHash, iLength, lPassword2, 0x40, lRequestedLength));

      //pK->SetLength(3); // SET only necessary key length.
      SME(pIV = GeneratePKCS12PBEKey(&bufSalt, nIterCount, 0x02, pszPassword, 
               oidHash, iLength, lPassword2, 0x40));
   }
   else
   {
      SME_THROW(22, "EncryptionAlgorithm not recognized!", NULL);
   }

   if (EncryptionAlgorithm.algorithm == pbewithSHAAnd40BitRC2_CBC)
   {
      iPBEKeyBits = 40;
      // create the rc2 cipher 
      pRC2Decryption = new RC2Decryption ((const unsigned char*)pK->Access(),
         (iPBEKeyBits/8), iPBEKeyBits);
 
      // create cbc object
      if (pIV == NULL)
         pIV = pK;
      cbc_decryption = new CBCPaddedDecryptor(*pRC2Decryption, 
         (const unsigned char *)pIV->Access());
   }
   else if (EncryptionAlgorithm.algorithm == pbeWithSHAAnd3_KeyTripleDES_CBC)
   {
      // create the 3DES cipher 
      /*char pKPBits[24];
      memcpy(pKPBits, pK->Access(), 20);
      memset(&pKPBits[20], '\0', 4);
      memcpy(&pKPBits[8], pK->Access(), 8);
      memcpy(&pKPBits[16], pK->Access(), 8);
      for (int iii=0; iii < 24; iii++)
         pKPBits[iii] = (p_pK[iii/8] & (1 << (iii % 8)));
         / * if (p_pK[iii/8] & (1 << (iii % 8)))
            pKPBits[iii] = 1;
         else
            pKPBits[iii] = 0;*/


      // BE SURE TO ADJUST THE PARITY!!!!!!
      unsigned char *ptr3=(unsigned char *)calloc(1, pK->Length());
      memcpy(ptr3, pK->Access(), pK->Length());
      for (int iii=0; iii < 24; iii++)
      {
         if (!CryptoPP::Parity((unsigned long)ptr3[iii]))
            ptr3[iii] ^= 0x01;
      }

      p3DESDecryption = new DES_EDE3_Decryption ((const unsigned char*)/*pKPBits*/ptr3/*pK->Access()*/);
      free(ptr3);

      // create cbc object
      if (pIV == NULL)
          pIV = pK;
      cbc_decryption = new CBCPaddedDecryptor(*p3DESDecryption, 
         (const unsigned char *)pIV->Access());
   }

   pbufOut=new CSM_Buffer;

   SME(RawDecrypt(&bufEncryptedKey, pbufOut, cbc_decryption, blocksize));
   if (pbufOut->Length() == 0)
   {
      delete pbufOut;
      pbufOut = NULL;      // FLAG missing or bad.
   }

   /*pbufOut->ConvertMemoryToFile("./decryptedBlob.log");*/

   if (pszPassword)
      free(pszPassword);
   if (pK)
      delete pK;
   if (pRC2Decryption)
       delete pRC2Decryption;
   if (pDESDecryption)
       delete pDESDecryption;
   if (p3DESDecryption)
      delete p3DESDecryption;
   if (cbc_decryption)
       delete cbc_decryption;
   if (pIV && pIV != pK)
       delete pIV;

   SME_FINISH
   SME_CATCH_SETUP
      if (pK)
         delete pK;
      if (pbufEncodedEncryptionParams)
         delete pbufEncodedEncryptionParams;
      if (pRC2Decryption)
         delete pRC2Decryption;
      if (pDESDecryption)
         delete pDESDecryption;
      if (p3DESDecryption)
         delete p3DESDecryption;
      if (pIV && pIV != pK)
          delete pIV;
      if (pbufOut)
         delete pbufOut;
      if (pszPassword)
         free(pszPassword);
   SME_CATCH_FINISH

   return pbufOut;
}       // END CSM_Free3::DecryptPKCS12Blob(...)

//////////////////////////////////////////////////////////////////////////
//  PROCESS the safeBags ONLY, already un-encrypted.
long CSM_Free3::DecryptPKCS12_ProcessBags(CSM_Buffer &bufEncodedBags, 
         const char *pszPassword, CSM_BufferLst &BufPrivList, 
         CSM_BufferLst &BufCertList)
{
   long status=0;
   SafeContents SafeBags;

   SME_SETUP("CSM_Free3::DecryptPKCS12_ProcessBags");
   // ASN.1 decode the private key
   DECODE_BUF(&SafeBags, &bufEncodedBags);
   SafeBag *pTmpSafeBag;
   AsnOid  oidSafeBag_certBag(OIDSafeBag_certBag);
   AsnOid  oidSafeBag_keyBag(OIDSafeBag_keyBag);
   AsnOid  oidSafeBag_pkcs8ShroudedKeyBag(OIDSafeBag_pkcs8ShroudedKeyBag);
   AsnOid  oidSafeBagContent_x509Certificate(OIDSafeBagContent_x509Certificate);
   //AsnOid  oidSafeBag_pkcs7_data("");       // SafeBag pkcs7_data
   SafeBags.SetCurrToFirst();
   for (pTmpSafeBag=SafeBags.Curr(); pTmpSafeBag; pTmpSafeBag=SafeBags.GoNext())
   {
      if (pTmpSafeBag->safeBagType == oidSafeBag_certBag)
      {
          CertCRLBag *pCertBag=NULL;
          CSM_Buffer *pBuf=NULL;
          ENCODE_BUF(&pTmpSafeBag->safeBagContent, pBuf);//RWC;11/15/02;.GetUndecodedAny();
          CSM_Buffer *pBuf2=NULL;
          if (pBuf)
          {
             pCertBag = new CertCRLBag;
             DECODE_BUF(pCertBag, pBuf);
             delete pBuf;
             pBuf = NULL;
          }
          /*else
          {
             pCertBag = new CertCRLBag;
             *pCertBag = *((CertCRLBag *)pTmpSafeBag->safeBagContent.value);
          }    // END if ASN.1 decoded already.*/

          if (pCertBag->bagId == oidSafeBagContent_x509Certificate)
          {
             ENCODE_BUF(&pCertBag->value, pBuf2);//RWC;11/15/02;.GetUndecodedAny();
             Certificate *pSNACCCert=NULL;
             if (pBuf2)
             {
                VDASafeBlob vDASafeBlob;

                //pBuf2->ConvertMemoryToFile("./CertSafeBag.bin");
                DECODE_BUF(&vDASafeBlob, pBuf2);
                delete pBuf2;
                pBuf2 = BufCertList.Append();
                //pBuf2=pCertBag->value.GetUndecodedAny();
                pBuf2->Set(vDASafeBlob.c_str(), vDASafeBlob.Len());
             }
             else    // IF ASN.1 decoded already.
             {
                pBuf2 = BufCertList.Append();
                pSNACCCert = (Certificate *)pTmpSafeBag->safeBagContent.value;
                pBuf2 = BufCertList.Append();
                ENCODE_BUF(pSNACCCert, pBuf2);
             }    // END if ASN.1 decoded already.

          }    // END if X.509 cert.
          else
          {
             SME_THROW(44, "PKCS12 Cert SafeBag not X.509 format!", NULL);
          }

          if (pCertBag)
          {
             delete pCertBag;
          }    // END if pBuf.
      }        // IF cert Bag.
      else if (pTmpSafeBag->safeBagType == oidSafeBag_keyBag)
      {
          CSM_Buffer *pBuf=NULL;
          ENCODE_BUF(&pTmpSafeBag->safeBagContent, pBuf);//RWC;11/15/02;.GetUndecodedAny();
          if (pBuf == NULL)
          {
             pBuf = new CSM_Buffer;
             ENCODE_BUF(&pTmpSafeBag->safeBagContent, pBuf);
          }    // END if ASN.1 decoded already.
          if (pBuf)
          {
             /**pPrivateBuf->ConvertMemoryToFile("./pPrivateKeyBuf.bin");*/
             PrivateKeyInfo snaccX;       //DEBUG
             CSM_Buffer *pBUF2 = BufPrivList.Append();  //Thank you Alan Borland, Protek
             *pBUF2 = *pBuf;                            //Thank you Alan Borland, Protek
             DECODE_BUF(&snaccX, pBUF2);   //DEBUG
             delete pBuf;

          }    // END if pBuf
      }
      else if (pTmpSafeBag->safeBagType == oidSafeBag_pkcs8ShroudedKeyBag)
      {                    //M_PKCS12_decrypt_skey
          CSM_Buffer *pBuf=NULL;
          ENCODE_BUF(&pTmpSafeBag->safeBagContent, pBuf);
          //RWC;DOES NOT WORK;
          //RWC; CSM_Buffer *pPrivateBuf = this->DecryptPrivateKey(pszPassword, pBuf);
          EncryptedPrivateKeyInfo snaccEncryptedX;
          // ASN.1 decode the EncryptedPrivateKeyInfo
          DECODE_BUF(&snaccEncryptedX, pBuf);
          CSM_Buffer bufEncryptedKey(snaccEncryptedX.encryptedData.c_str(),
                  snaccEncryptedX.encryptedData.Len());
          AlgorithmIdentifier DecryptAlgId;
          DecryptAlgId.algorithm = snaccEncryptedX.encryptionAlgorithm->algorithm;
          DecryptAlgId.parameters = snaccEncryptedX.encryptionAlgorithm->parameters;
          CSM_Buffer *pPrivateBuf = DecryptPKCS12Blob(pszPassword, 
                DecryptAlgId, bufEncryptedKey);
          if (DecryptAlgId.parameters)
             DecryptAlgId.parameters = NULL; 
                              //CLEAR, since given away
          if (pPrivateBuf)
          {
#ifdef _DEBUG
             pPrivateBuf->ConvertMemoryToFile("./pPrivateKeyBuf.bin");
#endif
             /*PrivateKeyInfo snaccX;
               DECODE_BUF(&snaccX, pPrivateBuf);*/
             CSM_Buffer *pBUF2 = BufPrivList.Append();
             *pBUF2 = *pPrivateBuf;
             delete pPrivateBuf;
          }
          if (pBuf)
              delete pBuf;
      }
      else
      {
         SME_THROW(44, "PKCS12 SafeBag not supported!", NULL);
      }
   }           // END for each SafeBag.


   SME_FINISH
   SME_CATCH_SETUP
   SME_CATCH_FINISH

   return status;
}        // END CSM_Free3::DecryptPKCS12_ProcessBags(...)


#ifdef OPENSSL_PKCS12_ENABLED

extern "C" {

#ifdef _DEBUG      // ONLY in DEBUG mode to avoid security issues.
// This global exported function is intended for diagnostics only; it
//  will decode a PKCS12 file, and export the private key and certificate
//  in the clear in the same directory as the file, returning the cert and
//  clear private key file names.
SM_FREE3DLL_API int DLLSFLExportClearPKCS12(char *pszPassword,char *pszPFXFile,
        char *&lpszCertFile, char *&lpszClearPrivateKey)
{
    long status=0;
    char *lpszPrivateKeyOut=NULL;
    int lPrivateKeyOutLen;
    char **lppszCertOut=NULL;
    int *lpCertOutLen=NULL;
    int lCertCount=0;
    CSM_Buffer *pCertBufFIRST=NULL;
    CSM_Buffer *pPrivateKey=NULL;
    CSM_Alg *pPublicKeyAlg=NULL;
    char **lppszCRLOutRETURN;
    int *lpCRLOutLenRETURN;
    int lCRLCountRETURN;
    static int count=0;
    int iDOTest=0;

#ifdef _DEBUG
    if (iDOTest)
    {
       CSM_Free3 Free3Inst;
       CSM_PrivDataLst PrivateKeyList;
       CSM_Buffer PFXBuf(pszPFXFile);
       status = Free3Inst.DecryptPKCS12PrivateKey(&PFXBuf, pszPassword, PrivateKeyList);
       //status = Pkcs12_Decode(pszPFXFile, NULL);
       return(status);
    }
#endif //_DEBUG



    // FIRST extract the private key and cert using OPEN-SSL
    status = SM_ExtractPrivateKeyFromPkcs12(pszPFXFile, pszPassword, 
        &lpszPrivateKeyOut, &lPrivateKeyOutLen,
        &lppszCertOut, &lpCertOutLen, &lCertCount,
        &lppszCRLOutRETURN,  // OUT, CRL buffer list (if present)
        &lpCRLOutLenRETURN,    // OUT, individual CRL buffer length(s)
        &lCRLCountRETURN);      // OUT, CRL count.


    if (status == 0 && lCertCount)   // ONLY if we have at lease 1 certificate
    {
            // SECOND, create appropriate data structures for Private key and Cert(s).
            //CSM_MsgCertCrls *pCertPath=new CSM_MsgCertCrls;
            if (lppszCertOut[0] != NULL)
            {
              pCertBufFIRST = new CSM_Buffer(lppszCertOut[0], lpCertOutLen[0]);
              lpszCertFile=strdup(pszPFXFile);
              lpszCertFile[strlen(pszPFXFile)-3] = '\0';
              strcat(lpszCertFile, "cer");
              pCertBufFIRST->ConvertMemoryToFile(lpszCertFile);
              /*for (int ii=1; ii < lCertCount; ii++)
              {
                 pCertBuf = new CSM_Buffer(lppszCertOut[ii], lpCertOutLen[ii]);
                 pCert=new CSM_CertificateChoice(*pCertBuf);
                 delete pCertBuf;
                 pCertPath->AddCert(pCert);    // MEMORY taken by "AddCert"
              }*/
            }
            if (lpszPrivateKeyOut !=  NULL)
            {
              pPrivateKey =new CSM_Buffer(lpszPrivateKeyOut,lPrivateKeyOutLen);
              lpszClearPrivateKey=strdup(pszPFXFile);
              lpszClearPrivateKey[strlen(pszPFXFile)-3] = '\0';
              strcat(lpszClearPrivateKey, "prv");
              pPrivateKey->ConvertMemoryToFile(lpszClearPrivateKey);
            }
    }
       if (lpszPrivateKeyOut)
           free(lpszPrivateKeyOut);
       if (pPrivateKey)
           delete pPrivateKey;
       if (pPublicKeyAlg)
           delete pPublicKeyAlg;

       status = SM_DeletePrivateKeyCerts(lppszCertOut, lpCertOutLen, lCertCount);
       status = SM_DeletePrivateKeyCerts(lppszCRLOutRETURN, lpCRLOutLenRETURN, 
                    lCRLCountRETURN);

       return(status);
}
#endif

//
//
long SFLFree3PKCS12Init(CSM_CtilMgr &Csmime, char *pszINPassword, char *pszPFXFile,
                        CSM_MsgCertCrls *pCertPathIN)
{
    long status=0;
    char lpszID[50];
    char *lpszPrivateKeyOut=NULL;
    int lPrivateKeyOutLen;
    char **lppszCertOut=NULL;
    int *lpCertOutLen=NULL;
    int lCertCount=0;
    CSM_Buffer *pCertBuf=NULL;
    CSM_Buffer *pCertBufFIRST=NULL;
    CSM_Buffer *pPrivateKey=NULL;
    CSM_TokenInterface  *pTokenInterface=NULL;
    CSM_Alg *pPublicKeyAlg=NULL;
    char **lppszCRLOutRETURN;
    int *lpCRLOutLenRETURN;
    int lCRLCountRETURN;
    static int count=0;
    char *pszPassword=NULL;

    SME_SETUP("SFLFree3PKCS12Init");
    // FIRST extract the private key and cert using OPEN-SSL
    status = SM_ExtractPrivateKeyFromPkcs12(pszPFXFile, pszINPassword, 
        &lpszPrivateKeyOut, &lPrivateKeyOutLen,
        &lppszCertOut, &lpCertOutLen, &lCertCount,
        &lppszCRLOutRETURN,  // OUT, CRL buffer list (if present)
        &lpCRLOutLenRETURN,    // OUT, individual CRL buffer length(s)
        &lCRLCountRETURN);      // OUT, CRL count.


    if (strlen(pszINPassword) < 8) // IMPORTANT, change ONLY after PKCS12 
    {                                //   extracted.
        pszPassword = (char *)calloc(1, 9);
        strcpy(pszPassword, pszINPassword);
        memset(&pszPassword[strlen(pszINPassword)], 'X', 
            8 - strlen(pszINPassword)); // STRETCH to at least 8 chars.
    }
    else
    {
        pszPassword = (char *)calloc(1, strlen(pszINPassword)+1);
        strcpy(pszPassword, pszINPassword);
    }

    if (status == 0 && lCertCount)   // ONLY if we have at lease 1 certificate
    {
            // SECOND, create appropriate data structures for Private key and Cert(s).
            CSM_MsgCertCrls *pCertPath=new CSM_MsgCertCrls;
            if (lppszCertOut[0] != NULL)
            {
              pCertBufFIRST = new CSM_Buffer(lppszCertOut[0], lpCertOutLen[0]);
              CSM_CertificateChoice *pCert=new CSM_CertificateChoice(*pCertBufFIRST);
              pPublicKeyAlg = pCert->GetPublicKeyAlg();
              pCertPath->AddCert(pCert);    // MEMORY NO LONGER taken by "AddCert"
              delete pCert;
              for (int ii=1; ii < lCertCount; ii++)
              {
                 pCertBuf = new CSM_Buffer(lppszCertOut[ii], lpCertOutLen[ii]);
                 pCert=new CSM_CertificateChoice(*pCertBuf);
                 delete pCertBuf;
                 pCertPath->AddCert(pCert);    // MEMORY taken by "AddCert"
                 delete pCert;
              }
            }

            // NOW add optional user specified certs, expected to be cert-path.
            CSM_CertificateChoice *pCertChoice;
            if (pCertPathIN && pCertPathIN->AccessCertificates())
            {
              pCertPathIN->AccessCertificates()->SetCurrToFirst();
              for (pCertChoice = pCertPathIN->AccessCertificates()->Curr(); 
                   pCertChoice; 
                   pCertChoice=pCertPathIN->AccessCertificates()->GoNext())
              {
                 pCertPath->AddCert(pCertChoice); // MEMORY NO LONGER taken by "AddCert"
              }            // END for each cert in this private key set.
            }       // END IF pCertPath

            if (lpszPrivateKeyOut !=  NULL)
              pPrivateKey =new CSM_Buffer(lpszPrivateKeyOut,lPrivateKeyOutLen);
            //pPrivateKey->ConvertMemoryToFile("./certs/config.d/PrivatePKCS12.bin");
                            //DEBUG send to file...
       // THIRD, we must re-wrap this clear private key in a format compatible with
       // the CTIL (a fudge, since we should directly interpret the PKCS12, but time
       // time presses on).
       // (NOTE::: IGNORE the CSM_CryptoKeysDSA class definition below, we simply 
       //  use the inherited component "CSM_CryptoKeysFree3Base" to wrap any clear
       //  Private key, including RSA.  We never defined an RSA class for Free3, 
       //  maybe later).
       CSM_CryptoKeysDsaExport /*CSM_CryptoKeysFree3Base*/ A;
       CSM_Buffer *pPrivateKeyWrapped = NULL;
       if (pPrivateKey)
       {
           // SIMPLY wrap this clear Key.
           pPrivateKeyWrapped  = A.WrapPrivateKey(*pPrivateKey, pszPassword, 
               pPublicKeyAlg );
       }

       // FINALLY, create login entry for this private key and cert.
       if (pCertBufFIRST) // && pPrivateKeyWrapped)
       {
           count++;
           sprintf(&lpszID[0], "PKCS12%d", count);
           pTokenInterface  = CSM_Free3::AddLoginStatic(NULL, *pCertBufFIRST,
                pPrivateKeyWrapped, pszPassword, lpszID, pCertPath);
           delete pCertBufFIRST;    // DELETE User cert.
       }

       if (lpszPrivateKeyOut)
           free(lpszPrivateKeyOut);
       if (pPrivateKeyWrapped)
           delete pPrivateKeyWrapped;
       if (pPrivateKey)
           delete pPrivateKey;
       if (pPublicKeyAlg)
           delete pPublicKeyAlg;
       if (pszPassword)
           free(pszPassword);

       // DO NOT FREE pCertPath, it is taken by AddLoginStatic(...)
       GLOBALAddLoginFinish(Csmime, pTokenInterface, lpszID, pCertPath);

       status = SM_DeletePrivateKeyCerts(lppszCertOut, lpCertOutLen, lCertCount);
       status = SM_DeletePrivateKeyCerts(lppszCRLOutRETURN, lpCRLOutLenRETURN, 
                    lCRLCountRETURN);
    }          // END if lCertCount
    else
    {
       char buf[1000];
       if (status != 0)
       {
         sprintf(buf, "Bad PKCS12 Decode/Decrypt, file=%s.", pszPFXFile);
         SME_THROW(29, buf, NULL);
       }
       else    // Certificate count in PKCS12 was 0
       {
         sprintf(buf, "Certificate count in PKCS12 was 0, file=%s.", pszPFXFile);
         SME_THROW(30, buf, NULL);
       }
    }

    SME_FINISH
    SME_CATCH_SETUP
       if (lpszPrivateKeyOut)
           free(lpszPrivateKeyOut);
       if (pPrivateKey)
           delete pPrivateKey;
       if (pPublicKeyAlg)
           delete pPublicKeyAlg;
       if (pszPassword)
           free(pszPassword);
       SM_DeletePrivateKeyCerts(lppszCertOut, lpCertOutLen, lCertCount);
       SM_DeletePrivateKeyCerts(lppszCRLOutRETURN, lpCRLOutLenRETURN, 
                    lCRLCountRETURN);
    SME_CATCH_FINISH


    return(status);
}

// THIS function is called by an application to create a PKCS12 file given
//  a private key file, certificate file, and a password.
//  RWC;3/27/01; THIS function MUST be updated to accommodate certifcate(s)
//  for the path, AND extract DSA Params (p, q, g) from an issuer if necessary.
SM_FREE3DLL_API int DLLSFLCreatePKCS12(char *lpszCertFile, 
    char *lpszClearPrivateKey, char *pszPassword, char *pszPFXFile) 
{
    long status=0;
    CSM_Buffer *pP=NULL, *pQ=NULL, *pG=NULL;
    CSM_CryptoKeysDsa *pCryptoDSA = NULL;
    CSM_CryptoKeysF3Rsa *pCryptoF3RSA = NULL;
    SME_SETUP("CCertWindowDlg::CreatePkcs12PrivateKey()");
    CSM_Buffer BufCertFile(lpszCertFile);
    CSM_CertificateChoice A(BufCertFile);
    CSM_Alg *pAlg=A.GetPublicKeyAlg();
    CSM_Buffer *pPublicKey=A.GetPublicKey();
    char *pPubKeyFilename = "pkcs12certpubkey.out";



	// sib
	// see if we have a decodable privateKeyInfo object and if so then just get the 
	// integer of the private key and save to the private key file
	// This was done to have a correct private key file for example-07 testing
	int status = -1;
    PrivateKeyInfo snaccPKI;
    CSM_Buffer *pbufFileIn=new CSM_Buffer(lpszClearPrivateKey);
	DECODE_BUF_NOFAIL(&snaccPKI, pbufFileIn, status);
    if (!status)
	{
		CSM_Buffer bufFileOut(snaccPKI.privateKey.c_str(),
			                  snaccPKI.privateKey.Len());
		bufFileOut.ConvertMemoryToFile(lpszClearPrivateKey);
	}
    delete pbufFileIn;


    if (pPublicKey)
    {
    pPublicKey->ConvertMemoryToFile(pPubKeyFilename);
    
    if (*pAlg->AccessSNACCId() == id_dsa || 
        *pAlg->AccessSNACCId() == id_dsa_with_sha1)
    {
         pCryptoDSA = SM_BuildCryptoKeysDSA(NULL, pszPassword);
          // call will write the EncryptedPrivateKeyInfo to output file pencPrvKeyFilename
         if(pP == NULL && pQ == NULL && pG == NULL)
         {     // ONLY if still blank, not on display; extract from issuer.
             //CSM_MsgCertCrls B;
            CSM_Buffer *pParams=pAlg->GetParams();
            if (pParams)
                pCryptoDSA->ExtractDSAParams(*pParams, pP, pQ, pG);
         }
         if(pP == NULL)
         {
             SME_THROW(25, "MUST HAVE DSA PARAMS TO BUILD PKCS12 PACKET, not in cert",
                 NULL);
         }
         CSM_Buffer *pPKCS12Buf=pCryptoDSA->WrapPkcs12(lpszClearPrivateKey, 
           pPubKeyFilename, lpszCertFile, pszPassword, *pP, 
           *pQ, *pG, pszPFXFile);
         delete pPKCS12Buf;  // RESULT already stored in optional "pencPrvKeyFilename".

    }
    else if (*pAlg->AccessSNACCId() == rsa ||
             *pAlg->AccessSNACCId() == rsaEncryption ||
             *pAlg->AccessSNACCId() == sha_1WithRSAEncryption ||
             *pAlg->AccessSNACCId() == sha_1WithRSAEncryption_ALT ||
             *pAlg->AccessSNACCId() == md5WithRSAEncryption ||
             *pAlg->AccessSNACCId() == AsnOid("1.2.840.113549.1.2"))
    {
         CSM_Buffer bufRawPKI;
         CSM_Buffer bufPKIPrivateKey(lpszClearPrivateKey);
         PrivateKeyInfo snaccPKI;
         char *pBufRawPKIFile = NULL;
         pCryptoF3RSA = SM_BuildCryptoKeysF3Rsa(NULL, pszPassword);
         DECODE_BUF_NOFAIL((&snaccPKI), &bufPKIPrivateKey, status);
         if (status == 0)       // Then this message is PrivateKeyInfo 
         {                      //  WE MUST UNWRAP BEFORE calling PKCS12
           char *ptr=(char *)calloc(1, strlen(lpszClearPrivateKey)+5);
           strcpy(ptr, lpszClearPrivateKey);
           strcat(ptr, "RAW");
           bufRawPKI.Set(snaccPKI.privateKey.c_str(), 
                         snaccPKI.privateKey.Len());
           bufRawPKI.ConvertMemoryToFile (ptr);
           pBufRawPKIFile = ptr;
         }  
         else  // ELSE ignore it, the format is already correct.
             pBufRawPKIFile = strdup(lpszClearPrivateKey);
         CSM_Buffer *pPKCS12Buf=pCryptoF3RSA->WrapPkcs12(pBufRawPKIFile, 
            lpszCertFile, pszPassword, pszPFXFile);
         if (pPKCS12Buf)
           delete pPKCS12Buf;  // RESULT already stored in optional "pencPrvKeyFilename".
         if (pBufRawPKIFile)
             free(pBufRawPKIFile);
    }

    }   // end if public key present.

   SME_FINISH
   SME_CATCH_SETUP
 
   SME_CATCH_FINISH
   return(status);
}

}     // END extern "C"

#endif      // OPENSSL_PKCS12_ENABLED

extern "C" {
//
//
long SFLFree3PKCS12Init2(CSM_CtilMgr &Csmime, char *pszINPassword, 
                         char *pszPFXFile, CSM_MsgCertCrls *pCertPathIN)
{
    long status=0;
    CSM_Buffer *pCertBuf=NULL;
    CSM_Buffer *pCertBufFIRST=NULL;
    CSM_Buffer *pPrivateKey=NULL;
    CSM_TokenInterface  *pTokenInterface=NULL;
    CSM_Alg *pPublicKeyAlg=NULL;
    char *pszPassword=NULL;
    CSM_PrivDataLst PrivateKeyList;
    char lpszID[50];
    static int count=0;
    CSM_Buffer PFXBuf(pszPFXFile);
    char *lpszPrivateKeyOut=NULL;
    /*
    int lPrivateKeyOutLen;
    char **lppszCertOut=NULL;
    int *lpCertOutLen=NULL;
    int lCertCount=0;
    char **lppszCRLOutRETURN;
    int *lpCRLOutLenRETURN;
    int lCRLCountRETURN;
    */
    SME_SETUP("SFLFree3PKCS12Init2");

    PFXBuf.ConvertFileToMemory();      // CHECK that the file exists first.

    // FIRST extract the private key and cert using Crypto++; use password as 
    //  specified, then change for our internal PKCS8.
    status = CSM_Free3::DecryptPKCS12PrivateKey(&PFXBuf, pszINPassword, PrivateKeyList);
#ifdef _DEBUG
    if (status)
    {
            std::cout << "ERROR in CSM_Free3::DecryptPKCS12PrivateKey, status=" <<  status 
            << " FILE=" << pszPFXFile << std::endl;
        if (status == -100) 
            status = 0;     // IGNORE if just the MAC address check, for testing DEBUG ONLY!
    }       // END if status
#endif

    if (strlen(pszINPassword) < 8) // IMPORTANT, change ONLY after PKCS12 
    {                                //   extracted.
        pszPassword = (char *)calloc(1, 9);
        strcpy(pszPassword, pszINPassword);
        memset(&pszPassword[strlen(pszINPassword)], 'X', 
            8 - strlen(pszINPassword)); // STRETCH to at least 8 chars.
    }
    else
    {
        pszPassword = (char *)calloc(1, strlen(pszINPassword)+1);
        strcpy(pszPassword, pszINPassword);
    }

    if (status == 0 && PrivateKeyList.Count())   // ONLY if we have at lease 1 certificate
    {
       CSM_PrivData *ptmpPrivateKeySet;
       PrivateKeyList.SetCurrToFirst();
       for (ptmpPrivateKeySet=PrivateKeyList.Curr(); ptmpPrivateKeySet;
            ptmpPrivateKeySet = PrivateKeyList.GoNext())
       {
            // SECOND, create appropriate data structures for Private key 
            //  and Cert(s).
            CSM_MsgCertCrls *pCertPath=new CSM_MsgCertCrls;
            if (ptmpPrivateKeySet->m_BufCertList.Count() != NULL)
            {
              ptmpPrivateKeySet->m_BufCertList.SetCurrToFirst();
              pCertBufFIRST = new CSM_Buffer(
                              *ptmpPrivateKeySet->m_BufCertList.Curr());
              CSM_CertificateChoice *pCert=new CSM_CertificateChoice(
                              *pCertBufFIRST);
              pPublicKeyAlg = pCert->GetPublicKeyAlg();
              pCertPath->AddCert(pCert);  // MEMORY NO LONGER taken by "AddCert"
                                          //  DUPLICATES auto-removed.
              delete pCert;
              pCertBuf=ptmpPrivateKeySet->m_BufCertList.GoNext();
              for (; pCertBuf; pCertBuf=ptmpPrivateKeySet->m_BufCertList.GoNext())
              {
                 pCert = new CSM_CertificateChoice(*pCertBuf);
                 pCertPath->AddCert(pCert);    // MEMORY NO LONGER taken by "AddCert"
                 delete pCert;
              }            // END for each cert in this private key set.
            }              // END if cert buffer(s) in PKCS12 decrypt

            // NOW add optional user specified certs, expected to be cert-path.
            CSM_CertificateChoice *pCertChoice;
            if (pCertPathIN && pCertPathIN->AccessCertificates())
            {
              pCertPathIN->AccessCertificates()->SetCurrToFirst();
              for (pCertChoice = pCertPathIN->AccessCertificates()->Curr(); 
                   pCertChoice; 
                   pCertChoice=pCertPathIN->AccessCertificates()->GoNext())
              {
                 pCertPath->AddCert(pCertChoice); // MEMORY NO LONGER taken by "AddCert"
              }            // END for each cert in this private key set.
            }       // END IF pCertPath

          // THIRD, we must re-wrap this clear private key in a format compatible with
          // the CTIL (a fudge, since we should directly interpret the PKCS12, but time
          // time presses on).
          // (NOTE::: IGNORE the CSM_CryptoKeysDSA class definition below, we simply 
          //  use the inherited component "CSM_CryptoKeysFree3Base" to wrap any clear
          //  Private key, including RSA.  We never defined an RSA class for Free3, 
          //  maybe later).
          if (ptmpPrivateKeySet->m_BufPriv.Length() !=  NULL)
            pPrivateKey = new CSM_Buffer(ptmpPrivateKeySet->m_BufPriv);
          //pPrivateKey->ConvertMemoryToFile("./certs/config.d/PrivatePKCS12.bin");
                                //DEBUG send to file...
          CSM_CryptoKeysDsaExport /*CSM_CryptoKeysFree3Base*/ A;
          CSM_Buffer *pPrivateKeyWrapped = NULL;
          if (pPrivateKey)
          {
             if (pPublicKeyAlg->algorithm == id_dsa)
             {             //RWC;remove wrapper, get just the key.
                PrivateKeyInfo SNACCPrivateKey;
                DECODE_BUF(&SNACCPrivateKey, pPrivateKey);
                delete pPrivateKey;
                pPrivateKey = new CSM_Buffer(
                   SNACCPrivateKey.privateKey.c_str(), 
                   SNACCPrivateKey.privateKey.Len());
             }
              // SIMPLY wrap this clear Key.
              pPrivateKeyWrapped  = A.WrapPrivateKey(*pPrivateKey, pszPassword, 
                  pPublicKeyAlg );
          }

          // FINALLY, create login entry for this private key and cert.
          if (pCertBufFIRST) // && pPrivateKeyWrapped)
          {
              count++;
              sprintf(&lpszID[0], "PKCS12%d", count);
              pTokenInterface  = CSM_Free3::AddLoginStatic(NULL, *pCertBufFIRST,
                   pPrivateKeyWrapped, pszPassword, lpszID, pCertPath);
              delete pCertBufFIRST;    // DELETE User cert.
             // DO NOT FREE pCertPath, it is taken by AddLoginStatic(...)
             GLOBALAddLoginFinish(Csmime, pTokenInterface, lpszID, pCertPath);
          }

          if (pPrivateKeyWrapped)
              delete pPrivateKeyWrapped;
          pPrivateKeyWrapped = NULL;
          if (pPrivateKey)
              delete pPrivateKey;
          pPrivateKey = NULL;
          if (pPublicKeyAlg)
              delete pPublicKeyAlg;
          pPublicKeyAlg = NULL;

       }       // END for PrivateKeyList items.


       if (pszPassword)
           free(pszPassword);

    }          // IF PrivateKeyList.CountL()
    else
    {
       char buf[1000];
       if (status != 0)
       {
         sprintf(buf, "Bad PKCS12 Decode/Decrypt, file=%s.", pszPFXFile);
         SME_THROW(29, buf, NULL);
       }
       else    // Certificate count in PKCS12 was 0
       {
         sprintf(buf, "Certificate count in PKCS12 was 0, file=%s.", pszPFXFile);
         SME_THROW(status, buf, NULL);
       }
    }       // END if PrivateKeyList.CountL()

    SME_FINISH
    catch (FileException &fe)     // CATCH special exception.
    {
       if (lpszPrivateKeyOut)
           free(lpszPrivateKeyOut);
       if (pPrivateKey)
           delete pPrivateKey;
       if (pPublicKeyAlg)
           delete pPublicKeyAlg;
       if (pszPassword)
           free(pszPassword);

#ifdef WIN32
       fe;      // REMOVES compiler warning.
#endif //WIN32
       char buf[1000];
       sprintf(buf, "Missing PKCS12, file=%s.", pszPFXFile);
       SME_THROW(29, buf, NULL);
    }        // END catch (FileException &)
    SME_CATCH_SETUP
       if (lpszPrivateKeyOut)
           free(lpszPrivateKeyOut);
       if (pPrivateKey)
           delete pPrivateKey;
       if (pPublicKeyAlg)
           delete pPublicKeyAlg;
       if (pszPassword)
           free(pszPassword);
      Exception.push(STACK_ENTRY);
      throw;
    }
   //SFL_CATCH_FINISH2
#ifndef _DEBUG
   catch (...) 
   {
       if (lpszPrivateKeyOut)
           free(lpszPrivateKeyOut);
       if (pPrivateKey)
           delete pPrivateKey;
       if (pPublicKeyAlg)
           delete pPublicKeyAlg;
       if (pszPassword)
           free(pszPassword);
      SME_THROW(33, "Unexpected exception thrown!", NULL);
   }
   //SFL_CATCH_FINISH_END
#endif      //_DEBUG



    return(status);
}        // END SFLFree3PKCS12Init2(...)


//##################################################################################
//  Factory definitions for creating private keys: DSA, ECDSA, DH, RSA.
SM_FREE3DLL_API CSM_CryptoKeysDsa * SM_BuildCryptoKeysDSA(CSM_CertificateChoice *pCert, 
    char *lpszPassword)
{
   CSM_CryptoKeysDsa *pDSA_CK;
   if(pCert == NULL)
   {
      pDSA_CK= new CSM_CryptoKeysDsaExport();
      pDSA_CK->SetPassword(lpszPassword);
   }
   else
      pDSA_CK= new CSM_CryptoKeysDsaExport(pCert, lpszPassword);

   return(pDSA_CK);
}

#ifdef CRYPTOPP_5_0
//
//
SM_FREE3DLL_API CSM_CryptoKeysECDsa * SM_BuildCryptoKeysECDsa(CSM_CertificateChoice *pCert, 
    char *lpszPassword)
{
   CSM_CryptoKeysECDsa *pECDSA_CK;
   if(pCert == NULL)
   {
      pECDSA_CK= new CSM_CryptoKeysECDsaExport();
      pECDSA_CK->SetPassword(lpszPassword);
   }
   else
      pECDSA_CK= new CSM_CryptoKeysECDsaExport(pCert, lpszPassword);

   return(pECDSA_CK);
}       // END SM_BuildCryptoKeysECDsa(...)

//
//
SM_FREE3DLL_API CSM_CryptoKeysECDH * SM_BuildCryptoKeysECDH(char *lpszPassword)
{
   CSM_CryptoKeysECDH *pECDH_CK= new CSM_CryptoKeysECDHExport();
   pECDH_CK->SetPassword(lpszPassword);

   return(pECDH_CK);
}       // END SM_BuildCryptoKeysECDH(...)

#endif //CRYPTOPP_5_0

SM_FREE3DLL_API CSM_CryptoKeysDH * SM_BuildCryptoKeysDH(CSM_CertificateChoice *pCert, 
    char *lpszPassword)
{
   CSM_CryptoKeysDH *pDH_CK;
   if(pCert == NULL)
   {
      pDH_CK= new CSM_CryptoKeysDHExport();
      pDH_CK->SetPassword(lpszPassword);
   }
   else
      pDH_CK= new CSM_CryptoKeysDHExport(pCert, lpszPassword);

   return(pDH_CK);
}

SM_FREE3DLL_API CSM_CryptoKeysF3Rsa *SM_BuildCryptoKeysF3Rsa(CSM_CertificateChoice *pCert, 
    char *lpszPassword)
{
   CSM_CryptoKeysF3Rsa *pRsa_CK;
   if(pCert == NULL)
   {
      pRsa_CK = new CSM_CryptoKeysF3RsaExport;
      pRsa_CK->SetPassword(lpszPassword);
   }
   else
      pRsa_CK = new CSM_CryptoKeysF3RsaExport(pCert, lpszPassword);

   return(pRsa_CK);
}
//##################################################################################

}       // END extern "C"


//RWC;DEBUG OF HMAC ONLY;#define TEST_HMAC
#ifdef TEST_HMAC
//////////////////////////////////////////////////////////////////////////
void TestHmac()
{
    CSM_Buffer *pBuf;
    /*************************************************************************
     FROM RFC2104
      key =         0x0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b
      key_len =     16 bytes
      data =        "Hi There"
      data_len =    8  bytes
      digest =      0x9294727a3638bb1c13f48ef8158bfc9d
    */
    char ptrKey1[]={(char)0x0b, (char)0x0b, (char)0x0b, (char)0x0b, (char)0x0b, 
                   (char)0x0b, (char)0x0b, (char)0x0b, (char)0x0b, (char)0x0b, 
                   (char)0x0b, (char)0x0b, (char)0x0b, (char)0x0b, (char)0x0b, 
                   (char)0x0b};
    CSM_Buffer BufKey1(ptrKey1, sizeof(ptrKey1));
    CSM_Buffer Data1("Hi There", strlen("Hi There"));
    unsigned char ptrExpected1[]={(unsigned char)0x92, (unsigned char)0x94, (unsigned char)0x72, (unsigned char)0x7a, 
                        (unsigned char)0x36, (unsigned char)0x38, (unsigned char)0xbb, (unsigned char)0x1c, 
                        (unsigned char)0x13, (unsigned char)0xf4, (unsigned char)0x8e, (unsigned char)0xf8, 
                        (unsigned char)0x15, (unsigned char)0x8b, (unsigned char)0xfc, (unsigned char)0x9d};
    CSM_Buffer BufExpected1((const char *)ptrExpected1, sizeof(ptrExpected1));
    pBuf = CSM_Free3::ComputePkcs12MACHash(md5, BufKey1, Data1);
    if (pBuf)
    {
        if (*pBuf == BufExpected1)
            std::cout << "EncryptPKCS12Blob: 1st SUCCESSFUL!" << std::endl;
        else
            std::cout << "EncryptPKCS12Blob: 1st UNSUCCESSFUL!" << std::endl;
        delete pBuf;
    }       // END IF pBuf


    /*************************************************************************
      key =         "Jefe"
      data =        "what do ya want for nothing?"
      data_len =    28 bytes
      digest =      0x750c783e6ab0b503eaa86e310a5db738
    */
    char ptrKey2[]="Jefe";
    CSM_Buffer BufKey2(ptrKey2, strlen(ptrKey2));
    CSM_Buffer Data2("what do ya want for nothing?", strlen("what do ya want for nothing?"));
    unsigned char ptrExpected2[]={(unsigned char)0x75, (unsigned char)0x0c, 
        (unsigned char)0x78, (unsigned char)0x3e, (unsigned char)0x6a, 
        (unsigned char)0xb0, (unsigned char)0xb5, (unsigned char)0x03, 
        (unsigned char)0xea, (unsigned char)0xa8, (unsigned char)0x6e, 
        (unsigned char)0x31, (unsigned char)0x0a, (unsigned char)0x5d, 
        (unsigned char)0xb7, (unsigned char)0x38 };
    CSM_Buffer BufExpected2((const char *)ptrExpected2, sizeof(ptrExpected2));
    pBuf = CSM_Free3::ComputePkcs12MACHash(md5, BufKey2, Data2);
    if (pBuf)
    {
        if (*pBuf == BufExpected2)
            std::cout << "EncryptPKCS12Blob: 2nd SUCCESSFUL!" << std::endl;
        else
            std::cout << "EncryptPKCS12Blob: 2nd UNSUCCESSFUL!" << std::endl;
        delete pBuf;
    }       // END IF pBuf


    /*************************************************************************
      key =         0xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
      key_len       16 bytes
      data =        0xDDDDDDDDDDDDDDDDDDDD...
                    ..DDDDDDDDDDDDDDDDDDDD...
                    ..DDDDDDDDDDDDDDDDDDDD...
                    ..DDDDDDDDDDDDDDDDDDDD...
                    ..DDDDDDDDDDDDDDDDDDDD
      data_len =    50 bytes
      digest =      0x56be34521d144c88dbb8c733f0e8b3f6
      */
    CSM_Buffer BufKey3((size_t)16);
    char *ptrKey3=(char *)BufKey3.Access();
    for (int iiii=0; iiii < 16; iiii++) ptrKey3[iiii] = (char)(unsigned char)0xaa;
    CSM_Buffer Data3((size_t)50);
    char *ptrData3=(char *)Data3.Access();
    for (int iii=0; iii < 50; iii++) ptrData3[iii] = (char)(unsigned char)0xDD;
    unsigned char ptrExpected3[]={(unsigned char)0x56, (unsigned char)0xbe, 
        (unsigned char)0x34, (unsigned char)0x52, (unsigned char)0x1d, 
        (unsigned char)0x14, (unsigned char)0x4c, (unsigned char)0x88, 
        (unsigned char)0xdb, (unsigned char)0xb8, (unsigned char)0xc7, 
        (unsigned char)0x33, (unsigned char)0xf0, (unsigned char)0xe8, 
        (unsigned char)0xb3, (unsigned char)0xf6 };
    CSM_Buffer BufExpected3((const char *)ptrExpected3, sizeof(ptrExpected3));
    pBuf = CSM_Free3::ComputePkcs12MACHash(md5, BufKey3, Data3);
    if (pBuf)
    {
        if (*pBuf == BufExpected3)
            std::cout << "EncryptPKCS12Blob: 3rd SUCCESSFUL!" << std::endl;
        else
            std::cout << "EncryptPKCS12Blob: 3rd UNSUCCESSFUL!" << std::endl;
        delete pBuf;
    }       // END IF pBuf


}           // END TestHmac(...)
#endif //TEST_HMAC

//////////////////////////////////////////////////////////////////////////
//
// RWC; WORK IN PROGRESS...
/* RWC;NOTES for our general PKCS12 files:
   for (pSNACCCSafeBag=SeqContentInfos.Curr(); pSNACCCSafeBag; 
        pSNACCCSafeBag=SeqContentInfos.GoNext())
   1st packet, blob is 
            if (pSNACCCSafeBag->safeBagType == id_encryptedData)
         THEN, within this blob, decrypted
            if (pencryptedData &&
                pencryptedData->encryptedContentInfo->contentType == id_data)
                WHICH contains a cert, extracted in DecryptPKCS12Cert() 
                calls DecryptPKCS12_ProcessBags(), decoding SafeBag
                if (pTmpSafeBag->safeBagType == oidSafeBag_certBag)
                   CertCRLBag, if (pCertBag->bagId == oidSafeBagContent_x509Certificate)
    2nd packet is
         else if (pSNACCCSafeBag->safeBagType == id_data)
               lStatus = DecryptPKCS12_ProcessBags(*pDataBuf, pszPassword, 
                                                  BufPrivList, BufCertList);
               WHICH contains a single private key, decoding SafeBag
               else if (pTmpSafeBag->safeBagType == oidSafeBag_pkcs8ShroudedKeyBag)

 */
long CSM_Free3::EncryptPKCS12PrivateKey(
         CSM_Buffer *&pEncryptedPrivateKeyInfo, // OUT
         const char *pszPassword,               // IN
         CSM_PrivDataLst &PrivateKeyList)       // IN
{
    EncryptedData *pencryptedData=NULL;
    AsnOcts SNACCOcts;
    CSM_Buffer *pBuf=NULL;
    PFX Pfx;
    //EncryptedData *pencryptedData=NULL;
    CSM_Buffer *pencryptedPrivDataBuf=NULL;
    SafeContents SeqContentInfos;  // Actually not SafeContents, but
                                    //   convenient definition.
    CSM_Buffer *pPKCS12Buf=NULL;
    CSM_Buffer *pPkcs12MAC=NULL;
    long lStatus=-1;       // Default failure.


   SME_SETUP("CSM_Free3::EncryptPKCS12PrivateKey");

#ifdef TEST_HMAC
   CSM_PrivDataLst PrivList;
   CSM_Buffer EncryptedPrivateKeyInfo("./bobX_12_OPENSSL.pfx");
   DecryptPKCS12PrivateKey(&EncryptedPrivateKeyInfo, "password", PrivList);
   TestHmac();
#endif // TEST_HMAC

   if (pszPassword == NULL)
      SME_THROW(SM_MISSING_PARAM, "MISSING PARAMS", NULL);

   if (pEncryptedPrivateKeyInfo == NULL)
       pEncryptedPrivateKeyInfo = new CSM_Buffer;

   // NEXT, load all certificates into a safe bag of the PKCS12.
   SafeBag *pSNACCCSafeBag;
   CSM_Buffer *pSNACCCSafeBagBuf=NULL;
   pSNACCCSafeBag = SeqContentInfos.Append();
   pSNACCCSafeBag->safeBagType = id_encryptedData;
   CSM_Buffer *pencryptedDataBuf = EncryptPKCS12CreateCertSafeBag(
                    PrivateKeyList, pszPassword, pencryptedPrivDataBuf);
            // EncryptedPKCS12CreateCertSafeBag(...) MUST create the private 
            //  key element as well due to the need for both IDs to match...
            //  It returns "pencryptedDataBuf".
   pencryptedData = new EncryptedData;
   pencryptedData->encryptedContentInfo = new EncryptedContentInfo;
   /*pencryptedData->encryptedContentInfo->contentType = id_data;*/
   DECODE_BUF(pencryptedData->encryptedContentInfo, pencryptedDataBuf);
   ENCODE_BUF(pencryptedData, pSNACCCSafeBagBuf);
   DECODE_BUF(&pSNACCCSafeBag->safeBagContent, pSNACCCSafeBagBuf);
   delete pSNACCCSafeBagBuf;
   pSNACCCSafeBagBuf = NULL;
   delete pencryptedData;
   delete pencryptedDataBuf;

   // NEXT, load all of the private keys into a protected safe bag of the PCKS12
   pSNACCCSafeBag = SeqContentInfos.Append();
   pSNACCCSafeBag->safeBagType = id_data;
   //pencryptedDataBuf = EncryptPKCS12CreatePrivSafeBag(BufPrivList, 
   //                                 pszPassword);
   if (pencryptedPrivDataBuf)
   {
       SNACCOcts.Set(pencryptedPrivDataBuf->Access(), pencryptedPrivDataBuf->Length());
       ENCODE_BUF(&SNACCOcts, pBuf);
       DECODE_BUF(&pSNACCCSafeBag->safeBagContent, pBuf);
       delete pencryptedPrivDataBuf;
   }        // IF pencryptedDataBuf
   else
   {
       SME_THROW(29, "BAD EncryptPKCS12CreatePrivSafeBag call.", NULL);
   }        // END IF pencryptedDataBuf
   delete pBuf;
   pBuf = NULL;
   delete pSNACCCSafeBagBuf;

   // NEXT, encode the PKCS12 data for MAC computation.
   ENCODE_BUF(&SeqContentInfos, pPKCS12Buf);

   // FINALLY, encode the PKCS12 data element.
   Pfx.authSafe = new ContentInfo;
   Pfx.authSafe->contentType = id_data;
   Pfx.version = 3; //RWC; for compatibility with OpenSSL.
   Pfx.macData = new MacData;
   /*DigestInfo ::= SEQUENCE {
      digestAlgorithm DigestAlgorithmIdentifier,
      digest          Digest
        }*/
   CSM_Buffer bufSalt;
   pPkcs12MAC = ComputePkcs12MAC(bufSalt, sha_1, pszPassword, *pPKCS12Buf);
   if (pPkcs12MAC)
   {
       Pfx.macData->macSalt.Set(bufSalt.Access(), bufSalt.Length());
       Pfx.macData->safeMac = new DigestInfo;
       Pfx.macData->safeMac->digestAlgorithm = new AlgorithmIdentifier;
       Pfx.macData->safeMac->digestAlgorithm->algorithm = sha_1; //DigestInfo
       CSM_Alg::LoadNullParams(Pfx.macData->safeMac->digestAlgorithm);
       //Pfx.macData->macIterationCount = 1;   // DEFAULT to 1, MUST BE MISSING for integration.
       Pfx.macData->safeMac->digest.Set(pPkcs12MAC->Access(), pPkcs12MAC->Length());
       delete pPkcs12MAC; pPkcs12MAC = NULL;

       SNACCOcts.Set(pPKCS12Buf->Access(), pPKCS12Buf->Length());
       delete pPKCS12Buf; pPKCS12Buf = NULL;
       ENCODE_BUF(&SNACCOcts, pBuf);
       DECODE_BUF(&Pfx.authSafe->content, pBuf);
       delete pBuf; pBuf = NULL;
       ENCODE_BUF(&Pfx, pEncryptedPrivateKeyInfo);
   }        // END IF ComputePkcs12MAC(...)

   SME_FINISH
   SME_CATCH_SETUP
    if (pPkcs12MAC)
        delete pPkcs12MAC;
   SME_CATCH_FINISH

   return lStatus;
}     // END CSM_Free3::EncryptPKCS12PrivateKey(...)

//////////////////////////////////////////////////////////////////////////
//
CSM_Buffer *CSM_Free3::EncryptPKCS12CreateCertSafeBag(
    const CSM_PrivDataLst &PrivateKeyList, // IN, cert(s)/private Key list
    const char *pszPasswordIN,    // IN, 
    CSM_Buffer *&pencryptedPrivDataBuf)  // OUT, for private keys, encrypted 
                                  //  at the same time as the certificate 
                                  //  SafeBag(s).
{
    const CSM_Buffer *pBufCert;
    const CSM_PrivData *pPrivData;
    CSM_Buffer *pBufCert2=NULL;
    CSM_Buffer bufEncodedBags;
    VDASafeBlob vDASafeBlob;
    CSM_Buffer *pTmpBuf;
    CSM_Buffer *pbufEncryptedKey;
    AsnOid  oidSafeBag_certBag(OIDSafeBag_certBag);
    AsnOid  oidSafeBagContent_x509Certificate(OIDSafeBagContent_x509Certificate);
    SafeBag *pTmpSafeBag=NULL;
    SafeContents SafeBags;
    SafeContents SafeBagsPriv;
    CertCRLBag *pCertBag;
    EncryptedContentInfo snaccEncryptedCI;
    CSM_Buffer *pEncryptedCert=NULL;
    SNACC::Attribute *pSNACCAttribute;
    SNACC::AsnAny *pTmpAny;
    BMPString TmpBmpString;
    char *pCharBmpString="My Certificate";
    SNACC::AsnOcts TmpOctString;
    CSM_Buffer TmpBuf, TmpDigest;

    SME_SETUP("CSM_Free3::EncryptPKCS12CreateCertSafeBag");

    if (pszPasswordIN == NULL)
       SME_THROW(SM_MISSING_PARAM, "MISSING PARAMS", NULL);

    PrivateKeyList.SetCurrToFirst();
    for (pPrivData = PrivateKeyList.Curr(); pPrivData; pPrivData = PrivateKeyList.GoNext())
    {
        pTmpSafeBag = NULL;
        for (pBufCert=pPrivData->m_BufCertList.Curr(); 
             pBufCert; 
             pBufCert=pPrivData->m_BufCertList.GoNext())
        {
            pTmpSafeBag = SafeBags.Append();
            pTmpSafeBag->safeBagType = oidSafeBag_certBag;
            pCertBag = new CertCRLBag;
            pBufCert2 = NULL;
            pCertBag->bagId = oidSafeBagContent_x509Certificate;
            vDASafeBlob.Set(pBufCert->Access(), pBufCert->Length());
            ENCODE_BUF(&vDASafeBlob, pBufCert2);
            if (pBufCert2)
            {
               DECODE_BUF(&pCertBag->value, pBufCert2);
                delete pBufCert2;
            }
            pTmpBuf = NULL;
            ENCODE_BUF(pCertBag, pTmpBuf);
            if (pTmpBuf)
            {
                DECODE_BUF(&pTmpSafeBag->safeBagContent, pTmpBuf);//RWC;11/15/02;.GetUndecodedAny();
                delete pTmpBuf;
            }   // END IF pTmpBuf

            //********************************************
            // LOAD attributes, including unique ID for this Cert.
            //   (that seem to be expected by MS Outlook)
            pTmpSafeBag->safeBagAttributes = new Attributes;
            pSNACCAttribute = pTmpSafeBag->safeBagAttributes->Append();
            pSNACCAttribute->type = pkcs_9_at_friendlyName;
            pTmpAny = pSNACCAttribute->values.Append();
            TmpBmpString.set(pCharBmpString);
            TmpBuf.Encode(TmpBmpString);
            TmpBuf.Decode(*pTmpAny);

            pSNACCAttribute = pTmpSafeBag->safeBagAttributes->Append();
            pSNACCAttribute->type = pkcs_9_at_localKeyId;
            pTmpAny = pSNACCAttribute->values.Append();
            SMTI_DigestDataSHA1((CSM_Buffer *)pBufCert, &TmpDigest);
            TmpOctString.Set(TmpDigest.Access(), TmpDigest.Length());
            TmpBuf.Encode(TmpOctString);
            TmpBuf.Decode(*pTmpAny);
        }      // END for each cert in this particular list (list within list).


        //********************************************
        // Take care of associated Private Key for this list of certs.
        if (pTmpSafeBag)    // ONLY if we loaded at least 1 cert.
           EncryptPKCS12CreatePrivSafeBag(pPrivData->m_BufPriv, pszPasswordIN, 
               SafeBagsPriv, pTmpSafeBag->safeBagAttributes);
    }       // END FOR each private key/cert in list.

    bufEncodedBags.Encode(SafeBags);
    snaccEncryptedCI.contentEncryptionAlgorithm = new AlgorithmIdentifier;
    snaccEncryptedCI.contentEncryptionAlgorithm->algorithm = pbewithSHAAnd40BitRC2_CBC;
    pbufEncryptedKey = EncryptPKCS12Blob(pszPasswordIN, 
         *snaccEncryptedCI.contentEncryptionAlgorithm, bufEncodedBags);
   if (pbufEncryptedKey)
   {
       snaccEncryptedCI.contentType = id_data;
       snaccEncryptedCI.encryptedContent = new AsnOcts;
       snaccEncryptedCI.encryptedContent->Set(pbufEncryptedKey->Access(), pbufEncryptedKey->Length());
       ENCODE_BUF(&snaccEncryptedCI, pEncryptedCert);
   }        // END IF pbufEncryptedKey


   //******************************************************
   // Encode Private Key encodings, if present.  This is necessary to align the
   //  specific Certificate ID with the associated Private Key ID.
    // ENCODE final private key SafeBag.  They are loaded in-sync.
    ENCODE_BUF(&SafeBagsPriv, pencryptedPrivDataBuf);


   


    SME_FINISH
    SME_CATCH_SETUP
    SME_CATCH_FINISH

    return pEncryptedCert;
}     // END CSM_Free3::EncryptPKCS12CreateCertSafeBag(...)

//////////////////////////////////////////////////////////////////////////
//
// NOTE::: THIS ROUTINE HAS NOT BEEN TESTED WITH SEVERAL PRIVATE KEYS.  May
//  need minor modifications.
void CSM_Free3::EncryptPKCS12CreatePrivSafeBag(
    const CSM_Buffer &BufPriv,   // IN, Private Key to be loaded
    const char *pszPasswordIN,   // IN, 
    SafeContents &SafeBags,      // OUT, resulting PrivateKey added to SafeBag.
    Attributes *pSNACCAttributes) // IN, Actual setting for this Private key's
                                  //   matching certificate(s).
{
    CSM_Buffer Buf;
    CSM_Buffer *pBufTmpPriv=NULL;
    AsnOid  oidSafeBag_pkcs8ShroudedKeyBag(OIDSafeBag_pkcs8ShroudedKeyBag);
    SafeBag *pTmpSafeBag;

    SME_SETUP("CSM_Free3::EncryptPKCS12CreatePrivSafeBag");

    if (pszPasswordIN == NULL)
       SME_THROW(SM_MISSING_PARAM, "MISSING PARAMS", NULL);

    EncryptedPrivateKeyInfo snaccEncryptedX;

        snaccEncryptedX.encryptionAlgorithm = new SNACC::PkcsAlgId;
        snaccEncryptedX.encryptionAlgorithm->algorithm = pbeWithSHAAnd3_KeyTripleDES_CBC;
        AlgorithmIdentifier DecryptAlgId;
        DecryptAlgId.algorithm = snaccEncryptedX.encryptionAlgorithm->algorithm;
        pBufTmpPriv = EncryptPKCS12Blob(pszPasswordIN, DecryptAlgId, BufPriv);
        if (DecryptAlgId.parameters)
        {
           snaccEncryptedX.encryptionAlgorithm->parameters = DecryptAlgId.parameters;
           DecryptAlgId.parameters = NULL; 
                             //CLEAR DO NOT DELETE, since given away
        }
        snaccEncryptedX.encryptedData.Set(pBufTmpPriv->Access(), pBufTmpPriv->Length());
        Buf.Encode(snaccEncryptedX);
        delete pBufTmpPriv;
        pBufTmpPriv = NULL;
        pTmpSafeBag = SafeBags.Append();
        pTmpSafeBag->safeBagType = oidSafeBag_pkcs8ShroudedKeyBag;
        Buf.Decode(pTmpSafeBag->safeBagContent);
        if (pSNACCAttributes)
        {
            pTmpSafeBag->safeBagAttributes = new Attributes;
            *pTmpSafeBag->safeBagAttributes = *pSNACCAttributes;
        }       // END IF pSNACCAttributes


    SME_FINISH
    SME_CATCH_SETUP
    SME_CATCH_FINISH

}     // END CSM_Free3::EncryptPKCS12CreatePrivSafeBag(...)


//////////////////////////////////////////////////////////////////////////
// RETURNS encrypted Blob.
CSM_Buffer *CSM_Free3::EncryptPKCS12Blob(const char *pszPasswordIn, 
   AlgorithmIdentifier &EncryptionAlgorithm, const CSM_Buffer &bufClearKey)
{
   CSM_Buffer *pK = NULL;
   CSM_Buffer *pIV = NULL;
   CSM_Buffer *pbufEncodedEncryptionParams=NULL;
   int blocksize = 0;
   AsnOid oidHash;
   int iLength = 20;
   int iPBEKeyBits=SM_FREE_RC2_DEFAULT_PBE_KEYBITS;
   EncryptedContentInfo snaccEncryptedCI;
   char *pszPassword=NULL;
   long lPassword2=(strlen(pszPasswordIn)+1)*2;
   PBEParameter snaccEncryptionParams;
   CSM_Buffer *pbufOut=NULL;
   long lRequestedLength=0;



   RC2Encryption *pRC2encryption=NULL;
   CBCPaddedEncryptor *pcbc_PADencryption=NULL;
#ifndef CRYPTOPP_5_0
   DES_EDE3_Encryption *pencryption=NULL;
   Filter *pcbc_encryption=NULL;
   CBCRawEncryptor *pcbc_NotPaddedEncryption=NULL;;
#else // CRYPTOPP_5_0
   StreamTransformation *pcbc_encryption=NULL;
#endif // CRYPTOPP_5_0

   SME_SETUP("CSM_Free3::EncryptPKCS12Blob");

   if (pszPasswordIn == NULL)
      SME_THROW(SM_MISSING_PARAM, "MISSING PARAMS", NULL);

   pszPassword=(char *)calloc(1, lPassword2);
   for (int iii=0; iii < strlen(pszPasswordIn); iii++)
        pszPassword[iii*2+1] = pszPasswordIn[iii];

   if (EncryptionAlgorithm.algorithm != pbewithSHAAnd40BitRC2_CBC &&
       EncryptionAlgorithm.algorithm != pbeWithSHAAnd3_KeyTripleDES_CBC)
   {
      SME_THROW(33, "EncryptionAlgorithm not supported, ONLY pbewithSHAAnd40BitRC2_CBC.", NULL);
   }


   // Create the SALT for encryption algorithm parameters
   CSM_Buffer bufSalt("        ", 8);
   // create lLength random bytes of data
   #ifndef CRYPTOPP_5_0
   rndRandom2.GetBlock((unsigned char *)bufSalt.Access(), 8);
   #else // CRYPTOPP_5_0
   char *p=(char *)bufSalt.Access();
   for (int ii=0; ii < 8; ii++)
       p[ii] = (char)rndRandom2.GenerateByte();
   #endif // CRYPTOPP_5_0
    //TEST;memcpy(p, "abcdefgh", 8);                      //RWC;TEST

   int nIterCount = 2048;

   if (EncryptionAlgorithm.algorithm == pbewithSHAAnd40BitRC2_CBC ||
       EncryptionAlgorithm.algorithm == pbeWithSHAAnd3_KeyTripleDES_CBC)
   {
       oidHash = sha_1;
       iLength = 20;
       blocksize = SM_COMMON_RC2_BLOCKSIZE;//iPBEKeyBits/8;
       if (EncryptionAlgorithm.algorithm == pbeWithSHAAnd3_KeyTripleDES_CBC)
          lRequestedLength = 24;    // MUST request larger value since SHA-1
                                    //  only provides 20 bytes...
      // generate the key using the salt, the iteration count, and the password
      SME(pK = GeneratePKCS12PBEKey(&bufSalt, nIterCount, 0x01, pszPassword, 
               oidHash, iLength, lPassword2, 0x40, lRequestedLength));

      //pK->SetLength(3); // SET only necessary key length.
      SME(pIV = GeneratePKCS12PBEKey(&bufSalt, nIterCount, 0x02, pszPassword, 
               oidHash, iLength, lPassword2, 0x40));

       snaccEncryptionParams.iterationCount = nIterCount;
       snaccEncryptionParams.salt.Set(bufSalt.Access(), bufSalt.Length());
       ENCODE_BUF(&snaccEncryptionParams, pbufEncodedEncryptionParams);
       if (EncryptionAlgorithm.parameters == NULL)
           EncryptionAlgorithm.parameters = new AsnAny;
       DECODE_BUF(EncryptionAlgorithm.parameters, pbufEncodedEncryptionParams);
                    // RETURN to application...
       delete pbufEncodedEncryptionParams;
       pbufEncodedEncryptionParams = NULL;
   }
   else
   {
      SME_THROW(22, "EncryptionAlgorithm not recognized!", NULL);
   }

   if (EncryptionAlgorithm.algorithm == pbewithSHAAnd40BitRC2_CBC)
   {
      blocksize = SM_COMMON_RC2_BLOCKSIZE;//iPBEKeyBits/8;
      iPBEKeyBits = 40;
      // create the rc2 cipher 
      pRC2encryption = new RC2Encryption((const unsigned char*)pK->Access(), 
             iPBEKeyBits/8, iPBEKeyBits);
      pcbc_PADencryption=new CBCPaddedEncryptor(*pRC2encryption,  
              (const unsigned char*)pIV->Access());
      pcbc_encryption = pcbc_PADencryption;
   }
   else if (EncryptionAlgorithm.algorithm == pbeWithSHAAnd3_KeyTripleDES_CBC)
   {
      // create the 3DES cipher 
      // BE SURE TO ADJUST THE PARITY!!!!!!
      unsigned char *ptr3=(unsigned char *)calloc(1, pK->Length());
      memcpy(ptr3, pK->Access(), pK->Length());
      for (int iii=0; iii < 24; iii++)
      {
         if (!CryptoPP::Parity((unsigned long)ptr3[iii]))
            ptr3[iii] ^= 0x01;
      }
#ifndef CRYPTOPP_5_0
      DES_EDE3_Encryption encryption((const unsigned char*)pK->Access());
      pcbc_PADencryption=new CBCPaddedEncryptor(encryption,  
          (const unsigned char*)pIV->Access());
      pcbc_encryption = pcbc_PADencryption;
#else // CRYPTOPP_5_0
      CBC_Mode<DES_EDE3>::Encryption *pTmpEncryption = new CBC_Mode<DES_EDE3>::Encryption;
      pTmpEncryption->SetKeyWithIV((const unsigned char*)pK->Access(), 24, 
                    (const unsigned char *)pIV->Access());
      pcbc_encryption = pTmpEncryption;
#endif // CRYPTOPP_5_0
      free(ptr3);
   }        // END IF algorithm check.
   pbufOut = new CSM_Buffer;
   RawEncrypt((CSM_Buffer *)&bufClearKey, pbufOut, pcbc_encryption, blocksize);

/*#ifdef _DEBUG
   CSM_Buffer *pResultBack=DecryptPKCS12Blob(pszPasswordIn, EncryptionAlgorithm
         , *pbufOut);
   if (pResultBack && *pResultBack != bufClearKey) //RWC;padding not removed!!!
       std::cout << "BAD NEWS from PKCS12 encryption of Cert!" << std::endl;
#endif*/

   if (pszPassword)
      free(pszPassword);
   if (pK)
      delete pK;
   if (pcbc_encryption)
       delete pcbc_encryption;
   if (pIV && pIV != pK)
       delete pIV;

   SME_FINISH
   SME_CATCH_SETUP
      if (pK)
         delete pK;
      if (pbufEncodedEncryptionParams)
         delete pbufEncodedEncryptionParams;
      if (pIV && pIV != pK)
          delete pIV;
      if (pcbc_encryption)
          delete pcbc_encryption;
      if (pbufOut)
         delete pbufOut;
      if (pszPassword)
         free(pszPassword);
   SME_CATCH_FINISH

   return pbufOut;
}       // END CSM_Free3::EncryptPKCS12Blob(...)

//
//  RETURNS computed MAC, or NULL if error.
CSM_Buffer *CSM_Free3::ComputePkcs12MAC(CSM_Buffer &bufSalt,    // IN/OUT
                                 const AsnOid &OidMac,          // IN
                                 const char *pszPassword,       // IN
                                 const CSM_Buffer &PKCS12Buf,   // IN
                                 const int iter)                // IN, OPTIONAL
{
   CSM_Buffer *pBufMacResult=NULL;

   // **** INITIALIZE Salt if necessary
    if (bufSalt.Length() == 0)
    {
       bufSalt.Set("        ", 8);  // PRE-initialize
       // create lLength random bytes of data
       #ifndef CRYPTOPP_5_0
       rndRandom2.GetBlock((unsigned char *)bufSalt.Access(), 8);
       #else // CRYPTOPP_5_0
       char *p=(char *)bufSalt.Access();
       for (int ii=0; ii < 8; ii++)
           p[ii] = (char)rndRandom2.GenerateByte();
       #endif // CRYPTOPP_5_0
       //TEST;memcpy(p, "abcdefgh", 8);                      //RWC;TEST
    }       // END if bufSalt pre-filled

   // **** NOW, Setup password as Unicode string containing trailing '\0'.
   long lPassword2 = (strlen(pszPassword)+1)*2;
   char *pszPasswordMAC=(char *)calloc(1, lPassword2);
   for (int iii=0; iii < strlen(pszPassword); iii++)
        pszPasswordMAC[iii*2+1] = pszPassword[iii]; // MAKE Unicode...

   // **** GENERATE PKCS12 MAC Key
   /*CSM_Buffer *pK = = GeneratePKCS12PBEKey(&bufSalt, 1, / *PKCS12MACID* / 0x03, 
        pszPasswordMAC, Pfx.macData->safeMac.digestAlgorithm, 
        / *MACKEYLENGTH* /20, lPassword2, 0x40, / *MACKEYLENGTH* /20));
   b)	If the PFX PDU is to be authenticated with HMAC, then an SHA-1 
   HMAC is computed on the contents of the Data in T (i.e. excluding the 
   OCTET STRING tag and length bytes).  This is exactly what would be initially
   digested in step 5a) if public-key authentication were being used 
   (FROM pkcs12-v1.doc)*/
        // GENERATE PKCS12 MAC using SHA-1 digest algorithm.
   /* FROM Crypto++ 5.0
     struct PBKDF_TestTuple
     {
	    byte purpose;                   IN OUR CASE, 0x03.
	    unsigned int iterations;        IN OUR CASE, 1
	    const char *hexPassword, *hexSalt, *hexDerivedKey;
     };
        {3, 1, "0073006D006500670000", "3D83C0E4546AC140", "8D967D88F6CAA9D714800AB3D48051D63F73A312"},*/
   //RWC;WRONG;PKCS5_PBKDF2_HMAC<SHA1> pbkdf;
#ifndef PRE_R2_3     // PATCH for a customer before R2.3 released!!!
   PKCS12_PBKDF<SHA1> pbkdf;
   //string password, salt; RWC;EXPECTED RESULT IS derivedKey;
		SecByteBlock derived(20);
		pbkdf.GeneralDeriveKey(derived, 20/*?SHOULD BE SAME LENGTH AS SHA-1 LENGTH?*/,
            0x03, (const unsigned char *)pszPasswordMAC ,lPassword2, 
            (const unsigned char *)bufSalt.Access(), 8, /*iterations*/iter);
        CSM_Buffer BufDerivedKey((const char *)(unsigned char *)derived, derived.size());
        /*In this version of this standard, SHA-1 is used for performing all 
          MACing, and so all MAC keys are 160 bits, 20 bytes. */
		//bool fail = memcmp(derived, derivedKey.data(), derived.size()) != 0;

    pBufMacResult = ComputePkcs12MACHash(OidMac, BufDerivedKey, PKCS12Buf);
#endif //PRE_R2_3     // PATCH for a customer before R2.3 released!!!

    return(pBufMacResult);
}       // END CSM_Free3::ComputePkcs12MAC(...)



//
// RETURNS hash result, given hash OID and input data.
CSM_Buffer *CSM_Free3::ComputePkcs12MACHash(
        const AsnOid &OidMac,          // IN
        const CSM_Buffer &BufKey,      // IN
        const CSM_Buffer &BufText)     // IN
{
    CSM_Buffer *pBufMacResult=NULL;
    int i;
    /**** COMPUTE actual MAC using derived key above, and data parameter
    /*  FROM RFC2104 on HMAC
    We define two fixed and different strings ipad and opad as follows
   (the 'i' and 'o' are mnemonics for inner and outer):
                  ipad = the byte 0x36 repeated B times
                  opad = the byte 0x5C repeated B times.
   To compute HMAC over the data `text' we perform
                    H(K XOR opad, H(K XOR ipad, text))
   Namely,
    (1) append zeros to the end of K to create a B byte string
        (e.g., if K is of length 20 bytes and B=64, then K will be
         appended with 44 zero bytes 0x00)
    (2) XOR (bitwise exclusive-OR) the B byte string computed in step
        (1) with ipad
    (3) append the stream of data 'text' to the B byte string resulting
        from step (2)
    (4) apply H to the stream generated in step (3)
    (5) XOR (bitwise exclusive-OR) the B byte string computed in
        step (1) with opad
    (6) append the H result from step (4) to the B byte string
        resulting from step (5)
    (7) apply H to the stream generated in step (6) and output
        the result
    */
    CSM_Buffer BFirstStage;
    CSM_Buffer B((size_t)64);
    char *ptr=(char *)B.Access();
    const char cIpad=0x36;
    const char cOpad=0x5c;
    // STEP 1-4
    memset(ptr, '\0', 64);   // PAD key with 0's to Data length
    memcpy(ptr, BufKey.Access(), BufKey.Length());
    for (i=0; i < 64; i++)
        ptr[i] ^= cIpad;
    B.Open(SM_FOPEN_APPEND);
    B.Write(BufText.Access(), BufText.Length()); //RWC; might be short if < key length.
    B.Close();
    if (OidMac == sha_1)
        SMTI_DigestDataSHA1(&B, &BFirstStage);  // FROM CSM_Common
    else if (OidMac == md5)
        SMTI_DigestDataInternal(&B, &BFirstStage, (AsnOid &)OidMac);
    // STEP 5+
    B.Alloc((size_t)64);    // RE-SET size of buffer (and buffer itself).
    B.SetLength(64);
    ptr = (char *)B.Access();
    memset(ptr, '\0', 64);
    memcpy(ptr, BufKey.Access(), BufKey.Length());
    for (i=0; i < 64; i++)
        ptr[i] ^= cOpad;
    B.Open(SM_FOPEN_APPEND);
    B.Write(BFirstStage.Access(), BFirstStage.Length());
    B.Close();
    pBufMacResult = new CSM_Buffer;
    if (OidMac == sha_1)
        SMTI_DigestDataSHA1(&B, pBufMacResult);  // FROM CSM_Common
    else if (OidMac == md5)
        SMTI_DigestDataInternal(&B, pBufMacResult, (AsnOid &)OidMac);

    return(pBufMacResult);
}       // END CSM_Free3::ComputePkcs12MACHash(...)


_END_CERT_NAMESPACE




// EOF sm_Free3Internal.cpp
