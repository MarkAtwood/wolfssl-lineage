#ifndef NO_SCCS_ID
static char SccsId[ ] = "@(#) sm_tstdlib.c 1.3 12/13/99 16:21:31"; 
#endif

/* Copyright (C) RSA Data Security, Inc. created 1992.

   This file is used to demonstrate how to interface to an
   RSA Data Security, Inc. licensed development product.

   You have a royalty-free right to use, modify, reproduce and
   distribute this demonstration file (including any modified
   version), provided that you agree that RSA Data Security,
   Inc. has no warranty, implied or otherwise, or liability
   for this demonstration file or any modified version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "aglobal.h"
#include "bsafe.h"
#pragma  warning( disable : 4131 )  // IGNORE old-style decl.

/* If the standard C library comes with a memmove() that correctly
     handles overlapping buffers, MEMMOVE_PRESENT should be defined as
     1, else 0.
   The following defines MEMMOVE_PRESENT as 1 if it has not already been
     defined as 0 with C compiler flags.
 */
#ifndef MEMMOVE_PRESENT
#define MEMMOVE_PRESENT 1
#endif

void CALL_CONV T_memset (p, c, count)
POINTER p;
int c;
unsigned int count;
{
  if (count != 0)
    memset (p, c, count);
}

void CALL_CONV T_memcpy (d, s, count)
POINTER d, s;
unsigned int count;
{
  if (count != 0)
    memcpy (d, s, count);
}

void CALL_CONV T_memmove (d, s, count)
POINTER d, s;
unsigned int count;
{
#if MEMMOVE_PRESENT
  if (count != 0)
    memmove (d, s, count);
#else
  unsigned int i;

  if ((char *)d == (char *)s)
    return;
  else if ((char *)d > (char *)s) {
    for (i = count; i > 0; i--)
      ((char *)d)[i-1] = ((char *)s)[i-1];
  }
  else {
    for (i = 0; i < count; i++)
      ((char *)d)[i] = ((char *)s)[i];
  }
#endif
}

int CALL_CONV T_memcmp (s1, s2, count)
POINTER s1, s2;
unsigned int count;
{
  if (count == 0)
    return (0);
  else
    return (memcmp (s1, s2, count));
}

POINTER CALL_CONV T_malloc (size)
unsigned int size;
{
  return ((POINTER)malloc (size == 0 ? 1 : size));
}

POINTER CALL_CONV T_realloc (p, size)
POINTER p;
unsigned int size;
{
  POINTER result;
  
  if (p == NULL_PTR)
    return (T_malloc (size));

  if ((result = (POINTER)realloc (p, size == 0 ? 1 : size)) == NULL_PTR)
    free (p);
  return (result);
}

void CALL_CONV T_free (p)
POINTER p;
{
  if (p != NULL_PTR)
    free (p);
}


int CALL_CONV T_strlen(p)
const char *p;
{
    return strlen(p);
}

char* CALL_CONV T_strcpy(dest, src)
char *dest;
const char *src;
{
    return(strcpy(dest, src));
}

int CALL_CONV T_strcmp (a, b)
const char *a, *b;
{
  return (strcmp (a, b));
}


