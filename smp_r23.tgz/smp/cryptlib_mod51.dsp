# Microsoft Developer Studio Project File - Name="cryptlib_mod" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Static Library" 0x0104

CFG=cryptlib_mod - Win32 FIPS 140 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "cryptlib_mod.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "cryptlib_mod.mak" CFG="cryptlib_mod - Win32 FIPS 140 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "cryptlib_mod - Win32 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "cryptlib_mod - Win32 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE "cryptlib_mod - Win32 FIPS 140 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "cryptlib_mod - Win32 FIPS 140 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""$/cryptlib_mod", BAAAAAAA"
# PROP Scc_LocalPath "."
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "cryptlib_mod"
# PROP BASE Intermediate_Dir "cryptlib_mod"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "release"
# PROP Intermediate_Dir "release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MD /W3 /GX /Zi /O2 /D "NDEBUG" /D "WIN32" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /FD /Zm200 /c
# SUBTRACT CPP /YX /Yc /Yu
# ADD BASE RSC /l 0x409
# ADD RSC /l 0x409
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"..\SMPDist\lib\cryptlib.lib"

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "cryptli0"
# PROP BASE Intermediate_Dir "cryptli0"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "debug"
# PROP Intermediate_Dir "debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /Z7 /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MDd /W3 /GX /ZI /Od /D "_DEBUG" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /D "WIN32" /D DSA_1024_BIT_MODULUS_ONLY=0 /FD /Zm200 /c
# SUBTRACT CPP /YX /Yc /Yu
# ADD BASE RSC /l 0x409
# ADD RSC /l 0x409
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"..\SMPDist\lib\cryptlib_d.lib"

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "cryptlib_mod___Win32_FIPS_140_Release"
# PROP BASE Intermediate_Dir "cryptlib_mod___Win32_FIPS_140_Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "FIPS_140_Release"
# PROP Intermediate_Dir "FIPS_140_Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /G5 /Gz /MT /W3 /GX /Zi /O2 /D "NDEBUG" /D "WIN32" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /Yu"pch.h" /FD /c
# ADD CPP /nologo /G5 /Gz /MT /W3 /GX /Zi /O2 /D "NDEBUG" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /D "WIN32" /D CRYPTOPP_ENABLE_COMPLIANCE_WITH_FIPS_140_2=1 /Yu"pch.h" /Fd"FIPS_140_Release/cryptopp" /FD /c
# ADD BASE RSC /l 0x409
# ADD RSC /l 0x409
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"FIPS_140_Release\cryptopp.lib"

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "cryptlib_mod___Win32_FIPS_140_Debug"
# PROP BASE Intermediate_Dir "cryptlib_mod___Win32_FIPS_140_Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "FIPS_140_Debug"
# PROP Intermediate_Dir "FIPS_140_Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MTd /W3 /GX /ZI /Od /D "_DEBUG" /D "WIN32" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /Yu"pch.h" /FD /c
# ADD CPP /nologo /G5 /Gz /MDd /W3 /GX /ZI /Od /D "_DEBUG" /D "_WINDOWS" /D "USE_PRECOMPILED_HEADERS" /D "WIN32" /D CRYPTOPP_ENABLE_COMPLIANCE_WITH_FIPS_140_2=1 /Yu"pch.h" /Fd"FIPS_140_Debug/cryptopp" /FD /c
# ADD BASE RSC /l 0x409
# ADD RSC /l 0x409
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"FIPS_140_Debug\cryptopp.lib"

!ENDIF 

# Begin Target

# Name "cryptlib_mod - Win32 Release"
# Name "cryptlib_mod - Win32 Debug"
# Name "cryptlib_mod - Win32 FIPS 140 Release"
# Name "cryptlib_mod - Win32 FIPS 140 Debug"
# Begin Group "Source Files"

# PROP Default_Filter ".cpp"
# Begin Source File

SOURCE=..\cryptopp51\3way.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\adler32.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\algebra.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\algparam.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\arc4.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\asn.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\base64.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\basecode.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\bfinit.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\blowfish.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\blumshub.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\cast.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\casts.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\channels.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\crc.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\cryptlib.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\datatest.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\default.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\des.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\dessp.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\dh.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\dh2.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\diamond.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\diamondt.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\dsa.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\ec2n.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\eccrypto.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\ecp.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\elgamal.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\eprecomp.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\esign.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\files.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\filters.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\fips140.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\fipstest.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gf256.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gf2_32.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gf2n.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gfpcrypt.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gost.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gzip.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\haval.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\hex.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\hrtimer.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\ida.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\idea.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\integer.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\iterhash.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\luc.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\mars.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\marss.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\md2.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\md4.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\md5.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\md5mac.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\misc.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\modes.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\modexppc.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\mqueue.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\mqv.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\nbtheory.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\network.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\oaep.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\osrng.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\panama.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\pch.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\pkcspad.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\polynomi.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\pssr.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\pubkey.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\queue.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rabin.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\randpool.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rc2.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rc5.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rc6.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rdtables.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\regtest.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rijndael.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\ripemd.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rng.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rsa.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rw.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\safer.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\seal.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\serpent.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\sha.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\shark.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\sharkbox.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\simple.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\skipjack.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\socketft.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\square.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\squaretb.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\strciphr.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\tea.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\tftables.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\tiger.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\tigertab.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\trdlocal.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\twofish.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\wait.cpp

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# PROP Exclude_From_Build 1

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# PROP Exclude_From_Build 1

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\wake.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\winpipes.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\xtr.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\xtrcrypt.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\zdeflate.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\zinflate.cpp
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\zlib.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter ".;.h"
# Begin Source File

SOURCE=..\cryptopp51\3way.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\3way.h
InputName=3way

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\3way.h
InputName=3way

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\3way.h
InputName=3way

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\3way.h
InputName=3way

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\adler32.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\adler32.h
InputName=adler32

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\adler32.h
InputName=adler32

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\adler32.h
InputName=adler32

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\adler32.h
InputName=adler32

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\aes.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\aes.h
InputName=aes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\aes.h
InputName=aes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\aes.h
InputName=aes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\aes.h
InputName=aes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\algebra.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\algebra.h
InputName=algebra

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\algebra.h
InputName=algebra

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\algebra.h
InputName=algebra

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\algebra.h
InputName=algebra

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\algparam.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\algparam.h
InputName=algparam

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\algparam.h
InputName=algparam

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\algparam.h
InputName=algparam

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\algparam.h
InputName=algparam

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\arc4.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\arc4.h
InputName=arc4

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\arc4.h
InputName=arc4

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\arc4.h
InputName=arc4

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\arc4.h
InputName=arc4

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\argnames.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\argnames.h
InputName=argnames

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\argnames.h
InputName=argnames

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\argnames.h
InputName=argnames

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\argnames.h
InputName=argnames

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\asn.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\asn.h
InputName=asn

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\asn.h
InputName=asn

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\asn.h
InputName=asn

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\asn.h
InputName=asn

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\base64.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\base64.h
InputName=base64

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\base64.h
InputName=base64

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\base64.h
InputName=base64

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\base64.h
InputName=base64

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\basecode.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\basecode.h
InputName=basecode

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\basecode.h
InputName=basecode

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\basecode.h
InputName=basecode

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\basecode.h
InputName=basecode

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\bench.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\bench.h
InputName=bench

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\bench.h
InputName=bench

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\bench.h
InputName=bench

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\bench.h
InputName=bench

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\blowfish.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\blowfish.h
InputName=blowfish

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\blowfish.h
InputName=blowfish

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\blowfish.h
InputName=blowfish

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\blowfish.h
InputName=blowfish

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\blumshub.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\blumshub.h
InputName=blumshub

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\blumshub.h
InputName=blumshub

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\blumshub.h
InputName=blumshub

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\blumshub.h
InputName=blumshub

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\cast.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\cast.h
InputName=cast

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\cast.h
InputName=cast

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\cast.h
InputName=cast

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\cast.h
InputName=cast

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\cbcmac.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\cbcmac.h
InputName=cbcmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\cbcmac.h
InputName=cbcmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\cbcmac.h
InputName=cbcmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\cbcmac.h
InputName=cbcmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\channels.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\channels.h
InputName=channels

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\channels.h
InputName=channels

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\channels.h
InputName=channels

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\channels.h
InputName=channels

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\config.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\config.h
InputName=config

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\config.h
InputName=config

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\config.h
InputName=config

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\config.h
InputName=config

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\crc.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\crc.h
InputName=crc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\crc.h
InputName=crc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\crc.h
InputName=crc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\crc.h
InputName=crc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\cryptlib.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\cryptlib.h
InputName=cryptlib

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\cryptlib.h
InputName=cryptlib

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\cryptlib.h
InputName=cryptlib

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\cryptlib.h
InputName=cryptlib

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\default.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\default.h
InputName=default

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\default.h
InputName=default

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\default.h
InputName=default

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\default.h
InputName=default

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\des.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\des.h
InputName=des

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\des.h
InputName=des

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\des.h
InputName=des

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\des.h
InputName=des

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\dh.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\dh.h
InputName=dh

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\dh.h
InputName=dh

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\dh.h
InputName=dh

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\dh.h
InputName=dh

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\dh2.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\dh2.h
InputName=dh2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\dh2.h
InputName=dh2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\dh2.h
InputName=dh2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\dh2.h
InputName=dh2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\diamond.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\diamond.h
InputName=diamond

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\diamond.h
InputName=diamond

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\diamond.h
InputName=diamond

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\diamond.h
InputName=diamond

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\dmac.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\dmac.h
InputName=dmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\dmac.h
InputName=dmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\dmac.h
InputName=dmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\dmac.h
InputName=dmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\dsa.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\dsa.h
InputName=dsa

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\dsa.h
InputName=dsa

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\dsa.h
InputName=dsa

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\dsa.h
InputName=dsa

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\ec2n.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\ec2n.h
InputName=ec2n

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\ec2n.h
InputName=ec2n

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\ec2n.h
InputName=ec2n

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\ec2n.h
InputName=ec2n

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\eccrypto.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\eccrypto.h
InputName=eccrypto

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\eccrypto.h
InputName=eccrypto

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\eccrypto.h
InputName=eccrypto

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\eccrypto.h
InputName=eccrypto

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\ecp.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\ecp.h
InputName=ecp

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\ecp.h
InputName=ecp

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\ecp.h
InputName=ecp

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\ecp.h
InputName=ecp

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\elgamal.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\elgamal.h
InputName=elgamal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\elgamal.h
InputName=elgamal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\elgamal.h
InputName=elgamal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\elgamal.h
InputName=elgamal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\eprecomp.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\eprecomp.h
InputName=eprecomp

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\eprecomp.h
InputName=eprecomp

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\eprecomp.h
InputName=eprecomp

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\eprecomp.h
InputName=eprecomp

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\esign.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\esign.h
InputName=esign

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\esign.h
InputName=esign

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\esign.h
InputName=esign

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\esign.h
InputName=esign

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\factory.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\factory.h
InputName=factory

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\factory.h
InputName=factory

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\factory.h
InputName=factory

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\factory.h
InputName=factory

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\files.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\files.h
InputName=files

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\files.h
InputName=files

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\files.h
InputName=files

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\files.h
InputName=files

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\filters.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\filters.h
InputName=filters

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\filters.h
InputName=filters

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\filters.h
InputName=filters

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\filters.h
InputName=filters

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\fips140.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\fips140.h
InputName=fips140

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\fips140.h
InputName=fips140

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\fips140.h
InputName=fips140

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\fips140.h
InputName=fips140

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\fltrimpl.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\fltrimpl.h
InputName=fltrimpl

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\fltrimpl.h
InputName=fltrimpl

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\fltrimpl.h
InputName=fltrimpl

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\fltrimpl.h
InputName=fltrimpl

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gf256.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\gf256.h
InputName=gf256

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\gf256.h
InputName=gf256

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\gf256.h
InputName=gf256

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\gf256.h
InputName=gf256

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gf2_32.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\gf2_32.h
InputName=gf2_32

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\gf2_32.h
InputName=gf2_32

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\gf2_32.h
InputName=gf2_32

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\gf2_32.h
InputName=gf2_32

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gf2n.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\gf2n.h
InputName=gf2n

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\gf2n.h
InputName=gf2n

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\gf2n.h
InputName=gf2n

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\gf2n.h
InputName=gf2n

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gfpcrypt.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\gfpcrypt.h
InputName=gfpcrypt

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\gfpcrypt.h
InputName=gfpcrypt

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\gfpcrypt.h
InputName=gfpcrypt

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\gfpcrypt.h
InputName=gfpcrypt

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gost.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\gost.h
InputName=gost

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\gost.h
InputName=gost

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\gost.h
InputName=gost

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\gost.h
InputName=gost

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\gzip.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\gzip.h
InputName=gzip

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\gzip.h
InputName=gzip

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\gzip.h
InputName=gzip

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\gzip.h
InputName=gzip

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\haval.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\haval.h
InputName=haval

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\haval.h
InputName=haval

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\haval.h
InputName=haval

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\haval.h
InputName=haval

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\hex.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\hex.h
InputName=hex

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\hex.h
InputName=hex

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\hex.h
InputName=hex

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\hex.h
InputName=hex

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\hmac.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\hmac.h
InputName=hmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\hmac.h
InputName=hmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\hmac.h
InputName=hmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\hmac.h
InputName=hmac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\hrtimer.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\hrtimer.h
InputName=hrtimer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\hrtimer.h
InputName=hrtimer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\hrtimer.h
InputName=hrtimer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\hrtimer.h
InputName=hrtimer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\ida.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\ida.h
InputName=ida

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\ida.h
InputName=ida

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\ida.h
InputName=ida

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\ida.h
InputName=ida

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\idea.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\idea.h
InputName=idea

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\idea.h
InputName=idea

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\idea.h
InputName=idea

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\idea.h
InputName=idea

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\integer.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\integer.h
InputName=integer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\integer.h
InputName=integer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\integer.h
InputName=integer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\integer.h
InputName=integer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\iterhash.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\iterhash.h
InputName=iterhash

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\iterhash.h
InputName=iterhash

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\iterhash.h
InputName=iterhash

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\iterhash.h
InputName=iterhash

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\lubyrack.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\lubyrack.h
InputName=lubyrack

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\lubyrack.h
InputName=lubyrack

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\lubyrack.h
InputName=lubyrack

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\lubyrack.h
InputName=lubyrack

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\luc.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\luc.h
InputName=luc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\luc.h
InputName=luc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\luc.h
InputName=luc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\luc.h
InputName=luc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\mars.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\mars.h
InputName=mars

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\mars.h
InputName=mars

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\mars.h
InputName=mars

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\mars.h
InputName=mars

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\md2.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\md2.h
InputName=md2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\md2.h
InputName=md2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\md2.h
InputName=md2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\md2.h
InputName=md2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\md4.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\md4.h
InputName=md4

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\md4.h
InputName=md4

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\md4.h
InputName=md4

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\md4.h
InputName=md4

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\md5.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\md5.h
InputName=md5

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\md5.h
InputName=md5

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\md5.h
InputName=md5

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\md5.h
InputName=md5

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\md5mac.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\md5mac.h
InputName=md5mac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\md5mac.h
InputName=md5mac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\md5mac.h
InputName=md5mac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\md5mac.h
InputName=md5mac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\mdc.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\mdc.h
InputName=mdc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\mdc.h
InputName=mdc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\mdc.h
InputName=mdc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\mdc.h
InputName=mdc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\misc.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\misc.h
InputName=misc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\misc.h
InputName=misc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\misc.h
InputName=misc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\misc.h
InputName=misc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\modarith.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\modarith.h
InputName=modarith

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\modarith.h
InputName=modarith

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\modarith.h
InputName=modarith

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\modarith.h
InputName=modarith

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\modes.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\modes.h
InputName=modes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\modes.h
InputName=modes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\modes.h
InputName=modes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\modes.h
InputName=modes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\modexppc.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\modexppc.h
InputName=modexppc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\modexppc.h
InputName=modexppc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\modexppc.h
InputName=modexppc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\modexppc.h
InputName=modexppc

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\mqueue.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\mqueue.h
InputName=mqueue

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\mqueue.h
InputName=mqueue

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\mqueue.h
InputName=mqueue

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\mqueue.h
InputName=mqueue

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\mqv.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\mqv.h
InputName=mqv

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\mqv.h
InputName=mqv

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\mqv.h
InputName=mqv

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\mqv.h
InputName=mqv

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\nbtheory.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\nbtheory.h
InputName=nbtheory

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\nbtheory.h
InputName=nbtheory

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\nbtheory.h
InputName=nbtheory

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\nbtheory.h
InputName=nbtheory

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\network.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\network.h
InputName=network

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\network.h
InputName=network

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\network.h
InputName=network

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\network.h
InputName=network

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\nr.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\nr.h
InputName=nr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\nr.h
InputName=nr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\nr.h
InputName=nr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\nr.h
InputName=nr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\oaep.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\oaep.h
InputName=oaep

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\oaep.h
InputName=oaep

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\oaep.h
InputName=oaep

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\oaep.h
InputName=oaep

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\oids.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\oids.h
InputName=oids

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\oids.h
InputName=oids

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\oids.h
InputName=oids

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\oids.h
InputName=oids

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\osrng.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\osrng.h
InputName=osrng

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\osrng.h
InputName=osrng

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\osrng.h
InputName=osrng

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\osrng.h
InputName=osrng

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\panama.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\panama.h
InputName=panama

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\panama.h
InputName=panama

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\panama.h
InputName=panama

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\panama.h
InputName=panama

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\pch.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\pch.h
InputName=pch

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\pch.h
InputName=pch

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\pch.h
InputName=pch

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\pch.h
InputName=pch

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\pkcspad.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\pkcspad.h
InputName=pkcspad

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\pkcspad.h
InputName=pkcspad

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\pkcspad.h
InputName=pkcspad

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\pkcspad.h
InputName=pkcspad

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\polynomi.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\polynomi.h
InputName=polynomi

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\polynomi.h
InputName=polynomi

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\polynomi.h
InputName=polynomi

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\polynomi.h
InputName=polynomi

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\pssr.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\pssr.h
InputName=pssr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\pssr.h
InputName=pssr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\pssr.h
InputName=pssr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\pssr.h
InputName=pssr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\pubkey.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\pubkey.h
InputName=pubkey

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\pubkey.h
InputName=pubkey

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\pubkey.h
InputName=pubkey

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\pubkey.h
InputName=pubkey

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\pwdbased.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\pwdbased.h
InputName=pwdbased

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\pwdbased.h
InputName=pwdbased

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\pwdbased.h
InputName=pwdbased

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\pwdbased.h
InputName=pwdbased

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\queue.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\queue.h
InputName=queue

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\queue.h
InputName=queue

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\queue.h
InputName=queue

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\queue.h
InputName=queue

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rabin.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\rabin.h
InputName=rabin

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\rabin.h
InputName=rabin

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\rabin.h
InputName=rabin

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\rabin.h
InputName=rabin

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\randpool.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\randpool.h
InputName=randpool

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\randpool.h
InputName=randpool

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\randpool.h
InputName=randpool

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\randpool.h
InputName=randpool

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rc2.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\rc2.h
InputName=rc2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\rc2.h
InputName=rc2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\rc2.h
InputName=rc2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\rc2.h
InputName=rc2

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rc5.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\rc5.h
InputName=rc5

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\rc5.h
InputName=rc5

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\rc5.h
InputName=rc5

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\rc5.h
InputName=rc5

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rc6.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\rc6.h
InputName=rc6

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\rc6.h
InputName=rc6

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\rc6.h
InputName=rc6

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\rc6.h
InputName=rc6

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rijndael.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\rijndael.h
InputName=rijndael

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\rijndael.h
InputName=rijndael

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\rijndael.h
InputName=rijndael

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\rijndael.h
InputName=rijndael

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\ripemd.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\ripemd.h
InputName=ripemd

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\ripemd.h
InputName=ripemd

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\ripemd.h
InputName=ripemd

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\ripemd.h
InputName=ripemd

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rng.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\rng.h
InputName=rng

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\rng.h
InputName=rng

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\rng.h
InputName=rng

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\rng.h
InputName=rng

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rsa.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\rsa.h
InputName=rsa

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\rsa.h
InputName=rsa

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\rsa.h
InputName=rsa

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\rsa.h
InputName=rsa

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\rw.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\rw.h
InputName=rw

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\rw.h
InputName=rw

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\rw.h
InputName=rw

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\rw.h
InputName=rw

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\safer.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\safer.h
InputName=safer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\safer.h
InputName=safer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\safer.h
InputName=safer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\safer.h
InputName=safer

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\seal.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\seal.h
InputName=seal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\seal.h
InputName=seal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\seal.h
InputName=seal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\seal.h
InputName=seal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\secblock.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\secblock.h
InputName=secblock

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\secblock.h
InputName=secblock

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\secblock.h
InputName=secblock

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\secblock.h
InputName=secblock

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\seckey.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\seckey.h
InputName=seckey

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\seckey.h
InputName=seckey

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\seckey.h
InputName=seckey

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\seckey.h
InputName=seckey

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\serpent.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\serpent.h
InputName=serpent

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\serpent.h
InputName=serpent

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\serpent.h
InputName=serpent

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\serpent.h
InputName=serpent

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\sha.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\sha.h
InputName=sha

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\sha.h
InputName=sha

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\sha.h
InputName=sha

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\sha.h
InputName=sha

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\shark.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\shark.h
InputName=shark

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\shark.h
InputName=shark

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\shark.h
InputName=shark

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\shark.h
InputName=shark

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\simple.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\simple.h
InputName=simple

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\simple.h
InputName=simple

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\simple.h
InputName=simple

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\simple.h
InputName=simple

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\skipjack.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\skipjack.h
InputName=skipjack

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\skipjack.h
InputName=skipjack

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\skipjack.h
InputName=skipjack

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\skipjack.h
InputName=skipjack

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\smartptr.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\smartptr.h
InputName=smartptr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\smartptr.h
InputName=smartptr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\smartptr.h
InputName=smartptr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\smartptr.h
InputName=smartptr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\socketft.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\socketft.h
InputName=socketft

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\socketft.h
InputName=socketft

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\socketft.h
InputName=socketft

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\socketft.h
InputName=socketft

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\square.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\square.h
InputName=square

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\square.h
InputName=square

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\square.h
InputName=square

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\square.h
InputName=square

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\strciphr.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\strciphr.h
InputName=strciphr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\strciphr.h
InputName=strciphr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\strciphr.h
InputName=strciphr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\strciphr.h
InputName=strciphr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\tea.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\tea.h
InputName=tea

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\tea.h
InputName=tea

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\tea.h
InputName=tea

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\tea.h
InputName=tea

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\tiger.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\tiger.h
InputName=tiger

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\tiger.h
InputName=tiger

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\tiger.h
InputName=tiger

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\tiger.h
InputName=tiger

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\trdlocal.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\trdlocal.h
InputName=trdlocal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\trdlocal.h
InputName=trdlocal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\trdlocal.h
InputName=trdlocal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\trdlocal.h
InputName=trdlocal

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\trunhash.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\trunhash.h
InputName=trunhash

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\trunhash.h
InputName=trunhash

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\trunhash.h
InputName=trunhash

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\trunhash.h
InputName=trunhash

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\twofish.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\twofish.h
InputName=twofish

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\twofish.h
InputName=twofish

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\twofish.h
InputName=twofish

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\twofish.h
InputName=twofish

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\validate.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\validate.h
InputName=validate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\validate.h
InputName=validate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\validate.h
InputName=validate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\validate.h
InputName=validate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\wait.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\wait.h
InputName=wait

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\wait.h
InputName=wait

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\wait.h
InputName=wait

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\wait.h
InputName=wait

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\wake.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\wake.h
InputName=wake

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\wake.h
InputName=wake

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\wake.h
InputName=wake

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\wake.h
InputName=wake

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\winpipes.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\winpipes.h
InputName=winpipes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\winpipes.h
InputName=winpipes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\winpipes.h
InputName=winpipes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\winpipes.h
InputName=winpipes

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\words.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\words.h
InputName=words

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\words.h
InputName=words

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\words.h
InputName=words

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\words.h
InputName=words

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\xormac.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\xormac.h
InputName=xormac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\xormac.h
InputName=xormac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\xormac.h
InputName=xormac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\xormac.h
InputName=xormac

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\xtr.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\xtr.h
InputName=xtr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\xtr.h
InputName=xtr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\xtr.h
InputName=xtr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\xtr.h
InputName=xtr

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\xtrcrypt.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\xtrcrypt.h
InputName=xtrcrypt

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\xtrcrypt.h
InputName=xtrcrypt

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\xtrcrypt.h
InputName=xtrcrypt

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\xtrcrypt.h
InputName=xtrcrypt

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\zdeflate.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\zdeflate.h
InputName=zdeflate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\zdeflate.h
InputName=zdeflate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\zdeflate.h
InputName=zdeflate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\zdeflate.h
InputName=zdeflate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\zinflate.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\zinflate.h
InputName=zinflate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\zinflate.h
InputName=zinflate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\zinflate.h
InputName=zinflate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\zinflate.h
InputName=zinflate

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=..\cryptopp51\zlib.h

!IF  "$(CFG)" == "cryptlib_mod - Win32 Release"

# Begin Custom Build
IntDir=.\release
InputPath=..\cryptopp51\zlib.h
InputName=zlib

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 Debug"

# Begin Custom Build
IntDir=.\debug
InputPath=..\cryptopp51\zlib.h
InputName=zlib

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Release"

# Begin Custom Build
IntDir=.\FIPS_140_Release
InputPath=..\cryptopp51\zlib.h
InputName=zlib

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ELSEIF  "$(CFG)" == "cryptlib_mod - Win32 FIPS 140 Debug"

# Begin Custom Build
IntDir=.\FIPS_140_Debug
InputPath=..\cryptopp51\zlib.h
InputName=zlib

"$(IntDir)\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	copy $(InputPath) "..\SMPDist\Algs\crypto++"

# End Custom Build

!ENDIF 

# End Source File
# End Group
# Begin Group "Miscellaneous"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\cryptopp51\GNUmakefile
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\License.txt
# End Source File
# Begin Source File

SOURCE=..\cryptopp51\Readme.txt
# End Source File
# End Group
# End Target
# End Project
